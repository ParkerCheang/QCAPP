import copy
# -*- coding: utf-8 -*-
"""
MediaField QC
Version 1.2.1
Developer: Cheang Sai Pio
Internal Tool
Target: Windows 7 / Windows 10 / Windows 11

Requires:
    customtkinter
    MediaInfo.exe
    ffmpeg.exe (TFF / BFF / Progressive 自動分析與修復)
    ffprobe.exe (stream metadata / timing / repair integrity verification)

MediaInfo.exe can be placed beside the EXE or in:
    _internal\\MediaInfo.exe
"""

import json
import math
import os
import re
import subprocess
import sys
import threading
import tempfile
import time
import tkinter as tk
import tkinter.font as tkfont
import zipfile
import queue
from xml.sax.saxutils import escape as xml_escape
from datetime import datetime
from tkinter import filedialog, messagebox

import customtkinter as ctk
try:
    from PIL import Image
except Exception:
    Image = None

OPENPYXL_AVAILABLE = False



# ----------------------------------------------------------------------
# Self-contained XLSX writer (Python standard library only; no XlsxWriter/openpyxl runtime dependency)
# ----------------------------------------------------------------------

def _xlsx_xml_safe_text(value):
    """Return text that is guaranteed to be legal in XML 1.0 / XLSX.

    MediaInfo can occasionally expose control characters or lone surrogate
    code points.  Those characters are not legal XML and can make Excel show
    the "content problem" repair dialog even though the ZIP package itself
    is otherwise valid.
    """
    if value is None:
        return ""
    text = str(value)
    out = []
    for ch in text:
        cp = ord(ch)
        if cp in (0x9, 0xA, 0xD) or 0x20 <= cp <= 0xD7FF or 0xE000 <= cp <= 0xFFFD or 0x10000 <= cp <= 0x10FFFF:
            out.append(ch)
        else:
            out.append(" ")
    return "".join(out)


def _xlsx_col_letter(index):
    result = ""
    while index:
        index, rem = divmod(index - 1, 26)
        result = chr(65 + rem) + result
    return result


def _xlsx_cell(ref, value, style=0, numeric=False):
    text = _xlsx_xml_safe_text(value)
    if numeric:
        # Numeric cells must contain a real finite numeric value.
        # The report currently uses integers here, but keeping this guard
        # makes the writer safe if future counters become floats.
        try:
            number = float(text)
            if number != number or number in (float("inf"), float("-inf")):
                text = "0"
        except Exception:
            text = "0"
        return '<c r="%s" s="%s"><v>%s</v></c>' % (ref, style, xml_escape(text))
    return '<c r="%s" s="%s" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (
        ref, style, xml_escape(text)
    )


def _xlsx_row(row_num, cells, height=None):
    attrs = ' r="%s"' % row_num
    if height is not None:
        attrs += ' ht="%s" customHeight="1"' % height
    return '<row%s>%s</row>' % (attrs, "".join(cells))


def _xlsx_sheet_xml(rows, widths, freeze_row=None, autofilter_ref=None,
                    merges=None, tab_color=None):
    parts = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
    ]
    if tab_color:
        parts.append('<sheetPr><tabColor rgb="FF%s"/><pageSetUpPr fitToPage="1"/></sheetPr>' % tab_color)
    else:
        parts.append('<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>')

    max_row = max(rows.keys()) if rows else 1
    parts.append('<dimension ref="A1:%s%d"/>' % (
        _xlsx_col_letter(len(widths)), max_row
    ))

    # IMPORTANT: worksheet child elements must follow the OOXML schema order.
    # Excel is stricter than a generic XML parser; putting <cols> before
    # <sheetViews>/<sheetFormatPr>, or <mergeCells> before <autoFilter>, can
    # trigger Excel's "content problem" repair dialog.
    parts.append('<sheetViews><sheetView showGridLines="0" workbookViewId="0">')
    if freeze_row is not None:
        parts.append(
            '<pane xSplit="0" ySplit="%d" topLeftCell="A%d" activePane="bottomLeft" state="frozen"/>'
            % (freeze_row, freeze_row + 1)
        )
        parts.append(
            '<selection pane="topLeft" activeCell="A1" sqref="A1"/><selection pane="bottomLeft" activeCell="A%d" sqref="A%d"/>'
            % (freeze_row + 1, freeze_row + 1)
        )
    else:
        parts.append('<selection activeCell="A1" sqref="A1"/>')
    parts.append('</sheetView></sheetViews>')

    parts.append('<sheetFormatPr defaultRowHeight="18"/>')

    parts.append('<cols>')
    for idx, width in enumerate(widths, 1):
        parts.append(
            '<col min="%d" max="%d" width="%s" customWidth="1"/>'
            % (idx, idx, width)
        )
    parts.append('</cols>')
    parts.append('<sheetData>')
    for row_num in sorted(rows):
        parts.append(rows[row_num])
    parts.append('</sheetData>')

    # OOXML schema order: autoFilter precedes mergeCells.
    if autofilter_ref:
        parts.append('<autoFilter ref="%s"/>' % autofilter_ref)

    if merges:
        parts.append('<mergeCells count="%d">' % len(merges))
        for ref in merges:
            parts.append('<mergeCell ref="%s"/>' % ref)
        parts.append('</mergeCells>')

    parts.append(
        '<pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>'
    )
    parts.append('<pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/>')
    parts.append('</worksheet>')
    return "".join(parts)


def _write_xlsx_report(path, results, app_version):
    """Create a QC-oriented Excel report where Actual / Expected / Result are
    immediately visible, matching the TXT report one-check-per-line layout.
    Uses only the Python standard library for Win7 compatibility.
    """
    now_text = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    styles_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="1"><numFmt numFmtId="164" formatCode="0.0"/></numFmts>
  <fonts count="5">
    <font><sz val="11"/><name val="Microsoft JhengHei"/></font>
    <font><b/><sz val="16"/><color rgb="FFFFFFFF"/><name val="Microsoft JhengHei"/></font>
    <font><sz val="10"/><color rgb="FF666666"/><name val="Microsoft JhengHei"/></font>
    <font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Microsoft JhengHei"/></font>
    <font><b/><sz val="11"/><color rgb="FF9C6500"/><name val="Microsoft JhengHei"/></font>
  </fonts>
  <fills count="8">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF17365D"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF2F75B5"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFD9EAF7"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFE2F0D9"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFFC7CE"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFFEB9C"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="3">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border><left style="thin"><color rgb="FFD0D7DE"/></left><right style="thin"><color rgb="FFD0D7DE"/></right><top style="thin"><color rgb="FFD0D7DE"/></top><bottom style="thin"><color rgb="FFD0D7DE"/></bottom><diagonal/></border>
    <border><left style="medium"><color rgb="FF2F75B5"/></left><right style="medium"><color rgb="FF2F75B5"/></right><top style="medium"><color rgb="FF2F75B5"/></top><bottom style="medium"><color rgb="FF2F75B5"/></bottom><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="14">
    <xf xfId="0" numFmtId="0" fontId="0" fillId="0" borderId="0"/>
    <xf xfId="0" numFmtId="0" fontId="1" fillId="2" borderId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <xf xfId="0" numFmtId="0" fontId="2" fillId="0" borderId="0" applyAlignment="1"><alignment vertical="center"/></xf>
    <xf xfId="0" numFmtId="0" fontId="2" fillId="4" borderId="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf xfId="0" numFmtId="0" fontId="1" fillId="4" borderId="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf xfId="0" numFmtId="0" fontId="3" fillId="3" borderId="2" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf xfId="0" numFmtId="0" fontId="0" fillId="0" borderId="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
    <xf xfId="0" numFmtId="0" fontId="0" fillId="0" borderId="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
    <xf xfId="0" numFmtId="0" fontId="0" fillId="5" borderId="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf xfId="0" numFmtId="0" fontId="0" fillId="6" borderId="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf xfId="0" numFmtId="0" fontId="3" fillId="3" borderId="2" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf xfId="0" numFmtId="0" fontId="0" fillId="4" borderId="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf xfId="0" numFmtId="0" fontId="4" fillId="7" borderId="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
    <xf xfId="0" numFmtId="164" fontId="0" fillId="0" borderId="1" applyNumberFormat="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
  <dxfs count="0"/>
  <tableStyles count="0" defaultTableStyle="TableStyleMedium9" defaultPivotStyle="PivotStyleLight16"/>
</styleSheet>"""

    file_count = len(results)
    all_checks = [item for r in results for item in (r.get("checks") or [])]
    has_source_field = any("source_field" in item for item in all_checks)
    has_hdr_fields = any(("confidence" in item or "target_spec" in item) for item in all_checks)
    _sheet1_name = "場序區段" if (has_source_field and not has_hdr_fields) else "檔案摘要"
    _sheet3_name = "需留意區段" if (has_source_field and not has_hdr_fields) else "異常明細"

    def _raw_status(obj, default_pass=None):
        status = str((obj or {}).get("result") or "").upper().strip()
        if status:
            return status
        if default_pass is None:
            default_pass = bool((obj or {}).get("pass"))
        return "PASS" if default_pass else "FAIL"

    def _status_text(status):
        status = str(status or "").upper()
        return {
            "PASS": "通過",
            "WARNING": "需複核",
            "INFO": "參考資料",
            "REPAIR": "需要修復",
            "FAIL": "不符合",
            "ERROR": "不符合",
        }.get(status, status or "—")

    def _status_style(status):
        status = str(status or "").upper()
        if status == "PASS":
            return 8
        if status in ("WARNING", "REPAIR", "INFO"):
            return 12 if status in ("WARNING", "REPAIR") else 11
        return 9

    statuses = [_raw_status(r, r.get("pass")) for r in results]
    pass_files = sum(1 for x in statuses if x == "PASS")
    warning_files = sum(1 for x in statuses if x == "WARNING")
    repair_files = sum(1 for x in statuses if x == "REPAIR")
    info_files = sum(1 for x in statuses if x == "INFO")
    fail_files = sum(1 for x in statuses if x in ("FAIL", "ERROR"))

    # Sheet 1: the main report — one row per parameter, exactly so Actual and
    # Expected can be compared side by side, e.g. Actual BT.709 / Expected BT.2020.
    report_rows = {
        1: _xlsx_row(1, [_xlsx_cell("A1", "MediaField QC — 技術明細", 1)], 30),
        2: _xlsx_row(2, [_xlsx_cell("A2", "檢測時間：%s    版本：v%s" % (now_text, app_version), 2)], 20),
        3: _xlsx_row(3, [_xlsx_cell(
            "A3",
            ("此頁保留技術證據；一般用戶請先看『檔案摘要』。可依目標規格、問題及判定篩選。"
             if has_hdr_fields else ("此頁保留場序技術證據；一般用戶請先看『檔案摘要』。" if has_source_field else "每一條檢測項目均列出：實際值、預期值及判定結果")),
            2
        )], 24 if has_hdr_fields else 20),
        5: _xlsx_row(5, (
            [_xlsx_cell("A5", "檔案", 10), _xlsx_cell("B5", "檢測項目", 10),
             _xlsx_cell("C5", "目標規格", 10), _xlsx_cell("D5", "實際值", 10),
             _xlsx_cell("E5", "預期值", 10), _xlsx_cell("F5", "判定可信度", 10),
             _xlsx_cell("G5", "判定", 10)]
            if has_hdr_fields else
            ([_xlsx_cell("A5", "檔案", 10), _xlsx_cell("B5", "檢測項目", 10),
              _xlsx_cell("C5", "來源場序", 10), _xlsx_cell("D5", "實際值", 10),
              _xlsx_cell("E5", "預期值", 10), _xlsx_cell("F5", "一致度 (%)", 10),
              _xlsx_cell("G5", "判定", 10)]
             if has_source_field else
             [_xlsx_cell("A5", "檔案", 10), _xlsx_cell("B5", "檢測項目", 10),
              _xlsx_cell("C5", "實際值", 10), _xlsx_cell("D5", "預期值", 10),
              _xlsx_cell("E5", "判定", 10)])
        ), 28),
    }
    rnum = 6
    for result in results:
        filename = os.path.basename(result.get("file", ""))
        overall = _raw_status(result, result.get("pass"))
        checks = result.get("checks") or []
        if not checks:
            shown_overall = _status_text(overall)
            vals = ([filename, "（沒有可顯示的檢測項目）", "", "", "", "", shown_overall] if has_hdr_fields else
                    ([filename, "（沒有可顯示的檢測項目）", "", "", "", "", shown_overall] if has_source_field else [filename, "（沒有可顯示的檢測項目）", "", "", shown_overall]))
            styles = ([6, 12, 6, 6, 6, 6, _status_style(overall)] if has_hdr_fields else
                      ([6, 12, 6, 6, 6, 6, _status_style(overall)] if has_source_field else [6, 12, 6, 6, _status_style(overall)]))
            report_rows[rnum] = _xlsx_row(rnum, [_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, styles[c-1]) for c,v in enumerate(vals,1)], 30)
            rnum += 1
            continue
        for item in checks:
            item_result = _raw_status(item, item.get("pass"))
            shown_item_result = _status_text(item_result)
            vals = ([filename, item.get("name", ""), item.get("target_spec", ""), item.get("actual", "") or "(空)", item.get("expected", "") or "(空)", item.get("confidence", "") or "—", shown_item_result] if has_hdr_fields else
                    ([filename, item.get("name", ""), item.get("source_field", ""), item.get("actual", "") or "(空)", item.get("expected", "") or "(空)", item.get("field_confidence_percent", ""), shown_item_result] if has_source_field else [filename, item.get("name", ""), item.get("actual", "") or "(空)", item.get("expected", "") or "(空)", shown_item_result]))
            cells = []
            result_col = 7 if has_hdr_fields else (7 if has_source_field else 5)
            for c, v in enumerate(vals, 1):
                if c == result_col:
                    style = _status_style(item_result)
                    cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, style))
                elif has_source_field and c == 6 and v not in ("", None):
                    cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, 13, numeric=True))
                else:
                    style = 12 if c == 2 else (6 if rnum % 2 == 0 else 7)
                    cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, style))
            report_rows[rnum] = _xlsx_row(rnum, cells, 34)
            rnum += 1
        # Blank separator between files for readability.
        rnum += 1

    report_end = rnum - 1
    report_xml = _xlsx_sheet_xml(
        report_rows,
        ([36, 30, 22, 44, 44, 16, 12] if has_hdr_fields else ([36, 30, 16, 44, 44, 14, 12] if has_source_field else [36, 30, 44, 44, 12])),
        freeze_row=5,
        autofilter_ref=(("A5:G%d" % report_end) if has_hdr_fields else ("A5:G%d" % report_end if has_source_field else "A5:E%d" % report_end)),
        merges=(["A1:G1", "A2:G2", "A3:G3"] if has_hdr_fields else (["A1:G1", "A2:G2", "A3:G3"] if has_source_field else ["A1:E1", "A2:E2", "A3:E3"])),
        tab_color="2F75B5",
    )

    # Sheet 2: user-facing summary.
    # Field-order reports are detection-first: one row per detected segment, with a
    # real numeric consistency column so Excel can filter e.g. >= 80 directly.
    # Repair policy is deliberately not used as the final result of the detection report.
    if has_source_field and not has_hdr_fields:
        field_segment_rows = []
        for result in results:
            for item in (result.get("checks") or []):
                if item.get("field_segment"):
                    field_segment_rows.append((result, item))

        off_target_count = sum(1 for _r, x in field_segment_rows if x.get("field_relation") == "與目標不同")
        review_count = sum(1 for _r, x in field_segment_rows if x.get("field_relation") == "人工複核")
        summary_rows = {
            1: _xlsx_row(1, [_xlsx_cell("A1", "MediaField QC — 場序檢測摘要", 1)], 30),
            2: _xlsx_row(2, [_xlsx_cell(
                "A2",
                "總檔案：%d    檢測區段：%d    與目標不同：%d    人工複核：%d" %
                (file_count, len(field_segment_rows), off_target_count, review_count),
                2
            )], 20),
            3: _xlsx_row(3, [_xlsx_cell(
                "A3",
                "此頁只呈現檢測事實；『一致度 (%)』為數值欄，可直接使用 Excel 篩選器選擇 >= 60、>= 80、>= 90 等條件。修復設定不會改寫檢測結果。",
                2
            )], 30),
            5: _xlsx_row(5, [
                _xlsx_cell(_xlsx_col_letter(c)+"5", h, 10)
                for c, h in enumerate([
                    "檔案名稱", "目標場序", "檢測場序", "TC In", "TC Out",
                    "一致度 (%)", "與目標關係", "完整路徑"
                ], 1)
            ], 28),
        }
        rnum = 6
        if field_segment_rows:
            for result, item in field_segment_rows:
                vals = [
                    os.path.basename(result.get("file", "")),
                    item.get("field_target", ""),
                    item.get("field_detected", ""),
                    item.get("field_tc_in", ""),
                    item.get("field_tc_out", ""),
                    item.get("field_confidence_percent", 0.0),
                    item.get("field_relation", ""),
                    result.get("file", ""),
                ]
                cells = []
                for c, v in enumerate(vals, 1):
                    if c == 6:
                        cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, 13, numeric=True))
                    elif c == 7 and v == "與目標不同":
                        cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, 12))
                    elif c == 7 and v == "人工複核":
                        cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, 11))
                    else:
                        cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, 6 if rnum % 2 == 0 else 7))
                summary_rows[rnum] = _xlsx_row(rnum, cells, 26)
                rnum += 1
        else:
            summary_rows[6] = _xlsx_row(6, [_xlsx_cell("A6", "沒有可顯示的場序區段。", 8)], 28)
            rnum = 7

        summary_xml = _xlsx_sheet_xml(
            summary_rows, [34, 20, 22, 18, 18, 14, 18, 58], freeze_row=5,
            autofilter_ref=("A5:H%d" % max(5, rnum-1)) if field_segment_rows else None,
            merges=(["A1:H1", "A2:H2", "A3:H3"] if field_segment_rows else ["A1:H1", "A2:H2", "A3:H3", "A6:H6"]),
            tab_color="70AD47"
        )
    else:
        summary_rows = {
            1: _xlsx_row(1, [_xlsx_cell("A1", "MediaField QC — 檔案摘要", 1)], 30),
            2: _xlsx_row(2, [_xlsx_cell(
                "A2",
                "總檔案：%d    通過：%d    需複核：%d    需要修復：%d    參考資料：%d    不符合：%d" %
                (file_count, pass_files, warning_files, repair_files, info_files, fail_files),
                2
            )], 20),
            3: _xlsx_row(3, [_xlsx_cell("A3", "先看『最終結果／問題或結論』；所有問題區段會完整列出，技術參數請到『技術明細』。", 2)], 20),
            5: _xlsx_row(5, [
                _xlsx_cell(_xlsx_col_letter(c)+"5", h, 10)
                for c, h in enumerate(["檔案名稱", "最終結果", "問題或結論", "可信度", "完整路徑", "檢測時間"], 1)
            ], 28),
        }
        rnum = 6
        for result in results:
            checks = result.get("checks") or []
            overall = _raw_status(result, result.get("pass"))

            issue = result.get("summary_issue") or ""
            confidence = result.get("summary_confidence") or "—"

            if not issue:
                relevant = [x for x in checks if _raw_status(x, x.get("pass")) in ("WARNING", "FAIL", "ERROR", "REPAIR") or x.get("user_relevant")]
                if relevant:
                    if len(relevant) == 1:
                        first = relevant[0]
                        issue = str(first.get("issue_title") or first.get("name") or "發現需處理項目")
                        confidence = first.get("confidence") or confidence
                    else:
                        lines = ["共 %d 個問題／需複核項目：" % len(relevant)]
                        for idx, one in enumerate(relevant, 1):
                            title = str(one.get("issue_title") or one.get("name") or "需處理項目")
                            actual = str(one.get("actual") or "").strip()
                            if actual:
                                title += "｜" + actual
                            lines.append("%d. %s" % (idx, title))
                        issue = "\n".join(lines)
                        confidence = relevant[0].get("confidence") or confidence
                elif overall == "PASS":
                    issue = "未發現達到門檻的異常"
                elif overall == "INFO":
                    issue = "有參考資訊需人工查看"
                else:
                    issue = "發現需處理項目"

            vals = [
                os.path.basename(result.get("file", "")),
                _status_text(overall),
                issue,
                confidence,
                result.get("file", ""),
                now_text,
            ]
            cells = []
            for c, v in enumerate(vals, 1):
                if c == 2:
                    style = _status_style(overall)
                elif c == 3:
                    style = 12 if overall != "PASS" else (6 if rnum % 2 == 0 else 7)
                else:
                    style = 6 if rnum % 2 == 0 else 7
                cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, style))
            issue_lines = max(1, str(issue or "").count("\n") + 1)
            summary_rows[rnum] = _xlsx_row(rnum, cells, min(140, 30 + issue_lines * 18))
            rnum += 1
        summary_xml = _xlsx_sheet_xml(
            summary_rows, [36, 14, 82, 14, 62, 22], freeze_row=5,
            autofilter_ref="A5:F%d" % max(5, rnum-1),
            merges=["A1:F1", "A2:F2", "A3:F3"], tab_color="70AD47"
        )

    # Sheet 3: attention/detail rows.  Field-order reports remain detection-first
    # and expose consistency as a numeric column for direct threshold filtering.
    if has_source_field and not has_hdr_fields:
        attention_rows = []
        for result in results:
            for item in (result.get("checks") or []):
                if item.get("field_segment") and item.get("field_relation") in ("與目標不同", "人工複核"):
                    attention_rows.append((result, item))
        fail_rows = {
            1: _xlsx_row(1, [_xlsx_cell("A1", "MediaField QC — 需留意場序區段", 1)], 30),
            2: _xlsx_row(2, [_xlsx_cell("A2", "只列出與目標場序不同或需要人工複核的檢測區段；可直接以『一致度 (%)』數值篩選。", 2)], 22),
            4: _xlsx_row(4, [_xlsx_cell(_xlsx_col_letter(c)+"4", h, 10) for c, h in enumerate(
                ["檔案名稱", "目標場序", "檢測場序", "TC In", "TC Out", "一致度 (%)", "與目標關係", "完整路徑"], 1)], 28),
        }
        rnum = 5
        if attention_rows:
            for result, item in attention_rows:
                vals = [
                    os.path.basename(result.get("file", "")), item.get("field_target", ""),
                    item.get("field_detected", ""), item.get("field_tc_in", ""),
                    item.get("field_tc_out", ""), item.get("field_confidence_percent", 0.0),
                    item.get("field_relation", ""), result.get("file", ""),
                ]
                cells = []
                for c, v in enumerate(vals, 1):
                    if c == 6:
                        cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, 13, numeric=True))
                    elif c == 7:
                        cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, 12 if v == "與目標不同" else 11))
                    else:
                        cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, 6 if rnum % 2 == 0 else 7))
                fail_rows[rnum] = _xlsx_row(rnum, cells, 26)
                rnum += 1
            fail_xml = _xlsx_sheet_xml(
                fail_rows, [34,20,22,18,18,14,18,58], freeze_row=4,
                autofilter_ref="A4:H%d" % (rnum-1),
                merges=["A1:H1", "A2:H2"], tab_color="C00000"
            )
        else:
            fail_rows[5] = _xlsx_row(5, [_xlsx_cell("A5", "沒有與目標不同或需人工複核的場序區段。", 8)], 28)
            fail_xml = _xlsx_sheet_xml(
                fail_rows, [34,20,22,18,18,14,18,58], freeze_row=4,
                merges=["A1:H1", "A2:H2", "A5:H5"], tab_color="70AD47"
            )
    else:
        fail_rows = {
            1: _xlsx_row(1, [_xlsx_cell("A1", "MediaField QC — 異常明細", 1)], 30),
            2: _xlsx_row(2, [_xlsx_cell("A2", "只顯示需要處理、需要複核或人工確認的項目；一般參考資訊不在此重複顯示", 2)], 20),
            4: _xlsx_row(4, [_xlsx_cell(_xlsx_col_letter(c)+"4", h, 10) for c, h in enumerate(
                (["檔案名稱", "檢測項目", "目標規格", "實際值", "預期值", "判定可信度", "判定"] if has_hdr_fields else ["檔案名稱", "檢測項目", "實際值", "預期值", "判定"]), 1)], 28),
        }
        rnum = 5
        for result in results:
            for item in (result.get("checks") or []):
                detail_result = _raw_status(item, item.get("pass"))
                if detail_result in ("PASS",) or (detail_result == "INFO" and not item.get("user_relevant")):
                    continue
                shown_detail_result = _status_text(detail_result)
                vals = ([os.path.basename(result.get("file", "")), item.get("name", ""), item.get("target_spec", ""), item.get("actual", "") or "(空)", item.get("expected", "") or "(空)", item.get("confidence", "") or "—", shown_detail_result] if has_hdr_fields else [os.path.basename(result.get("file", "")), item.get("name", ""), item.get("actual", "") or "(空)", item.get("expected", "") or "(空)", shown_detail_result])
                cells = []
                result_col = 7 if has_hdr_fields else 5
                for c, v in enumerate(vals, 1):
                    style = _status_style(detail_result) if c == result_col else (12 if c == 2 else (6 if rnum % 2 == 0 else 7))
                    cells.append(_xlsx_cell(_xlsx_col_letter(c)+str(rnum), v, style))
                fail_rows[rnum] = _xlsx_row(rnum, cells, 34)
                rnum += 1
        if rnum == 5:
            fail_rows[5] = _xlsx_row(5, [_xlsx_cell("A5", "沒有需要處理或複核的項目。", 8)], 28)
            fail_xml = _xlsx_sheet_xml(fail_rows, ([36,30,22,44,44,16,12] if has_hdr_fields else [36, 30, 44, 44, 12]), freeze_row=4, merges=(["A1:G1","A2:G2","A5:G5"] if has_hdr_fields else ["A1:E1", "A2:E2", "A5:E5"]), tab_color="70AD47")
        else:
            fail_xml = _xlsx_sheet_xml(fail_rows, ([36,30,22,44,44,16,12] if has_hdr_fields else [36, 30, 44, 44, 12]), freeze_row=4, autofilter_ref=(("A4:G%d" if has_hdr_fields else "A4:E%d") % (rnum-1)), merges=(["A1:G1","A2:G2"] if has_hdr_fields else ["A1:E1", "A2:E2"]), tab_color="C00000")

    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/xl/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>
</Types>"""
    root_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""
    # Keep workbook.xml deliberately minimal.  Desktop Excel is stricter here
    # than generic OOXML readers.  Optional workbook metadata such as
    # fileVersion/workbookPr/bookViews/calcPr is not needed for these reports
    # and on some Excel builds caused the "repaired records: /xl/workbook.xml"
    # dialog.  A minimal sheets-only workbook part is valid OOXML and is also
    # the most compatible form across Win7/10/11 Office versions.
    workbook_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="%s" sheetId="1" r:id="rId1"/>
    <sheet name="技術明細" sheetId="2" r:id="rId2"/>
    <sheet name="%s" sheetId="3" r:id="rId3"/>
  </sheets>
</workbook>""" % (_sheet1_name, _sheet3_name)
    workbook_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/>
  <Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>
  <Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""
    app_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>MediaField QC</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop>
  <HeadingPairs><vt:vector size="2" baseType="variant"><vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant><vt:variant><vt:i4>3</vt:i4></vt:variant></vt:vector></HeadingPairs>
  <TitlesOfParts><vt:vector size="3" baseType="lpstr"><vt:lpstr>%s</vt:lpstr><vt:lpstr>技術明細</vt:lpstr><vt:lpstr>%s</vt:lpstr></vt:vector></TitlesOfParts>
  <Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>16.0300</AppVersion>
</Properties>"""
    app_xml = app_xml % (_sheet1_name, _sheet3_name)
    core_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:creator>MediaField QC</dc:creator><cp:lastModifiedBy>MediaField QC</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">%sZ</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">%sZ</dcterms:modified>
</cp:coreProperties>""" % (datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S"), datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S"))
    theme_xml = r"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office Theme"><a:themeElements><a:clrScheme name="Office"><a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1><a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="1F497D"/></a:dk2><a:lt2><a:srgbClr val="EEECE1"/></a:lt2><a:accent1><a:srgbClr val="4F81BD"/></a:accent1><a:accent2><a:srgbClr val="C0504D"/></a:accent2><a:accent3><a:srgbClr val="9BBB59"/></a:accent3><a:accent4><a:srgbClr val="8064A2"/></a:accent4><a:accent5><a:srgbClr val="4BACC6"/></a:accent5><a:accent6><a:srgbClr val="F79646"/></a:accent6><a:hlink><a:srgbClr val="0000FF"/></a:hlink><a:folHlink><a:srgbClr val="800080"/></a:folHlink></a:clrScheme><a:fontScheme name="Office"><a:majorFont><a:latin typeface="Cambria"/><a:ea typeface=""/><a:cs typeface=""/><a:font script="Jpan" typeface="ＭＳ Ｐゴシック"/><a:font script="Hang" typeface="맑은 고딕"/><a:font script="Hans" typeface="宋体"/><a:font script="Hant" typeface="新細明體"/><a:font script="Arab" typeface="Times New Roman"/><a:font script="Hebr" typeface="Times New Roman"/><a:font script="Thai" typeface="Tahoma"/><a:font script="Ethi" typeface="Nyala"/><a:font script="Beng" typeface="Vrinda"/><a:font script="Gujr" typeface="Shruti"/><a:font script="Khmr" typeface="MoolBoran"/><a:font script="Knda" typeface="Tunga"/><a:font script="Guru" typeface="Raavi"/><a:font script="Cans" typeface="Euphemia"/><a:font script="Cher" typeface="Plantagenet Cherokee"/><a:font script="Yiii" typeface="Microsoft Yi Baiti"/><a:font script="Tibt" typeface="Microsoft Himalaya"/><a:font script="Thaa" typeface="MV Boli"/><a:font script="Deva" typeface="Mangal"/><a:font script="Telu" typeface="Gautami"/><a:font script="Taml" typeface="Latha"/><a:font script="Syrc" typeface="Estrangelo Edessa"/><a:font script="Orya" typeface="Kalinga"/><a:font script="Mlym" typeface="Kartika"/><a:font script="Laoo" typeface="DokChampa"/><a:font script="Sinh" typeface="Iskoola Pota"/><a:font script="Mong" typeface="Mongolian Baiti"/><a:font script="Viet" typeface="Times New Roman"/><a:font script="Uigh" typeface="Microsoft Uighur"/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/><a:font script="Jpan" typeface="ＭＳ Ｐゴシック"/><a:font script="Hang" typeface="맑은 고딕"/><a:font script="Hans" typeface="宋体"/><a:font script="Hant" typeface="新細明體"/><a:font script="Arab" typeface="Arial"/><a:font script="Hebr" typeface="Arial"/><a:font script="Thai" typeface="Tahoma"/><a:font script="Ethi" typeface="Nyala"/><a:font script="Beng" typeface="Vrinda"/><a:font script="Gujr" typeface="Shruti"/><a:font script="Khmr" typeface="DaunPenh"/><a:font script="Knda" typeface="Tunga"/><a:font script="Guru" typeface="Raavi"/><a:font script="Cans" typeface="Euphemia"/><a:font script="Cher" typeface="Plantagenet Cherokee"/><a:font script="Yiii" typeface="Microsoft Yi Baiti"/><a:font script="Tibt" typeface="Microsoft Himalaya"/><a:font script="Thaa" typeface="MV Boli"/><a:font script="Deva" typeface="Mangal"/><a:font script="Telu" typeface="Gautami"/><a:font script="Taml" typeface="Latha"/><a:font script="Syrc" typeface="Estrangelo Edessa"/><a:font script="Orya" typeface="Kalinga"/><a:font script="Mlym" typeface="Kartika"/><a:font script="Laoo" typeface="DokChampa"/><a:font script="Sinh" typeface="Iskoola Pota"/><a:font script="Mong" typeface="Mongolian Baiti"/><a:font script="Viet" typeface="Arial"/><a:font script="Uigh" typeface="Microsoft Uighur"/></a:minorFont></a:fontScheme><a:fmtScheme name="Office"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="50000"/><a:satMod val="300000"/></a:schemeClr></a:gs><a:gs pos="35000"><a:schemeClr val="phClr"><a:tint val="37000"/><a:satMod val="300000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="15000"/><a:satMod val="350000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="16200000" scaled="1"/></a:gradFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:shade val="51000"/><a:satMod val="130000"/></a:schemeClr></a:gs><a:gs pos="80000"><a:schemeClr val="phClr"><a:shade val="93000"/><a:satMod val="130000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="94000"/><a:satMod val="135000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="16200000" scaled="0"/></a:gradFill></a:fillStyleLst><a:lnStyleLst><a:ln w="9525" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"><a:shade val="95000"/><a:satMod val="105000"/></a:schemeClr></a:solidFill><a:prstDash val="solid"/></a:ln><a:ln w="25400" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln><a:ln w="38100" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst><a:outerShdw blurRad="40000" dist="20000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="38000"/></a:srgbClr></a:outerShdw></a:effectLst></a:effectStyle><a:effectStyle><a:effectLst><a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw></a:effectLst></a:effectStyle><a:effectStyle><a:effectLst><a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw></a:effectLst><a:scene3d><a:camera prst="orthographicFront"><a:rot lat="0" lon="0" rev="0"/></a:camera><a:lightRig rig="threePt" dir="t"><a:rot lat="0" lon="0" rev="1200000"/></a:lightRig></a:scene3d><a:sp3d><a:bevelT w="63500" h="25400"/></a:sp3d></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="40000"/><a:satMod val="350000"/></a:schemeClr></a:gs><a:gs pos="40000"><a:schemeClr val="phClr"><a:tint val="45000"/><a:shade val="99000"/><a:satMod val="350000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="20000"/><a:satMod val="255000"/></a:schemeClr></a:gs></a:gsLst><a:path path="circle"><a:fillToRect l="50000" t="-80000" r="50000" b="180000"/></a:path></a:gradFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="80000"/><a:satMod val="300000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="30000"/><a:satMod val="200000"/></a:schemeClr></a:gs></a:gsLst><a:path path="circle"><a:fillToRect l="50000" t="50000" r="50000" b="50000"/></a:path></a:gradFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>"""


    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", root_rels)
        z.writestr("docProps/app.xml", app_xml)
        z.writestr("docProps/core.xml", core_xml)
        z.writestr("xl/workbook.xml", workbook_xml)
        z.writestr("xl/_rels/workbook.xml.rels", workbook_rels)
        z.writestr("xl/styles.xml", styles_xml)
        z.writestr("xl/theme/theme1.xml", theme_xml)
        # Keep worksheet part numbers, workbook sheetIds and display order aligned.
        # This is intentionally conventional because desktop Excel is stricter
        # than generic XLSX readers and may otherwise show a repair dialog.
        z.writestr("xl/worksheets/sheet1.xml", summary_xml)
        z.writestr("xl/worksheets/sheet2.xml", report_xml)
        z.writestr("xl/worksheets/sheet3.xml", fail_xml)


APP_NAME = "MediaField QC"
APP_VERSION = "1.2.1"
DEVELOPER = "Cheang Sai Pio"
NO_CHECK = "不檢測"

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")


# ----------------------------------------------------------------------
# Common options
# Expanded v3.4.9: common broadcast / post / delivery values
# ----------------------------------------------------------------------

OPTIONS = {
    # Container / wrapper profile.  These are values commonly exposed by
    # MediaInfo in broadcast, post-production, and delivery workflows.
    "Format Profile": [
        NO_CHECK,
        "OP-1a",
        "OP-1a (Operational Pattern 1a)",
        "OP-1b",
        "OP-Atom",
        "OP-Atom (Operational Pattern Atom)",
        "OP-2a",
        "OP-3a",
        "QuickTime",
        "JVT",
        "Base Media",
        "ISO Base Media",
        "MP4 Base Media",
        "MPEG-4",
        "Matroska",
        "WebM",
        "AVI",
        "Wave",
        "WAVE",
        "Broadcast Wave",
        "BWF",
        "AIFF",
        "MPEG-TS",
        "MPEG-PS",
        "GXF",
        "LXF",
        "MXF",
        "MXF OP-1a",
        "MXF OP-Atom",
        "3GPP Media Release 4",
        "3GPP Media Release 5",
        "3GPP Media Release 6",
        "Ogg",
    ],

    # MediaInfo Writing application is not a closed technical standard.
    # These are common brands / applications used in broadcast and post.
    "Writing Application": [
        NO_CHECK,
        "Edius",
        "Sony",
        "Panasonic",
        "Adobe",
        "Avid",
        "Apple",
        "Blackmagic Design",
        "Canon",
        "RED",
        "ARRI",
        "GoPro",
        "AJA",
        "Atomos",
        "Autodesk",
        "Assimilate",
        "SGO",
        "Quantel",
        "Telestream",
        "FFmpeg",
        "DaVinci Resolve",
        "Premiere Pro",
        "Final Cut Pro",
        "Media Composer",
        "EDIUS",
        "Compressor",
        "HandBrake",
        "Shutter Encoder",
        "VLC",
        "OBS",
        "Microsoft",
    ],

    # Video codecs / commercial families commonly encountered in TV stations,
    # production, contribution, archive, and file delivery.
    "Video Format": [
        NO_CHECK,
        "AVC",
        "AVC-Intra",
        "AVC-Intra 50",
        "AVC-Intra 100",
        "AVC-Intra 200",
        "AVC-Intra 300",
        "AVC-Intra 422",
        "AVC-LongG",
        "XAVC",
        "XAVC Intra",
        "XAVC Long GOP",
        "XDCAM",
        "XDCAM HD",
        "XDCAM HD422",
        "XDCAM EX",
        "IMX",
        "MPEG-1 Video",
        "MPEG-2",
        "MPEG-4 Visual",
        "DV",
        "DVCAM",
        "DVCPRO",
        "DVCPRO 25",
        "DVCPRO 50",
        "DVCPRO HD",
        "HEVC",
        "JPEG 2000",
        "HTJ2K",
        "ProRes",
        "ProRes RAW",
        "Canopus HQ",
        "Canopus HQX",
        "DNxHD",
        "DNxHR",
        "VC-3",
        "VC-1",
        "AV1",
        "VP8",
        "VP9",
        "Theora",
        "FFV1",
        "HuffYUV",
        "Uncompressed",
        "V210",
        "UYVY",
        "RGB",
    ],

    # MediaInfo's Video stream profile field is codec-specific. Keep H.264/HEVC/MPEG-2/VC-1/ProRes/DNx/etc. here.
    # JVT is NOT a video-stream profile in this context; it is commonly the General/Container Format Profile.
    "Video Profile": [
        NO_CHECK,
        # AVC / H.264
        "Constrained Baseline@L1.0",
        "Constrained Baseline@L1.1",
        "Constrained Baseline@L2.0",
        "Constrained Baseline@L2.1",
        "Constrained Baseline@L3.0",
        "Constrained Baseline@L3.1",
        "Baseline@L1.0",
        "Baseline@L1.1",
        "Baseline@L2.0",
        "Baseline@L2.1",
        "Baseline@L3.0",
        "Baseline@L3.1",
        "Baseline@L4.0",
        "Baseline@L4.1",
        "Baseline@L4.2",
        "Main@L2.0",
        "Main@L2.1",
        "Main@L3.0",
        "Main@L3.1",
        "Main@L3.2",
        "Main@L4.0",
        "Main@L4.1",
        "Main@L4.2",
        "Main@L5.0",
        "Main@L5.1",
        "Main@L5.2",
        "High@L2.0",
        "High@L2.1",
        "High@L3.0",
        "High@L3.1",
        "High@L3.2",
        "High@L4.0",
        "High@L4.1",
        "High@L4.2",
        "High@L5.0",
        "High@L5.1",
        "High@L5.2",
        "High 10@L4.0",
        "High 10@L4.1",
        "High 10@L4.2",
        "High 10@L5.0",
        "High 10@L5.1",
        "High 10@L5.2",
        "High 10 Intra@L4.0",
        "High 10 Intra@L4.1",
        "High 10 Intra@L4.2",
        "High 10 Intra@L5.0",
        "High 10 Intra@L5.1",
        "High 10 Intra@L5.2",
        "High 4:2:2@L4.0",
        "High 4:2:2@L4.1",
        "High 4:2:2@L4.2",
        "High 4:2:2@L5.0",
        "High 4:2:2@L5.1",
        "High 4:2:2@L5.2",
        "High 4:2:2 Intra@L4.1",
        "High 4:2:2 Intra@L4.2",
        "High 4:2:2 Intra@L5.0",
        "High 4:2:2 Intra@L5.1",
        "High 4:2:2 Intra@L5.2",
        "High 4:4:4@L4.1",
        "High 4:4:4@L4.2",
        "High 4:4:4@L5.0",
        "High 4:4:4@L5.1",
        "High 4:4:4@L5.2",
        "High 4:4:4 Predictive@L4.1",
        "High 4:4:4 Predictive@L4.2",
        "High 4:4:4 Predictive@L5.0",
        "High 4:4:4 Predictive@L5.1",
        "High 4:4:4 Predictive@L5.2",
        "High 4:4:4 Intra@L4.1",
        "High 4:4:4 Intra@L4.2",
        "High 4:4:4 Intra@L5.0",
        "High 4:4:4 Intra@L5.1",
        "High 4:4:4 Intra@L5.2",
        "CAVLC 4:4:4 Intra@L4.1",
        "CAVLC 4:4:4 Intra@L4.2",
        "CAVLC 4:4:4 Intra@L5.0",
        "CAVLC 4:4:4 Intra@L5.1",
        # HEVC / H.265
        "Main@L3",
        "Main@L3.1",
        "Main@L4",
        "Main@L4.1",
        "Main@L5",
        "Main@L5.1",
        "Main@L5.2",
        "Main 10@L4",
        "Main 10@L4.1",
        "Main 10@L5",
        "Main 10@L5.1",
        "Main 10@L5.2",
        "Main 12@L5.1",
        "Main 4:2:2 10@L5.1",
        "Main 4:2:2 10@L5.2",
        # MPEG-2
        "Main@Main",
        "Main@High",
        "Main@Low",
        "4:2:2@Main",
        "4:2:2@High",
        "Simple@Main",
        "Simple@Low",
        # VC-1
        "Simple@L1",
        "Simple@L2",
        "Simple@L3",
        "Main@L1",
        "Main@L2",
        "Main@L3",
        "Advanced@L0",
        "Advanced@L1",
        "Advanced@L2",
        "Advanced@L3",
        # JPEG 2000
        "No restrictions",
        # VP9
        "Profile 0",
        "Profile 1",
        "Profile 2",
        "Profile 3",
        # AV1
        "Main",
        "High",
        "Professional",
        # Apple ProRes
        "422 Proxy",
        "422 LT",
        "422",
        "422 HQ",
        "4444",
        "4444 XQ",
        "4444 XQ (Apple ProRes)",
        # DNx
        "LB",
        "SQ",
        "HQ",
        "HQX",
        "444",
        "HQ 10-bit",
        "HQX 10-bit",
    ],

    "Resolution": [
        NO_CHECK,
        "352x240",
        "352x288",
        "640x480",
        "704x480",
        "704x576",
        "720x480",
        "720x486",
        "720x576",
        "768x576",
        "960x540",
        "960x720",
        "1280x720",
        "1280x1080",
        "1440x1080",
        "1920x1080",
        "2048x1080",
        "2560x1440",
        "3840x2160",
        "4096x2160",
        "5120x2160",
        "7680x4320",
        "8192x4320",
    ],

    "Frame Rate": [
        NO_CHECK,
        "23.976",
        "24",
        "25",
        "29.97",
        "30",
        "47.952",
        "48",
        "50",
        "59.94",
        "60",
        "95.904",
        "96",
        "100",
        "119.88",
        "120",
        "144",
        "240",
    ],

    "Chroma": [
        NO_CHECK,
        "4:0:0",
        "4:1:0",
        "4:1:1",
        "4:2:0",
        "4:2:2",
        "4:4:0",
        "4:4:4",
        "4:4:4:4",
    ],

    "Bit Depth": [
        NO_CHECK,
        "8",
        "10",
        "12",
        "14",
        "16",
        "20",
        "24",
        "32",
        "64",
    ],

    "Scan Type": [
        NO_CHECK,
        "Progressive",
        "Interlaced",
        "MBAFF",
        "PAFF",
        "MBAFF/Interlaced",
        "PsF",
        "Progressive segmented Frame",
    ],

    "Field Order": [
        NO_CHECK,
        "Top Field First",
        "Bottom Field First",
        "Progressive",
        "Unknown",
    ],

    "Color Primaries": [
        NO_CHECK,
        "BT.601",
        "BT.709",
        "BT.2020",
        "HLG",
        "BT.470 System B/G",
        "BT.470 System M",
        "SMPTE 170M",
        "SMPTE 240M",
        "SMPTE 428",
        "DCI-P3",
        "Display P3",
        "Film",
        "Generic Film",
        "sRGB",
        "XYZ",
        "P3",
    ],

    "Audio Format": [
        NO_CHECK,
        "PCM",
        "LPCM",
        "AES3",
        "SMPTE 302M",
        "AAC",
        "HE-AAC",
        "AC-3",
        "E-AC-3",
        "AC-4",
        "Dolby E",
        "DTS",
        "DTS-HD",
        "DTS-HD Master Audio",
        "MPEG Audio",
        "MPEG-1 Audio",
        "MPEG-2 Audio",
        "MP3",
        "FLAC",
        "ALAC",
        "Opus",
        "Vorbis",
        "WMA",
        "WMA Pro",
        "AMR",
        "G.711",
    ],

    "Audio Channels": [
        NO_CHECK,
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "10",
        "12",
        "16",
        "24",
        "32",
        "64",
    ],

    "Audio Sampling": [
        NO_CHECK,
        "8000",
        "11025",
        "12000",
        "16000",
        "22050",
        "24000",
        "32000",
        "44100",
        "48000",
        "88200",
        "96000",
        "176400",
        "192000",
        "384000",
    ],

    "Audio Bit Depth": [
        NO_CHECK,
        "8",
        "16",
        "20",
        "24",
        "32",
        "64",
    ],
}

DEFAULT_PRESETS = {}

# 「自訂」是程式唯一的內建初始狀態：所有項目皆不檢測。
# 使用者自行建立/保存的預設仍會從 presets.json 載入，不受影響。
CUSTOM_PRESET = {
    name: NO_CHECK
    for name in OPTIONS
}


# ----------------------------------------------------------------------
# Paths / MediaInfo
# ----------------------------------------------------------------------

def application_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def icon_resource_path(filename):
    """Locate bundled UI icon resources safely for source and PyInstaller."""
    base = application_dir()
    candidates = [
        os.path.join(base, "icons", filename),
        os.path.join(base, "_internal", "icons", filename),
    ]

    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        candidates.extend([
            os.path.join(meipass, "icons", filename),
            os.path.join(meipass, "_internal", "icons", filename),
        ])

    try:
        candidates.append(
            os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "icons",
                filename,
            )
        )
    except Exception:
        pass

    for path in candidates:
        if os.path.isfile(path):
            return path
    return None


def get_mediainfo_path():
    base = application_dir()

    candidates = [
        os.path.join(base, "_internal", "MediaInfo.exe"),
        os.path.join(base, "MediaInfo.exe"),
        os.path.join(base, "_internal", "MediaInfo"),
        os.path.join(base, "MediaInfo"),
    ]

    for path in candidates:
        if os.path.isfile(path):
            return path

    return None


def get_ffmpeg_path():
    """Locate the bundled FFmpeg executable used by field-order analysis/repair."""
    base = application_dir()
    candidates = [
        os.path.join(base, "_internal", "ffmpeg.exe"),
        os.path.join(base, "ffmpeg.exe"),
        os.path.join(base, "_internal", "ffmpeg"),
        os.path.join(base, "ffmpeg"),
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    return None


def get_ffprobe_path():
    base = application_dir()
    candidates = [
        os.path.join(base, "_internal", "ffprobe.exe"),
        os.path.join(base, "ffprobe.exe"),
        os.path.join(base, "_internal", "ffprobe"),
        os.path.join(base, "ffprobe"),
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    return None


# ----------------------------------------------------------------------
# User preset storage
# ----------------------------------------------------------------------

def get_user_data_dir():
    """Return a writable per-user data directory. Windows 7+ compatible."""

    root = os.environ.get("APPDATA") or application_dir()

    folder = os.path.join(
        root,
        APP_NAME.replace(" ", "_")
    )

    try:
        if not os.path.isdir(folder):
            os.makedirs(folder)
    except Exception:
        folder = application_dir()

    return folder


USER_PRESET_FILE = "presets.json"


def get_user_preset_path():
    return os.path.join(
        get_user_data_dir(),
        USER_PRESET_FILE
    )


def load_user_presets():
    path = get_user_preset_path()

    if not os.path.isfile(path):
        return {}

    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)

        if not isinstance(data, dict):
            return {}

        result = {}

        for preset_name, preset in data.items():

            if not isinstance(preset_name, str):
                continue

            if not preset_name.strip():
                continue

            if not isinstance(preset, dict):
                continue

            cleaned = {}

            for name in OPTIONS:
                value = preset.get(name, NO_CHECK)

                if value not in OPTIONS[name]:
                    value = NO_CHECK

                cleaned[name] = value

            result[preset_name.strip()] = cleaned

        return result

    except Exception:
        return {}


def save_user_presets(presets):
    path = get_user_preset_path()

    with open(path, "w", encoding="utf-8") as handle:
        json.dump(
            presets,
            handle,
            ensure_ascii=False,
            indent=2
        )

    return path


# ----------------------------------------------------------------------
# Normalization / matching
# ----------------------------------------------------------------------

def clean_text(value):
    if value is None:
        return ""

    return " ".join(
        str(value).strip().split()
    )


def normalize_resolution(width, height):

    w = re.sub(
        r"[^\d]",
        "",
        clean_text(width)
    )

    h = re.sub(
        r"[^\d]",
        "",
        clean_text(height)
    )

    if w and h:
        return "%sx%s" % (w, h)

    return ""


def normalize_fps(value):

    text = clean_text(value).replace(",", ".")

    if not text:
        return None

    match = re.search(
        r"\d+(?:\.\d+)?",
        text
    )

    if not match:
        return None

    try:
        return float(match.group(0))
    except Exception:
        return None


def fps_equal(actual, expected):

    a = normalize_fps(actual)
    b = normalize_fps(expected)

    if a is None or b is None:
        return False

    return abs(a - b) <= 0.02


def digits(value):

    return re.sub(
        r"[^\d]",
        "",
        clean_text(value)
    )


def normalize_chroma(value):

    text = (
        clean_text(value)
        .lower()
        .replace(" ", "")
    )

    # Keep the complete subsampling family MediaInfo may report.
    for value in ("4:4:4:4", "4:4:4", "4:4:0", "4:2:2", "4:2:0", "4:1:1", "4:1:0", "4:0:0"):
        if value in text:
            return value

    return clean_text(value)


def normalize_color(value):

    text = clean_text(value).lower()

    aliases = [
        ("bt.2020", "BT.2020"),
        ("bt2020", "BT.2020"),
        ("hlg", "HLG"),
        ("hybrid log-gamma", "HLG"),
        ("hybrid log gamma", "HLG"),
        ("arib std-b67", "HLG"),
        ("arib std b67", "HLG"),
        ("bt.709", "BT.709"),
        ("bt709", "BT.709"),
        ("bt.601", "BT.601"),
        ("bt601", "BT.601"),
        ("bt.470 system b/g", "BT.470 System B/G"),
        ("bt.470 system m", "BT.470 System M"),
        ("smpte 170m", "SMPTE 170M"),
        ("smpte 240m", "SMPTE 240M"),
        ("smpte 428", "SMPTE 428"),
        ("display p3", "Display P3"),
        ("p3", "DCI-P3"),
        ("generic film", "Generic Film"),
        ("film", "Film"),
    ]

    for needle, result in aliases:

        if needle in text:
            return result

    return clean_text(value)


def normalize_field_order(value):

    text = clean_text(value).lower()

    if not text:
        return ""

    if (
        "top field first" in text
        or text in ("tff", "top")
    ):
        return "Top Field First"

    if (
        "bottom field first" in text
        or text in ("bff", "bottom")
    ):
        return "Bottom Field First"

    if (
        "progressive" in text
        or text in ("prog", "p")
    ):
        return "Progressive"

    return clean_text(value)


def normalize_repair_target(value):
    value = normalize_field_order(value)
    if value in ("Top Field First", "Bottom Field First", "Progressive"):
        return value
    return "Top Field First"


def normalize_video_profile(value):
    """Normalize MediaInfo video-profile spelling without changing the profile family.

    MediaInfo may report AVC/H.264 levels as either ``High@L4`` or
    ``High@L4.0`` depending on the file/MediaInfo version.  These are the
    same H.264 level; the trailing ``.0`` is presentation formatting, not a
    different profile.  Other levels such as L4.1/L4.2 remain distinct.
    """
    text = clean_text(value)
    text = re.sub(r"\s+", " ", text)

    # Normalize the common H.264/HEVC level spelling: L4.0 == L4.
    text = re.sub(r"@L(\d+)\.0\b", r"@L\1", text, flags=re.IGNORECASE)

    return text.casefold()


def normalize_format_profile(value):
    """Normalize container/general Format Profile aliases safely.

    The UI contains a few human-readable aliases (for example
    ``OP-1a (Operational Pattern 1a)``) while MediaInfo normally reports
    the short canonical value (``OP-1a``).  Parenthetical explanations are
    therefore presentation text and must not cause a false FAIL.
    """
    text = clean_text(value)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s*\([^)]*\)\s*$", "", text)
    return text.casefold()


def normalize_codec(value):

    text = clean_text(value).lower()

    if (
        "hevc" in text
        or "h.265" in text
        or "h265" in text
    ):
        return "HEVC"

    # MediaInfo 對 AVC-Intra 會以 Commercial name 區分 50 / 100。
    # 保留正確的標準名稱，避免把 AVC-Intra 100 簡化成一般 AVC Intra。
    # AVC-Intra family.  MediaInfo may expose these via either Format or
    # Commercial name, so keep the exact class instead of collapsing to AVC.
    if re.search(r"avc[- _]?intra\s*[- ]?300\b", text):
        return "AVC-Intra 300"

    if re.search(r"avc[- _]?intra\s*[- ]?200\b", text):
        return "AVC-Intra 200"

    if re.search(r"avc[- _]?intra\s*[- ]?422\b", text):
        return "AVC-Intra 422"

    if re.search(r"avc[- _]?intra\s*[- ]?100\b", text):
        return "AVC-Intra 100"

    if re.search(r"avc[- _]?intra\s*[- ]?50\b", text):
        return "AVC-Intra 50"

    if re.search(r"avc[- _]?intra\b", text):
        return "AVC-Intra"

    if "avc-longg" in text or "avc longg" in text or "avc-long-g" in text:
        return "AVC-LongG"

    # DVCPRO family is commonly stored in MXF/P2.  MediaInfo may report
    # the family through Format, Commercial name, or codec identifiers.
    if re.search(r"dvcpro\s*[- ]?hd\b", text):
        return "DVCPRO HD"

    if re.search(r"dvcpro\s*[- ]?50\b", text):
        return "DVCPRO 50"

    if re.search(r"dvcpro\s*[- ]?25\b", text):
        return "DVCPRO 25"

    if re.search(r"dvcpro\b", text):
        return "DVCPRO"

    # Sony XAVC / XDCAM and MPEG-2 commercial families.  MediaInfo may
    # expose the family in Format, Commercial name, or Codec ID, so the
    # matcher receives the combined field text.
    if re.search(r"xavc\s*[- ]?intra", text):
        return "XAVC Intra"

    if re.search(r"xavc.*long\s*[- ]?gop|xavc[- ]?l", text):
        return "XAVC Long GOP"

    if "xavc" in text:
        return "XAVC"

    if re.search(r"xdcam.*hd422|mpeg.*hd422", text):
        return "XDCAM HD422"

    if re.search(r"xdcam.*hd", text):
        return "XDCAM HD"

    if re.search(r"xdcam.*ex", text):
        return "XDCAM EX"

    if "xdcam" in text:
        return "XDCAM"

    if re.search(r"\bimx\s*[- ]?(?:30|40|50)\b", text):
        return "IMX"

    if "imx" in text:
        return "IMX"

    if re.search(r"\bdvcam\b", text):
        return "DVCAM"

    if re.search(r"\bdv\b", text) and "dvcpro" not in text:
        return "DV"

    if "htj2k" in text or "jpeg 2000 part 15" in text:
        return "HTJ2K"

    if "av1" in text:
        return "AV1"

    if "vp9" in text:
        return "VP9"

    if "vp8" in text:
        return "VP8"

    if "vc-1" in text or "vc1" in text:
        return "VC-1"

    if "ffv1" in text:
        return "FFV1"

    if "huffyuv" in text or "huff yuv" in text:
        return "HuffYUV"

    if "v210" in text:
        return "V210"

    if "uyvy" in text:
        return "UYVY"

    if "uncompressed" in text or "raw video" in text:
        return "Uncompressed"

    if (
        "avc" in text
        or "h.264" in text
        or "h264" in text
    ):
        return "AVC"

    if "mpeg-1 video" in text:
        return "MPEG-1 Video"

    if "mpeg-4 visual" in text or "mpeg-4 part 2" in text:
        return "MPEG-4 Visual"

    if (
        "mpeg-2" in text
        or "mpeg video" in text
    ):
        return "MPEG-2"

    if (
        "jpeg 2000" in text
        or "jpeg2000" in text
    ):
        return "JPEG 2000"

    # Grass Valley / Canopus codecs commonly found in MOV / QuickTime.
    # Match HQX before HQ so "Canopus HQX" is never shortened to "Canopus HQ".
    if re.search(r"canopus\s+hqx\b", text):
        return "Canopus HQX"

    if re.search(r"canopus\s+hq\b", text):
        return "Canopus HQ"

    if "prores raw" in text or "proresraw" in text:
        return "ProRes RAW"

    if "prores" in text:
        return "ProRes"

    if "dnxhd" in text:
        return "DNxHD"

    if "dnxhr" in text:
        return "DNxHR"

    return clean_text(value)


def normalize_audio_format(value):

    text = clean_text(value).lower()

    # Specific families must be tested before their generic parent strings.
    if "smpte 302m" in text:
        return "SMPTE 302M"

    if "aes3" in text or "aes-3" in text:
        return "AES3"

    if "dolby e" in text:
        return "Dolby E"

    if "dts-hd master audio" in text or "dts-hd ma" in text:
        return "DTS-HD Master Audio"

    if "dts-hd" in text:
        return "DTS-HD"

    if "dts" in text:
        return "DTS"

    if "ac-4" in text or "ac4" in text:
        return "AC-4"

    if "e-ac-3" in text or "eac3" in text:
        return "E-AC-3"

    if "ac-3" in text or "ac3" in text:
        return "AC-3"

    if "he-aac" in text or "heaac" in text:
        return "HE-AAC"

    if "lpcm" in text or "pcm" in text:
        return "PCM"

    if "aac" in text:
        return "AAC"

    if "mpeg audio" in text or "mpeg-1 audio" in text or "mpeg-2 audio" in text:
        return "MPEG Audio"

    if "mp3" in text:
        return "MP3"

    if "flac" in text:
        return "FLAC"

    if "alac" in text:
        return "ALAC"

    if "opus" in text:
        return "Opus"

    if "vorbis" in text:
        return "Vorbis"

    if "wma pro" in text:
        return "WMA Pro"

    if "wma" in text:
        return "WMA"

    if "amr" in text:
        return "AMR"

    if "g.711" in text or "g711" in text or "pcm mu-law" in text or "pcm a-law" in text:
        return "G.711"

    return clean_text(value)


# ----------------------------------------------------------------------
# Scrollable combo box
# ----------------------------------------------------------------------

class ScrollableCTkComboBox(ctk.CTkComboBox):
    """CTkComboBox with a real, draggable vertical scrollbar in its popup.

    CustomTkinter's standard combo popup is intentionally compact and does not
    expose a scrollbar.  QC parameter lists can be 100+ items long, so a
    dedicated Tk popup is used here to keep selection fast and predictable.
    """

    POPUP_MAX_HEIGHT = 430
    ROW_HEIGHT = 38

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._scroll_popup = None
        self._scroll_listbox = None
        self._scroll_global_bind_id = None

    def _combo_values(self):
        values = getattr(self, "_values", None)
        if values is None:
            values = getattr(self, "values", None)
        return list(values or [])

    def _close_scroll_dropdown(self, event=None):
        popup = self._scroll_popup
        if popup is not None:
            try:
                if popup.winfo_exists():
                    popup.grab_release()
                    popup.destroy()
            except Exception:
                pass
        self._scroll_popup = None
        self._scroll_listbox = None

        root = self.winfo_toplevel()
        if self._scroll_global_bind_id is not None:
            try:
                root.unbind_class("all", "<Button-1>", self._scroll_global_bind_id)
            except Exception:
                pass
            self._scroll_global_bind_id = None

    def _select_scroll_value(self, event=None):
        listbox = self._scroll_listbox
        if listbox is None:
            return
        try:
            selection = listbox.curselection()
            if not selection:
                return
            value = listbox.get(selection[0])
            self.set(value)
            command = getattr(self, "_command", None)
            if command is None:
                command = getattr(self, "command", None)
            # CTkComboBox.set() already invokes the callback in some versions
            # only through the dropdown callback, so call it explicitly only
            # when the current implementation does not do so.
            # The guard below avoids double-callbacks on versions where set()
            # invokes the command itself.
            if command is not None:
                # Current CustomTkinter 5.x set() does not invoke _command;
                # the standard dropdown does so separately.
                command(value)
        finally:
            self._close_scroll_dropdown()

    def _popup_global_click(self, event):
        popup = self._scroll_popup
        if popup is None:
            return
        try:
            if not popup.winfo_exists():
                return
            x1 = popup.winfo_rootx()
            y1 = popup.winfo_rooty()
            x2 = x1 + popup.winfo_width()
            y2 = y1 + popup.winfo_height()
            cx1 = self.winfo_rootx()
            cy1 = self.winfo_rooty()
            cx2 = cx1 + self.winfo_width()
            cy2 = cy1 + self.winfo_height()
            inside_popup = x1 <= event.x_root <= x2 and y1 <= event.y_root <= y2
            inside_combo = cx1 <= event.x_root <= cx2 and cy1 <= event.y_root <= cy2
            if not inside_popup and not inside_combo:
                self._close_scroll_dropdown()
        except Exception:
            self._close_scroll_dropdown()

    def _open_dropdown_menu(self):
        if self._scroll_popup is not None:
            self._close_scroll_dropdown()
            return

        values = self._combo_values()
        if not values:
            return

        # Resolve colors from CustomTkinter when possible; fall back to the
        # application's dark theme so this remains compatible across versions.
        def _color(attr, fallback):
            try:
                value = getattr(self, attr)
                if isinstance(value, (tuple, list)):
                    mode = getattr(self, "_appearance_mode", 1)
                    value = value[mode] if len(value) > mode else value[-1]
                if isinstance(value, str):
                    return value
            except Exception:
                pass
            return fallback

        bg = _color("_dropdown_fg_color", "#2b2b2b")
        fg = _color("_text_color", "#f2f2f2")
        hover = "#1f6aa5"

        popup = tk.Toplevel(self.winfo_toplevel())
        popup.overrideredirect(True)
        popup.configure(bg="#202020")
        popup.attributes("-topmost", True)

        self._scroll_popup = popup

        outer = tk.Frame(
            popup,
            bg="#202020",
            bd=1,
            relief="solid",
        )
        outer.pack(fill="both", expand=True)

        frame = tk.Frame(
            outer,
            bg=bg,
        )
        frame.pack(fill="both", expand=True, padx=1, pady=1)

        row_height = self.ROW_HEIGHT
        visible_rows = min(max(len(values), 1), 12)
        height = min(
            self.POPUP_MAX_HEIGHT,
            max(42, visible_rows * row_height + 8),
        )
        width = max(self.winfo_width(), 400)

        scrollbar = tk.Scrollbar(
            frame,
            orient="vertical",
            width=16,
            command=lambda *args: listbox.yview(*args),
            bg="#3a3a3a",
            troughcolor="#1d1d1d",
            activebackground="#5b9bd5",
            relief="flat",
            bd=0,
            highlightthickness=0,
        )

        listbox = tk.Listbox(
            frame,
            activestyle="none",
            bg=bg,
            fg=fg,
            selectbackground=hover,
            selectforeground="#ffffff",
            highlightthickness=0,
            relief="flat",
            bd=0,
            font=("Segoe UI", 16),
            exportselection=False,
            yscrollcommand=scrollbar.set,
        )

        self._scroll_listbox = listbox

        listbox.pack(side="left", fill="both", expand=True, padx=(6, 0), pady=4)
        scrollbar.pack(side="right", fill="y", padx=(2, 4), pady=4)

        for value in values:
            listbox.insert("end", str(value))

        current = self.get()
        if current in values:
            index = values.index(current)
            listbox.selection_set(index)
            listbox.see(index)

        listbox.bind("<ButtonRelease-1>", self._select_scroll_value, add="+")
        listbox.bind("<Return>", self._select_scroll_value, add="+")
        popup.bind("<Escape>", self._close_scroll_dropdown, add="+")
        popup.bind("<MouseWheel>", lambda e: listbox.yview_scroll(-int(e.delta / 120), "units"), add="+")
        popup.bind("<Button-4>", lambda e: listbox.yview_scroll(-3, "units"), add="+")
        popup.bind("<Button-5>", lambda e: listbox.yview_scroll(3, "units"), add="+")

        x = self.winfo_rootx()
        y = self.winfo_rooty() + self.winfo_height()
        screen_h = popup.winfo_screenheight()
        if y + height > screen_h - 8:
            y = max(8, self.winfo_rooty() - height)

        popup.geometry("%dx%d+%d+%d" % (width, height, x, y))
        popup.update_idletasks()
        popup.lift()
        popup.focus_force()

        root = self.winfo_toplevel()
        self._scroll_global_bind_id = root.bind_class(
            "all",
            "<Button-1>",
            self._popup_global_click,
            add="+",
        )


# ----------------------------------------------------------------------
# Application
# ----------------------------------------------------------------------

class QCCheckerApp(ctk.CTk):

    def __init__(self):

        super().__init__()

        self.title(
            "%s v%s"
            % (
                APP_NAME,
                APP_VERSION
            )
        )

        self.geometry("1760x980")
        self.minsize(1500, 860)

        # Start maximized on Windows 7 / 10 / 11.  Keep the normal title bar
        # and taskbar behaviour; this is safer than borderless -fullscreen.
        self.after(0, self._maximize_main_window)

        # Custom dropdown is a separate Tk Toplevel.  When the main window
        # is minimized, Windows does not automatically minimize/destroy that
        # borderless popup, so explicitly close it on <Unmap>.
        self.bind("<Unmap>", self._on_main_window_unmap, add="+")
        self.bind("<Configure>", self._on_main_window_unmap, add="+")

        self.selected_files = []
        self.failed = []
        self.results = []
        self.running = False
        self.stop_requested = False
        self._current_process = None
        self._process_lock = threading.Lock()
        self._preset_manager_win = None
        self._ui_icon_cache = {}

        # Field-order auto repair settings.  These are deliberately kept
        # outside the QC rule list because repair is an action, not a QC rule.
        self.repair_enabled = tk.BooleanVar(value=True)
        self.repair_target = tk.StringVar(value="Top Field First")
        # 分析與修復決策分離：
        # - 分析階段保留 TFF / BFF / Progressive 的實際區段與一致度。
        # - 分析完成後，使用者再決定各類型是否修復，以及各自修復一致度。
        self.repair_tff = tk.BooleanVar(value=True)
        self.repair_bff = tk.BooleanVar(value=True)
        self.repair_progressive = tk.BooleanVar(value=True)
        self.repair_min_seconds = tk.StringVar(value="1.00")
        # 分析前仍保留這個百分比，作為「分析完成後修復門檻」的預設值；
        # 它不再把較低一致度區段從分析資料中刪掉。
        self.repair_confidence = tk.StringVar(value="90")
        self.repair_tff_confidence = tk.StringVar(value="90")
        self.repair_bff_confidence = tk.StringVar(value="90")
        self.repair_progressive_confidence = tk.StringVar(value="90")
        # Progressive -> 25i 修復品質模式。預設保留目前已驗證的快速路徑；
        # 高品質模式只切換 temporal interpolation，本身不改進度條、輸出規格或驗證流程。
        self.repair_progressive_method = tk.StringVar(value="快速時間重取樣（建議）")
        self.repair_output_dir = tk.StringVar(value="")
        self.repair_keep_original = tk.BooleanVar(value=True)
        self.repair_verify = tk.BooleanVar(value=True)
        self.repair_results = []
        self.repair_analysis_results = []
        self._repair_analysis_win = None
        self._repair_analysis_text = None
        self._repair_analysis_progress = None
        self._repair_analysis_progress_label = None
        self._repair_analysis_progress_detail_label = None
        self._repair_analysis_button = None
        self._repair_tff_checkbox = None
        self._repair_bff_checkbox = None
        self._repair_progressive_checkbox = None
        self._repair_tff_confidence_entry = None
        self._repair_bff_confidence_entry = None
        self._repair_progressive_confidence_entry = None
        self._repair_progressive_method_menu = None
        self._repair_progressive_choice_label = None
        self._analysis_progress_queue = queue.Queue()
        self._analysis_progress_polling = False
        # 場序分析進度：底層只提供「最新真實進度目標」，UI 再平滑追趕。
        # 這樣即使 FFmpeg/idet 很快產生大量更新，也不會因 queue 積壓而看成 0% -> 100%。
        self._analysis_progress_target = 0.0
        self._analysis_progress_display = 0.0
        self._analysis_progress_detail = ""
        self._analysis_progress_done = False
        # 場序進度啟動帶：保留 0-3% 給 ffprobe / 開檔 / decoder-filter 初始化。
        # UI 會由 0.x% 緩慢向前，不再長時間停在 0%，但真正分析完成前仍不會假到 100%。
        self._analysis_progress_started_at = 0.0
        self._analysis_real_progress_seen = False
        self._repair_export_win = None
        self._repair_export_progress = None
        self._repair_export_percent = None
        self._repair_export_time = None
        self._repair_export_speed = None
        self._repair_export_eta = None
        self._repair_export_file = None
        self._repair_export_stop_button = None
        self._repair_verify_win = None
        self._repair_verify_progress = None
        self._repair_verify_percent = None
        self._repair_verify_indeterminate = False
        self._repair_verify_progress_target = 0.0
        self._repair_verify_progress_display = 0.0
        self._repair_verify_progress_polling = False
        self._repair_verify_stage = None
        self._repair_verify_range = None
        self._repair_verify_detail = None
        self._repair_verify_stop_button = None
        # 場序專用 ffprobe 快取：分析→修復→驗證共用同一份 timing / field metadata。
        # 只服務場序模組，不改 INFO / HDR 的 probe 路徑。
        self._field_probe_cache = {}
        # Full decoded-frame counts are expensive, so cache them separately and
        # only request them during final repair validation / Smart Repair checks.
        self._field_frame_count_cache = {}
        self._field_packet_count_cache = {}

        # HDR / 色域內容一致性分析（完全獨立於場序模組）
        self._hdr_win = None
        self._hdr_progress = None
        self._hdr_progress_label = None
        self._hdr_result_text = None
        self._hdr_start_button = None
        self._hdr_stop_button = None
        self._hdr_results = []
        self._hdr_txt_button = None
        self._hdr_excel_button = None
        # HDR progress display smoothing.  The real analysis progress remains the
        # source of truth; the UI only catches up to that target in <=1% steps.
        self._hdr_progress_target = 0.0
        self._hdr_progress_display = 0.0
        self._hdr_progress_stage_text = "分析進度"
        self._hdr_progress_timer = None
        self._hdr_progress_final_label = None
        # SDR / HDR / 色域目標規格。自動模式依原影片 Metadata / Bitstream 標示
        # 選擇檢測基準；實際畫面內容只用來驗證該標示是否成立，絕不反向改寫目標。
        # 手動模式則把用戶指定規格視為交付規格。
        self.hdr_target_spec = tk.StringVar(value="自動判斷")
        # User-visible minimum duration for HDR/SDR/gamut picture-content issues.
        # Shorter detections remain internal evidence so flashes/transitions do not
        # become reportable content warnings. Metadata compliance is unaffected.
        self.hdr_min_issue_seconds = tk.StringVar(value="1.00")
        self._hdr_target_menu = None

        self.combos = {}
        self.rule_enabled = {}

        self.status_var = tk.StringVar(
            value="就緒"
        )

        self.file_var = tk.StringVar(
            value="尚未選擇檔案"
        )

        self.preset_var = tk.StringVar(
            value="自訂"
        )

        self.user_presets = load_user_presets()

        self.specs_collapsed = False
        self.left_panel_width = 560

        self._build_ui()
        self._refresh_summary()

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------

    def _maximize_main_window(self):
        """Maximize safely on Windows; fall back to the existing geometry."""
        try:
            self.state("zoomed")
        except Exception:
            try:
                self.attributes("-zoomed", True)
            except Exception:
                pass


    def _ui_icon(self, name, size=(20, 20)):
        """Load a PNG as CTkImage; missing/corrupt icons fall back safely."""
        key = (name, tuple(size))
        if key in self._ui_icon_cache:
            return self._ui_icon_cache[key]

        if Image is None:
            self._ui_icon_cache[key] = None
            return None

        path = icon_resource_path(name + ".png")
        if not path:
            self._ui_icon_cache[key] = None
            return None

        try:
            pil = Image.open(path).convert("RGBA")
            image = ctk.CTkImage(
                light_image=pil,
                dark_image=pil,
                size=tuple(size),
            )
            self._ui_icon_cache[key] = image
            return image
        except Exception:
            self._ui_icon_cache[key] = None
            return None

    def _icon_text(self, icon_name, plain_text, fallback_symbol=""):
        """Use plain text with PNG; preserve old symbol if icon is unavailable."""
        if self._ui_icon(icon_name, (20, 20)) is not None:
            return plain_text
        return (fallback_symbol + " " + plain_text).strip()


    def _build_ui(self):

        self.grid_columnconfigure(
            0,
            weight=0,
            minsize=560
        )

        self.grid_columnconfigure(
            1,
            weight=0,
            minsize=10
        )

        self.grid_columnconfigure(
            2,
            weight=1,
            minsize=720
        )

        self.grid_rowconfigure(
            0,
            weight=1
        )

        self.grid_rowconfigure(
            1,
            weight=0
        )

        # --------------------------------------------------------------
        # Left parameter panel
        # --------------------------------------------------------------

        self.left = ctk.CTkFrame(
            self,
            corner_radius=12,
            width=560
        )

        self.left.grid(
            row=0,
            column=0,
            padx=(12, 2),
            pady=12,
            sticky="nsew"
        )

        self.left.grid_propagate(False)

        self.left.grid_columnconfigure(
            0,
            weight=1
        )

        self.left.grid_rowconfigure(
            2,
            weight=1
        )

        left_header = ctk.CTkFrame(
            self.left,
            fg_color="transparent"
        )

        left_header.grid(
            row=0,
            column=0,
            padx=14,
            pady=(14, 4),
            sticky="ew"
        )

        left_header.grid_columnconfigure(
            0,
            weight=1
        )

        ctk.CTkLabel(
            left_header,
            text=self._icon_text("gear", "檢測規格", "⚙"),
            image=self._ui_icon("gear", (26, 26)),
            compound="left",
            font=ctk.CTkFont(
                size=23,
                weight="bold"
            ),
        ).grid(
            row=0,
            column=0,
            sticky="w"
        )

        self.collapse_specs_button = ctk.CTkButton(
            left_header,
            text=self._icon_text("chevron_up", "收起規格", "⌃"),
            image=self._ui_icon("chevron_up", (22, 22)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            width=110,
            height=32,
            command=self._toggle_specs_panel,
        )

        self.collapse_specs_button.grid(
            row=0,
            column=1,
            padx=(8, 2),
            sticky="e"
        )

        ctk.CTkLabel(
            self.left,
            text="初始為自訂／全部不檢測；勾選項目後，再於右側選擇標準",
            text_color=("gray50", "gray70"),
            font=ctk.CTkFont(size=13),
        ).grid(
            row=1,
            column=0,
            padx=18,
            pady=(0, 10),
            sticky="w"
        )

        self.rules_frame = ctk.CTkScrollableFrame(
            self.left
        )

        self.rules_frame.grid(
            row=2,
            column=0,
            padx=10,
            pady=5,
            sticky="nsew"
        )

        self.rules_frame.grid_columnconfigure(
            0,
            weight=1
        )

        for row, name in enumerate(OPTIONS):
            self._add_rule_row(
                row,
                name
            )

        # --------------------------------------------------------------
        # Preset buttons
        # --------------------------------------------------------------

        preset_frame = ctk.CTkFrame(
            self.left
        )

        preset_frame.grid(
            row=3,
            column=0,
            padx=12,
            pady=10,
            sticky="ew"
        )

        preset_frame.grid_columnconfigure(
            0,
            weight=1
        )

        preset_frame.grid_columnconfigure(
            1,
            weight=1
        )

        ctk.CTkLabel(
            preset_frame,
            text="快速套用預設",
            font=ctk.CTkFont(
                size=14,
                weight="bold"
            ),
        ).grid(
            row=0,
            column=0,
            columnspan=2,
            padx=10,
            pady=(8, 2),
            sticky="w"
        )

        self.preset_combo = ScrollableCTkComboBox(
            preset_frame,
            values=self._preset_names(),
            variable=self.preset_var,
            command=self._apply_preset,
            state="readonly",
            height=38,
            font=ctk.CTkFont(size=13),
        )

        self.preset_combo.grid(
            row=1,
            column=0,
            padx=(10, 5),
            pady=(2, 8),
            sticky="ew"
        )

        ctk.CTkButton(
            preset_frame,
            text=self._icon_text("gear", "管理預設", "⚙"),
            image=self._ui_icon("gear", (22, 22)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=38,
            command=self.manage_presets,
        ).grid(
            row=1,
            column=1,
            padx=(5, 10),
            pady=(2, 8),
            sticky="ew"
        )

        # --------------------------------------------------------------
        # Splitter
        # --------------------------------------------------------------

        self._splitter = tk.Frame(
            self,
            width=10,
            cursor="sb_h_double_arrow",
            bg="#4a4a4a",
            highlightthickness=0,
            bd=0,
        )

        self._splitter.grid(
            row=0,
            column=1,
            padx=0,
            pady=12,
            sticky="ns"
        )

        self._splitter.bind(
            "<Button-1>",
            self._start_splitter_drag
        )

        self._splitter.bind(
            "<B1-Motion>",
            self._drag_splitter
        )

        self._splitter.bind(
            "<ButtonRelease-1>",
            self._end_splitter_drag
        )

        self._splitter.bind(
            "<Double-Button-1>",
            self._reset_splitter
        )

        # --------------------------------------------------------------
        # Right result panel
        # --------------------------------------------------------------

        self.right = ctk.CTkFrame(
            self,
            corner_radius=12
        )

        self.right.grid(
            row=0,
            column=2,
            padx=(2, 12),
            pady=12,
            sticky="nsew"
        )

        self.right.grid_columnconfigure(
            0,
            weight=1
        )

        self.right.grid_rowconfigure(
            3,
            weight=1
        )

        header = ctk.CTkFrame(
            self.right,
            fg_color="transparent"
        )

        header.grid(
            row=0,
            column=0,
            padx=18,
            pady=(18, 5),
            sticky="ew"
        )

        header.grid_columnconfigure(
            0,
            weight=1
        )

        ctk.CTkLabel(
            header,
            text=APP_NAME,
            font=ctk.CTkFont(
                size=26,
                weight="bold"
            ),
        ).grid(
            row=0,
            column=0,
            sticky="w"
        )

        ctk.CTkLabel(
            header,
            text="可配置 Video / Media QC",
            text_color=("gray50", "gray70"),
            font=ctk.CTkFont(size=13),
        ).grid(
            row=1,
            column=0,
            sticky="w"
        )

        self.expand_specs_button = ctk.CTkButton(
            header,
            text=self._icon_text("menu", "檢測規格", "☰"),
            image=self._ui_icon("menu", (22, 22)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            width=118,
            height=34,
            command=self._toggle_specs_panel,
        )

        self.expand_specs_button.grid(
            row=0,
            column=1,
            rowspan=2,
            padx=5
        )

        self.expand_specs_button.grid_remove()

        self.about_button = ctk.CTkButton(
            header,
            text=self._icon_text("info", "關於", "ⓘ"),
            image=self._ui_icon("info", (22, 22)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            width=90,
            command=self.show_about
        )

        self.about_button.grid(
            row=0,
            column=2,
            rowspan=2,
            padx=5
        )

        # --------------------------------------------------------------
        # File selection
        # --------------------------------------------------------------

        file_frame = ctk.CTkFrame(
            self.right
        )

        file_frame.grid(
            row=1,
            column=0,
            padx=18,
            pady=10,
            sticky="ew"
        )

        file_frame.grid_columnconfigure(
            0,
            weight=1
        )

        ctk.CTkLabel(
            file_frame,
            textvariable=self.file_var,
            anchor="w",
            font=ctk.CTkFont(size=13),
        ).grid(
            row=0,
            column=0,
            padx=12,
            pady=8,
            sticky="ew"
        )

        # 單選／多選已整合：只保留一個「選擇影片」按鈕。
        # askopenfilenames() 同時支援選擇單一影片或多個影片。
        ctk.CTkButton(
            file_frame,
            text=self._icon_text("document", "選擇影片", "📑"),
            image=self._ui_icon("document", (22, 22)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            width=120,
            command=self.select_files
        ).grid(
            row=0,
            column=1,
            padx=3,
            pady=6
        )

        ctk.CTkButton(
            file_frame,
            text=self._icon_text("folder", "選擇資料夾", "📁"),
            image=self._ui_icon("folder", (22, 22)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            width=120,
            command=self.select_folder
        ).grid(
            row=0,
            column=2,
            padx=(3, 10),
            pady=6
        )

        # --------------------------------------------------------------
        # Current settings summary
        # --------------------------------------------------------------

        summary_frame = ctk.CTkFrame(
            self.right
        )

        summary_frame.grid(
            row=2,
            column=0,
            padx=18,
            pady=5,
            sticky="ew"
        )

        # Compact the summary area so the settings remain prominent without
        # leaving a large empty block around the text.
        summary_frame.configure(
            height=132
        )

        summary_frame.grid_propagate(False)

        self.right.grid_rowconfigure(
            2,
            weight=0,
            minsize=132
        )

        for i in range(3):
            summary_frame.grid_columnconfigure(
                i,
                weight=1
            )

        ctk.CTkLabel(
            summary_frame,
            text="目前檢測設定",
            font=ctk.CTkFont(
                size=20,
                weight="bold"
            ),
        ).grid(
            row=0,
            column=0,
            columnspan=3,
            padx=10,
            pady=(7, 3),
            sticky="w"
        )

        self.summary_labels = []

        for i in range(3):

            label = ctk.CTkLabel(
                summary_frame,
                text="",
                justify="left",
                anchor="nw",
                font=ctk.CTkFont(size=15),
            )

            label.grid(
                row=1,
                column=i,
                padx=10,
                pady=(1, 7),
                sticky="nw"
            )

            self.summary_labels.append(label)

        # --------------------------------------------------------------
        # Result log
        # --------------------------------------------------------------

        log_frame = ctk.CTkFrame(
            self.right,
            fg_color="transparent"
        )

        log_frame.grid(
            row=3,
            column=0,
            padx=18,
            pady=10,
            sticky="nsew"
        )

        log_frame.grid_rowconfigure(
            0,
            weight=1
        )

        log_frame.grid_columnconfigure(
            0,
            weight=1
        )

        self.log = ctk.CTkTextbox(
            log_frame,
            font=("Consolas", 16),
            wrap="none",
            border_width=1,
            border_color="#3f3f3f",
        )

        self.log.grid(
            row=0,
            column=0,
            sticky="nsew"
        )

        self.log._textbox.configure(
            spacing1=2,
            spacing3=2
        )

        self.log_xscroll = tk.Scrollbar(
            log_frame,
            orient="horizontal",
            command=self.log._textbox.xview,
            bg="#2b2b2b",
            troughcolor="#1f1f1f",
            activebackground="#4a4a4a",
            highlightthickness=0,
            bd=0,
        )

        self.log_xscroll.grid(
            row=1,
            column=0,
            sticky="ew",
            pady=(2, 0)
        )

        self.log._textbox.configure(
            xscrollcommand=self.log_xscroll.set
        )

        self.log._textbox.tag_configure(
            "PASS",
            foreground="#35d07f",
            spacing3=4
        )

        self.log._textbox.tag_configure(
            "FAIL",
            foreground="#ff4d5a",
            spacing3=4
        )

        self.log._textbox.tag_configure(
            "WARNING",
            foreground="#ffcc4d",
            spacing3=4
        )

        self.log._textbox.tag_configure(
            "HEADER",
            foreground="#8fc7ff",
            spacing3=4
        )

        self.log._textbox.tag_configure(
            "PARAMETER",
            foreground="#d8d8d8",
            spacing3=4
        )

        self.log._textbox.tag_configure(
            "RESULT",
            foreground="#f0f0f0",
            spacing3=4
        )

        # --------------------------------------------------------------
        # Bottom action buttons
        # --------------------------------------------------------------

        buttons = ctk.CTkFrame(
            self.right,
            fg_color="transparent"
        )

        buttons.grid(
            row=4,
            column=0,
            padx=18,
            pady=(0, 10),
            sticky="ew"
        )

        for i in range(6):
            buttons.grid_columnconfigure(
                i,
                weight=1
            )

        self.start_button = ctk.CTkButton(
            buttons,
            text=self._icon_text("play", "開始檢測", "▶"),
            image=self._ui_icon("play", (23, 23)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=40,
            command=self.start_check
        )
        self.start_button.grid(
            row=0,
            column=0,
            padx=3,
            sticky="ew"
        )

        self.stop_button = ctk.CTkButton(
            buttons,
            text=self._icon_text("stop", "停止檢測", "■"),
            image=self._ui_icon("stop", (23, 23)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=40,
            command=self.stop_check,
            state="disabled"
        )
        self.stop_button.grid(
            row=0,
            column=1,
            padx=3,
            sticky="ew"
        )

        ctk.CTkButton(
            buttons,
            text=self._icon_text("document", "TXT報告", "📄"),
            image=self._ui_icon("document", (23, 23)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=40,
            command=self.export_txt
        ).grid(
            row=0,
            column=2,
            padx=3,
            sticky="ew"
        )

        ctk.CTkButton(
            buttons,
            text=self._icon_text("chart", "Excel報告", "📊"),
            image=self._ui_icon("chart", (23, 23)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=40,
            command=self.export_excel
        ).grid(
            row=0,
            column=3,
            padx=3,
            sticky="ew"
        )

        ctk.CTkButton(
            buttons,
            text=self._icon_text("wrench", "場序檢測", "🛠"),
            image=self._ui_icon("wrench", (23, 23)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=40,
            command=self.open_field_repair
        ).grid(
            row=0,
            column=4,
            padx=3,
            sticky="ew"
        )

        ctk.CTkButton(
            buttons,
            text=self._icon_text("rainbow", "SDR / HDR / 色域內容一致性檢測", "🌈"),
            image=self._ui_icon("rainbow", (23, 23)),
            compound="left",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=40,
            command=self.open_hdr_gamut_check
        ).grid(
            row=0,
            column=5,
            padx=3,
            sticky="ew"
        )

        ctk.CTkButton(
            buttons,
            text="清除",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=40,
            command=self.clear_log
        ).grid(
            row=0,
            column=6,
            padx=3,
            sticky="ew"
        )

        # --------------------------------------------------------------
        # Bottom status
        # --------------------------------------------------------------

        bottom = ctk.CTkFrame(
            self,
            corner_radius=10
        )

        bottom.grid(
            row=1,
            column=0,
            columnspan=3,
            padx=12,
            pady=(0, 12),
            sticky="ew"
        )

        bottom.grid_columnconfigure(
            0,
            weight=0
        )

        bottom.grid_columnconfigure(
            1,
            weight=1
        )

        ctk.CTkLabel(
            bottom,
            textvariable=self.status_var,
            anchor="w",
            font=ctk.CTkFont(size=13),
        ).grid(
            row=0,
            column=0,
            padx=12,
            pady=8
        )

        self.progress = ctk.CTkProgressBar(
            bottom
        )

        self.progress.grid(
            row=0,
            column=1,
            padx=12,
            pady=8,
            sticky="ew"
        )

        self.progress.set(0)

    # ------------------------------------------------------------------
    # UI splitter
    # ------------------------------------------------------------------

    def _toggle_specs_panel(self):

        if self.specs_collapsed:
            self._expand_specs_panel()
        else:
            self._collapse_specs_panel()


    def _collapse_specs_panel(self):

        if self.specs_collapsed:
            return

        current = self.left.winfo_width()

        if current >= 200:
            self.left_panel_width = current

        self.specs_collapsed = True

        self.left.grid_remove()
        self._splitter.grid_remove()

        self.grid_columnconfigure(
            0,
            minsize=0,
            weight=0
        )

        self.grid_columnconfigure(
            1,
            minsize=0,
            weight=0
        )

        self.expand_specs_button.grid()

        self.update_idletasks()


    def _expand_specs_panel(self):

        if not self.specs_collapsed:
            return

        width = max(
            560,
            min(
                1050,
                int(self.left_panel_width or 680)
            )
        )

        self.specs_collapsed = False

        self.grid_columnconfigure(
            0,
            minsize=width,
            weight=0
        )

        self.grid_columnconfigure(
            1,
            minsize=10,
            weight=0
        )

        self.left.configure(
            width=width
        )

        self.left.grid()
        self._splitter.grid()

        self.expand_specs_button.grid_remove()

        self.update_idletasks()


    def _start_splitter_drag(self, event):

        self._splitter_drag_start_x = event.x_root

        self._splitter_start_width = max(
            520,
            self.left.winfo_width()
        )

        self.left_panel_width = (
            self._splitter_start_width
        )

        self._splitter.configure(
            bg="#2f80c0"
        )


    def _drag_splitter(self, event):

        delta = (
            event.x_root
            - getattr(
                self,
                "_splitter_drag_start_x",
                event.x_root
            )
        )

        new_width = int(
            getattr(
                self,
                "_splitter_start_width",
                680
            )
            + delta
        )

        total_width = max(
            1500,
            self.winfo_width()
        )

        right_min = 720
        left_min = 560

        left_max = max(
            left_min,
            min(
                1050,
                total_width - right_min - 40
            )
        )

        new_width = max(
            left_min,
            min(
                left_max,
                new_width
            )
        )

        self.grid_columnconfigure(
            0,
            minsize=new_width
        )

        self.left.configure(
            width=new_width
        )

        self.left_panel_width = new_width

        self.update_idletasks()


    def _reset_splitter(self, event=None):

        new_width = 680

        self.grid_columnconfigure(
            0,
            minsize=new_width
        )

        self.left.configure(
            width=new_width
        )

        self.left_panel_width = new_width

        self._splitter.configure(
            bg="#4a4a4a"
        )

        self.update_idletasks()


    def _end_splitter_drag(self, event=None):

        self._splitter.configure(
            bg="#4a4a4a"
        )

    # ------------------------------------------------------------------
    # Rule rows
    # ------------------------------------------------------------------

    def _add_rule_row(self, row, name):

        frame = ctk.CTkFrame(
            self.rules_frame
        )

        frame.grid(
            row=row,
            column=0,
            padx=4,
            pady=4,
            sticky="ew"
        )

        frame.grid_columnconfigure(
            0,
            minsize=205
        )

        frame.grid_columnconfigure(
            1,
            weight=1
        )

        enabled = tk.BooleanVar(
            value=False
        )

        self.rule_enabled[name] = enabled

        check = ctk.CTkCheckBox(
            frame,
            text=name,
            variable=enabled,
            command=self._refresh_summary,
            width=200,
            font=ctk.CTkFont(size=15),
        )

        check.grid(
            row=0,
            column=0,
            padx=(10, 8),
            pady=9,
            sticky="w"
        )

        combo = ScrollableCTkComboBox(
            frame,
            values=OPTIONS[name],
            width=400,
            state="readonly",
            height=40,
            font=ctk.CTkFont(size=15),
            command=lambda _v, n=name:
                self._refresh_summary(n),
        )

        combo.set(NO_CHECK)

        combo.grid(
            row=0,
            column=1,
            padx=(0, 10),
            pady=7,
            sticky="ew"
        )

        self.combos[name] = combo

    # ------------------------------------------------------------------
    # Presets
    # ------------------------------------------------------------------

    def _preset_names(self):

        # 內建只保留「自訂」；其他預設全部由使用者自行保存。
        names = ["自訂"]

        for name in self.user_presets:

            if name not in names:
                names.append(name)

        return names


    def _all_presets(self):

        presets = {
            "自訂": dict(CUSTOM_PRESET)
        }

        presets.update(
            DEFAULT_PRESETS
        )

        presets.update(
            self.user_presets
        )

        return presets


    def _refresh_preset_combo(
        self,
        selected="自訂"
    ):

        values = self._preset_names()

        self.preset_combo.configure(
            values=values
        )

        if selected in values:
            self.preset_var.set(
                selected
            )
        else:
            self.preset_var.set(
                "自訂"
            )


    def _collect_rule_values(
        self,
        widgets=None
    ):

        result = {}

        if widgets is None:

            for name in OPTIONS:
                result[name] = (
                    self.combos[name].get()
                )

        else:

            for name in OPTIONS:
                result[name] = (
                    widgets[name][1].get()
                )

        return result


    def _set_rules_from_preset(
        self,
        preset
    ):

        for name in OPTIONS:

            value = preset.get(
                name,
                NO_CHECK
            )

            if value not in OPTIONS[name]:
                value = NO_CHECK

            self.combos[name].set(
                value
            )

            self.rule_enabled[name].set(
                value != NO_CHECK
            )

        self._refresh_summary()


    def _refresh_summary(
        self,
        changed=None
    ):

        enabled_items = []

        for name in OPTIONS:

            if self.rule_enabled[name].get():

                value = self.combos[name].get()

                if value != NO_CHECK:
                    enabled_items.append(
                        (name, value)
                    )

        columns = [
            [],
            [],
            []
        ]

        for index, item in enumerate(
            enabled_items
        ):
            columns[
                index % 3
            ].append(
                "%s：%s" % item
            )

        for i in range(3):

            self.summary_labels[i].configure(
                text=(
                    "\n".join(
                        columns[i]
                    )
                    if columns[i]
                    else
                    "目前沒有啟用檢測項目"
                )
            )


    def _apply_preset(
        self,
        preset_name
    ):

        if preset_name == "自訂":
            # 「自訂」不是一個固定的全空白規格；它代表使用者目前
            # 在主面板編輯中的即時設定。切回「自訂」時不再把右側
            # 參數清空，避免使用者已設定的值突然消失。
            self.status_var.set("自訂：使用目前主面板設定")
            return

        preset = self._all_presets().get(
            preset_name
        )

        if not preset:
            return

        self._set_rules_from_preset(
            preset
        )

        self.write_log(
            "已套用預設：%s"
            % preset_name
        )

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------

    def _log_separator(self, char="="):
        """Create a separator that fills the visible main log width.

        The old fixed 100-character separator looked short after the main
        window started maximized.  This measures the actual textbox width and
        Consolas font, so the line automatically fits Win7/10/11 and different
        resolutions/DPI settings.
        """
        try:
            self.update_idletasks()
            width = int(self.log._textbox.winfo_width())
            if width <= 10:
                return char * 100

            font_obj = tkfont.Font(font=self.log._textbox.cget("font"))
            char_width = max(1, int(font_obj.measure(char)))

            # Leave a small right-side safety margin so the final character
            # does not disappear behind the vertical scrollbar/border.
            usable = max(100, width - 24)
            count = max(80, min(260, usable // char_width))
            return char * count
        except Exception:
            return char * 100


    def write_log(self, text):

        def append():

            try:

                message = str(text)

                message = message.replace(
                    "\\n",
                    "\n"
                )

                lines = message.splitlines()

                if not lines:

                    self.log._textbox.insert(
                        "end",
                        "\n"
                    )

                    self.log._textbox.see(
                        "end"
                    )

                    return

                for line in lines:

                    matches = list(
                        re.finditer(
                            r"\b(PASS|FAIL|WARNING)\b",
                            line
                        )
                    )

                    if matches:

                        cursor = 0

                        for match in matches:

                            if match.start() > cursor:

                                self.log._textbox.insert(
                                    "end",
                                    line[
                                        cursor:
                                        match.start()
                                    ],
                                    ("RESULT",)
                                )

                            status = match.group(1)

                            self.log._textbox.insert(
                                "end",
                                status,
                                (status,)
                            )

                            cursor = match.end()

                        if cursor < len(line):

                            self.log._textbox.insert(
                                "end",
                                line[cursor:],
                                ("RESULT",)
                            )

                    elif line.startswith("="):

                        self.log._textbox.insert(
                            "end",
                            line,
                            ("HEADER",)
                        )

                    else:

                        self.log._textbox.insert(
                            "end",
                            line,
                            ("RESULT",)
                        )

                    self.log._textbox.insert(
                        "end",
                        "\n"
                    )

                self.log._textbox.see(
                    "end"
                )

            except Exception:
                pass

        self.after(
            0,
            append
        )


    def clear_log(self):

        self.log._textbox.delete(
            "1.0",
            "end"
        )

        self.status_var.set(
            "就緒"
        )

        self.progress.set(
            0
        )

    # ------------------------------------------------------------------
    # Filename validation
    # ------------------------------------------------------------------

    def _filename_has_space(self, path):

        name = os.path.basename(
            path
        )

        return re.search(
            r"\s",
            name
        ) is not None


    def _validate_filenames(self, paths):

        bad = [
            path
            for path in paths
            if self._filename_has_space(path)
        ]

        return bad

    def _on_main_window_unmap(self, event=None):
        """Close every floating parameter dropdown when the main window is minimized."""
        try:
            if self.state() != "iconic":
                return
        except Exception:
            pass

        # ScrollableCTkComboBox creates a real Tk Toplevel for its dropdown.
        # Minimizing the parent does not automatically minimize that Toplevel,
        # so explicitly close ALL open dropdowns.
        for combo in list(getattr(self, "combos", {}).values()):
            try:
                combo._close_scroll_dropdown()
            except Exception:
                pass

        try:
            if getattr(self, "preset_combo", None) is not None:
                self.preset_combo._close_scroll_dropdown()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # File selection
    # ------------------------------------------------------------------

    def select_file(self):

        path = filedialog.askopenfilename(
            title="選擇影片",
            filetypes=[
                (
                    "Video Files",
                    "*.mxf *.mov *.mp4 *.mkv *.avi *.mts *.m2ts"
                ),
                (
                    "MXF Video",
                    "*.mxf"
                ),
                (
                    "All files",
                    "*.*"
                ),
            ],
        )

        if path:

            self.selected_files = [
                path
            ]

            self.file_var.set(
                "1 個檔案：%s"
                % os.path.basename(path)
            )

            self.write_log(
                "加入檔案：%s"
                % path
            )


    def select_files(self):
        paths = filedialog.askopenfilenames(
            title="多選影片",
            filetypes=[
                (
                    "Video Files",
                    "*.mxf *.mov *.mp4 *.mkv *.avi *.mts *.m2ts"
                ),
                ("MXF Video", "*.mxf"),
                ("All files", "*.*"),
            ],
        )

        if not paths:
            return

        self.selected_files = sorted(
            list(paths),
            key=lambda x: x.lower()
        )
        self.file_var.set(
            "%d 個檔案" % len(self.selected_files)
        )
        self.write_log(
            "選擇影片：加入 %d 個檔案" % len(self.selected_files)
        )
        for path in self.selected_files:
            self.write_log("  加入：%s" % path)


    def select_folder(self):

        folder = filedialog.askdirectory(
            title="選擇影片資料夾"
        )

        if not folder:
            return

        extensions = (
            ".mxf",
            ".mov",
            ".mp4",
            ".mkv",
            ".avi",
            ".mts",
            ".m2ts"
        )

        files = []

        for root, dirs, names in os.walk(folder):

            for name in names:

                if name.lower().endswith(
                    extensions
                ):
                    files.append(
                        os.path.join(
                            root,
                            name
                        )
                    )

        files.sort(
            key=lambda x: x.lower()
        )

        self.selected_files = files

        self.file_var.set(
            "%d 個檔案"
            % len(files)
        )

        self.write_log(
            "掃描資料夾：%s"
            % folder
        )

        self.write_log(
            "找到影片：%d 個"
            % len(files)
        )

    # ------------------------------------------------------------------
    # External process lifecycle / reliable Stop
    # ------------------------------------------------------------------

    @staticmethod
    def _terminate_external_process(process, grace_seconds=0.8):
        """Terminate one external process and guarantee it is reaped.

        Normal analysis never calls this helper.  It is only used after the
        user requests Stop, on timeout, or while cleaning up an unfinished
        process.  FFmpeg/MediaInfo first receive terminate(); if they do not
        exit within a short grace period they are killed and waited again.
        """
        if process is None:
            return
        try:
            if process.poll() is not None:
                try:
                    process.wait(timeout=0)
                except Exception:
                    pass
                return
        except Exception:
            return

        try:
            process.terminate()
        except Exception:
            pass

        try:
            process.wait(timeout=max(0.05, float(grace_seconds)))
            return
        except Exception:
            pass

        try:
            if process.poll() is None:
                process.kill()
        except Exception:
            pass
        try:
            process.wait(timeout=1.5)
        except Exception:
            pass

    def _register_current_process(self, process):
        """Register the active subprocess without allowing a post-Stop stage.

        Returns False when Stop has already been requested.  In that case the
        newly-created process is terminated immediately, preventing the small
        stage-transition race where a new FFmpeg could start after the user
        pressed Stop.
        """
        if process is None:
            return False
        with self._process_lock:
            if self.stop_requested:
                should_stop = True
            else:
                self._current_process = process
                should_stop = False
        if should_stop:
            self._terminate_external_process(process, 0.2)
            return False
        return True

    def _clear_current_process(self, process):
        with self._process_lock:
            if self._current_process is process:
                self._current_process = None

    def _request_stop_current_process(self):
        """Immediately request termination without blocking the Tk UI thread."""
        with self._process_lock:
            process = self._current_process
        if process is None:
            return

        # terminate() is intentionally issued immediately so blocked pipe reads
        # wake as soon as possible.  wait()/kill() runs off the Tk thread.
        try:
            if process.poll() is None:
                process.terminate()
        except Exception:
            pass

        def ensure_stopped():
            self._terminate_external_process(process, 0.8)
            self._clear_current_process(process)

        threading.Thread(target=ensure_stopped, daemon=True).start()

    # ------------------------------------------------------------------
    # MediaInfo
    #
    # IMPORTANT:
    # One video = one MediaInfo.exe call.
    # The entire metadata is read through JSON.
    # ------------------------------------------------------------------

    def mediainfo(self, inform, path):
        exe = get_mediainfo_path()
        if not exe:
            raise RuntimeError(
                "找不到 MediaInfo.exe。請將 MediaInfo.exe 放在程式旁邊或 _internal 資料夾。"
            )

        startupinfo = None
        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

        process = subprocess.Popen(
            [exe, "--Inform=" + inform, path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            startupinfo=startupinfo,
            universal_newlines=True,
            encoding="utf-8",
            errors="replace",
        )

        if not self._register_current_process(process):
            return ""

        try:
            while True:
                if self.stop_requested:
                    self._terminate_external_process(process)
                    return ""

                try:
                    stdout, stderr = process.communicate(timeout=0.2)
                    break
                except subprocess.TimeoutExpired:
                    continue

            return clean_text(stdout or "")
        finally:
            if self.stop_requested and process.poll() is None:
                self._terminate_external_process(process)
            self._clear_current_process(process)


    def _get_json_track_value(
        self,
        track,
        *keys
    ):
        """
        MediaInfo JSON 欄位安全讀取。

        MediaInfo 不同版本、輸出模式可能使用：
            Format_Profile
            Format profile
            Format profile / Writing application
            Writing_Application

        因此除了直接 key lookup 外，還會做「忽略大小寫、空白、底線、
        破折號及其他符號」的比對，避免同一個 MediaInfo 欄位因命名差異
        被誤判成空值。
        """

        if not isinstance(
            track,
            dict
        ):
            return ""

        # 先使用最精確的原始 key。
        for key in keys:

            value = track.get(
                key
            )

            if value is not None:

                value = clean_text(
                    value
                )

                if value:
                    return value

        # 再做寬鬆 key 比對。
        # 例如：
        #   Format_Profile
        #   Format profile
        #   format-profile
        # 都會正規化成同一個 key。
        def normalize_json_key(value):

            return re.sub(
                r"[^a-z0-9]",
                "",
                str(value).lower()
            )

        normalized_keys = {
            normalize_json_key(key)
            for key in keys
        }

        for actual_key, value in track.items():

            if (
                normalize_json_key(actual_key)
                not in normalized_keys
            ):
                continue

            if value is not None:

                value = clean_text(
                    value
                )

                if value:
                    return value

        return ""


    def read_media(self, path):
        """
        MediaInfo CLI text reader.

        核心原則：
            1. 一個影片只執行一次 MediaInfo.exe。
            2. 不使用 MediaInfo JSON。
            3. 直接取得 MediaInfo CLI 的完整文字輸出。
            4. 從這一份文字中解析 QC 所需值。
            5. Writing Application 僅比對真正的欄位值，不做全文命中。

        例如 MediaInfo CLI 輸出：

            Writing application : Grass Valley K.K. EDIUS 8.5.0.2034

        QC 預期：

            Grass Valley K.K.

        判定就是：

            "grass valley k.k." in raw_text.lower()

        因此 EDIUS 版本號完全不參與 Writing Application 判定。
        """

        exe = get_mediainfo_path()

        if not exe:
            raise RuntimeError(
                "找不到 MediaInfo.exe。"
                "請將 MediaInfo.exe 放在程式旁邊或 _internal 資料夾。"
            )

        startupinfo = None

        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

        # --------------------------------------------------------------
        # MediaInfo：整個影片只呼叫一次。
        #
        # 不使用 --Output=JSON。
        # 直接取得 MediaInfo CLI 的人類可讀完整文字。
        #
        # --Full：要求完整資訊。
        # --Language=raw：避免 Windows 語系造成欄位名稱變化。
        # --------------------------------------------------------------

        command = [
            exe,
            "--Full",
            "--Language=raw",
            path,
        ]

        try:
            result = subprocess.run(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                startupinfo=startupinfo,
                universal_newlines=True,
                encoding="utf-8",
                errors="replace",
            )

            raw = result.stdout or ""

            if not raw and result.stderr:
                raw = result.stderr or ""

        except TypeError:
            result = subprocess.run(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                startupinfo=startupinfo,
            )

            try:
                raw = result.stdout.decode(
                    "utf-8",
                    "replace",
                )
            except Exception:
                raw = ""

            if not raw:
                try:
                    raw = result.stderr.decode(
                        "utf-8",
                        "replace",
                    )
                except Exception:
                    pass

        raw = str(raw or "").replace("\r\n", "\n").replace("\r", "\n")

        if not raw.strip():
            raise RuntimeError(
                "MediaInfo 沒有返回文字資料。"
            )

        # --------------------------------------------------------------
        # CLI 文字解析工具
        # --------------------------------------------------------------

        def norm_key(value):
            return re.sub(
                r"[^a-z0-9]",
                "",
                str(value).strip().lower(),
            )

        def parse_sections(text):
            """
            將 MediaInfo：

                General
                Key : Value

                Video
                Key : Value

                Audio #1
                Key : Value

            解析成：

                {
                    "general": {...},
                    "video": {...},
                    "audio #1": {...}
                }

            同一個 key 若重複，保留第一個非空值。
            """

            sections = {}
            current = None

            # MediaInfo CLI 的欄位值本身可能含有冒號，
            # 因此只切第一個冒號。
            # 只把「真正的 MediaInfo 區段標題」當成 section。
            # 不能把所有沒有冒號的行都當標題；MediaInfo --Full 在不同版本
            # 可能出現無冒號的附加行，舊版 parser 會因此把 current section
            # 重設成陌生名稱，導致 Commercial name / Writing application
            # 變成空值，最後出現「實際 AVC / 預期 AVC-Intra 100」這類假 FAIL。
            section_re = re.compile(
                r"^(General|Video(?: #\d+)?|Audio(?: #\d+)?|Text(?: #\d+)?|Image(?: #\d+)?|Menu(?: #\d+)?)$",
                re.IGNORECASE,
            )

            for original_line in text.split("\n"):
                line = original_line.strip()

                if not line:
                    continue

                if ":" in line:
                    key, value = line.split(":", 1)
                    key = key.strip()
                    value = value.strip()

                    if not key:
                        continue

                    if current is None:
                        current = "general"
                        sections.setdefault(current, {})

                    bucket = sections.setdefault(current, {})
                    nk = norm_key(key)

                    if nk and value:
                        if nk not in bucket or not bucket[nk]:
                            bucket[nk] = value
                    continue

                # 只有已知 MediaInfo section header 才切換 section。
                # 其他無冒號行直接忽略，不破壞目前的 section。
                match = section_re.match(line)
                if match:
                    current = line.lower()
                    sections.setdefault(current, {})

            return sections

        sections = parse_sections(raw)

        def get_section(prefixes):
            for section_name, values in sections.items():
                normalized = norm_key(section_name)

                for prefix in prefixes:
                    if normalized == norm_key(prefix):
                        return values

            return {}

        def get_value(section, *labels):
            if not section:
                return ""

            for label in labels:
                value = section.get(norm_key(label), "")
                if value:
                    return clean_text(value)

            return ""

        # --------------------------------------------------------------
        # 取得各區段
        # --------------------------------------------------------------

        general = get_section(["general"])

        video = get_section(["video"])

        audio = {}
        audio_candidates = []

        for section_name, values in sections.items():
            normalized = norm_key(section_name)

            if normalized.startswith("audio"):
                audio_candidates.append(values)

        if audio_candidates:
            audio = audio_candidates[0]

        # --------------------------------------------------------------
        # General
        # --------------------------------------------------------------

        general_format = get_value(
            general,
            "Format",
        )

        general_format_profile = get_value(
            general,
            "Format profile",
            "Format_Profile",
        )

        # General 的 Commercial name 很重要。
        # 例如 AVC-Intra 100 在 MediaInfo 的 Video / Format 仍可能只寫 AVC，
        # 真正的編碼家族會出現在：
        #   Commercial name : AVC-Intra 100
        #
        # 某些 MediaInfo CLI 版本／輸出語系會讓欄位名稱稍有差異，
        # 所以除了 section parser 外，再從完整 CLI 文字做一次「欄位級」
        # fallback；只抓 Commercial name 那一行，不做全文命中。
        commercial_name = get_value(
            general,
            "Commercial name",
            "Commercial_Name",
            "CommercialName",
        )

        # MXF/P2 的關鍵修正：
        # MediaInfo CLI 有時會把 Commercial name 放在 Video 區段，
        # 而不是 General。此時不能只看 General，否則
        #   Format : AVC
        #   Commercial name : AVC-Intra 100
        # 會被錯誤判成普通 AVC。
        #
        # 先保留 General 的值；若沒有，再找 Video 的 Commercial name。
        if not commercial_name:
            commercial_name = get_value(
                video,
                "Commercial name",
                "Commercial_Name",
                "CommercialName",
            )

        # 最後直接從 MediaInfo CLI 原始文字逐行抓取 Commercial name。
        # 這裡刻意不依賴 section parser，因為不同 MediaInfo 版本可能把
        # Video 顯示成 Video / Video #1 / Video #2；我們真正要的只是
        # 「Commercial name : xxx」這個欄位本身。
        #
        # 對 MXF / P2：
        #   Format : AVC
        #   Commercial name : AVC-Intra 100
        #
        # 必須以 Commercial name 為準，不能再拿 Format=AVC 覆蓋它。
        commercial_matches = re.findall(
            r"(?im)^\s*commercial\s+name\s*:\s*(.+?)\s*$",
            raw,
        )

        if commercial_matches:
            # 只挑編碼格式相關的 Commercial name。
            # 若沒有 AVC-Intra / DVCPRO，再保留第一個欄位值作為 fallback。
            preferred = []
            for candidate in commercial_matches:
                candidate = clean_text(candidate)
                candidate_lower = candidate.lower()
                if (
                    re.search(r"\bavc[- ]?intra(?:[- ]?(?:50|100|200|300|422))?\b", candidate_lower)
                    or "dvcpro" in candidate_lower
                ):
                    preferred.append(candidate)

            if preferred:
                commercial_name = preferred[0]
            elif not commercial_name:
                commercial_name = clean_text(commercial_matches[0])

        # --------------------------------------------------------------
        # Writing Application
        #
        # 這裡故意不依賴單一 JSON key。
        #
        # 第一優先：MediaInfo CLI 的明確欄位。
        # 第二優先：整份 MediaInfo 原始文字直接搜尋：
        #   Grass Valley K.K.
        #   Apple
        #   Adobe
        #   Avid
        #
        # QC compare_rule() 還會再次對 raw_text 做包含式比對，
        # 因此即使某個 MediaInfo 版本欄位名稱略有不同，也不會變成空值。
        # --------------------------------------------------------------

        # --------------------------------------------------------------
        # Writing software：只讀 MediaInfo 的「欄位值」，不掃描整份文字。
        #
        # MediaInfo 不同格式/版本可能把軟件放在：
        #   Writing application : Grass Valley K.K. EDIUS 8.5...
        #   Writing library     : Lavf59.16.100
        #   Encoded application : ...
        #   Encoded library     : ...
        #
        # 因此這裡把四種真正的欄位都讀出來。MXF 比對時，若沒有
        # Writing application，就以 Writing library 等欄位作為 fallback。
        # 不把 MediaInfo 其他地方出現的軟件字樣當成 Writing Application。
        # --------------------------------------------------------------
        writing_application = get_value(
            general,
            "Writing application",
            "Writing Application",
            "Encoded application",
            "Encoded Application",
        )

        writing_library = get_value(
            general,
            "Writing library",
            "Writing Library",
            "Encoded library",
            "Encoded Library",
        )

        # 不依賴 section 名稱：直接從 MediaInfo 原始文字找「欄位名 : 值」。
        # 這仍然是欄位級解析，不是全文 keyword 命中。
        def direct_mediainfo_field(*labels):
            wanted = {norm_key(label) for label in labels}
            for original_line in raw.split("\n"):
                line = original_line.strip()
                if not line or ":" not in line:
                    continue
                key, value = line.split(":", 1)
                if norm_key(key) in wanted:
                    value = clean_text(value)
                    if value:
                        return value
            return ""

        def direct_application_field(text):
            """
            MediaInfo 的 Application 欄位採「欄位名規則」解析，不猜軟件。

            規則：只要欄位名稱中包含 application（大小寫不限），
            冒號後面的完整內容就是軟件欄位值。

            例如：
                Writing application : Grass Valley K.K. EDIUS 8.5.0.2034
                Writing Application : Lavf59.16.100
                Encoded application : SomeOtherEncoder 12.3

            都直接取冒號後面的值；不建立「軟件白名單」。
            """
            for original_line in str(text or "").split("\n"):
                line = original_line.strip()
                if not line or ":" not in line:
                    continue
                key, value = line.split(":", 1)
                if re.search(r"application", key, re.IGNORECASE):
                    value = clean_text(value)
                    if value:
                        return value
            return ""

        # 最重要的規則：只要 MediaInfo 原文存在任何「欄位名含
        # application」的欄位，就直接使用冒號後面的值。
        # 不猜品牌、不要求 Writing application 必須是固定名稱。
        # 只要 MediaInfo 原文存在「欄位名稱包含 application」的欄位，
        # 不論副檔名、大小寫或實際欄位名稱，都直接取冒號後面的值。
        # 例如：
        #   Writing application : Grass Valley K.K. EDIUS 8.5.0.2034
        #   Writing application : Lavf59.16.100
        #   Encoded application : Some Encoder 1.2.3
        # 都不做品牌白名單猜測。
        application_field = direct_application_field(raw)
        if application_field:
            writing_application = application_field

        if not writing_application:
            writing_application = direct_mediainfo_field(
                "Writing application",
                "Writing Application",
                "Encoded application",
                "Encoded Application",
            )

        if not writing_library:
            writing_library = direct_mediainfo_field(
                "Writing library",
                "Writing Library",
                "Encoded library",
                "Encoded Library",
            )

        # 保留原始文字供報告／除錯，但 Writing Application 不會用全文比對。
        data = {
            "raw_text": raw,
            "general_format": general_format,
            "general_format_profile": general_format_profile,
            "commercial_name": commercial_name,
            "writing_application": writing_application,
            "writing_library": writing_library,
            "file_extension": os.path.splitext(str(path))[1].lower(),
        }

        # --------------------------------------------------------------
        # Video
        # --------------------------------------------------------------

        data["format"] = get_value(
            video,
            "Format",
        )

        data["codec_id"] = get_value(
            video,
            "Codec ID",
            "CodecID",
        )

        data["profile"] = get_value(
            video,
            "Format profile",
            "Format_Profile",
            "FormatProfile",
        )

        if data["profile"] and "@" not in data["profile"]:
            profile_level = get_value(
                video,
                "Format level",
                "Format_Level",
                "FormatLevel",
            )

            if profile_level:
                if not profile_level.lower().startswith("l"):
                    profile_level = "L" + profile_level

                data["profile"] = (
                    data["profile"]
                    + "@"
                    + profile_level
                )

        data["width"] = get_value(
            video,
            "Width",
        )

        data["height"] = get_value(
            video,
            "Height",
        )

        data["fps"] = get_value(
            video,
            "Frame rate",
            "FrameRate",
        )

        data["chroma"] = get_value(
            video,
            "Chroma subsampling",
            "ChromaSubsampling",
        )

        data["bit_depth"] = get_value(
            video,
            "Bit depth",
            "BitDepth",
        )

        # 來源影片 Video bit rate。AVC-Intra 100 等固定碼率格式優先
        # 沿用來源 Video bit rate，避免修復後碼率意外大幅下降。
        data["video_bitrate"] = get_value(
            video,
            "Bit rate",
            "BitRate",
        )

        # General Overall bit rate 也保存下來。
        # AVC-Intra 100 的 Video bit rate 在不同 MediaInfo 版本有時會
        # 缺失或讀到不完整值；Overall bit rate 可作為安全的上限參考，
        # 避免修復成品的實際碼率突然掉到原片的很低比例。
        data["overall_bitrate"] = get_value(
            general,
            "Overall bit rate",
            "OverallBitRate",
            "Overall bitrate",
        )

        # --------------------------------------------------------------
        # Bit Depth fallback
        #
        # 部分 MOV / ProRes 檔案的 MediaInfo CLI 會把 Video 的
        # "Bit depth" 留空，但 Format profile 已經明確告訴我們
        # ProRes 類型。此時不能把空值直接判成 FAIL。
        # --------------------------------------------------------------
        if not digits(data["bit_depth"]):
            profile_text = clean_text(data.get("profile", ""))
            format_text = clean_text(data.get("format", ""))

            if "prores" in format_text.lower() or any(
                token in profile_text.lower()
                for token in (
                    "422 proxy",
                    "422 lt",
                    "422 hq",
                    "4444 xq",
                    "4444",
                    "422",
                )
            ):
                profile_lower = profile_text.lower()

                if "4444 xq" in profile_lower or "4444" in profile_lower:
                    data["bit_depth"] = "12"
                elif any(
                    token in profile_lower
                    for token in (
                        "422 proxy",
                        "422 lt",
                        "422 hq",
                        "422",
                    )
                ):
                    data["bit_depth"] = "10"

        data["scan_type"] = get_value(
            video,
            "Scan type",
            "ScanType",
        )

        data["field_order"] = get_value(
            video,
            "Scan order",
            "ScanOrder",
        )

        data["color"] = get_value(
            video,
            "Color primaries",
            "colour_primaries",
            "color_primaries",
        )

        # Transfer characteristics：HLG 是影片的 Transfer characteristics，
        # 但 MediaField QC 的「Color Primaries」檢測欄位也提供 HLG 選項。
        # 當使用者選擇 HLG 時，實際值改由 MediaInfo 的 Transfer characteristics
        # 判定，而 BT.709 / BT.2020 等仍然使用真正的 Color primaries。
        data["transfer"] = get_value(
            video,
            "Transfer characteristics",
            "Transfer characteristics Original",
            "TransferCharacteristics",
            "transfer_characteristics",
        )

        # --------------------------------------------------------------
        # Audio
        # --------------------------------------------------------------

        data["audio_format"] = get_value(
            audio,
            "Format",
        )

        data["audio_channels"] = get_value(
            audio,
            "Channels",
        )

        data["audio_sampling"] = get_value(
            audio,
            "Sampling rate",
            "SamplingRate",
        )

        # MediaInfo CLI 常見：
        #   Sampling rate : 48.0 kHz
        #
        # QC 需要：
        #   48000
        #
        # 所以這裡把 kHz 轉成 Hz。
        sampling_text = clean_text(
            data["audio_sampling"]
        )

        sampling_match = re.search(
            r"(\d+(?:\.\d+)?)\s*kHz",
            sampling_text,
            re.IGNORECASE,
        )

        if sampling_match:
            try:
                hz = float(sampling_match.group(1)) * 1000.0

                if abs(hz - round(hz)) < 0.001:
                    data["audio_sampling"] = str(
                        int(round(hz))
                    )
                else:
                    data["audio_sampling"] = str(hz)

            except Exception:
                pass

        data["audio_bit_depth"] = get_value(
            audio,
            "Bit depth",
            "BitDepth",
        )

        # --------------------------------------------------------------
        # MediaInfo CLI section-accurate fallback / authoritative fields
        #
        # IMPORTANT:
        # 不再依賴單一 section 名稱是否剛好叫「Video」或「Video #1」，
        # 也不讓 General/Video 的 Commercial name 被 Format=AVC 覆蓋。
        # 這裡直接從同一次 MediaInfo CLI 的原始文字，依「區段 + 欄位名」
        # 取值；這是 QC 比對的最終資料來源。
        #
        # 例如：
        #   Commercial name : AVC-Intra 100
        #   Format          : AVC
        # 必須得到 Video Format = AVC-Intra 100。
        # 又例如：
        #   Writing application : Grass Valley K.K. EDIUS ...
        # 必須得到 Writing Application = Grass Valley K.K. EDIUS ...，
        # 而不能因 metadata 中出現 com.apple / Lavf 就誤判。
        # --------------------------------------------------------------

        def raw_section_fields(section_kind):
            wanted = str(section_kind).lower()
            fields = {}
            current = None
            section_re = re.compile(
                r"^(General|Video(?: #\d+)?|Audio(?: #\d+)?|Text(?: #\d+)?|Image(?: #\d+)?|Menu(?: #\d+)?)$",
                re.IGNORECASE,
            )

            for original_line in raw.split("\n"):
                line = original_line.strip()
                if not line:
                    continue

                if ":" not in line:
                    match = section_re.match(line)
                    if match:
                        normalized = norm_key(line)
                        if normalized.startswith("video"):
                            current = "video"
                        elif normalized.startswith("audio"):
                            current = "audio"
                        elif normalized.startswith("general"):
                            current = "general"
                        else:
                            current = None
                    # 其他無冒號行不可重置 current。
                    continue

                if current != wanted:
                    continue

                key, value = line.split(":", 1)
                nk = norm_key(key)
                value = clean_text(value)
                if nk and value and nk not in fields:
                    fields[nk] = value

            return fields

        def raw_field_value(section_kind, *labels):
            """從同一次 MediaInfo 原始文字直接取指定 section 的欄位值。

            這是 QC 的 authoritative parser：只比較「欄位值」，絕不以整份
            MediaInfo 文字做關鍵字命中。
            """
            wanted = {norm_key(label) for label in labels}
            if not wanted:
                return ""

            current = None
            section_re = re.compile(
                r"^(General|Video(?: #\d+)?|Audio(?: #\d+)?|Text(?: #\d+)?|Image(?: #\d+)?|Menu(?: #\d+)?)$",
                re.IGNORECASE,
            )

            for original_line in raw.split("\n"):
                line = original_line.strip()
                if not line:
                    continue

                if ":" not in line:
                    match = section_re.match(line)
                    if match:
                        normalized = norm_key(line)
                        if normalized.startswith("video"):
                            current = "video"
                        elif normalized.startswith("audio"):
                            current = "audio"
                        elif normalized.startswith("general"):
                            current = "general"
                        else:
                            current = None
                    continue

                if current != section_kind:
                    continue

                key, value = line.split(":", 1)
                if norm_key(key) in wanted:
                    value = clean_text(value)
                    if value:
                        return value

            return ""

        raw_general = raw_section_fields("general")
        raw_video = raw_section_fields("video")
        raw_audio = raw_section_fields("audio")

        # --------------------------------------------------------------
        # Critical fields: direct-from-MediaInfo-text extraction
        # --------------------------------------------------------------
        # 這三個欄位是目前 MXF 問題的核心。即使 MediaInfo 某版本在
        # --Full 輸出中加入無冒號附加行，也不能讓 section parser 丟失值。
        # 直接從「指定 section + 指定欄位」讀取，仍然不是全文猜測。
        direct_writing = raw_field_value(
            "general",
            "Writing application",
            "Encoded application",
        )
        if direct_writing:
            data["writing_application"] = direct_writing

        direct_commercial = raw_field_value(
            "video",
            "Commercial name",
            "Commercial_Name",
            "CommercialName",
        ) or raw_field_value(
            "general",
            "Commercial name",
            "Commercial_Name",
            "CommercialName",
        )
        if direct_commercial:
            data["commercial_name"] = direct_commercial

        def raw_field(fields, *labels):
            for label in labels:
                value = fields.get(norm_key(label), "")
                if value:
                    return value
            return ""

        def raw_global_field(*labels):
            # 最後一道保險：直接抓「欄位名 : 值」這一行，
            # 仍然是欄位級比對，不是全文關鍵字搜尋。
            wanted = {norm_key(label) for label in labels}
            for original_line in raw.split("\n"):
                line = original_line.strip()
                if not line or ":" not in line:
                    continue
                key, value = line.split(":", 1)
                if norm_key(key) in wanted:
                    value = clean_text(value)
                    if value:
                        return value
            return ""

        # General 欄位：Writing application / Format / Format profile。
        # Writing library 是獨立欄位，不能冒充 Writing application；
        # 這對 MOV / QuickTime 特別重要，例如：
        #   Writing library : Grass Valley HQ
        # 不應被報告成 Writing Application = Grass Valley HQ。
        # 只從「真正的欄位」取值，不做全文關鍵字搜尋。
        authoritative_writing = raw_field(
            raw_general,
            "Writing application",
            "Encoded application",
        )
        if not authoritative_writing:
            authoritative_writing = raw_global_field(
                "Writing application",
                "Encoded application",
            )
        if authoritative_writing:
            data["writing_application"] = authoritative_writing

        # 最終 authoritative fallback：Application 欄位規則優先於任何 section parser。
        # 只要原文有 key 含 application，就直接取其冒號後面的值。
        # 不限 MXF / MOV / MP4，也不限制 application 的實際欄位名稱。
        # 注意：這裡仍然只接受 key 含 application 的欄位，絕不把
        # Writing library / Encoded library 當成 Writing Application。
        direct_application = re.search(
            r"(?im)^\s*[^:]*application[^:]*\s*:\s*(.+?)\s*$",
            raw,
        )
        if direct_application:
            application_value = clean_text(direct_application.group(1))
            if application_value:
                data["writing_application"] = application_value

        # 若 MediaField QC marker 存在，最後再強制回寫 canonical writer，
        # 防止後面的 application 欄位 fallback 把它覆蓋回 Lavf / 原 writer。
        if re.search(
            r"(?im)^\s*(?:Writing application|Encoded application|Writing library|Encoded library|Comment|Encoded by|Encoded_By)\s*:\s*MediaField QC\s*$",
            raw,
        ):
            data["writing_application"] = "MediaField QC"

        # MediaField QC 自己輸出的影片：若 FFmpeg / MXF muxer 有保留
        # 我們寫入的 writer identity，優先把它視為本工具產生的成品。
        # 這避免修復後再次 QC 時，仍顯示原始影片的 EDIUS / 其他 writer。
        mediafield_marker = re.search(
            r"(?im)^\s*(?:Writing application|Encoded application|Writing library|Encoded library|Comment|Encoded by|Encoded_By)\s*:\s*MediaField QC\s*$",
            raw,
        )
        if mediafield_marker:
            data["writing_application"] = "MediaField QC"
            data["writing_library"] = "MediaField QC"

        authoritative_writing_library = raw_field(
            raw_general,
            "Writing library",
            "Writing Library",
            "Encoded library",
            "Encoded Library",
        )
        if not authoritative_writing_library:
            authoritative_writing_library = raw_global_field(
                "Writing library",
                "Writing Library",
                "Encoded library",
                "Encoded Library",
            )
        if authoritative_writing_library:
            data["writing_library"] = authoritative_writing_library

        # MOV / QuickTime 特例：部分實際檔案的 MediaInfo General 區段
        # 沒有「Writing application」，只提供 Writing library。
        #
        # 重要：UI 的 Writing Application 是「廠牌／應用程式」層級，
        # 因此不能把「Apple QuickTime」或「Grass Valley HQ」原字串直接
        # 當成 UI 的實際值，否則使用者選「Apple」／「Grass Valley K.K.」
        # 時會出現明明是同一來源卻被判定 FAIL 的情況。
        # 這裡只對已知且明確的 MOV writer library 做有限 canonicalization，
        # 未知名稱一律保留原值，不猜測。
        if (
            not clean_text(data.get("writing_application", ""))
            and str(data.get("file_extension", "")).lower() in {".mov", ".qt"}
        ):
            mov_library = clean_text(
                data.get("writing_library", "")
                or authoritative_writing_library
            )
            mov_low = mov_library.casefold()

            if mov_low.startswith("apple quicktime"):
                data["writing_application"] = "Apple"
            elif mov_low.startswith("grass valley") and "edius" in mov_low:
                data["writing_application"] = "Edius"
            elif mov_low.startswith("grass valley"):
                data["writing_application"] = "Grass Valley K.K."
            elif re.fullmatch(r"Lavf\s*\d+(?:\.\d+)*", mov_library, re.IGNORECASE):
                data["writing_application"] = "FFmpeg"

        # 即使 MediaInfo 有真正的 Writing application 欄位，MOV 仍可能
        # 回傳「Apple QuickTime」這類品牌 + 平台名稱。
        # 對已知值做同樣的 canonicalization，讓「實際」欄位顯示與 UI
        # 選項一致；未知軟件則完全不改。
        if str(data.get("file_extension", "")).lower() in {".mov", ".qt"}:
            app_value = clean_text(data.get("writing_application", ""))
            app_low = app_value.casefold()
            if app_low.startswith("apple quicktime"):
                data["writing_application"] = "Apple"
            elif app_low.startswith("grass valley") and "edius" in app_low:
                data["writing_application"] = "Edius"
            elif app_low.startswith("grass valley"):
                data["writing_application"] = "Grass Valley K.K."
            elif re.fullmatch(r"Lavf\s*\d+(?:\.\d+)*", app_value, re.IGNORECASE):
                data["writing_application"] = "FFmpeg"

        authoritative_general_profile = raw_field(
            raw_general,
            "Format profile",
            "Format_Profile",
        )
        if not authoritative_general_profile:
            authoritative_general_profile = raw_global_field(
                "Format profile",
                "Format_Profile",
            )
        if authoritative_general_profile:
            data["general_format_profile"] = authoritative_general_profile
            data["format_profile"] = authoritative_general_profile

        # Commercial name：Video 區段優先，General 作為 fallback。
        # 對 MXF/P2 的 AVC-Intra / DVCPRO，這是最關鍵的欄位。
        authoritative_commercial = raw_field(
            raw_video,
            "Commercial name",
            "Commercial_Name",
            "CommercialName",
        ) or raw_field(
            raw_general,
            "Commercial name",
            "Commercial_Name",
            "CommercialName",
        )

        if not authoritative_commercial:
            # 只從 Commercial name 欄位取值；優先選 AVC-Intra / DVCPRO。
            commercial_candidates = re.findall(
                r"(?im)^\s*commercial\s+name\s*:\s*(.+?)\s*$",
                raw,
            )
            for candidate in commercial_candidates:
                candidate = clean_text(candidate)
                low = candidate.lower()
                if (
                    "avc-intra" in low
                    or "avc intra" in low
                    or "dvcpro" in low
                ):
                    authoritative_commercial = candidate
                    break
            if not authoritative_commercial and commercial_candidates:
                authoritative_commercial = clean_text(commercial_candidates[0])

        if authoritative_commercial:
            data["commercial_name"] = authoritative_commercial

        # Video：全部直接以 Video 區段欄位為準。
        video_field_map = {
            "format": ("Format",),
            "codec_id": ("Codec ID", "CodecID"),
            "profile": ("Format profile", "Format_Profile", "FormatProfile"),
            "width": ("Width",),
            "height": ("Height",),
            "fps": ("Frame rate", "FrameRate"),
            "chroma": ("Chroma subsampling", "ChromaSubsampling"),
            "bit_depth": ("Bit depth", "BitDepth"),
            "scan_type": ("Scan type", "ScanType"),
            "field_order": ("Scan order", "ScanOrder"),
            "color": ("Color primaries", "colour_primaries", "color_primaries"),
            "transfer": ("Transfer characteristics", "Transfer characteristics Original", "TransferCharacteristics", "transfer_characteristics"),
        }

        for target, labels in video_field_map.items():
            value = raw_field(raw_video, *labels)
            if value:
                data[target] = value

        # --------------------------------------------------------------
        # Color Primaries fallback：MXF / MediaInfo 不同版本相容處理。
        # 某些檔案在 MediaInfo GUI 會顯示 BT.709，但 CLI --Language=raw
        # 可能把欄位寫成 colour_primaries / colour primaries，或欄位位於
        # Video #1。只接受「Color Primaries」欄位本身，不掃描全文猜測，
        # 因此不會把 Transfer characteristics / Matrix coefficients 誤當成 BT.709。
        # --------------------------------------------------------------
        if not clean_text(data.get("color", "")):
            color_labels = {
                norm_key("Color primaries"),
                norm_key("colour primaries"),
                norm_key("colour_primaries"),
                norm_key("color_primaries"),
                norm_key("Color primaries Source"),
                norm_key("Color primaries Original"),
                norm_key("colour_primaries_Source"),
                norm_key("colour_primaries_Original"),
            }

            current = None
            section_re = re.compile(
                r"^(General|Video(?: #\d+)?|Audio(?: #\d+)?|Text(?: #\d+)?|Image(?: #\d+)?|Menu(?: #\d+)?)$",
                re.IGNORECASE,
            )
            for original_line in raw.split("\n"):
                line = original_line.strip()
                if not line:
                    continue
                if ":" not in line:
                    match = section_re.match(line)
                    if match:
                        normalized = norm_key(line)
                        if normalized.startswith("video"):
                            current = "video"
                        elif normalized.startswith("audio"):
                            current = "audio"
                        elif normalized.startswith("general"):
                            current = "general"
                        else:
                            current = None
                    continue
                if current != "video":
                    continue
                key, value = line.split(":", 1)
                if norm_key(key) in color_labels:
                    value = clean_text(value)
                    if value:
                        data["color"] = value
                        break

        # 最後一道欄位級 fallback：部分 MediaInfo 版本的 raw label
        # 可能包含語言後綴；只接受 key 中明確包含 color/colour + primaries。
        if not clean_text(data.get("color", "")):
            for original_line in raw.split("\n"):
                line = original_line.strip()
                if not line or ":" not in line:
                    continue
                key, value = line.split(":", 1)
                key_low = re.sub(r"[^a-z]", "", key.lower())
                if "primaries" in key_low and ("colour" in key_low or "color" in key_low):
                    value = clean_text(value)
                    if value:
                        data["color"] = value
                        break

        # MOV / QuickTime：某些 Grass Valley / Canopus 檔案的 MediaInfo
        # 版本可能把編碼名稱放在 Codec ID / Commercial name，而不是
        # Transfer characteristics fallback：不同 MediaInfo 版本可能使用
        # Transfer characteristics / transfer_characteristics 不同欄位名稱。
        if not clean_text(data.get("transfer", "")):
            transfer_labels = {
                norm_key("Transfer characteristics"),
                norm_key("Transfer characteristics Original"),
                norm_key("TransferCharacteristics"),
                norm_key("transfer_characteristics"),
            }
            current = None
            for original_line in raw.split("\n"):
                line = original_line.strip()
                if not line:
                    continue
                if ":" not in line:
                    match = section_re.match(line)
                    if match:
                        normalized = norm_key(line)
                        if normalized.startswith("video"):
                            current = "video"
                        elif normalized.startswith("audio"):
                            current = "audio"
                        else:
                            current = "other"
                    continue
                if current != "video":
                    continue
                key, value = line.split(":", 1)
                if norm_key(key) in transfer_labels:
                    value = clean_text(value)
                    if value:
                        data["transfer"] = value
                        break

        # Video -> Format。保留欄位級來源，讓 Video Format 可以正確辨識
        # Canopus HQ / Canopus HQX；不掃描整份文字猜測。
        if not data.get("format"):
            mov_codec_fallback = raw_field(
                raw_video,
                "Commercial name",
                "Codec ID",
                "Format",
            )
            if mov_codec_fallback:
                data["format"] = mov_codec_fallback

        # 若 Format profile 沒有 @Level，補上 MediaInfo 的 Format level。
        if data.get("profile") and "@" not in data["profile"]:
            raw_level = raw_field(
                raw_video,
                "Format level",
                "Format_Level",
                "FormatLevel",
            )
            if raw_level:
                level = raw_level
                if not level.lower().startswith("l"):
                    level = "L" + level
                data["profile"] = data["profile"] + "@" + level

        # Audio：同樣直接取第一個 Audio 區段。
        audio_field_map = {
            "audio_format": ("Format",),
            "audio_channels": ("Channels",),
            "audio_sampling": ("Sampling rate", "SamplingRate"),
            "audio_bit_depth": ("Bit depth", "BitDepth"),
        }

        for target, labels in audio_field_map.items():
            value = raw_field(raw_audio, *labels)
            if value:
                data[target] = value

        # --------------------------------------------------------------
        # Resolution
        # --------------------------------------------------------------

        data["resolution"] = normalize_resolution(
            data.get("width"),
            data.get("height"),
        )

        # Compatibility
        data["format_profile"] = (
            data.get("general_format_profile", "")
        )

        # Final MOV/QuickTime writer normalization must happen after all
        # authoritative field extraction.
        if str(data.get("file_extension", "")).lower() in {".mov", ".qt"}:
            data["writing_application"] = self._normalize_mov_writing_application(
                data.get("writing_application", "")
            )

        return data

    # ------------------------------------------------------------------
    # Matching
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize_mxf_writing_application(raw_value, raw_text="", writing_library=""):
        """
        從 MediaInfo 原文取得 MXF 的輸出軟件名稱。

        核心規則（不猜）：
        1. 優先找任何「欄位名稱包含 application」的欄位，大小寫不限。
        2. 冒號後面的內容就是該軟件欄位值。
        3. 不限制軟件品牌；未知軟件也原樣保留。
        4. Lavf + 版本號是 FFmpeg 的 MediaInfo 表示，轉成 FFmpeg。
        5. 一般版本號只從尾端去掉，不改動軟件本身的名稱。

        注意：不再掃描 MediaInfo 其他內容來「猜」軟件。
        """

        def extract_application(text):
            for original_line in str(text or "").split("\n"):
                line = original_line.strip()
                if not line or ":" not in line:
                    continue
                key, value = line.split(":", 1)
                if re.search(r"application", key, re.IGNORECASE):
                    value = clean_text(value)
                    if value:
                        return value
            return ""

        value = extract_application(raw_text)
        if not value:
            value = clean_text(raw_value)
        if not value:
            value = clean_text(writing_library)

        if not value:
            return ""

        # MediaInfo / FFmpeg 常見表示：Lavf59.16.100 / Lavf60.3.100
        # 這不是另一個軟件名稱，而是 FFmpeg 的 libavformat writer。
        if re.match(r"^Lavf\s*\d+(?:\.\d+)*$", value, re.IGNORECASE):
            return "FFmpeg"

        # EDIUS 在 MXF 中常見有兩種 MediaInfo 表示：
        #   Grass Valley K.K. EDIUS 8.5.0.2034
        #   Grass Valley K.K.
        # 兩者都代表 EDIUS。UI 的 canonical name 統一使用「Edius」。
        if re.search(r"\bedius\b", value, re.IGNORECASE):
            return "Edius"
        if re.fullmatch(r"Grass\s+Valley\s+K\.K\.", value, re.IGNORECASE):
            return "Edius"

        # FFmpeg writer。
        if re.match(r"^Lavf\s*\d+(?:\.\d+)*$", value, re.IGNORECASE):
            return "FFmpeg"

        # 只移除尾端版本號；未知 writer 保留原名稱，不猜測。
        value = re.sub(r"(?:\s+|[._-])v?\d+(?:[._-]\d+){1,}(?:\s*)$", "", value, flags=re.IGNORECASE)
        value = re.sub(r"\s+v\d+(?:[._-]\d+)*\s*$", "", value, flags=re.IGNORECASE)
        return clean_text(value)

    @staticmethod
    def _normalize_mov_writing_application(value):
        """Normalize known MOV/QuickTime writer labels without guessing unknown values."""
        value = clean_text(value)
        if not value:
            return ""
        low = value.casefold()
        if low.startswith("apple quicktime") or low == "apple":
            return "Apple"
        if low.startswith("grass valley") and "edius" in low:
            return "Edius"
        # EDIUS 產出的 MOV / QuickTime 有時只有「Grass Valley K.K.」
        # 而沒有把 EDIUS 寫在 Writing Application 值裡。
        # 與 MXF 的規則一致：這種值應視為 Edius。
        if re.fullmatch(r"Grass\s+Valley\s+K\.K\.", value, re.IGNORECASE):
            return "Edius"
        if low.startswith("grass valley"):
            return "Grass Valley K.K."
        if re.fullmatch(r"Lavf\s*\d+(?:\.\d+)*", value, re.IGNORECASE):
            return "FFmpeg"
        return value

    def compare_rule(
        self,
        name,
        expected,
        data
    ):

        if expected == NO_CHECK:
            return True, ""

        # --------------------------------------------------------------
        # Resolution
        # --------------------------------------------------------------

        if name == "Resolution":

            actual = data.get(
                "resolution",
                ""
            )

            return (
                actual == expected,
                actual
            )

        # --------------------------------------------------------------
        # Frame Rate
        # --------------------------------------------------------------

        if name == "Frame Rate":

            actual = data.get(
                "fps",
                ""
            )

            return (
                fps_equal(
                    actual,
                    expected
                ),
                actual
            )

        # --------------------------------------------------------------
        # Chroma
        # --------------------------------------------------------------

        if name == "Chroma":

            actual = normalize_chroma(
                data.get(
                    "chroma",
                    ""
                )
            )

            return (
                actual ==
                normalize_chroma(
                    expected
                ),
                actual
            )

        # --------------------------------------------------------------
        # Bit Depth
        # --------------------------------------------------------------

        if name == "Bit Depth":

            actual = digits(
                data.get(
                    "bit_depth",
                    ""
                )
            )

            return (
                actual ==
                digits(expected),
                actual
            )

        # --------------------------------------------------------------
        # Scan Type
        # --------------------------------------------------------------

        if name == "Scan Type":

            actual = clean_text(
                data.get(
                    "scan_type",
                    ""
                )
            )

            expected_lower = (
                expected.lower()
            )

            actual_lower = (
                actual.lower()
            )

            if expected_lower == "interlaced":

                return (
                    "interlaced"
                    in actual_lower
                    or
                    "mbaff"
                    in actual_lower
                    or
                    "paff"
                    in actual_lower,
                    actual
                )

            if expected_lower == "progressive":

                return (
                    "progressive"
                    in actual_lower,
                    actual
                )

            # MXF / AVC-Intra 常見的 MediaInfo 表示：
            #   Scan type : MBAFF
            # 而 QC 選項可顯示為：
            #   MBAFF/Interlaced
            # 兩者代表同一種交錯編碼方式，應視為 PASS。
            if "mbaff" in expected_lower and "interlaced" in expected_lower:
                return (
                    "mbaff" in actual_lower
                    or "interlaced" in actual_lower
                    or "paff" in actual_lower,
                    actual
                )

            return (
                expected_lower
                in actual_lower,
                actual
            )

        # --------------------------------------------------------------
        # Field Order
        # --------------------------------------------------------------

        if name == "Field Order":

            actual = normalize_field_order(
                data.get(
                    "field_order",
                    ""
                )
            )

            return (
                actual ==
                normalize_field_order(
                    expected
                ),
                actual
            )

        # --------------------------------------------------------------
        # Color Primaries
        # --------------------------------------------------------------

        if name == "Color Primaries":

            expected_normalized = normalize_color(expected)

            # HLG 屬於 Transfer characteristics，而不是 Color primaries。
            # 但為了讓使用者可以直接在目前的「Color Primaries」檢測項目
            # 選擇 HLG，當預期值為 HLG 時改讀 MediaInfo 的 Transfer characteristics。
            if expected_normalized == "HLG":
                actual = normalize_color(
                    data.get("transfer", "")
                )
            else:
                actual = normalize_color(
                    data.get("color", "")
                )

            return (
                actual == expected_normalized,
                actual
            )

        # --------------------------------------------------------------
        # Video Format
        # --------------------------------------------------------------

        if name == "Video Format":

            raw_text = data.get("raw_text", "")
            format_text = data.get("format", "")
            commercial_text = data.get("commercial_name", "")
            codec_id_text = data.get("codec_id", "")

            # ==========================================================
            # MXF 專用：直接從 MediaInfo 原始文字辨識「常見格式名稱」
            #
            # 重要：
            #   MXF 的 MediaInfo 可能顯示：
            #       Format          : AVC
            #       Commercial name : AVC-Intra 100
            #
            #   因此 MXF 不再用 Format=AVC 去猜。
            #   直接掃描同一次 MediaInfo 原始文字，找到明確的常見
            #   格式名稱後，就把它當成實際 Video Format。
            #
            #   MOV / MP4 的原有判定邏輯完全保留，不在這裡改動。
            # ==========================================================
            is_mxf = bool(
                re.search(
                    r"(?im)^\s*format\s*:\s*MXF\s*$",
                    raw_text,
                )
            )

            if is_mxf:
                # 長格式優先，避免先命中較短的家族名稱。
                # 只接受規格下的常見格式名稱。
                mxf_format_patterns = (
                    ("AVC-Intra 300", r"\bAVC[- ]?Intra[- ]?300\b"),
                    ("AVC-Intra 200", r"\bAVC[- ]?Intra[- ]?200\b"),
                    ("AVC-Intra 100", r"\bAVC[- ]?Intra[- ]?100\b"),
                    ("AVC-Intra 50",  r"\bAVC[- ]?Intra[- ]?50\b"),
                    ("AVC-Intra 422", r"\bAVC[- ]?Intra[- ]?422\b"),
                    ("AVC-Intra",     r"\bAVC[- ]?Intra\b"),
                    ("DVCPRO HD",      r"\bDVCPRO[- ]?HD\b"),
                    ("DVCPRO 50",      r"\bDVCPRO[- ]?50\b"),
                    ("DVCPRO 25",      r"\bDVCPRO[- ]?25\b"),
                    ("DVCPRO",         r"\bDVCPRO\b"),
                    ("ProRes",         r"\bProRes\b"),
                    ("DNxHD",          r"\bDNxHD\b"),
                    ("DNxHR",          r"\bDNxHR\b"),
                    ("JPEG 2000",      r"\bJPEG[- ]?2000\b"),
                    ("MPEG-2",         r"\bMPEG[- ]?2\b"),
                    ("HEVC",           r"\bHEVC\b"),
                    ("AV1",            r"\bAV1\b"),
                    ("VP9",            r"\bVP9\b"),
                    ("VC-3",           r"\bVC[- ]?3\b"),
                    ("AVC",            r"\bAVC\b"),
                )

                actual = ""
                for canonical, pattern in mxf_format_patterns:
                    if re.search(pattern, raw_text, re.IGNORECASE):
                        actual = canonical
                        break

                if actual:
                    return (
                        actual == normalize_codec(expected),
                        actual
                    )

            # ==========================================================
            # 非 MXF（尤其 MOV / MP4）：
            # 以 Video Format / Commercial name / Codec ID 的欄位值為準。
            # 其中包含 Grass Valley / Canopus 的 HQ / HQX。
            # ==========================================================

            # MediaInfo 對 AVC-Intra / DVCPRO 的 Format 有時只回傳家族名稱，
            # 但 General 的 Commercial name 會保留 50/100/200/300 或 DVCPRO HD。
            format_text = data.get("format", "")
            commercial_text = data.get("commercial_name", "")
            codec_id_text = data.get("codec_id", "")

            # 最終判定仍以同一次 MediaInfo 原始文字的欄位值為準。
            # 對 MXF/P2，Commercial name 才是 AVC-Intra / DVCPRO 的精確類別。
            raw_text = data.get("raw_text", "")
            direct_commercials = re.findall(
                r"(?im)^\s*commercial\s+name\s*:\s*(.+?)\s*$",
                raw_text,
            )
            if direct_commercials:
                preferred_direct = []
                for candidate in direct_commercials:
                    candidate = clean_text(candidate)
                    if re.search(
                        r"(?i)\b(?:AVC[- ]?Intra(?:[- ]?(?:50|100|200|300|422))?|DVCPRO(?:[- ]?(?:25|50|HD))?)\b",
                        candidate,
                    ):
                        preferred_direct.append(candidate)
                if preferred_direct:
                    commercial_text = preferred_direct[0]

            commercial_actual = normalize_codec(commercial_text) if commercial_text else ""

            if commercial_actual in {
                "AVC-Intra 50",
                "AVC-Intra 100",
                "AVC-Intra 200",
                "AVC-Intra 300",
                "AVC-Intra 422",
                "AVC-Intra",
                "DVCPRO",
                "DVCPRO 25",
                "DVCPRO 50",
                "DVCPRO HD",
            }:
                actual = commercial_actual
            else:
                raw_text = data.get("raw_text", "")
                raw_match = re.search(
                    r"(?im)^\s*commercial\s+name\s*:\s*(AVC[- ]?Intra(?:[- ]?(?:50|100|200|300|422))?|DVCPRO(?:[- ]?(?:25|50|HD))?)\s*$",
                    raw_text,
                )
                if raw_match:
                    actual = normalize_codec(raw_match.group(1))
                else:
                    codec_source = " %s %s %s " % (
                        format_text,
                        commercial_text,
                        codec_id_text,
                    )
                    actual = normalize_codec(codec_source)

            return (
                actual == normalize_codec(expected),
                actual
            )

        # --------------------------------------------------------------
        # Video Profile
        # --------------------------------------------------------------

        if name == "Video Profile":

            actual = clean_text(
                data.get(
                    "profile",
                    ""
                )
            )

            expected_profile = normalize_video_profile(expected)
            actual_profile = normalize_video_profile(actual)

            # Profiles are discrete values: 422 must not pass against 422 HQ.
            # Only harmless MediaInfo spelling differences are normalized,
            # notably L4 == L4.0. L4.1/L4.2/etc. remain distinct.
            return (
                bool(expected_profile)
                and expected_profile == actual_profile,
                actual
            )

        # --------------------------------------------------------------
        # Format Profile
        #
        # IMPORTANT:
        # General -> Format_Profile
        # --------------------------------------------------------------

        if name == "Format Profile":

            actual = clean_text(
                data.get(
                    "general_format_profile",
                    ""
                )
            )

            # MP4：MediaInfo 常見輸出為：
            #   Format         : MPEG-4
            #   Format profile : Base Media
            # QC 的 Format Profile 選項以 MPEG-4 作為容器規格名稱，
            # 所以只在 MP4 + Base Media 時，把 General 的 Format 直接
            # 當作實際 Format Profile。注意這裡不能使用 data["format"]，
            # 因為 data["format"] 是 Video / Format（例如 AVC）。
            # MOV / QuickTime 不走這個分支，維持原有判定。
            if (
                str(data.get("file_extension", "")).lower() == ".mp4"
                and actual.casefold() == "base media"
            ):
                mp4_format = clean_text(
                    data.get("general_format", "")
                )
                if mp4_format:
                    actual = mp4_format

            expected_profile = normalize_format_profile(expected)
            actual_profile = normalize_format_profile(actual)

            return (
                bool(expected_profile)
                and expected_profile == actual_profile,
                actual
            )

        # --------------------------------------------------------------
        # Writing Application
        # --------------------------------------------------------------

        if name == "Writing Application":

            expected_text = clean_text(expected)
            raw_text = data.get("raw_text", "")
            actual_raw = clean_text(data.get("writing_application", ""))

            # MXF：只把真正的 Writing application 欄位標準化。
            # 例如「Grass Valley K.K. EDIUS 8.5.0.2034」
            # 直接變成「Grass Valley K.K.」，版本號不參與判定。
            if str(data.get("file_extension", "")).lower() == ".mxf":
                # Edius 是 UI 的 canonical name。MediaInfo 常回傳
                # "Grass Valley K.K. EDIUS x.x.x"，統一視為 Edius。
                if expected_text.casefold() == "edius":
                    # EDIUS 實際上常由 MediaInfo 顯示為：
                    #   Grass Valley K.K.
                    #   Grass Valley K.K. EDIUS 8.x.x
                    # 兩者都代表 EDIUS。這裡只看 Writing Application
                    # 欄位值（actual_raw），避免被其他 metadata 干擾。
                    probe = actual_raw.strip()
                    if (
                        re.search(r"\bedius\b", probe, re.IGNORECASE)
                        or re.search(r"^Grass\s+Valley\s+K\.K\.(?:\s|$)", probe, re.IGNORECASE)
                    ):
                        return True, "Edius"

                # MXF：優先 Writing application；若 MediaInfo 只提供
                # Writing library（例如 Lavf59.16.100），就使用 library。
                # 版本號不參與判定，LavfXX 直接標準化為 FFmpeg。
                actual = self._normalize_mxf_writing_application(
                    actual_raw,
                    raw_text,
                    data.get("writing_library", ""),
                )

                # 使用者設定的是「要辨識的軟件名稱」，MediaInfo 欄位可能
                # 還帶產品名，例如：
                #   Grass Valley K.K. EDIUS 8.5.0.2034
                # 因此只要設定值出現在 Application 欄位值中即可 PASS。
                # 這仍然是「欄位值對欄位值」，不是全文搜尋。
                return (
                    bool(expected_text)
                    and bool(actual)
                    and expected_text.casefold() in actual.casefold(),
                    actual,
                )

            # MOV / 其他格式：使用 read_media() 最終 canonical value。
            # 不再用 raw MediaInfo application 欄位覆蓋它。
            actual = actual_raw

            if str(data.get("file_extension", "")).lower() in {".mov", ".qt"}:
                actual = self._normalize_mov_writing_application(actual)

            if str(data.get("file_extension", "")).lower() == ".mp4":
                if re.fullmatch(r"Lavf\s*\d+(?:\.\d+)*", actual, re.IGNORECASE):
                    actual = "FFmpeg"
                else:
                    # 只移除尾端版本號；未知軟件名稱原樣保留。
                    actual = re.sub(
                        r"(?:\s+|[._-])v?\d+(?:[._-]\d+){1,}\s*$",
                        "",
                        actual,
                        flags=re.IGNORECASE,
                    )
                    actual = clean_text(actual)

            found = (
                bool(expected_text)
                and bool(actual)
                and expected_text.casefold() in actual.casefold()
            )

            return found, actual

        # --------------------------------------------------------------
        # Audio Format
        # --------------------------------------------------------------

        if name == "Audio Format":

            actual = normalize_audio_format(
                data.get(
                    "audio_format",
                    ""
                )
            )

            return (
                actual ==
                normalize_audio_format(
                    expected
                ),
                actual
            )

        # --------------------------------------------------------------
        # Audio Channels
        # --------------------------------------------------------------

        if name == "Audio Channels":

            actual = digits(
                data.get(
                    "audio_channels",
                    ""
                )
            )

            return (
                actual ==
                digits(expected),
                actual
            )

        # --------------------------------------------------------------
        # Audio Sampling
        # --------------------------------------------------------------

        if name == "Audio Sampling":

            actual = digits(
                data.get(
                    "audio_sampling",
                    ""
                )
            )

            return (
                actual ==
                digits(expected),
                actual
            )

        # --------------------------------------------------------------
        # Audio Bit Depth
        # --------------------------------------------------------------

        if name == "Audio Bit Depth":

            actual = digits(
                data.get(
                    "audio_bit_depth",
                    ""
                )
            )

            return (
                actual ==
                digits(expected),
                actual
            )

        return True, ""

    # ------------------------------------------------------------------
    # Field-order detection / repair
    # ------------------------------------------------------------------

    def _ffmpeg_run(self, args, timeout=None, progress_callback=None):
        """Run FFmpeg; optionally expose real -progress information."""
        exe = get_ffmpeg_path()
        if not exe:
            raise RuntimeError(
                "找不到 ffmpeg.exe。請將 ffmpeg.exe 放在程式旁邊或 _internal 資料夾。"
            )
        startupinfo = None
        creationflags = 0
        env = os.environ.copy()
        exe_dir = os.path.dirname(os.path.abspath(exe))
        env["PATH"] = exe_dir + os.pathsep + env.get("PATH", "")

        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

        command = [exe]
        if progress_callback is not None:
            command += ["-progress", "pipe:1", "-stats_period", "0.25", "-nostats"]
        command += list(args)

        if self.stop_requested:
            return "", ""

        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            startupinfo=startupinfo,
            creationflags=creationflags,
            env=env,
            universal_newlines=True,
            encoding="utf-8",
            errors="replace",
        )
        if not self._register_current_process(process):
            return "", ""
        try:
            if progress_callback is None:
                stdout, stderr = process.communicate(timeout=timeout)
            else:
                stdout_lines = []
                stderr_lines = []
                start_time = time.time()

                def drain_stderr():
                    # metadata=mode=print 會逐行把 idet 的抽樣結果寫到 stderr。
                    # 這裡一定要用 readline()，不能用 read(256)：
                    # Windows 的 TextIOWrapper 可能會等待湊滿指定字元數，
                    # 導致幾十秒甚至幾分鐘都收不到第一個分析回報。
                    idet_re = re.compile(
                        r"lavfi\.idet\.single\.current_frame\s*=\s*(tff|bff|progressive|undetermined)",
                        re.IGNORECASE,
                    )
                    showinfo_re = re.compile(r"pts_time:([-+]?\d+(?:\.\d+)?)")
                    duration_re = re.compile(
                        r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)",
                        re.IGNORECASE,
                    )
                    idet_count = 0
                    try:
                        while True:
                            raw_line = process.stderr.readline()
                            if raw_line == "":
                                if process.poll() is not None:
                                    break
                                continue
                            line_text = raw_line.rstrip("\r\n")
                            if not line_text:
                                continue
                            stderr_lines.append(line_text)
                            if progress_callback is not None:
                                dm = duration_re.search(line_text)
                                if dm:
                                    try:
                                        input_duration = (
                                            int(dm.group(1)) * 3600.0
                                            + int(dm.group(2)) * 60.0
                                            + float(dm.group(3))
                                        )
                                        if input_duration > 0.0:
                                            progress_callback(
                                                "input_duration",
                                                str(input_duration),
                                                time.time() - start_time,
                                            )
                                    except Exception:
                                        pass
                                sm = showinfo_re.search(line_text)
                                if sm:
                                    try:
                                        progress_callback(
                                            "analysis_time",
                                            sm.group(1),
                                            time.time() - start_time,
                                        )
                                    except Exception:
                                        pass
                                im = idet_re.search(line_text)
                                if im:
                                    idet_count += 1
                                    try:
                                        progress_callback(
                                            "analysis_sample",
                                            str(idet_count),
                                            time.time() - start_time,
                                        )
                                    except Exception:
                                        pass
                    except Exception:
                        pass

                stderr_thread = threading.Thread(target=drain_stderr, daemon=True)
                stderr_thread.start()
                while True:
                    if self.stop_requested:
                        self._terminate_external_process(process)
                    line = process.stdout.readline()
                    if line == "":
                        if process.poll() is not None:
                            break
                        continue
                    line = line.strip()
                    if not line:
                        continue
                    stdout_lines.append(line)
                    if "=" in line:
                        key, value = line.split("=", 1)
                        if key in ("frame", "out_time_ms", "out_time_us", "speed", "progress"):
                            try:
                                progress_callback(key, value, time.time() - start_time)
                            except Exception:
                                pass
                stderr_thread.join(timeout=2.0)
                stderr = "\n".join(stderr_lines)
                stdout = "\n".join(stdout_lines)
                if timeout is not None and (time.time() - start_time) > timeout:
                    raise subprocess.TimeoutExpired(command, timeout)

            # A non-zero exit code caused by an explicit user Stop is not an
            # analysis failure.  The outer workflow will present "已停止".
            if self.stop_requested:
                return stdout or "", stderr or ""

            if process.returncode != 0:
                detail = (stderr or stdout or "").strip()
                if not detail:
                    detail = "FFmpeg 沒有輸出錯誤訊息；exit code=%s。" % process.returncode
                raise RuntimeError(
                    "FFmpeg 執行失敗（exit code=%s）：\n%s"
                    % (process.returncode, detail[-6000:])
                )
            return stdout or "", stderr or ""
        except subprocess.TimeoutExpired:
            self._terminate_external_process(process, 0.2)
            raise RuntimeError("FFmpeg 執行逾時。")
        finally:
            if self.stop_requested and process.poll() is None:
                self._terminate_external_process(process)
            self._clear_current_process(process)

    def _ffprobe_value(self, path, entry):
        """Run one ffprobe query through the same stoppable process lifecycle."""
        exe = get_ffprobe_path()
        if not exe:
            return ""
        startupinfo = None
        creationflags = 0
        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        command = [
            exe, "-v", "error", "-show_entries", entry,
            "-of", "default=noprint_wrappers=1:nokey=1", path,
        ]
        process = None
        try:
            if self.stop_requested:
                return ""
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                startupinfo=startupinfo,
                creationflags=creationflags,
                universal_newlines=True,
                encoding="utf-8",
                errors="replace",
            )
            if not self._register_current_process(process):
                return ""
            while True:
                if self.stop_requested:
                    self._terminate_external_process(process, 0.2)
                    return ""
                try:
                    stdout, _stderr = process.communicate(timeout=0.20)
                    return clean_text(stdout)
                except subprocess.TimeoutExpired:
                    continue
        except Exception:
            return ""
        finally:
            if process is not None:
                try:
                    if self.stop_requested and process.poll() is None:
                        self._terminate_external_process(process, 0.2)
                except Exception:
                    pass
                self._clear_current_process(process)

    def _field_probe_decoded_fps(self, path, max_frames=120):
        """Estimate actual decoded picture cadence from ffprobe frame timestamps.

        Some professional MXF files advertise a stream rate such as 50/1 while
        decoded pictures advance every 40 ms (25 pictures/s).  Field analysis and
        TC conversion must follow the decoded picture cadence, not blindly trust
        r_frame_rate/nb_frames metadata.

        FFprobe 4.4.1-compatible options only are used here.  The probe reads a
        small prefix of real decoded-frame timestamps; it never scans the whole
        programme and does not change any media.
        """
        exe = get_ffprobe_path()
        if not exe or self.stop_requested:
            return 0.0

        startupinfo = None
        creationflags = 0
        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

        process = None
        command = [
            exe, "-v", "error", "-select_streams", "v:0",
            "-read_intervals", "0%%+#%d" % max(24, int(max_frames)),
            "-show_entries", "frame=best_effort_timestamp_time,pkt_pts_time,pkt_dts_time",
            "-of", "json", path,
        ]
        try:
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                startupinfo=startupinfo,
                creationflags=creationflags,
                universal_newlines=True,
                encoding="utf-8",
                errors="replace",
            )
            if not self._register_current_process(process):
                return 0.0

            while True:
                if self.stop_requested:
                    self._terminate_external_process(process, 0.2)
                    return 0.0
                try:
                    stdout, _stderr = process.communicate(timeout=0.20)
                    break
                except subprocess.TimeoutExpired:
                    continue

            if process.returncode != 0 or not stdout:
                return 0.0

            data = json.loads(stdout)
            timestamps = []
            for frame in (data.get("frames") or []):
                raw = (
                    frame.get("best_effort_timestamp_time")
                    or frame.get("pkt_pts_time")
                    or frame.get("pkt_dts_time")
                )
                try:
                    value = float(raw)
                except Exception:
                    continue
                if math.isfinite(value):
                    timestamps.append(value)

            # Need enough observations to avoid deriving cadence from a damaged
            # opening GOP or one duplicated timestamp.
            if len(timestamps) < 12:
                return 0.0

            deltas = []
            previous = timestamps[0]
            for value in timestamps[1:]:
                delta = value - previous
                previous = value
                if 0.001 <= delta <= 1.0:
                    deltas.append(delta)
            if len(deltas) < 8:
                return 0.0

            ordered = sorted(deltas)
            mid = len(ordered) // 2
            if len(ordered) % 2:
                median_delta = ordered[mid]
            else:
                median_delta = (ordered[mid - 1] + ordered[mid]) / 2.0
            if median_delta <= 0.0:
                return 0.0

            fps = 1.0 / median_delta
            if not (1.0 <= fps <= 240.0):
                return 0.0

            # Require the majority of positive deltas to agree with the median.
            # This keeps genuinely variable-frame-rate material conservative.
            tolerance = max(0.0005, median_delta * 0.12)
            agreeing = sum(1 for d in deltas if abs(d - median_delta) <= tolerance)
            if agreeing < max(6, int(math.ceil(len(deltas) * 0.70))):
                return 0.0
            return float(fps)
        except Exception:
            return 0.0
        finally:
            if process is not None:
                try:
                    if self.stop_requested and process.poll() is None:
                        self._terminate_external_process(process, 0.2)
                except Exception:
                    pass
                self._clear_current_process(process)

    def _field_decoded_frame_count(self, path, refresh=False):
        """Return the actual decoded video-frame count from ffprobe.

        Do not trust stream nb_frames for final integrity checks: some MXF files
        expose field-rate-like counts that are 2x the decoded picture count.  This
        helper uses ffprobe -count_frames / nb_read_frames, which follows the actual
        video stream and is compatible with FFprobe 4.4.1.  It is intentionally
        called only for repair validation because it may need to scan the full file.
        """
        cache = getattr(self, "_field_frame_count_cache", None)
        if cache is None:
            cache = {}
            self._field_frame_count_cache = cache
        key = os.path.abspath(path)
        if refresh:
            cache.pop(key, None)
        if key in cache:
            return int(cache[key] or 0)

        exe = get_ffprobe_path()
        if not exe or self.stop_requested:
            return 0

        startupinfo = None
        creationflags = 0
        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

        command = [
            exe, "-v", "error", "-select_streams", "v:0",
            "-count_frames", "-show_entries", "stream=nb_read_frames",
            "-of", "default=noprint_wrappers=1:nokey=1", path,
        ]
        process = None
        count = 0
        try:
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                startupinfo=startupinfo,
                creationflags=creationflags,
                universal_newlines=True,
                encoding="utf-8",
                errors="replace",
            )
            if not self._register_current_process(process):
                return 0
            while True:
                if self.stop_requested:
                    self._terminate_external_process(process, 0.2)
                    return 0
                try:
                    stdout, _stderr = process.communicate(timeout=0.20)
                    break
                except subprocess.TimeoutExpired:
                    continue
            if process.returncode == 0:
                raw = clean_text(stdout)
                try:
                    count = int(round(float(raw))) if raw else 0
                except Exception:
                    count = 0
        except Exception:
            count = 0
        finally:
            if process is not None:
                try:
                    if self.stop_requested and process.poll() is None:
                        self._terminate_external_process(process, 0.2)
                except Exception:
                    pass
                self._clear_current_process(process)

        if count > 0:
            cache[key] = int(count)
        return int(count or 0)

    def _field_probe_info(self, path, refresh=False):
        """場序模組專用：一次 ffprobe 取齊 FPS / duration / field_order 等資料。

        這個 cache 只供場序分析、修復與修復後驗證使用，避免同一影片在同一輪
        工作中重複啟動多次 ffprobe；不改一般 QC / HDR 模組的既有 probe 路徑。
        """
        cache = getattr(self, "_field_probe_cache", None)
        if cache is None:
            cache = {}
            self._field_probe_cache = cache
        key = os.path.abspath(path)
        if refresh:
            cache.pop(key, None)
        if key in cache:
            return dict(cache[key])

        info = {
            "fps": 0.0,
            "metadata_fps": 0.0,
            "decoded_fps": 0.0,
            "fps_source": "",
            "duration": 0.0,
            "field_order": "",
            "field_order_raw": "",
            "r_frame_rate": "",
            "avg_frame_rate": "",
            "stream_duration": 0.0,
            "format_duration": 0.0,
            "nb_frames": 0.0,
            "width": 0,
            "height": 0,
            "pix_fmt": "",
            "stream_bit_rate": 0,
            "format_bit_rate": 0,
        }
        exe = get_ffprobe_path()
        process = None
        if exe and not self.stop_requested:
            startupinfo = None
            creationflags = 0
            if os.name == "nt":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            command = [
                exe, "-v", "error", "-select_streams", "v:0",
                "-show_entries",
                "stream=r_frame_rate,avg_frame_rate,field_order,nb_frames,duration,width,height,pix_fmt,bit_rate:format=duration,bit_rate",
                "-of", "json", path,
            ]
            try:
                process = subprocess.Popen(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    startupinfo=startupinfo,
                    creationflags=creationflags,
                    universal_newlines=True,
                    encoding="utf-8",
                    errors="replace",
                )
                if self._register_current_process(process):
                    while True:
                        if self.stop_requested:
                            self._terminate_external_process(process, 0.2)
                            break
                        try:
                            stdout, _stderr = process.communicate(timeout=0.20)
                            if process.returncode == 0 and stdout:
                                data = json.loads(stdout)
                                streams = data.get("streams") or []
                                stream = streams[0] if streams else {}
                                fmt = data.get("format") or {}
                                info["r_frame_rate"] = clean_text(stream.get("r_frame_rate", ""))
                                info["avg_frame_rate"] = clean_text(stream.get("avg_frame_rate", ""))
                                info["field_order_raw"] = clean_text(stream.get("field_order", "")).lower()
                                info["pix_fmt"] = clean_text(stream.get("pix_fmt", ""))
                                try:
                                    info["width"] = int(stream.get("width") or 0)
                                    info["height"] = int(stream.get("height") or 0)
                                except Exception:
                                    pass
                                for name, source, source_key in (
                                    ("stream_duration", stream, "duration"),
                                    ("format_duration", fmt, "duration"),
                                    ("nb_frames", stream, "nb_frames"),
                                ):
                                    try:
                                        info[name] = float(source.get(source_key) or 0.0)
                                    except Exception:
                                        info[name] = 0.0
                                try:
                                    info["stream_bit_rate"] = int(float(stream.get("bit_rate") or 0))
                                except Exception:
                                    pass
                                try:
                                    info["format_bit_rate"] = int(float(fmt.get("bit_rate") or 0))
                                except Exception:
                                    pass
                            break
                        except subprocess.TimeoutExpired:
                            continue
            except Exception:
                pass
            finally:
                if process is not None:
                    try:
                        if self.stop_requested and process.poll() is None:
                            self._terminate_external_process(process, 0.2)
                    except Exception:
                        pass
                    self._clear_current_process(process)

        metadata_fps = 0.0
        for rate in (info.get("r_frame_rate"), info.get("avg_frame_rate")):
            try:
                fps = normalize_fps(rate)
                if fps and fps > 0.0:
                    metadata_fps = float(fps)
                    break
            except Exception:
                pass
        info["metadata_fps"] = metadata_fps

        decoded_fps = self._field_probe_decoded_fps(path)
        if decoded_fps > 0.0:
            info["decoded_fps"] = float(decoded_fps)

        # Decoded PTS cadence is authoritative when it materially disagrees with
        # stream-rate metadata.  Otherwise keep the exact rational metadata rate
        # (e.g. 25/1, 30000/1001) to avoid needless floating-point drift.
        if decoded_fps > 0.0 and (
            metadata_fps <= 0.0
            or abs(decoded_fps - metadata_fps) / max(decoded_fps, metadata_fps) > 0.02
        ):
            info["fps"] = float(decoded_fps)
            info["fps_source"] = "decoded_pts"
        elif metadata_fps > 0.0:
            info["fps"] = float(metadata_fps)
            info["fps_source"] = "stream_metadata"
        elif decoded_fps > 0.0:
            info["fps"] = float(decoded_fps)
            info["fps_source"] = "decoded_pts"

        mapping = {
            "tt": "Top Field First",
            "bb": "Bottom Field First",
            "progressive": "Progressive",
            "unknown": "",
            "": "",
        }
        info["field_order"] = mapping.get(info.get("field_order_raw", ""), "")

        duration_candidates = []
        for name in ("format_duration", "stream_duration"):
            value = float(info.get(name) or 0.0)
            if value > 0.0:
                duration_candidates.append(value)

        fps = float(info.get("fps") or 0.0)
        frames = float(info.get("nb_frames") or 0.0)
        frame_duration = (frames / fps) if fps > 0.0 and frames > 0.0 else 0.0

        # nb_frames can describe fields rather than decoded pictures on some MXF
        # files (test5 is a 50/25-style example).  Never use frame-count duration
        # as the sole authority when metadata FPS disagrees with decoded PTS cadence.
        # In that case leave duration unresolved here; the analysis pass / decoded
        # frame-count fallback will establish the real timeline safely.
        rate_mismatch = bool(
            metadata_fps > 0.0 and decoded_fps > 0.0
            and abs(metadata_fps - decoded_fps) / max(metadata_fps, decoded_fps) > 0.02
        )
        if frame_duration > 0.0:
            if not duration_candidates:
                if not rate_mismatch:
                    duration_candidates.append(frame_duration)
            else:
                reference = max(duration_candidates)
                ratio = frame_duration / reference if reference > 0.0 else 1.0
                if 0.80 <= ratio <= 1.25:
                    duration_candidates.append(frame_duration)

        if duration_candidates:
            smallest = min(duration_candidates)
            sane = [v for v in duration_candidates if smallest <= 0.0 or v <= smallest * 1.25]
            info["duration"] = max(sane or duration_candidates)

        # ffprobe JSON 不完整時，只以現有 MediaInfo 結果補缺；不逐欄再開 ffprobe。
        if not info["fps"] or not info["field_order"]:
            try:
                media = self.read_media(path)
            except Exception:
                media = {}
            if not info["fps"]:
                try:
                    media_fps = normalize_fps(media.get("fps", ""))
                    if media_fps and media_fps > 0.0:
                        info["fps"] = float(media_fps)
                        info["fps_source"] = "mediainfo_fallback"
                except Exception:
                    pass
            if not info["field_order"]:
                value = normalize_field_order(media.get("field_order", ""))
                if value in ("Top Field First", "Bottom Field First", "Progressive"):
                    info["field_order"] = value

        cache[key] = dict(info)
        return dict(info)

    def _field_run_idet(self, path, fps=25.0, start=None, duration=None, progress_callback=None, sample_stride=1, coarse_period=0, coarse_keep=0):
        """場序專用 streaming idet runner。

        v1.2.0 True-Realtime：Windows/PyInstaller 下不再依賴 TextIOWrapper.readline()
        的緩衝時機。stdout / stderr 都以 binary + os.read() 即時讀取；進度直接由
        已收到的逐幀 idet metadata 數量推進，因此是實際已分析 frame 的進度，
        不是 UI 補間或事後重播百分比。
        """
        exe = get_ffmpeg_path()
        if not exe:
            raise RuntimeError("找不到 ffmpeg.exe。請將 ffmpeg.exe 放在程式旁邊或 _internal 資料夾。")
        startupinfo = None
        creationflags = 0
        env = os.environ.copy()
        exe_dir = os.path.dirname(os.path.abspath(exe))
        env["PATH"] = exe_dir + os.pathsep + env.get("PATH", "")
        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

        command = [exe, "-hide_banner", "-loglevel", "info"]
        if start is not None:
            command += ["-ss", self._ts(max(0.0, float(start)))]
        if duration is not None:
            command += ["-t", self._ts(max(0.01, float(duration)))]
        # metadata=print 本身已逐幀輸出 idet 結果；不再加 showinfo，避免同一幀
        # 產生額外 stderr 訊息。進度以實際收到的 idet frame count 為權威。
        stride = max(1, int(sample_stride or 1))
        period = max(0, int(coarse_period or 0))
        keep = max(0, int(coarse_keep or 0))
        if period > 0 and 0 < keep < period:
            # IMPORTANT: idet needs a run of consecutive frames.  Sampling one
            # isolated frame every N frames makes true TFF/BFF look Progressive.
            # Therefore the fast pass keeps a consecutive block from every period
            # (about 70% duty cycle) and skips only a short gap between blocks.
            vf = "select=lt(mod(n\\,%d)\\,%d),idet,metadata=mode=print:key=lavfi.idet.single.current_frame" % (period, keep)
        elif stride > 1:
            # Retained for compatibility with older internal callers, but the new
            # adaptive field analyser intentionally uses consecutive-block sampling.
            vf = "select=not(mod(n\\,%d)),idet,metadata=mode=print:key=lavfi.idet.single.current_frame" % stride
        else:
            vf = "idet,metadata=mode=print:key=lavfi.idet.single.current_frame"
        command += [
            "-i", path,
            "-vf", vf,
            "-an", "-progress", "pipe:1", "-stats_period", "0.25", "-nostats",
            "-f", "null", "NUL" if os.name == "nt" else "/dev/null",
        ]
        if self.stop_requested:
            return [], 0.0

        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            startupinfo=startupinfo,
            creationflags=creationflags,
            env=env,
            universal_newlines=False,
            bufsize=0,
        )
        if not self._register_current_process(process):
            return [], 0.0

        samples = []
        stderr_tail = []
        ffmpeg_duration = [0.0]
        start_time = time.time()
        idet_re = re.compile(
            r"lavfi\.idet\.single\.current_frame\s*=\s*(tff|bff|progressive|undetermined)",
            re.IGNORECASE,
        )
        duration_re = re.compile(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", re.IGNORECASE)
        callback_lock = threading.Lock()

        def safe_progress(key, value):
            if progress_callback is None:
                return
            try:
                with callback_lock:
                    progress_callback(key, str(value), time.time() - start_time)
            except Exception:
                pass

        def handle_stderr_line(line):
            if not line:
                return
            stderr_tail.append(line)
            if len(stderr_tail) > 240:
                del stderr_tail[:80]
            dm = duration_re.search(line)
            if dm:
                try:
                    total = int(dm.group(1)) * 3600.0 + int(dm.group(2)) * 60.0 + float(dm.group(3))
                    if total > 0.0:
                        ffmpeg_duration[0] = total
                        safe_progress("input_duration", total)
                except Exception:
                    pass
            im = idet_re.search(line)
            if im:
                k = len(samples)
                if period > 0 and 0 < keep < period:
                    # Map the kth selected frame back to its original source frame.
                    source_index = (k // keep) * period + (k % keep)
                else:
                    source_index = k * stride
                samples.append((source_index, im.group(1).lower()))
                # Progress is reported in source-frame units so the existing GUI
                # calculation remains monotonic for coarse and precise scans.
                if len(samples) == 1 or len(samples) % 5 == 0:
                    safe_progress("analysis_sample", source_index + 1)

        def binary_line_reader(pipe, handler):
            pending = b""
            try:
                fd = pipe.fileno()
                while True:
                    try:
                        chunk = os.read(fd, 8192)
                    except Exception:
                        chunk = b""
                    if not chunk:
                        break
                    pending += chunk
                    while b"\n" in pending:
                        raw, pending = pending.split(b"\n", 1)
                        text = raw.rstrip(b"\r").decode("utf-8", "replace")
                        handler(text)
                if pending:
                    handler(pending.rstrip(b"\r").decode("utf-8", "replace"))
            except Exception:
                pass

        def handle_stdout_line(line):
            line = (line or "").strip()
            if not line or "=" not in line:
                return
            key, value = line.split("=", 1)
            if key in ("frame", "out_time_ms", "out_time_us", "speed", "progress"):
                safe_progress(key, value)

        stderr_thread = threading.Thread(
            target=binary_line_reader, args=(process.stderr, handle_stderr_line), daemon=True
        )
        stdout_thread = threading.Thread(
            target=binary_line_reader, args=(process.stdout, handle_stdout_line), daemon=True
        )
        stderr_thread.start()
        stdout_thread.start()

        try:
            while process.poll() is None:
                if self.stop_requested:
                    self._terminate_external_process(process)
                    break
                time.sleep(0.03)
            try:
                process.wait(timeout=2.0)
            except Exception:
                if process.poll() is None:
                    self._terminate_external_process(process)
            stderr_thread.join(timeout=2.0)
            stdout_thread.join(timeout=2.0)

            if self.stop_requested:
                return list(samples), float(ffmpeg_duration[0] or 0.0)
            if process.returncode != 0:
                detail = "\n".join(stderr_tail).strip()
                raise RuntimeError(
                    "FFmpeg idet 執行失敗（exit code=%s）：\n%s"
                    % (process.returncode, detail[-6000:] or "沒有額外錯誤訊息")
                )
            return list(samples), float(ffmpeg_duration[0] or 0.0)
        finally:
            if self.stop_requested and process.poll() is None:
                self._terminate_external_process(process)
            self._clear_current_process(process)

    def _field_progressive_temporal_probe(self, path, start, end, fps=25.0):
        """Low-cost second-pass check for idet Progressive candidates.

        The purpose is not to replace idet.  It asks a narrower question:
        do the two fields inside each coded frame appear to come from the
        same moment (Progressive/PsF-like), or do they carry separate temporal
        samples (true interlaced-like)?

        A short centre window is bob-deinterlaced to low-resolution gray frames.
        For true interlaced material, adjacent bob fields tend to contain
        comparable motion.  For Progressive/PsF material, the two bob outputs
        originating from the same source frame are usually much more similar
        than the boundary between two source frames.  Low-motion material is
        intentionally returned as inconclusive instead of being called P.
        """
        ffmpeg = get_ffmpeg_path()
        if not ffmpeg:
            return {"state": "unavailable", "reason": "找不到 FFmpeg"}

        try:
            start = max(0.0, float(start or 0.0))
            end = max(start, float(end or start))
            seg_len = max(0.0, end - start)
            if seg_len <= 0.0:
                return {"state": "inconclusive", "reason": "區段長度不足"}

            # Probe only a short centre window.  This keeps the extra pass cheap
            # even on UHD long-form programmes while avoiding transition edges.
            probe_len = min(2.4, max(1.2, seg_len * 0.55))
            if seg_len <= probe_len + 0.05:
                probe_start = start
                probe_len = seg_len
            else:
                probe_start = start + max(0.0, (seg_len - probe_len) * 0.5)

            cmd = [
                ffmpeg, "-hide_banner", "-loglevel", "error",
                "-ss", "%.6f" % probe_start,
                "-t", "%.6f" % probe_len,
                "-i", path,
                "-an", "-sn", "-dn",
                "-vf",
                "bwdif=mode=send_field:parity=auto:deint=all,scale=160:90:flags=bilinear,format=gray",
                # FFmpeg 4.4.1 defaults may duplicate/drop rawvideo frames to satisfy
                # the stream-declared rate.  That destroys the even/odd bob-field
                # pairing used below on MXF files whose header rate differs from PTS.
                # -vsync 0 is the 4.4.1-compatible passthrough mode.
                "-vsync", "0",
                "-f", "rawvideo", "-pix_fmt", "gray", "-",
            ]
            creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                creationflags=creationflags
            )
            if not self._register_current_process(proc):
                return {"state": "stopped", "reason": "使用者已停止分析"}
            try:
                raw, err = proc.communicate()
            finally:
                self._clear_current_process(proc)

            if self.stop_requested:
                return {"state": "stopped", "reason": "使用者已停止分析"}
            if proc.returncode not in (0, None) or not raw:
                return {
                    "state": "inconclusive",
                    "reason": "場間時間驗證無法取得足夠畫面",
                }

            frame_size = 160 * 90
            frame_count = len(raw) // frame_size
            if frame_count < 6:
                return {"state": "inconclusive", "reason": "場間時間樣本不足"}
            raw = raw[:frame_count * frame_size]
            frames = [memoryview(raw)[i * frame_size:(i + 1) * frame_size] for i in range(frame_count)]

            def frame_mad(a, b):
                # Spatial subsampling keeps Python overhead very low.  The metric
                # is only used as a relative temporal ratio, not a quality score.
                total = 0
                count = 0
                for k in range(0, frame_size, 4):
                    total += abs(int(a[k]) - int(b[k]))
                    count += 1
                return float(total) / float(max(1, count))

            diffs = [frame_mad(frames[i], frames[i + 1]) for i in range(frame_count - 1)]
            same_frame_field_diffs = diffs[0::2]
            next_frame_boundary_diffs = diffs[1::2]
            if len(same_frame_field_diffs) < 2 or len(next_frame_boundary_diffs) < 2:
                return {"state": "inconclusive", "reason": "場間時間樣本不足"}

            def median(values):
                vals = sorted(float(v) for v in values)
                n = len(vals)
                if not n:
                    return 0.0
                if n % 2:
                    return vals[n // 2]
                return (vals[n // 2 - 1] + vals[n // 2]) * 0.5

            intra = median(same_frame_field_diffs)
            boundary = median(next_frame_boundary_diffs)
            ratio = intra / max(0.05, boundary)
            motion = max(intra, boundary)

            # Conservative thresholds: low motion never becomes a confirmed P
            # merely because idet could not see combing.
            if motion < 0.70:
                state = "low_motion"
                reason = "畫面運動量偏低，無法可靠證明為真正 Progressive"
            elif boundary >= 0.85 and ratio <= 0.62:
                state = "progressive"
                reason = "場內兩個 field 接近同一時間點，Progressive/PsF 證據明顯"
            elif intra >= 0.65 and ratio >= 0.78:
                state = "interlaced"
                reason = "相鄰 field 均呈現時間差，場間時間結構偏向真正交錯掃描"
            else:
                state = "inconclusive"
                reason = "場間時間證據不足，保守不自動確認 Progressive"

            return {
                "state": state,
                "reason": reason,
                "field_pair_diff": intra,
                "frame_boundary_diff": boundary,
                "temporal_ratio": ratio,
                "motion_score": motion,
                "probe_start": probe_start,
                "probe_duration": probe_len,
            }
        except Exception as exc:
            return {"state": "inconclusive", "reason": "場間時間驗證失敗：%s" % exc}

    def _probe_field_order(self, path):
        """場序模組取得來源 field_order；優先使用一次性 field probe cache。"""
        try:
            value = normalize_field_order(self._field_probe_info(path).get("field_order", ""))
            if value in ("Top Field First", "Bottom Field First", "Progressive"):
                return value
        except Exception:
            pass
        return ""

    @staticmethod
    def _parse_idet_current_frames(text, fps=25.0, sample_stride=1):
        """Return [(frame_index, classification)] from ordered idet samples.

        對場序分析而言，sample_stride=1 時每一筆
        lavfi.idet.single.current_frame 就是下一個連續影片 frame。
        部分 Windows FFmpeg + MXF 的 stderr 中，metadata 與 showinfo 的
        pts_time 行並不是可靠的 1:1 對應；若直接把兩個獨立 list zip，
        會把 15 秒素材的場序分類壓縮到約前 7.5 秒。

        因此 stride=1 時直接以 idet 分類出現次序作 frame index。
        這同時保留真正的逐幀邊界，BFF/TFF/P 不再因 log 對位而錯時。
        """
        single_re = re.compile(
            r"lavfi\.idet\.single\.current_frame\s*=\s*(tff|bff|progressive|undetermined)", re.IGNORECASE
        )
        multi_re = re.compile(
            r"lavfi\.idet\.multiple\.current_frame\s*=\s*(tff|bff|progressive|undetermined)", re.IGNORECASE
        )
        singles = [m.group(1).lower() for m in single_re.finditer(text)]
        multiples = [m.group(1).lower() for m in multi_re.finditer(text)]
        classes = []
        for idx, single in enumerate(singles):
            multi = multiples[idx] if idx < len(multiples) else "undetermined"
            # Layer 1/2 consensus: single-frame temporal evidence + multi-frame idet history.
            # When both are known and agree, confidence is strongest.  When they disagree,
            # retain the single result for the raw stream; the temporal smoothing layer below
            # decides whether it forms a stable segment instead of forcing a false boundary.
            if single == "undetermined" and multi in ("tff", "bff", "progressive"):
                classes.append(multi)
            else:
                classes.append(single)
        stride = max(1, int(sample_stride))
        return [(idx * stride, cls) for idx, cls in enumerate(classes)]

    @staticmethod
    def _smooth_field_runs(samples, min_frames=3, merge_gap=2, undetermined_context_max_frames=None):
        """Clean idet noise while preserving genuine field-order boundaries.

        Undetermined bridge policy (v1.2.1):
        - short A -> U -> A may be absorbed back into A;
        - A -> U -> B, where A != B, keeps U as its own boundary segment;
        - long U never gets absorbed merely because both neighbours match.

        ``undetermined_context_max_frames`` is the maximum U-run length eligible
        for same-neighbour absorption.  None means no U absorption.
        """
        if not samples:
            return []

        work = list(samples)
        known_classes = ("tff", "bff", "progressive")
        try:
            u_bridge_limit = (
                max(1, int(undetermined_context_max_frames))
                if undetermined_context_max_frames is not None
                else 0
            )
        except Exception:
            u_bridge_limit = 0

        # Undetermined continuity policy (v1.2.1):
        # 1) A-U-A: the U belongs to the same stable field-order context A.
        #    For an interior bridge we keep the 2 s safety limit so a genuinely
        #    long ambiguous section is not swallowed merely because both sides match.
        # 2) A-U-B (A != B): keep U independent; there is no defensible way to
        #    assign it to the left or right side.
        # 3) Edge U-A / A-U: there is only one known neighbour and no conflicting
        #    evidence, so preserve the legacy continuity behaviour and inherit A.
        #    Raw U observations are still retained separately and remain in the
        #    confidence denominator, so this does NOT manufacture a 100% segment.
        i = 0
        while i < len(work):
            if work[i][1] != "undetermined":
                i += 1
                continue

            j = i + 1
            while j < len(work) and work[j][1] == "undetermined":
                j += 1

            run_len = j - i
            left_cls = work[i - 1][1] if i > 0 else None
            right_cls = work[j][1] if j < len(work) else None
            replacement = None

            # Interior A-U-A: absorb only short ambiguous bridges.
            if (
                u_bridge_limit > 0
                and run_len <= u_bridge_limit
                and left_cls in known_classes
                and left_cls == right_cls
            ):
                replacement = left_cls
            # Leading U-A: preserve continuity with the only known neighbour.
            elif i == 0 and right_cls in known_classes:
                replacement = right_cls
            # Trailing A-U: preserve continuity with the only known neighbour.
            elif j >= len(work) and left_cls in known_classes:
                replacement = left_cls

            if replacement is not None:
                for k in range(i, j):
                    work[k] = (work[k][0], replacement)

            i = j

        # idet can emit a few false TFF/BFF/P classifications at the very first
        # or last frames while the filter warms up.  Keep the legacy edge cleanup
        # for known classes only.  Never use this rule to absorb Undetermined.
        if work:
            first_cls = work[0][1]
            first_end = 1
            while first_end < len(work) and work[first_end][1] == first_cls:
                first_end += 1
            if (
                first_cls in known_classes
                and first_end < len(work)
                and first_end < min_frames
            ):
                next_cls = work[first_end][1]
                if next_cls in known_classes:
                    for k in range(0, first_end):
                        work[k] = (work[k][0], next_cls)

            last_cls = work[-1][1]
            last_start = len(work) - 1
            while last_start > 0 and work[last_start - 1][1] == last_cls:
                last_start -= 1
            if (
                last_cls in known_classes
                and last_start > 0
                and (len(work) - last_start) < min_frames
            ):
                prev_cls = work[last_start - 1][1]
                if prev_cls in known_classes:
                    for k in range(last_start, len(work)):
                        work[k] = (work[k][0], prev_cls)

        # Remove a very short KNOWN misclassification only when both sides agree.
        # Undetermined has already been handled by the explicit bridge rule above,
        # so it must not be swallowed here when A != B or when it is too long.
        cleaned = []
        i = 0
        while i < len(work):
            cls = work[i][1]
            j = i + 1
            while j < len(work) and work[j][1] == cls:
                j += 1

            if (
                cls in known_classes
                and (j - i) < min_frames
                and cleaned
                and j < len(work)
            ):
                left_cls = cleaned[-1][1]
                right_cls = work[j][1]
                if left_cls == right_cls and left_cls in known_classes:
                    for k in range(i, j):
                        cleaned.append((work[k][0], left_cls))
                    i = j
                    continue

            cleaned.extend(work[i:j])
            i = j

        return cleaned

    def _probe_video_fps(self, path, default=25.0):
        """取得場序實際 picture cadence；metadata 不可信時以 decoded PTS 校正。"""
        try:
            probe = self._field_probe_info(path)
            value = float(probe.get("fps") or 0.0)
            if value > 0.0:
                return value
        except Exception:
            pass

        try:
            data = self.read_media(path)
            value = normalize_fps(data.get("fps", ""))
            if value and value > 0.0:
                return float(value)
        except Exception:
            pass

        try:
            return max(1.0, float(default))
        except Exception:
            return 25.0

    def _probe_duration_seconds(self, path, fps_hint=25.0):
        """取得 MXF/長片可用的總時長。

        某些 MXF 的 format duration / stream duration 會比真正片長短幾個百分比，
        例如 15:00 被回報成約 14:21。不能再採用「第一個非零值就返回」。
        這裡同時收集 container / stream / frame-count 三種候選值，
        並採用合理候選中的最大值，避免修復輸出被提前截短。
        """
        candidates = []

        for entry in ("format=duration", "stream=duration"):
            try:
                raw = self._ffprobe_value(path, entry)
                value = float(raw) if raw else 0.0
                if value > 0.0:
                    candidates.append(value)
            except Exception:
                pass

        frame_duration = 0.0
        try:
            raw_frames = self._ffprobe_value(path, "stream=nb_frames")
            frames = float(raw_frames) if raw_frames else 0.0
            fps = float(fps_hint or 25.0)
            if frames > 0.0 and fps > 0.0:
                frame_duration = frames / fps
        except Exception:
            pass

        if frame_duration > 0.0 and candidates:
            reference = max(candidates)
            ratio = frame_duration / reference if reference > 0.0 else 1.0
            if 0.80 <= ratio <= 1.25:
                candidates.append(frame_duration)

        if not candidates:
            # No trustworthy duration metadata: count actual decoded pictures rather
            # than trusting stream nb_frames, which can be field-rate-like on MXF.
            try:
                decoded_frames = self._field_decoded_frame_count(path)
                fps = float(fps_hint or 25.0)
                if decoded_frames > 0 and fps > 0.0:
                    return float(decoded_frames) / fps
            except Exception:
                pass
            # Last-resort legacy fallback only when actual decoded counting is not
            # available (for example ffprobe missing).
            if frame_duration > 0.0:
                return frame_duration
            return 0.0

        # 允許正常 metadata 間的小幅差異，但排除 2x field-count 類離群值。
        smallest = min(candidates)
        sane = [
            v for v in candidates
            if smallest <= 0.0 or v <= smallest * 1.25
        ]
        return max(sane or candidates)

    def _analyze_field_order(self, path, progress_callback=None):
        """分析場序；整片 TFF/BFF/Progressive 也必須能被辨識並重構。"""
        ffmpeg = get_ffmpeg_path()
        if not ffmpeg:
            raise RuntimeError("找不到 ffmpeg.exe。請將 ffmpeg.exe 放在程式旁邊或 _internal 資料夾。")

        probe = self._field_probe_info(path)
        fps = float(probe.get("fps") or 0.0)
        if fps <= 0.0:
            fps = self._probe_video_fps(path, 25.0)
        duration = float(probe.get("duration") or 0.0)
        if duration <= 0.0:
            duration = self._probe_duration_seconds(path, fps)

        # 來源 field_order 只作 idet 完全不可用時的 fallback。
        source_field_order = normalize_field_order(probe.get("field_order", ""))
        if source_field_order not in ("Top Field First", "Bottom Field First", "Progressive"):
            source_field_order = ""

        # v1.2.0: adaptive field scan.  idet requires consecutive frames;
        # isolated 5-fps frame picking makes real interlace look Progressive.
        # The fast pass therefore analyses consecutive blocks (~70% duty cycle)
        # and skips only short gaps.  Any non-target/uncertain block is then
        # re-read frame-by-frame before the original smoothing/confidence/P logic.
        target_for_scan = normalize_repair_target(self.repair_target.get())
        target_cls_for_scan = {
            "Top Field First": "tff",
            "Bottom Field First": "bff",
            "Progressive": "progressive",
        }.get(target_for_scan, "tff")

        coarse_period = max(1, int(round(float(fps))))
        coarse_keep = max(1, int(math.ceil(coarse_period * 0.70)))
        coarse_enabled = bool(fps >= 9.0 and coarse_keep < coarse_period)

        sample_stride = 1
        samples, ffmpeg_duration = self._field_run_idet(
            path, fps=fps, progress_callback=progress_callback, sample_stride=1,
            coarse_period=(coarse_period if coarse_enabled else 0),
            coarse_keep=(coarse_keep if coarse_enabled else 0),
        )
        # If the first pass is a true full-frame pass (no coarse select), every
        # idet sample corresponds to one decoded source picture.  Preserve that
        # exact count so post-repair validation does not decode the source again.
        exact_source_decoded_frames = len(samples) if (samples and not coarse_enabled) else 0
        if progress_callback is not None:
            try:
                progress_callback("field_phase", "coarse_done", 0.0)
            except Exception:
                pass
        used_metadata_fallback = not bool(samples)

        # 某些 MXF 的 stream rate / nb_frames 與實際 decoded picture cadence 不一致。
        # FFmpeg 開檔時 stderr 的 Duration 可作額外時間軸證據，因此在較長時校正 duration。
        frame_tolerance = 1.0 / max(1.0, float(fps))
        if ffmpeg_duration > 0.0 and (
            duration <= 0.0 or ffmpeg_duration > duration + frame_tolerance
        ):
            duration = ffmpeg_duration
        if samples and fps > 0.0:
            sample_span = (max(idx for idx, _ in samples) + 1) / fps
            if sample_span > 0.0 and (
                duration <= 0.0 or sample_span > duration + frame_tolerance
            ):
                duration = sample_span

        # Refine only suspect coarse ranges.  Strong metadata disagreement forces
        # a full precise pass because metadata may indicate a whole-programme
        # conversion requirement and this path must remain maximally conservative.
        if samples and coarse_enabled and duration > 0.0:
            coarse_samples = [(int(i), c) for i, c in samples]
            frame_total_hint = max(1, int(round(duration * fps)))
            source_cls = {
                "Top Field First": "tff",
                "Bottom Field First": "bff",
                "Progressive": "progressive",
            }.get(source_field_order, "")
            force_full_precise = bool(source_cls and source_cls != target_cls_for_scan)

            suspect_windows = []
            if force_full_precise:
                suspect_windows = [(0, frame_total_hint)]
            else:
                i = 0
                buffer_frames = max(coarse_period, int(round(fps * 1.0)))
                while i < len(coarse_samples):
                    cls = coarse_samples[i][1]
                    j = i + 1
                    while j < len(coarse_samples) and coarse_samples[j][1] == cls:
                        j += 1
                    if cls != target_cls_for_scan:
                        a = max(0, coarse_samples[i][0] - buffer_frames)
                        b_base = coarse_samples[j][0] if j < len(coarse_samples) else frame_total_hint
                        b = min(frame_total_hint, b_base + buffer_frames)
                        suspect_windows.append((a, b))
                    i = j

                # Merge overlapping/nearby windows before launching FFmpeg.
                merged_windows = []
                for a, b in suspect_windows:
                    if merged_windows and a <= merged_windows[-1][1] + int(round(fps * 0.5)):
                        merged_windows[-1] = (merged_windows[-1][0], max(merged_windows[-1][1], b))
                    else:
                        merged_windows.append((a, b))
                suspect_windows = merged_windows

                # If most of the programme is suspect, one precise pass is cheaper
                # and safer than many seeks.
                suspect_frames = sum(max(0, b - a) for a, b in suspect_windows)
                if suspect_frames >= frame_total_hint * 0.65:
                    suspect_windows = [(0, frame_total_hint)]

            if suspect_windows:
                # Expand coarse observations into a dense provisional timeline.
                # Precise windows below overwrite every suspect frame, so inferred
                # values are used only for clearly target-matching normal regions.
                dense = [target_cls_for_scan] * frame_total_hint
                for k, (idx, cls) in enumerate(coarse_samples):
                    a = max(0, min(frame_total_hint, int(idx)))
                    b = (coarse_samples[k + 1][0] if k + 1 < len(coarse_samples) else frame_total_hint)
                    b = max(a, min(frame_total_hint, int(b)))
                    if b > a:
                        dense[a:b] = [cls] * (b - a)

                total_refine_frames = max(1, sum(max(0, wb - wa) for wa, wb in suspect_windows))
                refined_before = 0
                if progress_callback is not None:
                    try:
                        progress_callback("field_phase", "refining", 0.0)
                        progress_callback("field_refine_progress", "0/%d" % total_refine_frames, 0.0)
                    except Exception:
                        pass

                for wa, wb in suspect_windows:
                    if self.stop_requested:
                        break
                    start_sec = wa / float(fps)
                    window_frames = max(1, wb - wa)
                    window_sec = max(0.05, window_frames / float(fps))

                    def _refine_progress(_key, _value, _elapsed, _base=refined_before,
                                         _wf=window_frames, _total=total_refine_frames):
                        if progress_callback is None:
                            return
                        try:
                            local_done = 0.0
                            if _key == "analysis_sample":
                                local_done = max(0.0, min(float(_wf), float(_value)))
                            elif _key == "frame":
                                local_done = max(0.0, min(float(_wf), float(_value)))
                            elif _key in ("out_time_ms", "out_time_us"):
                                seconds = max(0.0, float(_value) / 1000000.0)
                                local_done = max(0.0, min(float(_wf), seconds * float(fps)))
                            elif _key == "progress" and str(_value).lower() == "end":
                                local_done = float(_wf)
                            else:
                                return
                            done = min(float(_total), float(_base) + local_done)
                            progress_callback("field_refine_progress", "%.3f/%d" % (done, _total), _elapsed)
                        except Exception:
                            pass

                    precise, _local_duration = self._field_run_idet(
                        path, fps=fps, start=start_sec, duration=window_sec,
                        progress_callback=_refine_progress, sample_stride=1,
                    )
                    # A single precise window spanning the full programme is an
                    # exact decoded-picture pass.  Reuse its count later instead
                    # of running a second full ffprobe decode before validation.
                    if (
                        len(suspect_windows) == 1
                        and wa <= 0
                        and wb >= frame_total_hint
                        and precise
                    ):
                        exact_source_decoded_frames = len(precise)
                    for local_idx, cls in precise:
                        absolute_idx = wa + int(local_idx)
                        if 0 <= absolute_idx < frame_total_hint:
                            dense[absolute_idx] = cls
                    refined_before += window_frames
                    if progress_callback is not None:
                        try:
                            progress_callback(
                                "field_refine_progress",
                                "%d/%d" % (min(refined_before, total_refine_frames), total_refine_frames),
                                0.0,
                            )
                        except Exception:
                            pass

                if progress_callback is not None:
                    try:
                        progress_callback("field_phase", "refine_done", 0.0)
                    except Exception:
                        pass
                samples = [(idx, cls) for idx, cls in enumerate(dense)]
                sample_stride = 1
            else:
                # Entire coarse timeline agrees with the requested target.  Convert
                # the sparse observations to a dense target timeline so all existing
                # downstream code stays frame-exact without another FFmpeg pass.
                if progress_callback is not None:
                    try:
                        progress_callback("field_phase", "refine_skipped", 0.0)
                    except Exception:
                        pass
                samples = [(idx, target_cls_for_scan) for idx in range(frame_total_hint)]
                sample_stride = 1

        # idet 的 metadata 在部分 Windows FFmpeg build / 某些 ProRes/MXF
        # 組合中可能不輸出 current_frame。這時不能把「沒有 samples」
        # 錯誤解讀成「沒有場序」；只要 ffprobe 已明確告知 TFF/BFF/P，
        # 就用整片 dominant order 作為 fallback。
        if samples:
            samples = [(int(_idx), cls) for _idx, cls in samples]
        elif source_field_order:
            fallback_cls = {
                "Top Field First": "tff",
                "Bottom Field First": "bff",
                "Progressive": "progressive",
            }[source_field_order]
            frame_total = max(1, int(round(duration * fps))) if duration else 1
            samples = [
                (i * sample_stride, fallback_cls)
                for i in range(max(1, (frame_total + sample_stride - 1) // sample_stride))
            ]
        else:
            raise RuntimeError("FFmpeg idet 沒有產生可用的 TFF/BFF/Progressive 分析資料，而且 ffprobe 也沒有 field_order。")

        # 建立整片權威 frame_total 必須早於任何 raw/Undetermined 區段運算。
        # 上一版把這段留在 Progressive 驗證 helper 之後，令正常有 idet samples
        # 的路徑在 Undetermined context guard 先使用 frame_total 而觸發
        # UnboundLocalError。duration 仍以 probe/FFmpeg 校正後值為權威。
        if duration > 0.0:
            frame_total = max(1, int(round(duration * fps)))
        else:
            frame_total = max((idx for idx, _ in samples), default=0) + max(1, int(sample_stride))
            duration = frame_total / fps if fps else 0.0

        min_seconds = 1.00
        try:
            min_seconds = max(0.10, float(self.repair_min_seconds.get()))
        except Exception:
            pass
        # 分析與修復門檻完全分離。
        # 分析必須保留所有達到最低時長的 TFF/BFF/Progressive 區段及其實際
        # 一致度，不可以再用隱藏的 50% floor 先行刪除候選。真正是否修復，
        # 只由分析完成頁的「修復類型 + 修復一致度選擇」決定。
        # Progressive 的 Motion / Field-Temporal 二次驗證仍會記錄作技術參考，
        # 但不會覆蓋使用者在修復頁的明確選擇。
        analysis_reference_confidence = 0.90
        candidate_confidence_floor = 0.0
        confidence = candidate_confidence_floor

        min_sample_count = max(2, int(math.ceil(min_seconds * fps / sample_stride - 1e-9)))

        # 保存 idet 原始逐幀判定。
        # 後面的 smooth 只用來建立穩定區段邊界；「區段一致度」必須回頭
        # 從原始資料計算，否則 smooth 後同一 run 內自然幾乎全部相同，
        # 百分比就會失去意義而長期顯示 100%。
        raw_samples = list(samples)

        # Preserve raw Undetermined runs as technical references before smoothing.
        # These references MUST NOT feed back into TFF/BFF/P classification.
        # Main GUI/report policy is intentionally more permissive:
        #   <1s  -> suppress;
        #   1–2s -> context-sensitive (same-side continuity can be absorbed as
        #           transition/effect; different neighbours remain manual review);
        #   >2s  -> always keep as manual-review information.
        undetermined_reference_segments = []
        _u = 0
        while _u < len(raw_samples):
            if raw_samples[_u][1] != "undetermined":
                _u += 1
                continue
            _v = _u + 1
            while _v < len(raw_samples) and raw_samples[_v][1] == "undetermined":
                _v += 1
            _start_frame = int(raw_samples[_u][0])
            _end_frame = min(frame_total, int(raw_samples[_v][0]) if _v < len(raw_samples) else frame_total)
            _dur = max(0.0, min(duration, _end_frame / fps) - (_start_frame / fps))
            _left = raw_samples[_u - 1][1] if _u > 0 else None
            _right = raw_samples[_v][1] if _v < len(raw_samples) else None
            if _dur >= 1.0:
                # <=2 秒 U 採 bridge 規則：
                # A-U-A（A 為 T/B/P）屬同一穩定區段內的短暫不確定，核心分類會
                # 把 U 併回 A；A-U-B 則無法判定 U 應歸前或後，保持獨立供人工複核。
                # 片頭／片尾只有單側上下文時，核心分類會延續唯一已知鄰居；
                # raw U 仍保留在技術參考與一致度分母，避免被誤算成 100%。
                if _dur <= 2.0:
                    _left_known = _left in ("tff", "bff", "progressive")
                    _right_known = _right in ("tff", "bff", "progressive")
                    if _left_known and _right_known and _left == _right:
                        _policy = "same_class_bridge"
                        _note = "短暫場序不確定位於相同場序兩側，已視為同一場序區段的過渡證據；不獨立列主畫面"
                        _main = False
                    elif _left_known and _right_known and _left != _right:
                        _policy = "short_review"
                        _note = "短暫場序不確定位於兩個不同場序之間；無法可靠歸前或歸後，建議人工複核"
                        _main = True
                    else:
                        _policy = "edge_context"
                        _note = "短暫場序不確定位於片頭／片尾或只有單側上下文；不硬判歸屬，只保留技術參考"
                        _main = False
                else:
                    _policy = "long_review"
                    _note = "持續超過 2 秒仍無法可靠確定場序；建議人工複核"
                    _main = True
                undetermined_reference_segments.append({
                    "start_frame": _start_frame,
                    "end_frame": _end_frame,
                    "start": _start_frame / fps,
                    "end": min(duration, _end_frame / fps),
                    "duration": _dur,
                    "left_class": _left or "",
                    "right_class": _right or "",
                    "policy": _policy,
                    "main_display": _main,
                    "note": _note,
                })
            _u = _v

        # Undetermined bridge policy：只把 <=2 秒且左右為相同可靠場序的
        # A-U-A 併回 A；A-U-B 保持獨立；片頭 U-A / 片尾 A-U 延續唯一
        # 已知鄰居以保持舊版穩定分類。raw U 仍保存供 TXT / Excel 技術參考，
        # 並保留在一致度分母內。
        undetermined_bridge_frames = max(1, int(math.ceil(2.0 * fps / max(1, sample_stride) - 1e-9)))
        samples = self._smooth_field_runs(
            samples,
            min_frames=min_sample_count,
            undetermined_context_max_frames=undetermined_bridge_frames,
        )

        raw_class_by_frame = {
            int(frame_idx): cls
            for frame_idx, cls in raw_samples
        }

        def raw_segment_ratio(start_frame, end_frame, expected_cls):
            """以 idet 原始逐幀資料計算此區段的分類一致度。

            Undetermined 亦屬一次實際觀察，必須留在分母。否則例如
            60 幀 Progressive + 40 幀 Undetermined 會被錯算成 100% P。
            """
            values = []
            for frame_idx in range(int(start_frame), int(end_frame), max(1, int(sample_stride))):
                cls = raw_class_by_frame.get(frame_idx)
                if cls in ("tff", "bff", "progressive", "undetermined"):
                    values.append(cls)
            if not values:
                return 0.0
            return (
                float(sum(1 for cls in values if cls == expected_cls))
                / float(len(values))
            )

        progressive_validation_cache = {}

        def validate_progressive_candidate(start_frame, end_frame, idet_ratio):
            """Confirm a Progressive run with an independent temporal-field check."""
            key = (int(start_frame), int(end_frame))
            if key in progressive_validation_cache:
                return progressive_validation_cache[key]

            # If both stream metadata and idet independently say Progressive,
            # that is already two independent layers.  This also allows a
            # completely static genuine-P clip to remain repairable.
            if source_field_order == "Progressive" and float(idet_ratio) >= confidence:
                result = {
                    "state": "progressive",
                    "confirmed": True,
                    "reason": "Metadata 與逐幀 idet 均支持 Progressive",
                    "temporal_ratio": None,
                    "motion_score": None,
                }
            else:
                result = self._field_progressive_temporal_probe(
                    path, start_frame / fps, min(duration, end_frame / fps), fps=fps
                )
                result = dict(result or {})
                result["confirmed"] = result.get("state") == "progressive"

                # Strong interlaced stream metadata is supporting context, not
                # an override.  It is reported to the user when temporal evidence
                # also says the candidate is interlaced-like.
                if result.get("state") == "interlaced" and source_field_order in (
                    "Top Field First", "Bottom Field First"
                ):
                    result["reason"] = (
                        result.get("reason", "")
                        + "；Metadata 同時標示 %s" % source_field_order
                    )
            progressive_validation_cache[key] = result
            progressive_phase["done"] = min(progressive_phase.get("total", 0), progressive_phase.get("done", 0) + 1)
            if progress_callback is not None and progressive_phase.get("total", 0) > 0:
                try:
                    progress_callback(
                        "progressive_validation",
                        "%d/%d" % (progressive_phase["done"], progressive_phase["total"]),
                        0.0,
                    )
                except Exception:
                    pass
            return result

        # duration / frame_total 已在 raw 區段與 Undetermined context guard
        # 之前建立；此處只取得最終修復目標，避免後段重新改寫時間軸基準。
        target = normalize_repair_target(self.repair_target.get())

        # 場序統一規則：
        # - 目標 Progressive：TFF/BFF 都需要轉 Progressive。
        # - 目標 TFF：BFF 與 Progressive 都需要轉 TFF。
        # - 目標 BFF：TFF 與 Progressive 都需要轉 BFF。
        #
        # Progressive 不再只是「顯示但不修復」；只要使用者的目標是
        # TFF/BFF，就會把已確認的 Progressive 區段列入 anomalies，
        # 後續只重構這些異常段，正常段仍不動。
        if target == "Progressive":
            unwanted = {"tff", "bff"}
        elif target == "Top Field First":
            unwanted = {"bff", "progressive"}
        else:
            unwanted = {"tff", "progressive"}

        # 進度 Phase 2：預先計算真正需要做 Progressive 二次驗證的候選數。
        # 主 idet 只佔整體 0-75%；P temporal probe 佔 75-95%。
        # 這樣新增多證據驗證後不會出現 UI 長時間停在 0% / 75% 後突然 100%。
        progressive_phase = {"done": 0, "total": 0}
        _pi = 0
        while _pi < len(samples):
            _cls = samples[_pi][1]
            _pj = _pi + 1
            while _pj < len(samples) and samples[_pj][1] == _cls:
                _pj += 1
            if _cls == "progressive" and _cls in unwanted:
                _start = samples[_pi][0]
                _end = min(frame_total, samples[_pj][0] if _pj < len(samples) else frame_total)
                _length = max(0, _end - _start)
                if _length >= max(1, int(math.ceil(min_seconds * fps - 1e-9))):
                    _ratio = raw_segment_ratio(_start, _end, _cls)
                    if _ratio >= confidence:
                        progressive_phase["total"] += 1
            _pi = _pj
        if progress_callback is not None:
            try:
                progress_callback("field_phase", "candidates_ready", 0.0)
                if progressive_phase["total"]:
                    progress_callback("progressive_validation", "0/%d" % progressive_phase["total"], 0.0)
                else:
                    progress_callback("progressive_validation", "1/1", 0.0)
            except Exception:
                pass

        anomalies = []
        i = 0
        while i < len(samples):
            cls = samples[i][1]
            j = i + 1
            while j < len(samples) and samples[j][1] == cls:
                j += 1

            if cls in unwanted:
                start_frame = samples[i][0]
                # end_frame 採「下一個場序區段的第一幀」作為 exclusive Out。
                # 例如 25fps：BFF 由 00:00:08:07 開始、下一段於 00:00:09:10
                # 開始，則 BFF 正確區間就是 08:07 - 09:10；不能再 +1 frame。
                end_frame = min(
                    frame_total,
                    samples[j][0] if j < len(samples) else frame_total
                )
                known = [c for _, c in samples[i:j] if c in ("tff", "bff", "progressive")]
                length_frames = max(0, end_frame - start_frame)
                if known and length_frames >= max(1, int(math.ceil(min_seconds * fps - 1e-9))):
                    # 真正的判定一致度：使用 smooth 前的 idet 原始逐幀分類。
                    # 這裡只建立「可供使用者選擇」的候選，不能再用任何隱藏
                    # percentage floor 或 Progressive 二次驗證先行否決。
                    ratio = raw_segment_ratio(start_frame, end_frame, cls)
                    detected = {
                        "tff": "Top Field First",
                        "bff": "Bottom Field First",
                        "progressive": "Progressive",
                    }[cls]
                    progressive_check = None
                    if cls == "progressive":
                        progressive_check = validate_progressive_candidate(start_frame, end_frame, ratio)
                        if self.stop_requested:
                            break
                    segment_end = min(duration, end_frame / fps)
                    segment_duration = max(0.0, segment_end - (start_frame / fps))
                    anomaly = {
                        "start_frame": start_frame,
                        "end_frame": end_frame,
                        "start": start_frame / fps,
                        "end": segment_end,
                        "duration": segment_duration,
                        "detected": detected,
                        "target": target,
                        "confidence": ratio,
                        "repairable": True,
                    }
                    if progressive_check:
                        anomaly["progressive_validation"] = progressive_check
                        anomaly["progressive_validation_advisory"] = True
                    anomalies.append(anomaly)
            i = j

        merged = []
        for item in anomalies:
            # 只合併真正相接/重疊的同類異常。
            # 舊版容許跨 0.25 秒 gap 合併，若 gap 其實是正常 TFF/BFF，
            # 修復器就可能把正常小段一併處理。現在正常段一律保留。
            if (
                merged
                and int(item.get("start_frame", 0)) <= int(merged[-1].get("end_frame", 0))
                and item["detected"] == merged[-1]["detected"]
            ):
                merged[-1]["end"] = max(merged[-1]["end"], item["end"])
                merged[-1]["duration"] = merged[-1]["end"] - merged[-1]["start"]
                merged[-1]["end_frame"] = max(merged[-1]["end_frame"], item["end_frame"])
                merged[-1]["confidence"] = min(
                    merged[-1]["confidence"], item["confidence"]
                )
            else:
                merged.append(dict(item))

        # UI 顯示用：保留所有經過平滑後的場序區段，包括 Progressive。
        # 「顯示區段」與「需要修復」必須分離：Progressive 即使符合目標，
        # 也應該在分析結果中明確列出，而不是顯示成 0 段。
        display_segments = []
        class_names = {
            "tff": "Top Field First",
            "bff": "Bottom Field First",
            "progressive": "Progressive",
            "undetermined": "場序無法確定",
        }
        i = 0
        while i < len(samples):
            cls = samples[i][1]
            j = i + 1
            while j < len(samples) and samples[j][1] == cls:
                j += 1
            start_frame = samples[i][0]
            # 顯示區段與 anomaly 使用相同的 frame-exact exclusive Out，
            # 避免畫面顯示與實際修復範圍相差一幀。
            end_frame = min(
                frame_total,
                samples[j][0] if j < len(samples) else frame_total,
            )
            if end_frame > start_frame:
                segment_duration = min(duration, end_frame / fps) - start_frame / fps
                # TFF/BFF/P 服從用戶的「最少異常長度」。Undetermined 使用
                # 獨立上下文規則：<1s 不進主結果；1–2s 若仍存在，表示前後
                # 場序不同而沒有被 transition guard 吸收，只作人工複核；>2s
                # 才視為持續的不確定區段。任何 Undetermined 都不自動修復。
                if cls == "undetermined":
                    if segment_duration < 1.0:
                        i = j
                        continue
                elif segment_duration < min_seconds:
                    i = j
                    continue
                # UI 百分比是「原始 idet 區段一致度」，不是機率式 confidence。
                confidence_ratio = raw_segment_ratio(start_frame, end_frame, cls)
                detected_name = class_names.get(cls, cls)
                progressive_check = None
                if cls == "progressive" and detected_name != target:
                    # 保持檢測結果為 Progressive。二次 temporal probe 只作技術
                    # 參考，不再把使用者可見分類改成 P-like，也不否決修復選擇。
                    progressive_check = validate_progressive_candidate(
                        start_frame, end_frame, confidence_ratio
                    )
                if cls == "undetermined":
                    if segment_duration <= 2.0:
                        reason = "短暫場序不確定，可能位於轉場／效果或場序切換邊界；只供人工複核"
                    else:
                        reason = "持續超過 2 秒仍無法可靠確定場序；只供人工複核"
                elif detected_name == target:
                    reason = "符合目標場序"
                elif progressive_check and progressive_check.get("confirmed"):
                    reason = "已建立修復候選；P 二次驗證支持：%s" % progressive_check.get("reason", "場間時間證據支持")
                elif progressive_check:
                    reason = "已建立修復候選；P 二次驗證只作參考：%s" % progressive_check.get("reason", "證據不足")
                else:
                    reason = "已建立可供修復頁選擇的異常候選"
                display_segments.append({
                    "start_frame": start_frame,
                    "end_frame": end_frame,
                    "start": start_frame / fps,
                    "end": min(duration, end_frame / fps),
                    "duration": min(duration, end_frame / fps) - start_frame / fps,
                    "detected": detected_name,
                    "target": target,
                    "confidence": confidence_ratio,
                    "confidence_threshold": analysis_reference_confidence,
                    "needs_repair": False,
                    "repair_reason": reason,
                    "progressive_validation": progressive_check,
                    "raw_detected": class_names.get(cls, cls),
                    "undetermined_context": (
                        "short_review" if cls == "undetermined" and segment_duration <= 2.0
                        else ("long_review" if cls == "undetermined" else "")
                    ),
                })
            i = j

        def mark_display_repairs(segments, repair_ranges):
            """依實際修復範圍標記 UI 區段；不用 start/end 完全相等。"""
            for segment in segments:
                segment["needs_repair"] = False
                if segment.get("detected") in ("場序無法確定", "Undetermined", "Progressive-like（未確認）"):
                    continue
                seg_a = float(segment.get("start", 0.0))
                seg_b = float(segment.get("end", seg_a))
                for anomaly in repair_ranges:
                    if segment.get("detected") != anomaly.get("detected"):
                        continue
                    a = float(anomaly.get("start", 0.0))
                    b = float(anomaly.get("end", a))
                    overlap = min(seg_b, b) - max(seg_a, a)
                    if overlap > 0.0005:
                        segment["needs_repair"] = True
                        segment["repair_reason"] = "符合有效異常條件；已列入實際修復範圍"
                        break

        # 只有真正需要重構的區段才標記 needs_repair。
        mark_display_repairs(display_segments, merged)

        # 只有「idet 完全沒有資料、確實使用 metadata fallback」時，才允許
        # metadata 建立整片重構。正常情況以逐幀 idet 為權威，避免 metadata
        # 寫錯時把本來正確的大部分畫面整片重構。
        # Progressive -> TFF/BFF 也屬於真正需要重構的轉換。
        whole_file_needs_rebuild = False
        if used_metadata_fallback and source_field_order:
            if target == "Progressive":
                whole_file_needs_rebuild = source_field_order in ("Top Field First", "Bottom Field First")
            elif target == "Top Field First":
                whole_file_needs_rebuild = source_field_order in ("Bottom Field First", "Progressive")
            else:
                whole_file_needs_rebuild = source_field_order in ("Top Field First", "Progressive")
        if not merged and whole_file_needs_rebuild:
            merged = [{
                "start_frame": 0,
                "end_frame": frame_total,
                "start": 0.0,
                "end": duration,
                "duration": duration,
                "detected": source_field_order,
                "target": target,
                "confidence": raw_segment_ratio(
                    0,
                    frame_total,
                    {
                        "Top Field First": "tff",
                        "Bottom Field First": "bff",
                        "Progressive": "progressive",
                    }.get(source_field_order, "progressive"),
                ) or 1.0,
                "repairable": True,
                "full_rebuild": True,
            }]

        # 整片 fallback 若在這裡才建立，重新同步 UI 顯示標記。
        mark_display_repairs(display_segments, merged)

        counts = {
            "Top Field First": sum(1 for _, c in samples if c == "tff") * sample_stride,
            "Bottom Field First": sum(1 for _, c in samples if c == "bff") * sample_stride,
            "Progressive": sum(1 for _, c in samples if c == "progressive") * sample_stride,
            "Undetermined": sum(max(0, int(seg.get("end_frame",0))-int(seg.get("start_frame",0))) for seg in display_segments if seg.get("detected")=="場序無法確定"),
        }

        # 只有本次確實是 metadata fallback 時才以 metadata 補整片 frame count。
        # 一旦有真實 idet 樣本，統計亦保持 idet 結果，避免 metadata 寫錯
        # 時污染「實際內容」判斷與後面的 Progressive/Interlaced 決策。
        if used_metadata_fallback and source_field_order:
            key = source_field_order
            known_total = (
                counts["Top Field First"]
                + counts["Bottom Field First"]
                + counts["Progressive"]
            )
            if known_total == 0:
                counts[key] = frame_total
            elif counts.get(key, 0) == 0 and known_total < max(1, frame_total // 2):
                counts[key] = frame_total

        total_count = sum(counts.values())
        if total_count > frame_total and total_count > 0:
            scale = float(frame_total) / float(total_count)
            counts = {k: int(round(v * scale)) for k, v in counts.items()}

        if exact_source_decoded_frames > 0:
            try:
                self._field_frame_count_cache[os.path.abspath(path)] = int(exact_source_decoded_frames)
            except Exception:
                pass

        if progress_callback is not None:
            try:
                progress_callback("field_finalize", "done", 0.0)
            except Exception:
                pass

        return {
            # Internal source reference used only by post-repair integrity checks.
            "source_path": path,
            "fps": fps,
            "duration": duration,
            # Authoritative source timeline size for post-repair integrity checks.
            "source_frame_count": int(frame_total),
            # Exact only when the analysis already decoded every source picture.
            # Zero means post-repair validation must obtain an exact count itself.
            "source_decoded_frame_count": int(exact_source_decoded_frames or 0),
            "samples": samples,
            "counts": counts,
            "segments": display_segments,
            "anomalies": merged,
            "target": target,
            "sample_stride": sample_stride,
            "source_field_order": source_field_order,
            "used_metadata_fallback": bool(used_metadata_fallback),
            "min_seconds": float(min_seconds),
            # 舊欄位保留給報告/相容舊資料；代表分析前輸入的預設修復百分比，
            # 不再代表「低於此值就從分析中消失」。
            "confidence_threshold": float(analysis_reference_confidence),
            "analysis_reference_confidence": float(analysis_reference_confidence),
            "candidate_confidence_floor": float(candidate_confidence_floor),
            "undetermined_reference_segments": undetermined_reference_segments,
            "undetermined_suppress_seconds": 1.0,
            "undetermined_context_seconds": 2.0,
            "detection_method": "自適應多層場序判斷（連續區塊快速掃描 + 可疑區逐幀 idet + run consistency + Progressive Motion/Field-Temporal 二次驗證 + Undetermined same-class bridge/context guard）",
        }

    @staticmethod
    def _bitrate_to_bps(value):
        text = str(value or "").strip().replace(",", "")
        m = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*(k|m|g)?(?:b/s|bps)?", text, re.IGNORECASE)
        if not m:
            return 0
        try:
            number = float(m.group(1))
            unit = (m.group(2) or "").lower()
            factor = {"k": 1000.0, "m": 1000000.0, "g": 1000000000.0}.get(unit, 1.0)
            # MediaInfo may omit the unit while returning a raw integer.
            return int(round(number * factor))
        except Exception:
            return 0

    def _encoder_for_repair(self, path, target="Top Field First"):
        """選擇與來源 codec 相容的重新編碼器。"""
        data = self.read_media(path)
        raw_text = str(data.get("raw_text", "") or "")
        codec_text = " %s %s %s " % (
            data.get("format", ""),
            data.get("commercial_name", ""),
            data.get("codec_id", ""),
        )

        # IMPORTANT: MXF MediaInfo commonly reports:
        #   Format          : AVC
        #   Commercial name : AVC-Intra 100
        # Some MediaInfo/Windows builds used by the packaged application
        # fail to carry Commercial name into data["commercial_name"], even
        # though it is present in raw_text.  The previous code then normalized
        # only to generic "AVC", fell through to the normal H.264 CRF=23 path,
        # and produced the user's 21.4 Mb/s High 4:2:2@L4 file instead of
        # AVC-Intra 100.
        #
        # For MXF, treat the authoritative MediaInfo field itself as the
        # codec signal.  This is deliberately field-based, not a broad
        # "AVC" keyword guess.
        is_mxf_source = (
            str(data.get("general_format", "")).strip().lower() == "mxf"
            or str(data.get("file_extension", "")).strip().lower() == ".mxf"
            or bool(re.search(r"(?im)^\s*format\s*:\s*MXF\s*$", raw_text))
        )
        raw_commercial = ""
        commercial_match = re.search(
            r"(?im)^\s*commercial\s+name\s*:\s*(.+?)\s*$",
            raw_text,
        )
        if commercial_match:
            raw_commercial = clean_text(commercial_match.group(1))

        raw_avci100 = bool(re.search(
            r"(?i)\bAVC[- ]?Intra[- ]?100\b",
            raw_commercial or raw_text,
        ))
        codec_text = "%s %s %s %s" % (
            codec_text,
            raw_commercial,
            data.get("profile", ""),
            data.get("format", ""),
        )
        codec = normalize_codec(codec_text).lower()
        chroma = normalize_chroma(data.get("chroma", ""))
        bit_depth = digits(data.get("bit_depth", ""))
        progressive_output = normalize_repair_target(target) == "Progressive"

        if codec in ("avc", "h264") or codec.startswith("avc-intra") or codec.startswith("xavc"):
            # For AVC-Intra sources, explicitly request the AVC-Intra 100
            # class when the source is AVC-Intra 100.  This prevents a repair
            # from silently turning the MXF into a generic High 4:2:2 Intra.
            is_avci = (
                codec.startswith("avc-intra")
                or "avc-intra" in codec_text.lower()
                or (is_mxf_source and raw_avci100)
            )
            args = ["-c:v", "libx264", "-preset", "medium",
                    "-g", "1", "-bf", "0", "-sc_threshold", "0"]
            if chroma == "4:2:2":
                args += ["-profile:v", "high422"]
            elif chroma == "4:4:4":
                args += ["-profile:v", "high444"]
            else:
                args += ["-profile:v", "high"]
            if bit_depth == "10":
                if chroma == "4:2:2":
                    args += ["-pix_fmt", "yuv422p10le"]
                elif chroma == "4:4:4":
                    args += ["-pix_fmt", "yuv444p10le"]
                else:
                    args += ["-pix_fmt", "yuv420p10le"]
            if not progressive_output:
                args += ["-flags", "+ilme+ildct"]
                args += ["-top", "1" if normalize_repair_target(target) == "Top Field First" else "0"]

            if is_avci:
                # AVC-Intra 100：優先使用來源 Video bit rate。
                # 若來源沒有提供 Bit rate，才回退到 100 Mb/s。
                video_bps = self._bitrate_to_bps(data.get("video_bitrate", ""))
                overall_bps = self._bitrate_to_bps(data.get("overall_bitrate", ""))

                # Raw MediaInfo fallback for the packaged Windows build.
                # The user's source is known to be 114 Mb/s Video / 120 Mb/s
                # Overall.  Prefer the actual Video field whenever available.
                if video_bps <= 0:
                    m_vbr = re.search(
                        r"(?im)^\s*bit\s+rate\s*:\s*([0-9.]+\s*(?:k|m|g)?b/s)\s*$",
                        raw_text,
                    )
                    if m_vbr:
                        video_bps = self._bitrate_to_bps(m_vbr.group(1))

                # AVC-Intra 100 的標準 Video rate 約 100 Mb/s。
                # MediaInfo 的 Overall bit rate 可能約 120 Mb/s（含音訊、
                # MXF/KLV 等開銷），不能直接把 Overall 當成 Video rate；
                # 但如果 Video rate 缺失，就以合理的 AVC-Intra 100 目標值
                # 100 Mb/s 輸出，而不是落到很低的 fallback。
                # AVC-Intra 100 的影像碼率以來源 Video bitrate 為基準；你的素材為 114 Mb/s。
                # 不把 MediaInfo 的 Overall bit rate 直接當成 Video bit rate；
                # Overall 還包含音訊、MXF/KLV 等容器開銷。
                #
                # 之前「讀來源 Video bit rate 再決定 target」在不同 MediaInfo
                # 輸出格式下可能取得錯誤/不完整值，導致成品碼率異常偏低。
                # AVC-Intra 100 這裡直接鎖定 100 Mb/s，並讓 x264 的
                # AVC-Intra class + CBR/HRD 一起約束實際編碼碼率。
                # 使用者提供的原始 AVC-Intra 100 MXF：Video 114 Mb/s CBR，
                # Overall 120 Mb/s。直接鎖定 video stream bitrate，避免某些
                # Windows/x264 build 因只使用 avcintra-class 而降到 20~30 Mb/s。
                target_bps = video_bps if 105000000 <= video_bps <= 125000000 else 114000000
                target_kbps = int(round(target_bps / 1000.0))
                target_mbps = target_bps / 1000000.0
                params = (
                    "avcintra-class=100:"
                    "bitrate=%d:keyint=1:keyint_min=1:scenecut=0:"
                    "bframes=0:force-cfr=1:rc-lookahead=0:mbtree=0:"
                    "nal-hrd=cbr:vbv-maxrate=%d:vbv-bufsize=%d"
                    % (target_kbps, target_kbps, target_kbps * 2)
                )
                if not progressive_output:
                    params += ":interlaced=1:tff=%d" % (
                        1 if normalize_repair_target(target) == "Top Field First" else 0
                    )

                args += [
                    "-coder", "0",
                    "-tune", "psnr",
                    "-avcintra-class", "100",
                    "-b:v", "%d" % target_bps,
                    "-minrate", "%d" % target_bps,
                    "-maxrate", "%d" % target_bps,
                    "-bufsize", "%d" % (target_bps * 2),
                    "-x264-params", params,
                    "-vtag", "ai12",
                ]
                # MXF mux rate 以來源約 120 Mb/s 的級別控制；不把
                # Overall bitrate 當成 Video bitrate，但避免容器輸出掉到
                # 過低的 VBR 封裝速率。
                # 不強制 MXF muxrate；由 muxer 依實際影音串流與 KLV 開銷計算，
                # 避免 muxrate 與 x264 的 CBR 設定互相干擾。
            else:
                args += ["-x264-params", "keyint=1:scenecut=0:bframes=0"]
            return args

        if codec == "hevc":
            # HEVC / H.265：允許 Progressive <-> TFF/BFF 自動重編碼。
            # 優先保持來源像素格式與 bitrate；不把 4K HEVC 成品降成 H.264。
            args = ["-c:v", "libx265", "-preset", "medium"]

            if bit_depth == "10":
                if chroma == "4:2:2":
                    args += ["-pix_fmt", "yuv422p10le"]
                elif chroma == "4:4:4":
                    args += ["-pix_fmt", "yuv444p10le"]
                else:
                    args += ["-pix_fmt", "yuv420p10le"]
            else:
                if chroma == "4:2:2":
                    args += ["-pix_fmt", "yuv422p"]
                elif chroma == "4:4:4":
                    args += ["-pix_fmt", "yuv444p"]
                else:
                    args += ["-pix_fmt", "yuv420p"]

            video_bps = self._bitrate_to_bps(data.get("video_bitrate", ""))
            if video_bps > 0:
                args += [
                    "-b:v", str(int(video_bps)),
                    "-maxrate", str(int(round(video_bps * 1.15))),
                    "-bufsize", str(int(round(video_bps * 2.0))),
                ]
            else:
                # 沒有可靠 bitrate 時採品質模式，避免亂猜固定碼率。
                args += ["-crf", "18"]

            x265_params = ["repeat-headers=1"]
            if not progressive_output:
                # x265 interlace: 1 = TFF, 2 = BFF。
                x265_params.append(
                    "interlace=%d"
                    % (1 if normalize_repair_target(target) == "Top Field First" else 2)
                )
                args += [
                    "-top",
                    "1" if normalize_repair_target(target) == "Top Field First" else "0",
                ]

            args += ["-x265-params", ":".join(x265_params)]

            # MP4/MOV HEVC 採 hvc1，兼容 QuickTime / Apple 系統與常見 NLE。
            if str(path).lower().endswith((".mp4", ".mov", ".m4v")):
                args += ["-tag:v", "hvc1"]

            return args

        if codec == "mpeg-2":
            args = ["-c:v", "mpeg2video", "-qscale:v", "2", "-g", "1", "-bf", "0"]
            if not progressive_output:
                args += [
                    "-flags", "+ilme+ildct",
                    "-top", "1" if normalize_repair_target(target) == "Top Field First" else "0",
                ]
            return args

        if codec == "prores":
            profile_text = str(data.get("profile", "")).lower()
            # FFmpeg prores_ks profile values:
            # 0=Proxy, 1=LT, 2=422, 3=HQ, 4=4444, 5=4444 XQ.
            if "4444 xq" in profile_text or "4444xq" in profile_text:
                profile_name = "5"
            elif "4444" in profile_text:
                profile_name = "4"
            elif "hq" in profile_text:
                profile_name = "3"
            elif "lt" in profile_text:
                profile_name = "1"
            elif "proxy" in profile_text:
                profile_name = "0"
            else:
                profile_name = "2"

            args = ["-c:v", "prores_ks", "-profile:v", profile_name]
            if not progressive_output:
                # ProRes encoder 必須同時收到 interlaced flags + field order。
                # 僅靠 filtergraph 的 setfield/fieldorder，encoder 仍可能
                # 把輸出寫成原本的場序或 progressive。
                args += [
                    "-flags", "+ilme+ildct",
                    "-top", "1" if normalize_repair_target(target) == "Top Field First" else "0",
                ]
            return args

        if codec in ("dnxhd", "dnxhr"):
            args = ["-c:v", "dnxhd", "-b:v", "120M"]
            if not progressive_output:
                args += [
                    "-flags", "+ilme+ildct",
                    "-top", "1" if normalize_repair_target(target) == "Top Field First" else "0",
                ]
            return args

        if codec == "dvvideo" or codec.startswith("dv"):
            return ["-c:v", "dvvideo"]

        if codec == "jpeg 2000":
            return ["-c:v", "jpeg2000", "-q:v", "1"]

        if codec == "v210":
            return ["-c:v", "v210"]

        # VC-1 可由 FFmpeg 可靠解碼，但目前沒有適合作為本工具自動
        # 場序重構成品的同 codec 編碼路徑。對 MOV/QuickTime 來源改用
        # ProRes 422 HQ 作明確、安全的中間/交付兼容輸出；其他容器則
        # 使用 Intra H.264，避免因來源是 VC-1 而直接中止修復。
        if codec == "vc-1":
            source_ext = os.path.splitext(str(path))[1].lower()
            if source_ext in (".mov", ".qt"):
                args = ["-c:v", "prores_ks", "-profile:v", "3"]
                if bit_depth == "10" and chroma == "4:2:2":
                    args += ["-pix_fmt", "yuv422p10le"]
                elif chroma == "4:2:2":
                    args += ["-pix_fmt", "yuv422p10le"]
                if not progressive_output:
                    args += [
                        "-flags", "+ilme+ildct",
                        "-top", "1" if normalize_repair_target(target) == "Top Field First" else "0",
                    ]
                return args

            args = [
                "-c:v", "libx264", "-preset", "medium",
                "-g", "1", "-bf", "0", "-sc_threshold", "0",
            ]
            if chroma == "4:2:2":
                args += ["-profile:v", "high422", "-pix_fmt", "yuv422p10le" if bit_depth == "10" else "yuv422p"]
            elif chroma == "4:4:4":
                args += ["-profile:v", "high444", "-pix_fmt", "yuv444p10le" if bit_depth == "10" else "yuv444p"]
            else:
                args += ["-profile:v", "high", "-pix_fmt", "yuv420p10le" if bit_depth == "10" else "yuv420p"]
            args += ["-crf", "16", "-x264-params", "keyint=1:scenecut=0:bframes=0"]
            if not progressive_output:
                args += [
                    "-flags", "+ilme+ildct",
                    "-top", "1" if normalize_repair_target(target) == "Top Field First" else "0",
                ]
            return args

        # Canopus HQ/HQA/HQX 沒有通用的 FFmpeg 編碼器可重新產生同一編碼。
        # 但 FFmpeg 可以解碼這些來源；場序重構必須重新編碼，因此對 MOV
        # 輸出採用高品質、10-bit、4:2:2 的 ProRes 422/HQ 作為明確的
        # 兼容輸出，而不是直接宣稱「同 codec」。
        if codec in ("canopus hq", "canopus hqa", "canopus hqx"):
            args = ["-c:v", "prores_ks", "-profile:v", "3"]
            if bit_depth == "10" and chroma == "4:2:2":
                args += ["-pix_fmt", "yuv422p10le"]
            if not progressive_output:
                args += [
                    "-flags", "+ilme+ildct",
                    "-top", "1" if normalize_repair_target(target) == "Top Field First" else "0",
                ]
            return args

        raise RuntimeError(
            "目前不會對此編碼器直接進行自動重編碼修復：%s。為避免輸出成規格不明的成品，已停止。"
            % (codec or "Unknown")
        )

    def _analysis_is_effectively_progressive(self, analysis):
        """只在「已確認 Progressive 幾乎覆蓋整片」時視為純 Progressive。

        不能再單靠 raw idet Progressive frame count >=99% 決定整片 P。
        EDIUS 正常 TFF、靜止／低運動畫面可能讓 idet 大量報 P；若這些 P
        已被 Motion / Field-Temporal 二次驗證降為 Progressive-like，就絕不能
        觸發整片 P→25i 重構。
        """
        analysis = analysis or {}
        source_order = normalize_field_order(analysis.get("source_field_order", ""))

        # idet 完全不可用時，才允許 metadata 作整片 fallback。
        if bool(analysis.get("used_metadata_fallback")):
            return source_order == "Progressive"

        duration = float(analysis.get("duration") or 0.0)
        if duration <= 0.0:
            return False

        # 只有已通過一致度 + Progressive 二次驗證、真正進入 anomalies 的 P
        # 才能計入「已確認 Progressive 覆蓋」。Progressive-like、低一致度 P、
        # Undetermined 全部不計。
        ranges = []
        for item in (analysis.get("anomalies") or []):
            if normalize_field_order(item.get("detected", "")) != "Progressive":
                continue
            if not item.get("repairable", False):
                continue
            a = max(0.0, float(item.get("start", 0.0)))
            b = min(duration, float(item.get("end", a)))
            if b > a:
                ranges.append((a, b))

        if not ranges:
            return False

        ranges.sort()
        merged = []
        for a, b in ranges:
            if merged and a <= merged[-1][1] + 1e-6:
                merged[-1] = (merged[-1][0], max(merged[-1][1], b))
            else:
                merged.append((a, b))

        confirmed_p = sum(max(0.0, b - a) for a, b in merged)
        # 允許極短片頭/片尾 warm-up，但至少 99% 時長必須是「已確認 P」。
        return (confirmed_p / duration) >= 0.99 and (duration - confirmed_p) <= 0.50

    def _is_progressive_to_hd25i(self, path, analysis):
        """Progressive -> TFF/BFF 的統一輸出政策：1920x1080 25i AVC-Intra MXF。

        只要「本次實際 repair list」內包含任何 Progressive -> interlaced 區段，
        整個修復成品就必須切換到統一的 HD 25i 時間軸與 MXF 交付格式。
        不能只在近乎全片 Progressive 時才啟用，否則 30p MOV 之類的混合／局部
        Progressive 素材會錯誤沿用來源 30fps/container，輸出成 30i MOV。

        TFF<->BFF 純場序修復仍維持原來源時間基準／container；只有真正選中的
        Progressive -> TFF/BFF 修復才觸發本規則。
        """
        analysis = self._effective_repair_analysis(analysis or {})
        target = normalize_repair_target(
            (analysis or {}).get("target", self.repair_target.get())
        )
        if target not in ("Top Field First", "Bottom Field First"):
            return False

        if not self._field_repair_type_enabled("Progressive", target):
            return False

        # 第一優先：repair list 是修復階段的唯一權威。
        # 只要當前使用者設定真正選中至少一段 Progressive，就必須輸出 HD 25i MXF。
        for item in (analysis.get("anomalies") or []):
            if normalize_field_order(item.get("detected", "")) != "Progressive":
                continue
            if item.get("repair_selected") is False:
                continue
            if item.get("repairable", True) is False:
                continue
            try:
                if float(item.get("end", 0.0)) <= float(item.get("start", 0.0)):
                    continue
            except Exception:
                pass
            return True

        # 第二層：整片 Progressive fallback / metadata-only 分析仍沿用既有判定。
        if self._analysis_is_effectively_progressive(analysis):
            return True

        # 只有逐幀分析資料不足、或整片 fallback 時才再看 source field metadata。
        # 若已有 repair candidates 但沒有選中 P，不可因 metadata 寫 Progressive 而
        # 誤把純 TFF<->BFF 修復強制變成 25i MXF。
        has_detection_data = bool(
            analysis.get("segments")
            or analysis.get("repair_candidates")
            or analysis.get("anomalies")
        )
        if has_detection_data and not bool(analysis.get("used_metadata_fallback")):
            return False

        source_order = normalize_field_order(
            (analysis or {}).get("source_field_order", "")
        )
        if not source_order:
            source_order = self._probe_field_order(path)
        if not source_order:
            try:
                source_order = normalize_field_order(
                    self.read_media(path).get("field_order", "")
                )
            except Exception:
                source_order = ""

        return source_order == "Progressive"

    def _repair_output_path_for_analysis(self, src_path, output_dir, analysis):
        base, ext = os.path.splitext(os.path.basename(src_path))
        if self._is_progressive_to_hd25i(src_path, analysis):
            # A：Progressive -> TFF/BFF 是正式 HD 25i 格式轉換，
            # 不沿用原 MP4/MOV/HEVC container。
            ext = ".mxf"
        return os.path.join(output_dir, base + "_fixed" + ext.lower())

    def _avcintra100_hd_interlaced_args(self, target):
        """A 規則輸出：1920x1080 / 25i / AVC-Intra 100 / 4:2:2 10-bit。"""
        target = normalize_repair_target(target)
        top = 1 if target == "Top Field First" else 0
        target_bps = 114000000
        target_kbps = int(round(target_bps / 1000.0))
        params = (
            "avcintra-class=100:"
            "bitrate=%d:keyint=1:keyint_min=1:scenecut=0:"
            "bframes=0:force-cfr=1:rc-lookahead=0:mbtree=0:"
            "nal-hrd=cbr:vbv-maxrate=%d:vbv-bufsize=%d:"
            "interlaced=1:tff=%d"
            % (target_kbps, target_kbps, target_kbps * 2, top)
        )
        return [
            "-c:v", "libx264",
            "-preset", "medium",
            "-g", "1",
            "-bf", "0",
            "-sc_threshold", "0",
            "-profile:v", "high422",
            "-pix_fmt", "yuv422p10le",
            "-flags", "+ilme+ildct",
            "-top", str(top),
            "-coder", "0",
            "-tune", "psnr",
            "-avcintra-class", "100",
            "-b:v", str(target_bps),
            "-minrate", str(target_bps),
            "-maxrate", str(target_bps),
            "-bufsize", str(target_bps * 2),
            "-x264-params", params,
            "-vtag", "ai12",
        ]

    @staticmethod
    def _ts(value):
        # FFmpeg filtergraph seconds with enough precision, locale independent.
        return "%.6f" % max(0.0, float(value))


    def _repair_smart_avcintra_eligible(self, path, analysis, output_path):
        """Return (eligible, reason) for the loss-minimising AVC-Intra smart-repair path.

        This path is deliberately narrow.  It is used only when normal sections can
        be cut on independent AVC-Intra frames and the requested repair is a local
        TFF<->BFF parity correction.  Progressive temporal conversion, whole-file
        rebuilds and uncertain structures always fall back to the proven legacy path.
        """
        try:
            target = normalize_repair_target((analysis or {}).get("target", self.repair_target.get()))
            if target not in ("Top Field First", "Bottom Field First"):
                return False, "目標不是交錯場序"
            if self._is_progressive_to_hd25i(path, analysis):
                return False, "Progressive→25i 需要時域重構"
            if self._analysis_is_effectively_progressive(analysis):
                return False, "來源接近整片 Progressive"
            if bool((analysis or {}).get("used_metadata_fallback")):
                return False, "本次分析使用 metadata fallback"

            anomalies = [dict(a) for a in ((analysis or {}).get("anomalies") or []) if a.get("repairable", False)]
            if not anomalies:
                return False, "沒有可修復區段"
            if any(a.get("full_rebuild") for a in anomalies):
                return False, "需要整片重構"
            if any(normalize_field_order(a.get("detected", "")) == "Progressive" for a in anomalies):
                return False, "包含 Progressive 區段"
            opposite = "Bottom Field First" if target == "Top Field First" else "Top Field First"
            if any(normalize_field_order(a.get("detected", "")) != opposite for a in anomalies):
                return False, "異常不只是單純 TFF/BFF 反轉"

            src_ext = os.path.splitext(path)[1].lower()
            out_ext = os.path.splitext(output_path)[1].lower()
            if src_ext != ".mxf" or out_ext != ".mxf":
                return False, "Smart Repair 目前只對 MXF 啟用"

            data = self.read_media(path)
            raw = str(data.get("raw_text", "") or "")
            commercial = str(data.get("commercial_name", "") or "")
            profile_blob = " %s %s %s %s " % (
                data.get("format", ""), commercial, data.get("codec_id", ""), raw
            )
            if not re.search(r"(?i)\bAVC[- ]?Intra[- ]?100\b", profile_blob):
                return False, "來源不是 AVC-Intra 100"

            # Smart path currently preserves one video stream plus all audio streams.
            # If the MXF carries ancillary/data/subtitle/second-video streams, do not
            # silently discard them: fall back to the legacy mapper which keeps d/s.
            codec_types = str(self._ffprobe_value(path, "stream=codec_type") or "").lower().split()
            if codec_types.count("video") != 1:
                return False, "來源包含多於一條影片串流"
            if any(t not in ("video", "audio") for t in codec_types):
                return False, "來源包含 ancillary/data/subtitle 串流，需完整保留"

            src_order = normalize_field_order((analysis or {}).get("source_field_order", ""))
            if src_order and src_order != target:
                return False, "主體來源場序與目標不一致"

            duration = float((analysis or {}).get("duration") or 0.0)
            if duration <= 0.0:
                return False, "來源片長不可可靠取得"
            coverage = 0.0
            for a in anomalies:
                coverage += max(0.0, min(duration, float(a.get("end", 0.0))) - max(0.0, float(a.get("start", 0.0))))
            # 異常太多時 Smart Repair 的切段/拼接收益很低；回到一次全片 encode 更穩定。
            if coverage / max(0.001, duration) > 0.35:
                return False, "異常覆蓋超過 35%，全片重建較合適"
            return True, "AVC-Intra 100 局部 TFF/BFF 可 Smart Repair"
        except Exception as exc:
            return False, "Smart Repair 資格檢查失敗：%s" % exc

    def _repair_video_smart_avcintra(self, path, analysis, output_path, progress_callback=None, overwrite=False):
        """Repair only local TFF/BFF AVC-Intra ranges and stream-copy normal ranges.

        The final result is accepted only when duration and field-order metadata stay
        within one-frame tolerance.  Any failure returns False so the caller can run
        the legacy whole-file path instead.  This makes speed an optimisation, never
        a correctness requirement.
        """
        eligible, reason = self._repair_smart_avcintra_eligible(path, analysis, output_path)
        if not eligible:
            try:
                self.write_log("  Smart Repair：不使用（%s）" % reason)
            except Exception:
                pass
            return False

        target = normalize_repair_target(analysis.get("target", self.repair_target.get()))
        target_code = "tff" if target == "Top Field First" else "bff"
        opposite = "Bottom Field First" if target == "Top Field First" else "Top Field First"
        source_code = "bff" if opposite == "Bottom Field First" else "tff"
        duration = float(analysis.get("duration") or 0.0)
        probe = self._field_probe_info(path)
        fps = float(probe.get("fps") or 0.0) or float(analysis.get("fps") or 25.0)
        fps = max(1.0, fps)

        # Frame-align every cut.  Analysis boundaries already originate from frame
        # indices; re-quantising here prevents decimal -ss/-t rounding from changing
        # the total number of video frames.
        anomalies = []
        for a in (analysis.get("anomalies") or []):
            if not a.get("repairable", False):
                continue
            af = max(0, int(round(float(a.get("start", 0.0)) * fps)))
            bf = max(af + 1, int(round(float(a.get("end", 0.0)) * fps)))
            start = af / fps
            end = min(duration, bf / fps)
            if end > start + (0.25 / fps):
                anomalies.append((start, end))
        anomalies.sort()
        merged=[]
        for a,b in anomalies:
            if merged and a <= merged[-1][1] + (0.25/fps):
                merged[-1]=(merged[-1][0], max(merged[-1][1], b))
            else:
                merged.append((a,b))
        anomalies=merged
        if not anomalies:
            return False

        segments=[]
        cursor=0.0
        for a,b in anomalies:
            if a > cursor + (0.25/fps):
                segments.append((cursor,a,False))
            segments.append((max(cursor,a),b,True))
            cursor=max(cursor,b)
        if cursor < duration - (0.25/fps):
            segments.append((cursor,duration,False))

        encoder_args = self._encoder_for_repair(path, target)
        # Faster x264 motion/search preset is safe for this local all-intra repair:
        # codec class, GOP=1, 4:2:2 10-bit, bitrate and field flags stay explicitly
        # pinned by _encoder_for_repair.  It changes encoder search effort, not timing.
        if "-preset" in encoder_args:
            pi=encoder_args.index("-preset")
            if pi+1 < len(encoder_args) and encoder_args[pi+1] == "medium":
                encoder_args[pi+1] = "fast"

        try:
            self.write_log("  Smart Repair：啟用 AVC-Intra 100 局部修復（正常段 stream copy）。")
        except Exception:
            pass

        final_dir=os.path.dirname(os.path.abspath(output_path)) or os.getcwd()
        os.makedirs(final_dir, exist_ok=True)
        tmp_root=tempfile.mkdtemp(prefix="MediaFieldQC_repair_", dir=final_dir)
        made=[]
        try:
            # If caller allowed overwrite, remove only the requested final path.
            if os.path.exists(output_path):
                if bool(overwrite):
                    os.remove(output_path)
                else:
                    raise RuntimeError("輸出檔案已存在：%s" % output_path)

            cumulative=0.0
            def mapped_cb(base, span):
                last={"local":0.0}
                def cb(key, value, wall):
                    if progress_callback is None:
                        return
                    if key in ("out_time_ms","out_time_us"):
                        try:
                            last["local"] = max(last["local"], min(span, float(value)/1000000.0))
                            progress_callback("out_time_us", str(int((base+last["local"])*1000000.0)), wall)
                        except Exception:
                            pass
                    elif key == "speed":
                        progress_callback("speed", value, wall)
                    # Do not forward intermediate progress=end: the outer GUI would
                    # incorrectly jump to 100% after the first segment.
                return cb

            for idx,(start,end,bad) in enumerate(segments):
                if self.stop_requested:
                    raise InterruptedError("使用者已停止輸出。")
                seg_dur=max(1.0/fps, end-start)
                seg_path=os.path.join(tmp_root,"seg_%04d.mxf" % idx)
                made.append(seg_path)
                base=cumulative
                if not bad:
                    args=[
                        "-hide_banner","-loglevel","error","-y",
                        "-ss",self._ts(start),"-i",path,"-t",self._ts(seg_dur),
                        "-map","0:v:0","-map","0:a?",
                        "-c","copy","-avoid_negative_ts","make_zero",
                        "-f","mxf",seg_path,
                    ]
                else:
                    vf=(
                        "setfield=%s,fieldorder=%s,setfield=%s,"
                        "tpad=stop_mode=clone:stop_duration=1,"
                        "trim=duration=%s,setpts=PTS-STARTPTS,fps=fps=%s:round=near"
                        % (source_code,target_code,target_code,self._ts(seg_dur),self._ts(fps))
                    )
                    args=[
                        "-hide_banner","-loglevel","error","-y",
                        "-ss",self._ts(start),"-i",path,"-t",self._ts(seg_dur),
                        "-map","0:v:0","-map","0:a?","-vf",vf,
                    ] + list(encoder_args) + [
                        "-r",("%.6f" % fps).rstrip("0").rstrip("."),
                        "-c:a","copy","-f","mxf",seg_path,
                    ]
                self._ffmpeg_run(args, timeout=None, progress_callback=mapped_cb(base,seg_dur))
                cumulative += seg_dur
                if progress_callback:
                    progress_callback("out_time_us", str(int(min(duration,cumulative)*1000000.0)), 0.0)

            list_path=os.path.join(tmp_root,"concat.txt")
            with open(list_path,"w",encoding="utf-8",newline="\n") as fh:
                for sp in made:
                    q=os.path.abspath(sp).replace("\\","/").replace("'","'\\''")
                    fh.write("file '%s'\n" % q)

            # Final join is packet-copy only.  -t is a hard guard against muxer/audio
            # tail packets extending the programme beyond the authoritative source
            # timeline; exact acceptance is still checked immediately afterwards.
            join_args=[
                "-hide_banner","-loglevel","error","-y",
                "-f","concat","-safe","0","-i",list_path,
                "-map","0:v:0","-map","0:a?","-c","copy",
                "-t",self._ts(duration),
                "-metadata","company_name=MediaField QC",
                "-metadata","product_name=",
                "-metadata","product_version=%s" % APP_VERSION,
                "-metadata","application_platform=Windows",
                "-metadata","writing_application=MediaField QC",
                "-metadata","encoded_application=MediaField QC",
                "-metadata","writing_library=MediaField QC",
                "-metadata","encoded_library=MediaField QC",
                "-metadata","comment=MediaField QC",
                "-metadata","encoded_by=MediaField QC",
                "-f","mxf",output_path,
            ]
            # Do not connect the raw concat progress directly to the GUI because it
            # restarts from zero.  Segment progress already represented the source
            # timeline; after a successful join we emit the single final completion.
            self._ffmpeg_run(join_args, timeout=None, progress_callback=None)

            out_probe=self._field_probe_info(output_path, refresh=True)
            out_duration=float(out_probe.get("duration") or 0.0)
            if out_duration <= 0.0:
                out_duration=self._probe_duration_seconds(output_path,fps)
            # Smart path is stricter than the generic verifier: at most ~1 frame.
            tol=max(0.025,1.10/fps)
            if out_duration <= 0.0 or abs(out_duration-duration) > tol:
                raise RuntimeError(
                    "Smart Repair 片長保護觸發（原片 %.6fs／成品 %.6fs／允許 %.6fs）"
                    % (duration,out_duration,tol)
                )
            # Compare actual decoded picture counts, not stream nb_frames.
            # Some MXF files expose nb_frames at field-rate (for example 250 while
            # only 125 pictures decode), which would otherwise cause a false FAIL.
            source_frames = self._field_decoded_frame_count(path)
            out_frames = self._field_decoded_frame_count(output_path, refresh=True)
            if source_frames > 0 and out_frames > 0 and abs(out_frames - source_frames) > 1:
                raise RuntimeError(
                    "Smart Repair 幀數保護觸發（原片實際 %d 幀／成品實際 %d 幀）"
                    % (source_frames, out_frames)
                )
            out_order=normalize_field_order(out_probe.get("field_order", ""))
            if out_order and out_order != target:
                raise RuntimeError("Smart Repair 場序標示不符（%s，目標 %s）" % (out_order,target))

            if progress_callback:
                progress_callback("out_time_us",str(int(duration*1000000.0)),0.0)
                progress_callback("progress","end",0.0)
            try:
                self.write_log(
                    "  Smart Repair 完成：只重編碼 %.3fs／%.3fs（%.1f%%）；片長檢查 PASS。"
                    % (sum(b-a for a,b in anomalies),duration,100.0*sum(b-a for a,b in anomalies)/max(0.001,duration))
                )
            except Exception:
                pass
            return True
        except InterruptedError:
            try:
                if os.path.isfile(output_path): os.remove(output_path)
            except Exception: pass
            raise
        except Exception as exc:
            try:
                if os.path.isfile(output_path): os.remove(output_path)
            except Exception:
                pass
            try:
                self.write_log("  Smart Repair 回退安全模式：%s" % exc)
            except Exception:
                pass
            return False
        finally:
            try:
                import shutil
                shutil.rmtree(tmp_root,ignore_errors=True)
            except Exception:
                pass

    def _repair_video(self, path, analysis, output_path, progress_callback=None, overwrite=False):
        """Optimised repair wrapper with correctness-first automatic fallback."""
        if self._repair_video_smart_avcintra(
            path, analysis, output_path,
            progress_callback=progress_callback, overwrite=overwrite,
        ):
            return
        # Proven full-filtergraph path remains the authority for Progressive,
        # whole-file conversion, unsupported codecs, or any smart-path anomaly.
        return self._repair_video_legacy(
            path, analysis, output_path,
            progress_callback=progress_callback, overwrite=overwrite,
        )

    def _repair_video_legacy(self, path, analysis, output_path, progress_callback=None, overwrite=False):
        anomalies = analysis.get("anomalies") or []
        target = normalize_repair_target(
            analysis.get("target", self.repair_target.get())
        )
        duration = float(analysis.get("duration") or 0.0)

        # Explicit whole-file conversion: TFF<->BFF or interlaced<->Progressive
        # must not depend on the presence of local "anomaly" runs.
        source_order = normalize_field_order(analysis.get("source_field_order", ""))
        if not source_order:
            source_order = self._probe_field_order(path)
        if not source_order:
            try:
                source_order = normalize_field_order(self.read_media(path).get("field_order", ""))
            except Exception:
                source_order = ""
        # A 判定以已完成的 idet 分析為權威。
        # 若 stream metadata 沒標 Progressive，但分析幾乎全片為 P，
        # 修復階段必須把它當作整條 Progressive，而不是只修 anomaly 小段。
        if (
            target in ("Top Field First", "Bottom Field First")
            and self._field_repair_type_enabled("Progressive", target)
            and self._analysis_is_effectively_progressive(analysis)
        ):
            source_order = "Progressive"

        # 整片重構只在兩種情況成立：
        # 1) 逐幀 idet 完全不可用，這次分析本身就是 metadata fallback；
        # 2) 逐幀分析確認整片實際上近乎純 Progressive，且使用者要轉 TFF/BFF。
        # 其餘混合場序一律按 anomalies 只修異常段，避免 metadata 寫錯時全片重構。
        metadata_fallback = bool(analysis.get("used_metadata_fallback"))
        effectively_progressive = self._analysis_is_effectively_progressive(analysis)
        whole_file_needs_rebuild = False
        if metadata_fallback:
            # Metadata fallback 亦必須服從分析完成後的 TFF/BFF/P 修復選擇；
            # 不能因為沒有 idet 區段資料就繞過使用者的 checkbox。
            if source_order in ("Top Field First", "Bottom Field First", "Progressive"):
                whole_file_needs_rebuild = (
                    source_order != target
                    and self._field_repair_type_enabled(source_order, target)
                )
        elif (
            effectively_progressive
            and target in ("Top Field First", "Bottom Field First")
            and self._field_repair_type_enabled("Progressive", target)
        ):
            whole_file_needs_rebuild = True
            source_order = "Progressive"
        if whole_file_needs_rebuild:
            probe_duration = float(self._field_probe_info(path).get("duration") or 0.0)
            duration = duration or probe_duration or self._probe_duration_seconds(path, normalize_fps(analysis.get("fps")) or 25.0)
            anomalies = [{
                "start": 0.0, "end": duration, "detected": source_order,
                "repairable": True, "full_rebuild": True,
            }]

        if not anomalies:
            raise RuntimeError("沒有需要修復的 TFF/BFF/Progressive 異常。")

        # Undetermined / 低信心區段仍然不允許自動修復。
        # 已確認的 Progressive 若需要轉成 TFF/BFF，後面會按來源 FPS 建立
        # 足夠 temporal samples，再以 tinterlace 組成真正上下場；不是只改 Metadata。
        for anomaly in anomalies:
            if not anomaly.get("repairable", False):
                raise RuntimeError(
                    "發現無法安全修復的異常（%s - %s）：%s。"
                    % (
                        self._timecode(anomaly["start"]),
                        self._timecode(anomaly["end"]),
                        anomaly.get("detected", "Unknown"),
                    )
                )

        p_to_hd25i = self._is_progressive_to_hd25i(
            path, analysis
        )
        if p_to_hd25i:
            # A：所有 Progressive -> TFF/BFF 都統一輸出 HD 25i AVC-Intra MXF。
            encoder_args = self._avcintra100_hd_interlaced_args(target)
        else:
            encoder_args = self._encoder_for_repair(path, target)

        # 場級重構與 trim/concat 可能讓濾鏡鏈輸出 time base 被 FFmpeg
        # 表示成微秒級 1/1000000，部分 libx264/AVC-Intra 組合會誤把它
        # 當成 FPS，導致「FPS 1000000/1 not compatible with AVC-Intra 100」。
        # 明確鎖定輸出 CFR 為來源 FPS，避免 encoder 直接吃到濾鏡鏈的 time base。
        source_probe = self._field_probe_info(path)
        source_fps = float(source_probe.get("fps") or 0.0)
        if source_fps <= 0.0:
            source_fps = self._probe_video_fps(
                path,
                normalize_fps(analysis.get("fps")) or 25.0,
            )
        output_fps = max(1.0, float(source_fps))
        if p_to_hd25i:
            output_fps = 25.0

        # 自動選擇 Progressive -> interlaced 的工作策略。
        #
        # 只要 repair list 內有 Progressive -> TFF/BFF，成品時間軸已由
        # _is_progressive_to_hd25i() 統一為 25fps。若整條來源本身是約 50p
        # Progressive，才可直接把相鄰兩個 progressive frame 組成 25i；
        # 其他來源 FPS（例如 25p / 30p / 60p）則先建立 50 temporal samples
        # 再 interlace，避免產生 30i MOV 等與交付政策不一致的成品。
        pure_progressive_source = (
            source_order == "Progressive"
            and whole_file_needs_rebuild
        )
        if p_to_hd25i:
            # A：只有真正約 50p 才可直接利用原生 50 temporal samples 組成 25i。
            direct_high_fps_interlace = (
                pure_progressive_source
                and 49.0 <= float(source_fps) <= 51.0
            )
        else:
            direct_high_fps_interlace = (
                pure_progressive_source
                and source_fps >= 47.0
            )

        if direct_high_fps_interlace and not p_to_hd25i:
            output_fps = float(source_fps) / 2.0

        if not duration:
            duration = max(float(a["end"]) for a in anomalies)

        segments = []
        cursor = 0.0
        for anomaly in anomalies:
            a = max(cursor, float(anomaly["start"]))
            b = min(duration, float(anomaly["end"]))
            if a > cursor + 0.001:
                segments.append((cursor, a, False, None))
            segments.append((a, b, True, anomaly["detected"]))
            cursor = b

        if cursor < duration - 0.001:
            segments.append((cursor, duration, False, None))

        # 局部 BFF/TFF 混入的關鍵：
        # setfield 只改 frame 的 field-order 標記，不改像素；而 fieldorder
        # 會依這個標記決定是否需要做真正的 field-order 轉換。
        # 因此對異常區段必須先「明確告訴 fieldorder 原本是 BFF/TFF」，
        # 再轉成目標場序；上一版直接 fieldorder=tff 在主流 TFF stream
        # 中可能判定「已經是 TFF」而跳過轉換。
        #
        # FFmpeg 文件也明確說明：
        #   - setfield 只標記 field property；
        #   - fieldorder 才執行 field-order transformation；
        #   - fieldorder 的轉換是逐行位移，而不是 deinterlace。
        #
        # 這裡仍然只對 anomaly 做 trim，正常區段原樣通過；每段都
        # setpts=PTS-STARTPTS 後 concat，最後重新建立單一連續 PTS。
        filters = []
        labels = []
        target_code = "tff" if target == "Top Field First" else "bff"

        for idx, (start, end, bad, detected) in enumerate(segments):
            label = "v%d" % idx
            labels.append("[%s]" % label)
            part = (
                "[0:v]trim=start=%s:end=%s,setpts=PTS-STARTPTS"
                % (self._ts(start), self._ts(end))
            )

            if p_to_hd25i:
                # A：先統一到 1920x1080，再做 temporal conversion。\n                # 4K 先縮小可大幅降低 MCI 成本；HD 來源則保持/縮放到標準 1080。
                part += ",scale=1920:1080:flags=lanczos"

            if target == "Progressive":
                if bad:
                    parity = (
                        "tff"
                        if normalize_field_order(detected) == "Top Field First"
                        else "bff"
                    )
                    part += (
                        ",setfield=%s"
                        ",yadif=mode=send_frame:parity=%s:deint=all"
                        % (parity, parity)
                    )
                part += ",setfield=prog"
            elif bad and detected == "Progressive":
                # 真正 Progressive -> interlaced TFF/BFF。
                #
                # 效能分級：
                # A. 純 50/59.94/60p Progressive：
                #    不插幀，直接把相鄰 frame 組成 fields，
                #    50p -> 25i、59.94p -> 29.97i、60p -> 30i。
                #
                # B. 23.976/24/25/29.97/30p，或混合場序檔案中的 P 區段：
                #    需要先補成 2 倍 temporal samples，再 interlace。
                #    使用 mi_mode=blend，避免 mci 運動估算造成長片極慢。
                interlace_mode = (
                    "interleave_top"
                    if target == "Top Field First"
                    else "interleave_bottom"
                )

                if direct_high_fps_interlace:
                    part += (
                        ",setfield=prog"
                        ",tinterlace=mode=%s"
                        ",setfield=%s"
                        % (interlace_mode, target_code)
                    )
                elif p_to_hd25i:
                    # Progressive -> HD 25i 快速時間重取樣。
                    # 25p / 29.97p / 30p / 59.94p / 60p 等非原生約 50p 來源，
                    # 先以 minterpolate blend 建立 50 temporal samples，再組成 25i。
                    # 相比 mi_mode=mci 不做昂貴的運動估算，可大幅縮短長片處理時間；
                    # 仍保持 50 temporal samples -> 25i 的時間結構，不改輸出規格。
                    # Scene-change protection prevents temporal interpolation across hard cuts.
                    # Keep threshold at FFmpeg's conservative/default-like 10 level.
                    if self._progressive_repair_method_key() == "optical":
                        temporal_filter = "minterpolate=fps=50:mi_mode=mci:scd=fdiff:scd_threshold=10"
                    else:
                        temporal_filter = "minterpolate=fps=50:mi_mode=blend:scd=fdiff:scd_threshold=10"
                    part += (
                        ",setfield=prog"
                        ",%s"
                        ",tinterlace=mode=%s"
                        ",setfield=%s"
                        % (temporal_filter, interlace_mode, target_code)
                    )
                else:
                    doubled_fps = output_fps * 2.0
                    method = "mci" if self._progressive_repair_method_key() == "optical" else "blend"
                    part += (
                        ",setfield=prog"
                        ",minterpolate=fps=%s:mi_mode=%s:scd=fdiff:scd_threshold=10"
                        ",tinterlace=mode=%s"
                        ",setfield=%s"
                        % (
                            self._ts(doubled_fps),
                            method,
                            interlace_mode,
                            target_code,
                        )
                    )
            elif bad and detected in ("Bottom Field First", "Top Field First"):
                source_code = (
                    "bff" if detected == "Bottom Field First" else "tff"
                )
                # 重要：先把「這一段實際被偵測為 BFF/TFF」寫到 frame
                # property，fieldorder 才會真正執行轉換，而不是看到整片
                # stream 的 dominant TFF flag 後直接跳過。
                part += (
                    ",setfield=%s,fieldorder=%s,setfield=%s"
                    % (source_code, target_code, target_code)
                )
            else:
                # 正常區段不改像素，只保持目標輸出 field metadata。
                part += ",setfield=%s" % target_code

            # 任何需要時域轉換的 filter（尤其 minterpolate/tinterlace）
            # 在每個獨立 trim 區段的頭尾都可能少掉少量 frame。
            # 長片若有很多 Progressive 區段，這些少量誤差會累積成數十秒。
            #
            # 每段在 concat 前先補足尾端，再 trim 回「原始 segment 長度」，
            # 因此無論該段內部 filter 實際吐出多少 frame，時間軸長度都以
            # 原片 start/end 為權威，不允許逐段縮短。
            segment_duration = max(0.0, float(end) - float(start))
            part += (
                ",tpad=stop_mode=clone:stop_duration=1"
                ",trim=duration=%s,setpts=PTS-STARTPTS"
                % self._ts(segment_duration)
            )

            part += "[%s]" % label
            filters.append(part)

        # 注意：
        # Progressive -> TFF/BFF 一旦被使用者選入 repair list，整個成品
        # 會統一到 25fps / 25i 時間基準；純 TFF<->BFF 修復才維持來源 FPS。
        # 只有整條來源為約 50p Progressive 時，P 區段可直接用原生 50
        # temporal samples 組成 25i；其他情況按 50-sample 路徑重構。
        #
        # concat 本身會依每段 PTS 串回完整時間軸。
        # 不能再用 setpts=N/(fps*TB) 依「實際輸出幀數」重建時間，
        # 否則 minterpolate/tinterlace 在每段邊界少掉的 frame 會直接
        # 壓縮整片時長（例如 15:00 被縮成 14:21）。
        #
        # 最後只用 fps filter 將輸出鎖回來源 CFR；總 duration 仍由
        # 各原始 segment 的 start/end 決定。
        filters.append(
            "%sconcat=n=%d:v=1:a=0,"
            "fps=fps=%s:round=near,"
            "tpad=stop_mode=clone:stop_duration=1,"
            "trim=duration=%s,setpts=PTS-STARTPTS,"
            "setfield=%s[outv]"
            % (
                "".join(labels),
                len(labels),
                self._ts(output_fps),
                self._ts(duration),
                target_code,
            )
        )
        filter_chain = ";".join(filters)

        args = [
            "-hide_banner", "-loglevel", "error", "-y" if bool(overwrite) else "-n", "-i", path,
            "-filter_complex", filter_chain,
            "-map", "[outv]", "-map", "0:a?", "-map_metadata", "0",
            # 修復成品必須明確標示由 MediaField QC 產生。
            # 同時寫入多個常見 application/library 欄位，讓不同
            # 容器與 MediaInfo 版本都有機會保留 writer identity。
            # MXF 的 MediaInfo「Writing application」主要來自 MXF Identification Set。
            # FFmpeg MXF muxer 使用 company_name / product_name / product_version
            # 寫入這個 Identification Set，因此這裡必須明確指定本軟件名稱，
            # 不能只依賴一般的 writing_application metadata。
            "-metadata", "company_name=MediaField QC",
            "-metadata", "product_name=",
            "-metadata", "product_version=%s" % APP_VERSION,
            "-metadata", "application_platform=Windows",
            # 同時保留通用 writer marker，供其他容器 / MediaInfo 版本識別。
            "-metadata", "writing_application=MediaField QC",
            "-metadata", "encoded_application=MediaField QC",
            "-metadata", "writing_library=MediaField QC",
            "-metadata", "encoded_library=MediaField QC",
            "-metadata", "comment=MediaField QC",
            "-metadata", "encoded_by=MediaField QC",
        ] + encoder_args + [
            # 相容 FFmpeg 4.4.1：舊版不認得 -fps_mode。
            "-r", ("%.6f" % output_fps).rstrip("0").rstrip("."),
        ]

        if p_to_hd25i:
            # A 格式轉換輸出 MXF，來源壓縮音訊不直接 copy，統一為 PCM。
            args += ["-c:a", "pcm_s24le", "-ar", "48000"]
        else:
            args += ["-c:a", "copy", "-c:d", "copy", "-c:s", "copy"]

        # Hard timeline guard: even when the user disables the optional
        # post-repair field re-scan, audio/data tail packets must not extend the
        # repaired programme beyond the authoritative source duration.
        args += ["-t", self._ts(duration)]

        args += [
            "-f", (
                "mxf" if str(output_path).lower().endswith(".mxf") else
                "mov" if str(output_path).lower().endswith(".mov") else
                "mp4" if str(output_path).lower().endswith((".mp4", ".m4v")) else
                "matroska"
            ),
            output_path,
        ]

        self._ffmpeg_run(args, timeout=None, progress_callback=progress_callback)

        # AVC-Intra 100 的成品必須維持約 100 Mb/s 的 Video bitrate。
        # 某些舊版/客製 FFmpeg+x264 在 CBR 參數組合下可能沒有真正套用
        # AVC-Intra rate control，產生 20~30 Mb/s 的異常低碼率成品。
        # 這裡直接用 ffprobe 驗證實際成品；若低於 80 Mb/s，刪除低碼率
        # 成品並用明確 CBR 的 AVC-Intra 100 參數重新編碼一次。
        if str(output_path).lower().endswith(".mxf"):
            src_data = self.read_media(path)
            src_raw = str(src_data.get("raw_text", "") or "")
            src_commercial_match = re.search(
                r"(?im)^\s*commercial\s+name\s*:\s*(.+?)\s*$",
                src_raw,
            )
            src_commercial = clean_text(src_commercial_match.group(1)) if src_commercial_match else ""
            src_text = " %s %s %s %s " % (
                src_data.get("format", ""),
                src_data.get("commercial_name", ""),
                src_data.get("codec_id", ""),
                src_commercial,
            )
            is_avci100 = bool(re.search(
                r"(?i)\bAVC[- ]?Intra[- ]?100\b",
                src_text,
            ))
            if is_avci100:
                actual = self._bitrate_to_bps(self._ffprobe_value(output_path, "stream=bit_rate"))
                if actual <= 0:
                    actual = self._bitrate_to_bps(self._ffprobe_value(output_path, "format=bit_rate"))
                if actual and actual < 80000000:
                    try:
                        os.remove(output_path)
                    except Exception:
                        pass
                    retry_args = list(args)
                    # Remove the first rate-control options and rebuild with the same explicit
                    # AVC-Intra 100 CBR parameters. Never fall back to CRF/QP.
                    cleaned = []
                    skip_next = False
                    rate_opts = {"-b:v", "-minrate", "-maxrate", "-bufsize", "-x264-params"}
                    i = 0
                    while i < len(retry_args):
                        if retry_args[i] in rate_opts:
                            i += 2
                            continue
                        cleaned.append(retry_args[i])
                        i += 1
                    # Retry with explicit CBR; do not use QP-only fallback,
                    # because QP-only is what allowed the previous build to
                    # collapse to ~26 Mb/s on simple footage.
                    retry_bps = 114000000
                    retry_params = (
                        "avcintra-class=100:bitrate=114000:"
                        "keyint=1:keyint_min=1:scenecut=0:bframes=0:"
                        "force-cfr=1:rc-lookahead=0:mbtree=0:"
                        "nal-hrd=cbr:vbv-maxrate=114000:vbv-bufsize=228000"
                    )
                    out_index = len(cleaned) - 1
                    cleaned = cleaned[:out_index] + [
                        "-avcintra-class", "100",
                        "-b:v", str(retry_bps),
                        "-minrate", str(retry_bps),
                        "-maxrate", str(retry_bps),
                        "-bufsize", str(retry_bps * 2),
                        "-x264-params", retry_params,
                    ] + cleaned[out_index:]
                    self._ffmpeg_run(cleaned, timeout=None, progress_callback=progress_callback)
                    actual2 = self._bitrate_to_bps(self._ffprobe_value(output_path, "stream=bit_rate"))
                    if actual2 <= 0:
                        actual2 = self._bitrate_to_bps(self._ffprobe_value(output_path, "format=bit_rate"))
                    if actual2 and actual2 < 80000000:
                        raise RuntimeError(
                            "AVC-Intra 100 輸出碼率異常：%s。來源 Video 約 114 Mb/s；FFmpeg 成品未達到 AVC-Intra 100 的碼率要求。"
                            % ("%.1f Mb/s" % (actual2 / 1000000.0))
                        )
                    if actual2 <= 0:
                        raise RuntimeError(
                            "無法讀取 AVC-Intra 100 成品的實際 bitrate，為避免產生規格不明的低碼率成品，已停止。"
                        )

    def _analyze_field_order_range(
        self, path, start, end, progress_callback=None,
        target_override=None, min_seconds_override=None, confidence_override=None,
    ):
        """只分析指定時間窗；供修復後驗證使用。

        驗證必須使用「當次實際修復時」的 target / 最低秒數 / 一致度，
        不能重新讀 UI 目前值，否則分析後改設定或視窗狀態變化會令驗證政策漂移。
        Progressive 亦沿用主分析的 Motion / Field-Temporal 二次驗證。
        """
        ffmpeg = get_ffmpeg_path()
        if not ffmpeg:
            raise RuntimeError("找不到 ffmpeg.exe。")
        probe = self._field_probe_info(path)
        fps = float(probe.get("fps") or 0.0) or 25.0
        start = max(0.0, float(start))
        end = max(start, float(end))
        window_duration = max(0.05, end - start)
        sample_stride = 1
        raw_samples, _ffmpeg_duration = self._field_run_idet(
            path, fps=fps, start=start, duration=window_duration,
            progress_callback=progress_callback,
        )
        target = normalize_repair_target(
            target_override if target_override is not None else self.repair_target.get()
        )
        if target == "Progressive":
            unwanted = {"tff", "bff"}
        elif target == "Top Field First":
            unwanted = {"bff", "progressive"}
        else:
            unwanted = {"tff", "progressive"}

        if min_seconds_override is None:
            min_seconds = 1.00
            try:
                min_seconds = max(0.10, float(self.repair_min_seconds.get()))
            except Exception:
                pass
        else:
            min_seconds = max(0.10, float(min_seconds_override))

        if confidence_override is None:
            confidence = 0.90
        else:
            confidence = max(0.50, min(1.0, float(confidence_override)))

        # 嚴格使用 ceil，避免最低異常長度因 frame rounding 被縮短。
        min_frames = max(2, int(math.ceil(min_seconds * fps - 1e-9)))
        # Range verification uses the same short-U bridge authority as the main
        # analysis: only <=2s A-U-A is absorbed; A-U-B and long U stay independent.
        verify_u_bridge_frames = max(1, int(math.ceil(2.0 * fps / max(1, sample_stride) - 1e-9)))
        samples = self._smooth_field_runs(
            raw_samples,
            min_frames=min_frames,
            undetermined_context_max_frames=verify_u_bridge_frames,
        )
        raw_class_by_frame = {int(frame_idx): cls for frame_idx, cls in raw_samples}

        def raw_ratio(a_frame, b_frame, expected):
            values = []
            for frame_idx in range(int(a_frame), int(b_frame), sample_stride):
                cls = raw_class_by_frame.get(frame_idx)
                if cls in ("tff", "bff", "progressive", "undetermined"):
                    values.append(cls)
            if not values:
                return 0.0
            return sum(1 for cls in values if cls == expected) / float(len(values))

        runs = []
        i = 0
        frame_total = max(1, int(round(window_duration * fps)))
        while i < len(samples):
            cls = samples[i][1]
            j = i + 1
            while j < len(samples) and samples[j][1] == cls:
                j += 1
            a_frame = samples[i][0]
            b_frame = min(frame_total, samples[j][0] if j < len(samples) else frame_total)
            if cls in unwanted and (b_frame - a_frame) >= min_frames:
                ratio = raw_ratio(a_frame, b_frame, cls)
                if ratio >= confidence:
                    detected = {
                        "tff": "Top Field First",
                        "bff": "Bottom Field First",
                        "progressive": "Progressive",
                    }[cls]

                    if cls == "progressive" and target in ("Top Field First", "Bottom Field First"):
                        abs_start = start + a_frame / fps
                        abs_end = start + b_frame / fps
                        pcheck = self._field_progressive_temporal_probe(
                            path, abs_start, abs_end, fps=fps
                        ) or {}
                        # 只有獨立場間時間證據也確認 P 才可令驗證 FAIL。
                        if pcheck.get("state", "inconclusive") != "progressive":
                            i = j
                            continue
                        runs.append({
                            "start": abs_start,
                            "end": abs_end,
                            "detected": detected,
                            "confidence": ratio,
                            "progressive_validation": pcheck,
                        })
                    else:
                        runs.append({
                            "start": start + a_frame / fps,
                            "end": start + b_frame / fps,
                            "detected": detected,
                            "confidence": ratio,
                        })
            i = j
        return {
            "start": start, "end": end, "fps": fps,
            "samples": samples, "raw_samples": raw_samples, "bad_runs": runs,
            "min_seconds": min_seconds, "confidence_threshold": confidence,
            "target": target,
        }

    def _field_video_packet_count(self, path, refresh=False):
        """Fast video packet count for repair validation (no full decode).

        ffprobe -count_packets walks the container packet stream but does not decode
        every picture, so it is substantially faster than -count_frames on long
        AVC-Intra/MXF files.  It is used only as a fast integrity layer; ambiguous
        results automatically fall back to the full decoded-picture count.
        """
        cache = getattr(self, "_field_packet_count_cache", None)
        if cache is None:
            cache = {}
            self._field_packet_count_cache = cache
        key = os.path.abspath(path)
        if refresh:
            cache.pop(key, None)
        if key in cache:
            return int(cache[key] or 0)

        exe = get_ffprobe_path()
        if not exe or self.stop_requested:
            return 0
        startupinfo = None
        creationflags = 0
        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        cmd = [
            exe, "-v", "error", "-select_streams", "v:0",
            "-count_packets", "-show_entries", "stream=nb_read_packets",
            "-of", "default=noprint_wrappers=1:nokey=1", path,
        ]
        process = None
        value = 0
        try:
            process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                startupinfo=startupinfo, creationflags=creationflags,
                universal_newlines=True, encoding="utf-8", errors="replace",
            )
            if not self._register_current_process(process):
                return 0
            while True:
                if self.stop_requested:
                    self._terminate_external_process(process, 0.2)
                    return 0
                try:
                    stdout, _stderr = process.communicate(timeout=0.20)
                    break
                except subprocess.TimeoutExpired:
                    continue
            if process.returncode == 0:
                try:
                    value = int(clean_text(stdout) or 0)
                except Exception:
                    value = 0
            if value > 0:
                cache[key] = value
            return value
        finally:
            self._clear_current_process(process)

    def _field_output_frames_for_repair_validation(self, output_path, source_analysis, expected_frames):
        """Return output picture count using a fast trusted path when possible.

        A repair export already reports its actual written frame counter through
        FFmpeg -progress.  If that counter and the muxed video packet count both
        agree with the expected timeline (±1), and duration has already passed,
        a second full-file decode adds little integrity value.  Any disagreement
        or unavailable evidence falls back to the original strict -count_frames
        decoded-picture verification.
        """
        source_analysis = source_analysis or {}
        try:
            export_frames = int(source_analysis.get("_repair_export_frame_count") or 0)
        except Exception:
            export_frames = 0
        try:
            expected_frames = int(expected_frames or 0)
        except Exception:
            expected_frames = 0

        packet_frames = self._field_video_packet_count(output_path, refresh=True)
        if (
            expected_frames > 0
            and export_frames > 0
            and packet_frames > 0
            and abs(export_frames - expected_frames) <= 1
            and abs(packet_frames - expected_frames) <= 1
            and abs(packet_frames - export_frames) <= 1
        ):
            return packet_frames, "fast"

        # Conservative fallback: exact decoded-picture count remains authority
        # whenever export/mux evidence is missing or disagrees.
        return self._field_decoded_frame_count(output_path, refresh=True), "decoded"

    def _field_expected_repair_output_frames(
            self, source_analysis, output_fps, source_frames=0):
        """
        計算場序修復後合理的 decoded picture count。

        一般 TFF/BFF 修復：
        decoded frame count 應與原片基本一致。

        Progressive -> HD 25i：
        成品固定按 output_fps（正常為 25fps）計算合理 coded picture count。
        核心硬規則仍然是修復後總時長必須和原片一致。
        """
        source_analysis = source_analysis or {}

        try:
            source_frames = int(source_frames or 0)
        except Exception:
            source_frames = 0

        if not bool(source_analysis.get("_progressive_to_hd25i")):
            return source_frames

        try:
            out_fps = float(output_fps or 0.0)
        except Exception:
            out_fps = 0.0

        if out_fps <= 0.0:
            out_fps = 25.0

        try:
            duration = float(source_analysis.get("duration") or 0.0)
        except Exception:
            duration = 0.0

        if duration > 0.0:
            return max(1, int(round(duration * out_fps)))

        try:
            source_fps = float(source_analysis.get("fps") or 0.0)
        except Exception:
            source_fps = 0.0

        if source_frames > 0 and source_fps > 0.0:
            return max(
                1,
                int(round(source_frames * out_fps / source_fps))
            )

        return 0

    def _field_source_frames_for_repair_validation(self, source_analysis):
        """Return an exact source decoded-picture count without needless re-decoding.

        Prefer an exact count captured during the original full-frame idet pass.
        If that was not available, use the existing decoded-frame cache.  Only as
        a last resort run the expensive full ffprobe -count_frames source scan.
        This keeps the ±1 source/output rule unchanged while avoiding duplicate
        work for the common repair paths that already decoded the full source.
        """
        source_analysis = source_analysis or {}
        try:
            exact = int(source_analysis.get("source_decoded_frame_count") or 0)
        except Exception:
            exact = 0
        if exact > 0:
            return exact

        source_path = str(source_analysis.get("source_path") or "")
        if not source_path:
            return 0
        try:
            cache = getattr(self, "_field_frame_count_cache", {}) or {}
            cached = int(cache.get(os.path.abspath(source_path)) or 0)
        except Exception:
            cached = 0
        if cached > 0:
            return cached

        # Strict fallback: keep the original decoded-frame-count requirement.
        return self._field_decoded_frame_count(source_path)

    def _verify_repair_timeline_integrity(self, output_path, source_analysis=None):
        """Always enforce duration/frame-count integrity after a repair export.

        This check is intentionally independent of the optional field-order re-scan.
        Users may disable the expensive selective field verification, but a repaired
        file is never accepted when its programme duration or decoded picture count
        differs materially from the source.
        """
        source_analysis = source_analysis or {}
        source_duration = float(source_analysis.get("duration") or 0.0)
        source_fps = float(source_analysis.get("fps") or 0.0) or 25.0

        output_probe = self._field_probe_info(output_path, refresh=True)
        output_duration = float(output_probe.get("duration") or 0.0)
        output_fps = float(output_probe.get("fps") or 0.0) or source_fps
        if output_duration <= 0.0:
            output_duration = self._probe_duration_seconds(output_path, output_fps)

        tolerance = max(0.025, 1.25 / max(1.0, output_fps))
        if source_duration > 0.0 and output_duration > 0.0:
            delta = abs(output_duration - source_duration)
            if delta > tolerance:
                return False, (
                    "成品片長與原片不一致（原片 %.3fs／成品 %.3fs／差 %.3fs；允許約一幀）。"
                    % (source_duration, output_duration, delta)
                )

        if bool(source_analysis.get("_progressive_to_hd25i")):
            # For P->25i the expected output picture count is duration * output_fps;
            # a second full source decode adds no validation value.
            try:
                source_frames = int(source_analysis.get("source_decoded_frame_count") or source_analysis.get("source_frame_count") or 0)
            except Exception:
                source_frames = 0
        else:
            source_frames = self._field_source_frames_for_repair_validation(source_analysis)
            if source_frames <= 0:
                try:
                    source_frames = int(source_analysis.get("source_frame_count") or 0)
                except Exception:
                    source_frames = 0
        expected_frames = self._field_expected_repair_output_frames(
            source_analysis,
            output_fps,
            source_frames,
        )
        output_frames, frame_validation_mode = self._field_output_frames_for_repair_validation(
            output_path, source_analysis, expected_frames
        )

        if (
            expected_frames > 0
            and output_frames > 0
            and abs(output_frames - expected_frames) > 1
        ):
            if bool(source_analysis.get("_progressive_to_hd25i")):
                return False, (
                    "成品實際幀數不符合 25i 時間軸"
                    "（預期約 %d 幀／成品 %d 幀；"
                    "原片 %d 幀，片長必須保持一致）。"
                    % (
                        expected_frames,
                        output_frames,
                        source_frames,
                    )
                )

            return False, (
                "成品實際幀數與原片不一致"
                "（原片 %d 幀／成品 %d 幀）。"
                % (
                    source_frames,
                    output_frames,
                )
            )

        if bool(source_analysis.get("_progressive_to_hd25i")):
            return True, (
                "時間軸完整性 PASS：片長保持一致；"
                "25i 成品實際 decoded frame count 符合預期"
                "（約 %d 幀）。"
                % expected_frames
            )

        return True, (
            "時間軸完整性 PASS："
            "片長與實際 decoded frame count 正常。"
        )

    def _verify_repair_selective(self, output_path, target, source_analysis=None, progress_callback=None):
        """只驗證「實際已修復範圍」，前後 buffer 只供上下文，不得製造假 FAIL。

        核心原則：分析階段明確標示「保留／不修復」的低一致度 P、
        Progressive-like、Undetermined 或其他未進 anomalies 的區段，不得因為
        位於某個修復區段前後 1 秒 buffer 內，就反過來令整個修復成品 FAIL。
        """
        target = normalize_repair_target(target)
        source_analysis = source_analysis or {}
        output_media = self.read_media(output_path)
        output_probe = self._field_probe_info(output_path, refresh=True)

        metadata_order = normalize_field_order(output_media.get("field_order", ""))
        if not metadata_order:
            metadata_order = normalize_field_order(output_probe.get("field_order", ""))

        is_p_to_hd25i = bool(source_analysis.get("_progressive_to_hd25i"))

        # 結構/metadata 檢查。
        if is_p_to_hd25i:
            width = int(digits(output_media.get("width", "")) or 0)
            height = int(digits(output_media.get("height", "")) or 0)
            out_fps = normalize_fps(output_media.get("fps", ""))
            if out_fps is None:
                out_fps = float(output_probe.get("fps") or 0.0) or 25.0

            structure_errors = []
            if width != 1920 or height != 1080:
                structure_errors.append("解析度=%sx%s" % (width or "?", height or "?"))
            if abs(float(out_fps) - 25.0) > 0.02:
                structure_errors.append("FPS=%.6f" % float(out_fps))
            if metadata_order != target:
                structure_errors.append("Scan order=%s" % (metadata_order or "Unknown"))
            if structure_errors:
                return False, (
                    "修復後驗證 FAIL：HD 25i 結構不符合目標（%s；目標 1920x1080 / 25fps / %s）。"
                    % ("、".join(structure_errors), target)
                )
        else:
            # Progressive 目標亦要檢查已存在的明確 Scan order；舊版只檢查 TFF/BFF 目標。
            if metadata_order and metadata_order != target:
                return False, "輸出 Scan order = %s，目標 = %s" % (metadata_order, target)

        anomalies = [
            dict(a) for a in (source_analysis.get("anomalies") or [])
            if a.get("repairable", True)
        ]
        if not anomalies:
            return True, "修復後驗證 PASS：沒有需要重檢測的實際修復區段。"

        output_duration = float(output_probe.get("duration") or 0.0)
        if output_duration <= 0.0:
            output_duration = self._probe_duration_seconds(
                output_path, source_analysis.get("fps") or 25.0
            )

        # 片長完整性：防止時域 filter / concat 令成品縮短或增長。
        source_duration = float(source_analysis.get("duration") or 0.0)
        verify_fps = float(output_probe.get("fps") or 0.0) or float(source_analysis.get("fps") or 25.0)
        # Length is a hard QC invariant.  Allow only muxer/time-base rounding of
        # about one frame; the old three-frame tolerance could hide a short output.
        duration_tolerance = max(0.025, 1.25 / max(1.0, verify_fps))
        if source_duration > 0.0 and output_duration > 0.0:
            delta = abs(output_duration - source_duration)
            if delta > duration_tolerance:
                return False, (
                    "修復後驗證 FAIL：成品片長與原片不一致（原片 %.3fs／成品 %.3fs／差 %.3fs；允許約一幀）。"
                    % (source_duration, output_duration, delta)
                )

        # Also compare actual decoded picture counts.  Never use stream nb_frames
        # as the final authority because some MXF files report field-rate-like
        # counts.  A one-picture tolerance covers container boundary rounding only.
        if is_p_to_hd25i:
            # P->25i validation uses the 25i timeline expectation; do not spend
            # another full decode on the source solely to recover its old P count.
            try:
                source_frames = int(source_analysis.get("source_decoded_frame_count") or source_analysis.get("source_frame_count") or 0)
            except Exception:
                source_frames = 0
        else:
            source_frames = self._field_source_frames_for_repair_validation(source_analysis)

        expected_frames = self._field_expected_repair_output_frames(
            source_analysis,
            verify_fps,
            source_frames,
        )
        output_frames, frame_validation_mode = self._field_output_frames_for_repair_validation(
            output_path, source_analysis, expected_frames
        )

        if (
            expected_frames > 0
            and output_frames > 0
            and abs(output_frames - expected_frames) > 1
        ):
            if is_p_to_hd25i:
                return False, (
                    "修復後驗證 FAIL："
                    "成品實際幀數不符合 25i 時間軸"
                    "（預期約 %d 幀／成品 %d 幀；"
                    "原片 %d 幀，片長必須保持一致）。"
                    % (
                        expected_frames,
                        output_frames,
                        source_frames,
                    )
                )

            return False, (
                "修復後驗證 FAIL："
                "成品實際幀數與原片不一致"
                "（原片 %d 幀／成品 %d 幀）。"
                % (
                    source_frames,
                    output_frames,
                )
            )

        # repair_cores 是真正被修復的 authoritative 範圍。
        repair_cores = []
        for anomaly in anomalies:
            a = max(0.0, float(anomaly.get("start", 0.0)))
            b = float(anomaly.get("end", a))
            if output_duration > 0.0:
                b = min(output_duration, b)
            if b > a + 0.0005:
                repair_cores.append((a, b))
        if not repair_cores:
            return True, "修復後驗證 PASS：沒有有效的實際修復區段。"

        min_seconds = max(0.10, float(source_analysis.get("min_seconds") or 1.00))
        confidence = float(source_analysis.get("confidence_threshold") or 0.90)
        frame_tol = 1.0 / max(1.0, verify_fps)

        # 修復內容驗證採「短區段完整、長區段多點抽樣」。
        #
        # 場序重構 filter 對一個 repair core 是同一條 deterministic filter
        # graph；長達數分鐘的 core 再逐幀重跑 idet，主要是在重複相同工作。
        # 因此 <=30 秒仍完整驗證；更長的 core 驗證首尾，並約每 30 秒
        # 取一個連續 4 秒 window。這些 window 內仍是逐幀 idet，不是單幀抽樣，
        # 可保留 idet 所需的連續 temporal context。
        #
        # 這只優化「場序內容重掃」；整片片長與實際 decoded frame count
        # 仍是硬性全片驗證，沒有放寬。
        buffer_seconds = 1.0
        full_verify_limit = 30.0
        sample_interval = 30.0
        sample_span = 4.0
        windows = []
        for a, b in repair_cores:
            core_len = max(0.0, b - a)
            if core_len <= full_verify_limit:
                wa = max(0.0, a - buffer_seconds)
                wb = b + buffer_seconds
                if output_duration > 0.0:
                    wb = min(output_duration, wb)
                if wb > wa + 0.01:
                    windows.append((wa, wb))
                continue

            # First and last boundaries are the most important concat/filter points.
            boundary_span = max(sample_span, min(8.0, sample_span + 2.0 * buffer_seconds))
            windows.append((max(0.0, a - buffer_seconds), min(output_duration or (a + boundary_span), a + boundary_span)))
            windows.append((max(0.0, b - boundary_span), min(output_duration or (b + buffer_seconds), b + buffer_seconds)))

            # Interior checkpoints. Keep every checkpoint fully inside the core.
            t = a + sample_interval
            half = sample_span * 0.5
            while t < b - sample_interval * 0.5:
                wa = max(a, t - half)
                wb = min(b, t + half)
                if wb > wa + 0.01:
                    windows.append((wa, wb))
                t += sample_interval

        windows.sort()
        merged = []
        for a, b in windows:
            if merged and a <= merged[-1][1] + 0.05:
                merged[-1] = (merged[-1][0], max(merged[-1][1], b))
            else:
                merged.append((a, b))

        total_work = sum(max(0.01, b - a) for a, b in merged)
        done_before = 0.0
        bad = []

        def overlap_with_repaired_core(run):
            ra = float(run.get("start", 0.0))
            rb = float(run.get("end", ra))
            best = 0.0
            for ca, cb in repair_cores:
                overlap = min(rb, cb) - max(ra, ca)
                best = max(best, overlap)
            # 只有在「實際修復範圍內」持續達到最低異常時長才算 FAIL。
            # 一個 buffer 裡 1.3s 的 P 若只擦到 repair core 0.1s，不得推翻成品。
            return best + frame_tol >= min_seconds

        for index, (a, b) in enumerate(merged, 1):
            duration = max(0.01, b - a)
            last = {"current": 0.0}

            def range_progress(key, value, elapsed, _a=a, _b=b, _d=duration,
                               _before=done_before, _index=index, _count=len(merged),
                               _fps=verify_fps):
                current = last["current"]
                try:
                    if key in ("analysis_sample", "frame"):
                        current = min(_d, float(value) / max(1.0, _fps))
                    elif key in ("out_time_ms", "out_time_us"):
                        current = min(_d, float(value) / 1000000.0)
                    elif key == "progress" and str(value).lower() == "end":
                        current = _d
                except Exception:
                    current = last["current"]
                last["current"] = max(last["current"], current)
                if progress_callback:
                    fraction = (_before + last["current"]) / max(0.01, total_work)
                    progress_callback(fraction, _index, _count, _a, _b, last["current"], _d)

            result = self._analyze_field_order_range(
                output_path, a, b,
                progress_callback=range_progress,
                target_override=target,
                min_seconds_override=min_seconds,
                confidence_override=confidence,
            )
            range_bad = result.get("bad_runs") or []

            if is_p_to_hd25i:
                # 對 P→25i 成品：結構已確認 25i，內容 idet 的 P 不可推翻結構；
                # 只把真正相反 field parity 視為 FAIL。
                opposite = (
                    "Bottom Field First" if target == "Top Field First" else "Top Field First"
                )
                range_bad = [
                    run for run in range_bad
                    if normalize_field_order(run.get("detected", "")) == opposite
                ]

            # 最重要的同步修正：buffer 內未修的區段只作上下文，不可 FAIL。
            range_bad = [run for run in range_bad if overlap_with_repaired_core(run)]
            bad.extend(range_bad)

            done_before += duration
            if progress_callback:
                progress_callback(
                    done_before / max(0.01, total_work), index, len(merged),
                    a, b, duration, duration
                )
            if self.stop_requested:
                raise RuntimeError("驗證已停止。")

        if bad:
            first = bad[0]
            return False, "修復後驗證 FAIL：實際已修復範圍內仍發現 %d 段相反場序；首段 %s - %s（%s）" % (
                len(bad), self._timecode(first["start"]), self._timecode(first["end"]), first["detected"]
            )
        if is_p_to_hd25i:
            return True, (
                "修復後驗證 PASS：結構為 1920x1080 / 25fps / %s；"
                "已驗證 %d 個修復範圍，未發現真正相反場序；"
                "長區段採多點連續逐幀驗證，整片片長與 25i decoded frame count 已完整核對。"
                % (target, len(repair_cores))
            )
        return True, (
            "修復後驗證 PASS：已驗證 %d 個實際修復範圍；"
            "短區段完整重檢，長區段採首尾 + 約每 %.0f 秒多點連續逐幀驗證；"
            "整片片長與 decoded frame count 仍已完整核對。"
            % (len(repair_cores), sample_interval)
        )

    def _verify_repair(self, output_path, target, source_analysis=None, progress_callback=None):
        # 相容舊呼叫點：所有修復後驗證統一走選擇性區段驗證，
        # 避免任何路徑意外重新掃描整條長影片。
        return self._verify_repair_selective(
            output_path,
            target,
            source_analysis=source_analysis,
            progress_callback=progress_callback,
        )

    def _hdr_probe_bitstream_metadata(self, path):
        """One stoppable ffprobe for HDR/colour metadata plus timing essentials.

        The result is cached for this analysis and replaces several separate
        ffprobe launches (primaries / transfer / matrix / duration fields).
        """
        cache = getattr(self, "_hdr_probe_cache", None)
        if cache is None:
            cache = {}
            self._hdr_probe_cache = cache
        key = os.path.abspath(path)
        if key in cache:
            return dict(cache[key])

        values = {
            "color_primaries": "",
            "color_transfer": "",
            "color_space": "",
            "color_range": "",
            "field_order": "",
            "r_frame_rate": "",
            "avg_frame_rate": "",
            "width": "",
            "height": "",
            "pix_fmt": "",
            "bits_per_raw_sample": "",
            "stream_duration": "",
            "format_duration": "",
            "nb_frames": "",
        }
        exe = get_ffprobe_path()
        process = None
        if exe:
            startupinfo = None
            creationflags = 0
            if os.name == "nt":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            cmd = [
                exe, "-v", "error", "-select_streams", "v:0",
                "-show_entries",
                "stream=color_primaries,color_transfer,color_space,color_range,field_order,r_frame_rate,avg_frame_rate,width,height,pix_fmt,bits_per_raw_sample,duration,nb_frames:format=duration",
                "-of", "json", path,
            ]
            try:
                if not self.stop_requested:
                    process = subprocess.Popen(
                        cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        startupinfo=startupinfo,
                        creationflags=creationflags,
                        universal_newlines=True,
                        encoding="utf-8",
                        errors="replace",
                    )
                    if self._register_current_process(process):
                        while True:
                            if self.stop_requested:
                                self._terminate_external_process(process, 0.2)
                                break
                            try:
                                stdout, _stderr = process.communicate(timeout=0.20)
                                obj = json.loads(stdout or "{}")
                                st = (obj.get("streams") or [{}])[0] or {}
                                fmt = obj.get("format") or {}
                                for k in (
                                    "color_primaries", "color_transfer", "color_space",
                                    "color_range", "field_order", "r_frame_rate",
                                    "avg_frame_rate", "width", "height", "pix_fmt",
                                    "bits_per_raw_sample", "nb_frames",
                                ):
                                    values[k] = clean_text(st.get(k, ""))
                                values["stream_duration"] = clean_text(st.get("duration", ""))
                                values["format_duration"] = clean_text(fmt.get("duration", ""))
                                self._hdr_probe_stream_cache = getattr(self, "_hdr_probe_stream_cache", {})
                                self._hdr_probe_stream_cache[key] = dict(st)
                                break
                            except subprocess.TimeoutExpired:
                                continue
            except Exception:
                pass
            finally:
                if process is not None:
                    try:
                        if self.stop_requested and process.poll() is None:
                            self._terminate_external_process(process, 0.2)
                    except Exception:
                        pass
                    self._clear_current_process(process)

        # v1.2.0 HDR metadata robustness fix:
        # Release packages ship both FFmpeg and FFprobe.  Keep this fallback for
        # source/debug runs or malformed files where ffprobe leaves colour fields blank; decode only
        # ONE video frame through showinfo and read the coded-stream colour VUI from
        # FFmpeg's stderr.  This is deliberately a fallback, so normal ffprobe data
        # is never overwritten.  It fixes deliverables whose MediaInfo/container
        # interpretation says BT.709 while the HEVC/H.264 elementary stream still
        # declares BT.2020 / HLG.
        need_ffmpeg_colour_fallback = any(
            not clean_text(values.get(k, ""))
            for k in ("color_primaries", "color_transfer", "color_space")
        )
        if need_ffmpeg_colour_fallback and not self.stop_requested:
            ffmpeg = get_ffmpeg_path()
            if ffmpeg:
                process = None
                startupinfo = None
                creationflags = 0
                if os.name == "nt":
                    startupinfo = subprocess.STARTUPINFO()
                    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                null_out = "NUL" if os.name == "nt" else os.devnull
                cmd = [
                    ffmpeg, "-hide_banner", "-loglevel", "info",
                    "-i", path,
                    "-map", "0:v:0", "-frames:v", "1",
                    "-vf", "showinfo", "-an", "-sn", "-dn",
                    "-f", "null", null_out,
                ]
                ffmpeg_stderr = ""
                try:
                    process = subprocess.Popen(
                        cmd,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.PIPE,
                        startupinfo=startupinfo,
                        creationflags=creationflags,
                        universal_newlines=True,
                        encoding="utf-8",
                        errors="replace",
                    )
                    if self._register_current_process(process):
                        while True:
                            if self.stop_requested:
                                self._terminate_external_process(process, 0.2)
                                break
                            try:
                                _stdout, ffmpeg_stderr = process.communicate(timeout=0.20)
                                break
                            except subprocess.TimeoutExpired:
                                continue
                except Exception:
                    ffmpeg_stderr = ""
                finally:
                    if process is not None:
                        try:
                            if self.stop_requested and process.poll() is None:
                                self._terminate_external_process(process, 0.2)
                        except Exception:
                            pass
                        self._clear_current_process(process)

                if ffmpeg_stderr:
                    # Preferred source: showinfo prints explicit labels, e.g.
                    # color_range:tv color_space:bt2020nc
                    # color_primaries:bt2020 color_trc:arib-std-b67
                    patterns = {
                        "color_range": r"\bcolor_range:([^\s]+)",
                        "color_space": r"\bcolor_space:([^\s]+)",
                        "color_primaries": r"\bcolor_primaries:([^\s]+)",
                        "color_transfer": r"\bcolor_trc:([^\s]+)",
                    }
                    for field, pattern in patterns.items():
                        if clean_text(values.get(field, "")):
                            continue
                        m = re.search(pattern, ffmpeg_stderr, flags=re.IGNORECASE)
                        if m:
                            token = clean_text(m.group(1)).strip(",;)[]")
                            if token and token.lower() not in ("unknown", "unspecified", "reserved"):
                                values[field] = token

                    # Compatibility fallback for older FFmpeg builds whose showinfo
                    # does not print the explicit colour labels.  Parse the input
                    # stream descriptor: yuv420p10le(tv, bt2020nc/bt2020/arib-std-b67, ...)
                    if any(
                        not clean_text(values.get(k, ""))
                        for k in ("color_primaries", "color_transfer", "color_space")
                    ):
                        stream_line = ""
                        for line in ffmpeg_stderr.splitlines():
                            if "Stream #" in line and "Video:" in line:
                                stream_line = line
                                break
                        if stream_line:
                            m = re.search(r"\((tv|pc|limited|full)?\s*,?\s*([^()/,\s]+)\s*/\s*([^()/,\s]+)\s*/\s*([^(),\s]+)", stream_line, flags=re.IGNORECASE)
                            if m:
                                rng, matrix, primaries, transfer = m.groups()
                                if not clean_text(values.get("color_range", "")) and rng:
                                    values["color_range"] = clean_text(rng)
                                if not clean_text(values.get("color_space", "")) and matrix:
                                    values["color_space"] = clean_text(matrix)
                                if not clean_text(values.get("color_primaries", "")) and primaries:
                                    values["color_primaries"] = clean_text(primaries)
                                if not clean_text(values.get("color_transfer", "")) and transfer:
                                    values["color_transfer"] = clean_text(transfer)

        cache[key] = dict(values)
        return dict(values)

    def _hdr_duration_from_probe(self, bitstream, fps_hint=25.0):
        """Resolve a sane HDR-analysis duration from the consolidated ffprobe.

        Some MXF files expose nb_frames as field-rate units while decoded pictures
        advance at half that rate.  Container/stream duration is therefore preferred;
        frame-count duration is admitted only when it agrees reasonably with the
        real timeline, matching the protection used by the field-order module.
        """
        duration_candidates = []
        for key in ("format_duration", "stream_duration"):
            try:
                value = float((bitstream or {}).get(key) or 0.0)
                if value > 0.0:
                    duration_candidates.append(value)
            except Exception:
                pass

        frame_duration = 0.0
        try:
            frames = float((bitstream or {}).get("nb_frames") or 0.0)
            fps = float(fps_hint or 25.0)
            if frames > 0.0 and fps > 0.0:
                frame_duration = frames / fps
        except Exception:
            frame_duration = 0.0

        if frame_duration > 0.0:
            metadata_rates = []
            for key in ("r_frame_rate", "avg_frame_rate"):
                value = normalize_fps((bitstream or {}).get(key, ""))
                if value and value > 0.0:
                    metadata_rates.append(float(value))
            rate_mismatch = any(
                abs(rate - float(fps_hint or 25.0)) / max(rate, float(fps_hint or 25.0)) > 0.02
                for rate in metadata_rates
            )
            if not duration_candidates:
                if not rate_mismatch:
                    duration_candidates.append(frame_duration)
            else:
                reference = max(duration_candidates)
                ratio = frame_duration / reference if reference > 0.0 else 1.0
                if 0.80 <= ratio <= 1.25:
                    duration_candidates.append(frame_duration)

        if not duration_candidates:
            return 0.0

        smallest = min(duration_candidates)
        sane = [
            v for v in duration_candidates
            if smallest <= 0.0 or v <= smallest * 1.25
        ]
        return max(sane or duration_candidates)

    @staticmethod
    def _hdr_normalize_colour_token(value):
        v = clean_text(value).strip().lower()
        aliases = {
            "bt2020nc": "bt2020nc",
            "bt2020_ncl": "bt2020nc",
            "bt2020": "bt2020",
            "arib-std-b67": "hlg",
            "arib std-b67": "hlg",
            "hlg": "hlg",
            "smpte2084": "pq",
            "smpte st 2084": "pq",
            "st2084": "pq",
            "bt709": "bt709",
            "709": "bt709",
            "tv": "limited",
            "limited": "limited",
            "pc": "full",
            "full": "full",
        }
        return aliases.get(v, v)

    def _hdr_metadata_crosscheck(self, media_data, bitstream):
        """Compare container/MediaInfo values against ffprobe stream signalling."""
        mi_prim = self._hdr_normalize_colour_token(
            media_data.get("color", "")
        )
        mi_tr = self._hdr_normalize_colour_token(
            media_data.get("transfer", "")
        )

        bs_prim = self._hdr_normalize_colour_token(
            bitstream.get("color_primaries", "")
        )
        bs_tr = self._hdr_normalize_colour_token(
            bitstream.get("color_transfer", "")
        )
        bs_matrix = self._hdr_normalize_colour_token(
            bitstream.get("color_space", "")
        )
        bs_range = self._hdr_normalize_colour_token(
            bitstream.get("color_range", "")
        )

        issues = []

        if mi_prim and bs_prim and mi_prim != bs_prim:
            issues.append(
                "Container/MediaInfo 與編碼串流的 Color Primaries 不一致"
            )

        if mi_tr and bs_tr and mi_tr != bs_tr:
            issues.append(
                "Container/MediaInfo 與編碼串流的 Transfer 不一致"
            )

        return {
            "issues": issues,
            "has_conflict": bool(issues),
            "stream_primaries": bitstream.get("color_primaries", "") or "未標示",
            "stream_transfer": bitstream.get("color_transfer", "") or "未標示",
            "stream_matrix": bitstream.get("color_space", "") or "未標示",
            "stream_range": bitstream.get("color_range", "") or "未標示",
            "normalized_stream_primaries": bs_prim,
            "normalized_stream_transfer": bs_tr,
            "normalized_stream_matrix": bs_matrix,
            "normalized_stream_range": bs_range,
        }

    @staticmethod
    def _hdr_metadata_kind(data, ff_primaries="", ff_transfer="", ff_matrix=""):
        """Classify declared colour signalling, preferring coded-stream VUI.

        ffprobe reads the actual video-stream VUI (colour primaries / transfer /
        matrix).  MediaInfo/container text is retained as a fallback only when the
        coded stream leaves a field blank.  This prevents a container/parser value
        such as BT.709 from masking an HLG/BT.2020 HEVC bitstream declaration.
        Any disagreement is still reported separately by
        ``_hdr_metadata_crosscheck``.
        """
        mi_primaries = clean_text(data.get("color", ""))
        mi_transfer = clean_text(data.get("transfer", ""))
        stream_primaries = clean_text(ff_primaries)
        stream_transfer = clean_text(ff_transfer)

        # Authoritative order for encoded deliverables:
        #   1) elementary-stream VUI/bitstream signalling (ffprobe)
        #   2) MediaInfo/container value only when the stream field is absent
        primaries_raw = stream_primaries or mi_primaries
        transfer_raw = stream_transfer or mi_transfer

        primaries = primaries_raw.lower()
        transfer = transfer_raw.lower()
        matrix = clean_text(ff_matrix).lower()

        is_2020 = any(x in primaries for x in ("2020", "bt2020"))
        is_hlg = any(
            x in transfer
            for x in ("hlg", "arib std-b67", "arib-std-b67", "std-b67")
        )
        is_pq = any(
            x in transfer
            for x in ("smpte st 2084", "smpte2084", "st2084", "pq")
        )
        is_709 = (
            any(x in primaries for x in ("709", "bt709"))
            and any(x in transfer for x in ("709", "bt709"))
        )

        if is_2020 and is_hlg:
            kind = "BT.2020 / HLG"
        elif is_2020 and is_pq:
            kind = "BT.2020 / PQ"
        elif is_709:
            kind = "BT.709 / SDR"
        elif is_2020:
            kind = "BT.2020（Transfer 非 HLG/PQ 或未標示）"
        else:
            kind = "未明確標示 HDR"

        return {
            "kind": kind,
            "primaries": primaries_raw or "未標示",
            "transfer": transfer_raw or "未標示",
            "matrix": clean_text(ff_matrix) or "未標示",
            "is_hdr": bool(is_2020 and (is_hlg or is_pq)),
            "is_hlg": bool(is_hlg),
            "is_pq": bool(is_pq),
            "is_2020": bool(is_2020),
            "is_709": bool(is_709),
        }

    def _hdr_joint_signal_gamut_samples(
        self, path, metadata, signal_fps=2.0, gamut_fps=1.0,
        width=128, height=72, duration=None, progress_callback=None
    ):
        """Decode the programme once and feed Layers 2, 3 and 4 together.

        One FFmpeg decode is split inside the filter graph.  The first branch keeps
        the existing 2 fps signalstats sampling; the second branch keeps the existing
        1 fps 128x72 RGB gamut sampling.  No sampling density, colour equation or
        detector threshold is changed.  If this combined path is unavailable on an
        older FFmpeg build, the caller can safely fall back to the legacy two-pass
        helpers.
        """
        exe = get_ffmpeg_path()
        if not exe:
            raise RuntimeError('找不到 ffmpeg.exe')

        startupinfo = None
        creationflags = 0
        if os.name == 'nt':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

        env = os.environ.copy()
        exe_dir = os.path.dirname(os.path.abspath(exe))
        env['PATH'] = exe_dir + os.pathsep + env.get('PATH', '')

        null_sink = 'NUL' if os.name == 'nt' else '/dev/null'
        filter_graph = (
            '[0:v]split=2[s0][g0];'
            '[s0]fps=fps=%s,signalstats,metadata=mode=print[sout];'
            '[g0]fps=fps=%s,scale=%d:%d:flags=fast_bilinear,format=rgb24[gout]'
            % (self._ts(signal_fps), self._ts(gamut_fps), int(width), int(height))
        )
        cmd = [
            exe, '-hide_banner', '-loglevel', 'info', '-i', path,
            '-filter_complex', filter_graph,
            '-map', '[sout]', '-an', '-sn', '-dn', '-vsync', '0', '-f', 'null', null_sink,
            '-map', '[gout]', '-an', '-sn', '-dn', '-vsync', '0',
            '-f', 'rawvideo', '-pix_fmt', 'rgb24', 'pipe:1',
        ]

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            startupinfo=startupinfo,
            creationflags=creationflags,
            env=env,
        )
        if not self._register_current_process(process):
            return [], []

        # Drain FFmpeg metadata/log output concurrently so the stderr pipe can never
        # fill while raw RGB frames are being read from stdout.
        stderr_chunks = []
        def _drain_stderr():
            try:
                while True:
                    chunk = process.stderr.read(65536)
                    if not chunk:
                        break
                    stderr_chunks.append(chunk)
            except Exception:
                pass
        stderr_thread = threading.Thread(target=_drain_stderr, daemon=True)
        stderr_thread.start()

        frame_size = int(width) * int(height) * 3
        gamut_samples = []
        frame_index = 0
        total_duration = max(0.0, float(duration or 0.0))
        expected_frames = max(1, int(math.ceil(total_duration * float(gamut_fps))))

        # Reuse the same inverse-transfer LUT cache as the range validator.
        lut_cache = getattr(self, '_hdr_inverse_lut_cache', None)
        if lut_cache is None:
            lut_cache = {}
            self._hdr_inverse_lut_cache = lut_cache
        is_hlg = bool((metadata or {}).get('is_hlg'))
        is_pq = bool((metadata or {}).get('is_pq'))
        lut_key = 'hlg' if is_hlg else ('pq' if is_pq else 'gamma22')
        linear_lut = lut_cache.get(lut_key)
        if linear_lut is None:
            if is_hlg:
                linear_lut = [self._hdr_inverse_hlg(v / 255.0) for v in range(256)]
            elif is_pq:
                linear_lut = [self._hdr_inverse_pq(v / 255.0) for v in range(256)]
            else:
                linear_lut = [(v / 255.0) ** 2.2 for v in range(256)]
            lut_cache[lut_key] = linear_lut

        if (metadata or {}).get('is_2020'):
            r_rr = [1.660491 * v for v in linear_lut]; r_gg = [-0.124550 * v for v in linear_lut]; r_bb = [-0.018151 * v for v in linear_lut]
            g_rr = [-0.587641 * v for v in linear_lut]; g_gg = [1.132900 * v for v in linear_lut]; g_bb = [-0.100579 * v for v in linear_lut]
            b_rr = [-0.072850 * v for v in linear_lut]; b_gg = [-0.008349 * v for v in linear_lut]; b_bb = [1.118730 * v for v in linear_lut]
        else:
            r_rr = r_gg = r_bb = g_rr = g_gg = g_bb = b_rr = b_gg = b_bb = None

        def _read_exact(stream, size):
            buf = bytearray()
            while len(buf) < size:
                if self.stop_requested:
                    return bytes(buf)
                part = stream.read(size - len(buf))
                if not part:
                    break
                buf.extend(part)
            return bytes(buf)

        try:
            while True:
                if self.stop_requested:
                    self._terminate_external_process(process)
                    break
                raw = _read_exact(process.stdout, frame_size)
                if not raw or len(raw) < frame_size:
                    break

                outside = 0
                edge_near = 0
                considered = 0
                for i in range(0, frame_size, 3):
                    ri, gi, bi = raw[i], raw[i + 1], raw[i + 2]
                    r = linear_lut[ri]; g = linear_lut[gi]; b = linear_lut[bi]
                    peak = max(r, g, b)
                    if peak < 0.0008:
                        continue
                    if (metadata or {}).get('is_2020'):
                        rr = r_rr[ri] + g_rr[gi] + b_rr[bi]
                        gg = r_gg[ri] + g_gg[gi] + b_gg[bi]
                        bb = r_bb[ri] + g_bb[gi] + b_bb[bi]
                    else:
                        rr, gg, bb = r, g, b
                    considered += 1
                    tol = max(peak * 0.012, 1e-7)
                    if rr < -tol or gg < -tol or bb < -tol:
                        outside += 1
                    positive_sum = max(0.0, rr) + max(0.0, gg) + max(0.0, bb)
                    if positive_sum > 1e-9:
                        if min(
                            max(0.0, rr) / positive_sum,
                            max(0.0, gg) / positive_sum,
                            max(0.0, bb) / positive_sum,
                        ) <= 0.012:
                            edge_near += 1

                ratio = outside / float(considered) if considered else 0.0
                edge_ratio = edge_near / float(considered) if considered else 0.0
                gamut_samples.append({
                    'time': frame_index / float(gamut_fps),
                    'outside709_ratio': ratio,
                    'outside709_percent': ratio * 100.0,
                    'edge709_ratio': edge_ratio,
                    'edge709_percent': edge_ratio * 100.0,
                    'considered_pixels': considered,
                })
                frame_index += 1
                if progress_callback is not None:
                    try:
                        progress_callback(min(1.0, frame_index / float(expected_frames)))
                    except Exception:
                        pass
        finally:
            try:
                if process.stdout:
                    process.stdout.close()
            except Exception:
                pass
            if process.poll() is None:
                if self.stop_requested:
                    self._terminate_external_process(process)
                else:
                    try:
                        process.wait(timeout=2.0)
                    except Exception:
                        self._terminate_external_process(process)
            try:
                stderr_thread.join(timeout=2.0)
            except Exception:
                pass
            self._clear_current_process(process)

        stderr_text = b''.join(stderr_chunks).decode('utf-8', errors='replace')
        frame_re = re.compile(
            r"frame:\s*\d+\s+pts:\s*[-+]?\d+\s+pts_time:\s*([-+]?\d+(?:\.\d+)?)",
            re.IGNORECASE,
        )
        stat_re = re.compile(
            r"lavfi\.signalstats\.([A-Z0-9]+)\s*=\s*([-+]?\d+(?:\.\d+)?)",
            re.IGNORECASE,
        )
        signal_samples = []
        current = None
        for line in stderr_text.splitlines():
            fm = frame_re.search(line)
            if fm:
                if current is not None:
                    signal_samples.append(current)
                try:
                    pts = max(0.0, float(fm.group(1)))
                except Exception:
                    pts = 0.0
                current = {'time': pts}
                continue
            sm = stat_re.search(line)
            if sm and current is not None:
                try:
                    current[sm.group(1).upper()] = float(sm.group(2))
                except Exception:
                    pass
        if current is not None:
            signal_samples.append(current)

        if progress_callback is not None and not self.stop_requested:
            try:
                progress_callback(1.0)
            except Exception:
                pass
        return signal_samples, gamut_samples

    def _hdr_signalstats_samples(self, path, sample_fps=2.0, duration=None, progress_callback=None):
        """Sample picture statistics with FFmpeg signalstats.

        Sampling density and the signalstats algorithm are unchanged.  The
        optional callback reports real decoded-time progress so the HDR bar can
        move continuously instead of jumping only at stage boundaries.
        """
        vf = (
            "fps=fps=%s,"
            "signalstats,"
            "metadata=mode=print"
            % self._ts(sample_fps)
        )

        total_duration = max(0.0, float(duration or 0.0))

        def ff_progress(key, value, _elapsed):
            if progress_callback is None or total_duration <= 0.0:
                return
            try:
                if key in ("out_time_us", "out_time_ms"):
                    # FFmpeg progress values are expressed in microseconds.
                    seconds = max(0.0, float(value) / 1000000.0)
                    progress_callback(min(1.0, seconds / total_duration))
                elif key == "progress" and str(value).strip().lower() == "end":
                    progress_callback(1.0)
            except Exception:
                pass

        _stdout, stderr = self._ffmpeg_run(
            [
                "-hide_banner", "-loglevel", "info",
                "-i", path,
                "-vf", vf,
                "-an", "-f", "null",
                "NUL" if os.name == "nt" else "/dev/null",
            ],
            progress_callback=ff_progress if progress_callback is not None else None,
        )

        frame_re = re.compile(
            r"frame:\s*\d+\s+pts:\s*[-+]?\d+\s+pts_time:\s*([-+]?\d+(?:\.\d+)?)",
            re.IGNORECASE,
        )
        stat_re = re.compile(
            r"lavfi\.signalstats\.([A-Z0-9]+)\s*=\s*([-+]?\d+(?:\.\d+)?)",
            re.IGNORECASE,
        )

        samples = []
        current = None

        for line in (stderr or "").splitlines():
            fm = frame_re.search(line)
            if fm:
                if current is not None:
                    samples.append(current)
                try:
                    pts = max(0.0, float(fm.group(1)))
                except Exception:
                    pts = 0.0
                current = {"time": pts}
                continue

            sm = stat_re.search(line)
            if sm and current is not None:
                try:
                    current[sm.group(1).upper()] = float(sm.group(2))
                except Exception:
                    pass

        if current is not None:
            samples.append(current)

        if progress_callback is not None:
            try:
                progress_callback(1.0)
            except Exception:
                pass
        return samples

    @staticmethod
    def _hdr_inverse_hlg(v):
        """Inverse ARIB STD-B67 HLG OETF to scene-linear light."""
        import math
        v = max(0.0, min(1.0, float(v)))
        a = 0.17883277
        b = 1.0 - 4.0 * a
        c = 0.5 - a * math.log(4.0 * a)
        if v <= 0.5:
            return (v * v) / 3.0
        return (math.exp((v - c) / a) + b) / 12.0

    @staticmethod
    def _hdr_inverse_pq(v):
        """Inverse SMPTE ST 2084 (PQ) EOTF, normalized to 0..1 = 0..10000 nits."""
        v = max(0.0, min(1.0, float(v)))
        m1 = 2610.0 / 16384.0
        m2 = 2523.0 / 32.0
        c1 = 3424.0 / 4096.0
        c2 = 2413.0 / 128.0
        c3 = 2392.0 / 128.0
        p = v ** (1.0 / m2)
        num = max(p - c1, 0.0)
        den = max(c2 - c3 * p, 1e-12)
        return (num / den) ** (1.0 / m1)

    @staticmethod
    def _hdr_bt2020_to_rec709_linear(r, g, b):
        """Convert linear BT.2020 RGB to linear Rec.709 RGB.

        A negative Rec.709 component means that chromaticity lies outside the
        Rec.709 primary triangle.  We intentionally use the negative-channel
        test rather than >1.0 so HDR brightness itself is not confused with
        wide-gamut colour.
        """
        rr = 1.660491 * r - 0.587641 * g - 0.072850 * b
        gg = -0.124550 * r + 1.132900 * g - 0.008349 * b
        bb = -0.018151 * r - 0.100579 * g + 1.118730 * b
        return rr, gg, bb

    def _hdr_gamut_boundary_samples(self, path, metadata, sample_fps=1.0,
                                    width=128, height=72, duration=None,
                                    progress_callback=None):
        """Second-layer content analysis: estimate BT.2020 gamut occupancy.

        FFmpeg downsamples decoded frames to small RGB24 samples.  For HLG/PQ
        tagged BT.2020 material, RGB code values are linearized, transformed
        from BT.2020 primaries to Rec.709 primaries, then tested against the
        Rec.709 gamut boundary.  The result is a per-sample ratio of pixels
        whose chromaticity requires BT.2020 beyond Rec.709.

        This is still a QC heuristic, not a forensic proof of source colour
        space.  Its main value is detecting a sustained *change* in gamut
        occupancy inside one HDR programme.
        """
        exe = get_ffmpeg_path()
        if not exe:
            raise RuntimeError('找不到 ffmpeg.exe')

        startupinfo = None
        creationflags = 0
        if os.name == 'nt':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

        env = os.environ.copy()
        exe_dir = os.path.dirname(os.path.abspath(exe))
        env['PATH'] = exe_dir + os.pathsep + env.get('PATH', '')

        vf = 'fps=fps=%s,scale=%d:%d:flags=fast_bilinear,format=rgb24' % (
            self._ts(sample_fps), width, height
        )
        cmd = [
            exe, '-hide_banner', '-loglevel', 'error', '-i', path,
            '-vf', vf, '-an', '-sn', '-dn', '-vsync', '0',
            '-f', 'rawvideo', '-pix_fmt', 'rgb24', 'pipe:1'
        ]

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            startupinfo=startupinfo,
            creationflags=creationflags,
            env=env,
        )
        if not self._register_current_process(process):
            return []

        frame_size = int(width) * int(height) * 3
        samples = []
        frame_index = 0
        is_hlg = bool(metadata.get('is_hlg'))
        is_pq = bool(metadata.get('is_pq'))
        expected_frames = max(1, int(math.ceil(max(0.0, float(duration or 0.0)) * float(sample_fps))))

        # rgb24 has only 256 possible code values per channel.  Precomputing the
        # inverse-transfer curve removes millions of repeated pow/exp calls while
        # keeping exactly the same frame samples and gamut thresholds.
        if is_hlg:
            linear_lut = [self._hdr_inverse_hlg(v / 255.0) for v in range(256)]
        elif is_pq:
            linear_lut = [self._hdr_inverse_pq(v / 255.0) for v in range(256)]
        else:
            linear_lut = [(v / 255.0) ** 2.2 for v in range(256)]

        # Speed optimization without changing samples/thresholds: precompute the
        # linear BT.2020→Rec.709 matrix contribution of each 8-bit channel value.
        # This removes a Python function call + 9 multiplications for every pixel.
        if metadata.get("is_2020"):
            r_rr = [1.660491 * v for v in linear_lut]; r_gg = [-0.124550 * v for v in linear_lut]; r_bb = [-0.018151 * v for v in linear_lut]
            g_rr = [-0.587641 * v for v in linear_lut]; g_gg = [1.132900 * v for v in linear_lut]; g_bb = [-0.100579 * v for v in linear_lut]
            b_rr = [-0.072850 * v for v in linear_lut]; b_gg = [-0.008349 * v for v in linear_lut]; b_bb = [1.118730 * v for v in linear_lut]
        else:
            r_rr = r_gg = r_bb = g_rr = g_gg = g_bb = b_rr = b_gg = b_bb = None

        def _read_exact_gamut(stream, size):
            buf = bytearray()
            while len(buf) < size:
                if self.stop_requested:
                    return bytes(buf)
                part = stream.read(size - len(buf))
                if not part:
                    break
                buf.extend(part)
            return bytes(buf)

        try:
            while True:
                if self.stop_requested:
                    self._terminate_external_process(process)
                    break

                raw = _read_exact_gamut(process.stdout, frame_size)
                if not raw or len(raw) < frame_size:
                    break

                outside = 0
                edge_near = 0
                considered = 0
                # Ignore near-black pixels: their chromaticity is numerically
                # unstable and adds no useful gamut evidence.
                for i in range(0, frame_size, 3):
                    r = linear_lut[raw[i]]
                    g = linear_lut[raw[i + 1]]
                    b = linear_lut[raw[i + 2]]

                    peak = max(r, g, b)
                    if peak < 0.0008:
                        continue

                    if metadata.get("is_2020"):
                        ri, gi, bi = raw[i], raw[i + 1], raw[i + 2]
                        rr = r_rr[ri] + g_rr[gi] + b_rr[bi]
                        gg = r_gg[ri] + g_gg[gi] + b_gg[bi]
                        bb = r_bb[ri] + g_bb[gi] + b_bb[bi]
                    else:
                        # BT.709/SDR-labelled material is already in the reference gamut;
                        # do not falsely reinterpret its RGB values as BT.2020 primaries.
                        rr, gg, bb = r, g, b
                    considered += 1

                    # Relative tolerance prevents tiny rounding/conversion
                    # noise around the Rec.709 boundary from being counted.
                    tol = max(peak * 0.012, 1e-7)
                    if rr < -tol or gg < -tol or bb < -tol:
                        outside += 1

                    # Layer 4: gamut-boundary pile-up.
                    # Use normalized Rec.709 linear RGB chromatic direction,
                    # not absolute brightness, so HDR highlight level itself
                    # is not mistaken for gamut clipping.  Pixels extremely
                    # close to one side of the Rec.709 triangle count as an
                    # edge sample.  The detector later looks for a sustained
                    # *change* against this programme's own baseline.
                    positive_sum = max(0.0, rr) + max(0.0, gg) + max(0.0, bb)
                    if positive_sum > 1e-9:
                        nr = max(0.0, rr) / positive_sum
                        ng = max(0.0, gg) / positive_sum
                        nb = max(0.0, bb) / positive_sum
                        if min(nr, ng, nb) <= 0.012:
                            edge_near += 1

                ratio = (outside / float(considered)) if considered else 0.0
                edge_ratio = (
                    edge_near / float(considered)
                    if considered
                    else 0.0
                )
                samples.append({
                    'time': frame_index / float(sample_fps),
                    'outside709_ratio': ratio,
                    'outside709_percent': ratio * 100.0,
                    'edge709_ratio': edge_ratio,
                    'edge709_percent': edge_ratio * 100.0,
                    'considered_pixels': considered,
                })
                frame_index += 1
                if progress_callback is not None:
                    try:
                        progress_callback(min(1.0, frame_index / float(expected_frames)))
                    except Exception:
                        pass
        finally:
            try:
                if process.stdout:
                    process.stdout.close()
            except Exception:
                pass
            if process.poll() is None:
                self._terminate_external_process(process)
            self._clear_current_process(process)

        if progress_callback is not None and not self.stop_requested:
            try:
                progress_callback(1.0)
            except Exception:
                pass

        return samples

    def _hdr_find_gamut_drop_runs(self, gamut_samples, duration, fps_for_tc):
        """Locate sustained drops in BT.2020-beyond-709 gamut occupancy."""
        usable = [
            s for s in gamut_samples
            if s.get('considered_pixels', 0) > 0
        ]
        if len(usable) < 5:
            return [], {'reason': '色域樣本不足'}

        ratios = [float(s.get('outside709_ratio', 0.0)) for s in usable]
        med = self._hdr_median(ratios)
        high = sorted(ratios)[max(0, int(len(ratios) * 0.75) - 1)] if ratios else 0.0

        # If almost the entire programme itself lives inside Rec.709, there is
        # no reliable wide-gamut baseline from which to detect a 709 insert.
        if med < 0.006 and high < 0.012:
            return [], {
                'median_outside709': med,
                'p75_outside709': high,
                'reason': '全片 BT.2020 超出 Rec.709 的色域佔用本身很低，第二層色域比較證據不足',
            }

        # 以全片自己的 BT.2020 / Rec.709 gamut occupancy 作相對基準。
        # 可疑區段必須同時符合：
        #   1) 低於基準的 88%
        #   2) 與基準相差至少 5 個百分點
        # 這比舊版 med*0.38 更適合偵測「HDR -> 未轉換 Rec.709 -> HDR」混剪。
        threshold = med * 0.88
        min_absolute_drop = 0.05
        step = 1.0
        if len(usable) >= 2:
            ds = [
                usable[i]['time'] - usable[i-1]['time']
                for i in range(1, min(len(usable), 20))
                if usable[i]['time'] > usable[i-1]['time']
            ]
            if ds:
                step = self._hdr_median(ds)

        runs = []
        start = None
        last = None
        vals = []

        def flush():
            nonlocal start, last, vals
            if start is None or last is None:
                start = last = None
                vals = []
                return
            end = min(float(duration or (last + step)), last + step)
            span = max(0.0, end - start)
            if span >= 1.8 and len(vals) >= 2:
                runs.append({
                    'start': start,
                    'end': end,
                    'tc_start': self._timecode_frames(start, fps_for_tc),
                    'tc_end': self._timecode_frames(end, fps_for_tc),
                    'avg_outside709_percent': (sum(vals) / len(vals)) * 100.0,
                    'baseline_outside709_percent': med * 100.0,
                    'evidence': 'gamut',
                })
            start = last = None
            vals = []

        max_gap = step * 1.6
        for s in usable:
            t = float(s.get('time', 0.0))
            ratio = float(s.get('outside709_ratio', 0.0))
            flagged = (
                ratio <= threshold
                and (med - ratio) >= min_absolute_drop
            )
            if flagged:
                if start is None:
                    start = last = t
                    vals = [ratio]
                elif t - last <= max_gap:
                    last = t
                    vals.append(ratio)
                else:
                    flush()
                    start = last = t
                    vals = [ratio]
            else:
                flush()
        flush()

        return runs, {
            'median_outside709': med,
            'p75_outside709': high,
            'threshold': threshold,
            'min_absolute_drop': min_absolute_drop,
            'sample_count': len(usable),
        }

    def _hdr_find_gamut_edge_runs(
        self,
        gamut_samples,
        duration,
        fps_for_tc,
    ):
        """Layer 4: locate sustained Rec.709 gamut-boundary pile-up changes.

        This is deliberately a relative detector.  A colourful programme may
        naturally have many edge colours; therefore an absolute edge ratio is
        never enough to produce a warning by itself.
        """
        usable = [
            s for s in (gamut_samples or [])
            if s.get("considered_pixels", 0) > 0
            and "edge709_ratio" in s
        ]
        if len(usable) < 5:
            return [], {"reason": "色域邊界樣本不足"}

        ratios = [float(s.get("edge709_ratio", 0.0)) for s in usable]
        med = self._hdr_median(ratios)

        ordered = sorted(ratios)
        p75 = ordered[min(
            len(ordered) - 1,
            max(0, int(round((len(ordered) - 1) * 0.75))),
        )]

        # We care about a sudden concentration on the boundary.  Require both
        # a relative rise and a meaningful absolute rise to avoid noise.
        threshold = max(med * 1.45, med + 0.035, 0.055)

        step = 1.0
        if len(usable) >= 2:
            diffs = [
                usable[i]["time"] - usable[i - 1]["time"]
                for i in range(1, min(len(usable), 20))
                if usable[i]["time"] > usable[i - 1]["time"]
            ]
            if diffs:
                step = self._hdr_median(diffs)

        runs = []
        start = last = None
        vals = []

        def flush():
            nonlocal start, last, vals
            if start is None or last is None:
                start = last = None
                vals = []
                return

            end = min(
                float(duration or (last + step)),
                last + step,
            )
            if end - start >= 1.8 and len(vals) >= 2:
                avg = sum(vals) / float(len(vals))
                runs.append({
                    "start": start,
                    "end": end,
                    "tc_start": self._timecode_frames(start, fps_for_tc),
                    "tc_end": self._timecode_frames(end, fps_for_tc),
                    "edge709_percent": avg * 100.0,
                    "baseline_edge709_percent": med * 100.0,
                    "evidence": "edge",
                })

            start = last = None
            vals = []

        max_gap = step * 1.6
        for s in usable:
            t = float(s.get("time", 0.0))
            ratio = float(s.get("edge709_ratio", 0.0))
            flagged = ratio >= threshold

            if flagged:
                if start is None:
                    start = last = t
                    vals = [ratio]
                elif t - last <= max_gap:
                    last = t
                    vals.append(ratio)
                else:
                    flush()
                    start = last = t
                    vals = [ratio]
            else:
                flush()
        flush()

        return runs, {
            "median_edge709": med,
            "p75_edge709": p75,
            "threshold": threshold,
            "sample_count": len(usable),
        }

    @staticmethod
    def _hdr_signal_nominal_max(samples):
        """Infer code-value scale used by FFmpeg signalstats (8/10/12/16 bit)."""
        vmax = 0.0
        for s in samples or []:
            for key in ("YMAX", "YHIGH", "YAVG"):
                try:
                    vmax = max(vmax, float(s.get(key, 0.0)))
                except Exception:
                    pass

        if vmax <= 255.5:
            return 255.0
        if vmax <= 1023.5:
            return 1023.0
        if vmax <= 4095.5:
            return 4095.0
        return 65535.0

    @staticmethod
    def _hdr_hlg_reference_display_nits_from_code(code_value, peak_nits=1000.0):
        """Approximate HLG reference-display luminance from normalized code.

        This is used only for *relative* programme consistency checks.  It is
        not presented as absolute source-scene truth.
        """
        import math
        e = max(0.0, min(1.0, float(code_value)))

        # Inverse HLG OETF -> scene-linear relative signal.
        a = 0.17883277
        b = 1.0 - 4.0 * a
        c = 0.5 - a * math.log(4.0 * a)
        if e <= 0.5:
            scene = (e * e) / 3.0
        else:
            scene = (math.exp((e - c) / a) + b) / 12.0

        # BT.2100-style reference display system gamma for 1000 nit.
        # Keep implementation intentionally fixed/repeatable for QC comparison.
        gamma_sys = 1.2
        display_rel = max(scene, 0.0) ** gamma_sys
        return display_rel * float(peak_nits)

    def _hdr_hlg_nits_profile_for_run(self, samples, run, duration):
        """Layer 5b: compare local HLG reference-display luminance behaviour."""
        usable = [
            s for s in (samples or [])
            if "YAVG" in s and ("YHIGH" in s or "YMAX" in s)
        ]
        if len(usable) < 5:
            return {"valid": False, "reason": "HLG 亮度樣本不足"}

        code_max = self._hdr_signal_nominal_max(usable)
        start = float(run.get("start", 0.0))
        end = float(run.get("end", start))
        duration = float(duration or end)
        ref_span = 3.0

        candidate = [
            s for s in usable
            if start <= float(s.get("time", 0.0)) < end
        ]
        neighbours = [
            s for s in usable
            if (
                max(0.0, start - ref_span)
                <= float(s.get("time", 0.0))
                < start
                or end
                <= float(s.get("time", 0.0))
                <= min(duration, end + ref_span)
            )
        ]

        if len(candidate) < 2 or len(neighbours) < 2:
            return {"valid": False, "reason": "前後 HLG 參考不足"}

        def med_nits(rows, key, fallback=None):
            vals = []
            for s in rows:
                raw = s.get(key, fallback(s) if fallback else None)
                if raw is None:
                    continue
                code = max(0.0, min(1.0, float(raw) / code_max))
                vals.append(
                    self._hdr_hlg_reference_display_nits_from_code(code)
                )
            return self._hdr_median(vals) if vals else 0.0

        c_avg = med_nits(candidate, "YAVG")
        c_high = med_nits(
            candidate,
            "YHIGH",
            fallback=lambda s: s.get("YMAX"),
        )
        n_avg = med_nits(neighbours, "YAVG")
        n_high = med_nits(
            neighbours,
            "YHIGH",
            fallback=lambda s: s.get("YMAX"),
        )

        if n_avg <= 0.0 or n_high <= 0.0:
            return {"valid": False, "reason": "HLG 參考亮度無法建立"}

        avg_ratio = c_avg / n_avg
        high_ratio = c_high / n_high

        low = bool(avg_ratio <= 0.78 and high_ratio <= 0.84)
        high = bool(avg_ratio >= 1.28 and high_ratio >= 1.16)

        return {
            "valid": True,
            "direction": "low" if low else ("high" if high else "normal"),
            "candidate_avg_nits": c_avg,
            "candidate_high_nits": c_high,
            "reference_avg_nits": n_avg,
            "reference_high_nits": n_high,
            "avg_ratio": avg_ratio,
            "high_ratio": high_ratio,
        }

    def _hdr_hlg_reference_evidence_for_run(
        self,
        samples,
        run,
        duration,
    ):
        """Layer 5: local HLG reference-level consistency.

        HLG reference values (roughly 38% for 18% grey and ~75% for reference
        white) are useful anchors, but this function never assumes that every
        shot contains a grey card, skin tone or white object.

        Instead it asks a safer question:
        when neighbouring HLG shots provide enough mid/high-level reference
        information, does the candidate show a sustained collapse or expansion
        of the HLG level structure?

        This avoids treating ordinary night scenes as SDR merely because they
        are dark.
        """
        usable = [
            s for s in (samples or [])
            if "YAVG" in s and ("YHIGH" in s or "YMAX" in s)
        ]
        if len(usable) < 5:
            return {
                "valid": False,
                "direction": "none",
                "reason": "HLG 參考亮度樣本不足",
            }

        code_max = self._hdr_signal_nominal_max(usable)
        start = float(run.get("start", 0.0))
        end = float(run.get("end", start))
        duration = float(duration or end)

        # Local context rather than whole-programme median: better for
        # day/night/indoor scene changes.
        ref_span = 3.0
        before_start = max(0.0, start - ref_span)
        after_end = min(duration, end + ref_span)

        candidate = [
            s for s in usable
            if start <= float(s.get("time", 0.0)) < end
        ]
        neighbours = [
            s for s in usable
            if (
                before_start <= float(s.get("time", 0.0)) < start
                or end <= float(s.get("time", 0.0)) <= after_end
            )
        ]

        if len(candidate) < 2 or len(neighbours) < 2:
            return {
                "valid": False,
                "direction": "none",
                "reason": "可疑段前後 HLG 參考畫面不足",
            }

        def center(rows, key, fallback=None):
            vals = []
            for s in rows:
                value = s.get(key, fallback(s) if fallback else None)
                if value is not None:
                    vals.append(float(value) / code_max)
            return self._hdr_median(vals) if vals else 0.0

        c_avg = center(candidate, "YAVG")
        c_high = center(
            candidate,
            "YHIGH",
            fallback=lambda s: s.get("YMAX"),
        )
        n_avg = center(neighbours, "YAVG")
        n_high = center(
            neighbours,
            "YHIGH",
            fallback=lambda s: s.get("YMAX"),
        )

        # Reference points are used only to decide whether the local context
        # contains enough HLG information for this layer to be meaningful.
        # ~0.38 = 18% grey anchor; ~0.75 = HLG reference-white region.
        has_reference_context = bool(
            n_high >= 0.66
            or n_avg >= 0.30
        )
        if not has_reference_context:
            return {
                "valid": False,
                "direction": "none",
                "candidate_yavg": c_avg,
                "candidate_yhigh": c_high,
                "reference_yavg": n_avg,
                "reference_yhigh": n_high,
                "reason": "前後畫面屬低亮度場景，HLG 參考亮度層不作硬判定",
            }

        # Collapse: typical of unconverted SDR/709 embedded in HLG when local
        # neighbouring shots have normal HLG reference/highlight structure.
        low = bool(
            (n_avg - c_avg) >= 0.075
            and (n_high - c_high) >= 0.085
            and c_avg <= n_avg * 0.84
            and c_high <= n_high * 0.90
        )

        # Expansion: candidate is abnormally lifted/extended relative to local
        # HLG, useful as supporting evidence for duplicate HDR processing.
        high = bool(
            (c_avg - n_avg) >= 0.075
            and (c_high - n_high) >= 0.055
            and c_avg >= n_avg * 1.16
            and c_high >= n_high * 1.06
        )

        direction = "low" if low else ("high" if high else "normal")
        return {
            "valid": True,
            "direction": direction,
            "candidate_yavg": c_avg,
            "candidate_yhigh": c_high,
            "reference_yavg": n_avg,
            "reference_yhigh": n_high,
            "grey_anchor": 0.38,
            "reference_white_anchor": 0.75,
        }

    def _hdr_attach_extra_evidence(
        self,
        runs,
        edge_runs,
        samples,
        duration,
        fps_for_tc,
    ):
        """Attach layers 4 and 5 without generating standalone false alarms.

        Gamut edge pile-up and HLG reference-level consistency are supporting
        evidence.  They strengthen an already-suspicious section but do not,
        by themselves, label a normal creative shot as an error.
        """
        output = []

        for run in runs or []:
            item = dict(run)
            item["edge_evidence"] = False

            for er in edge_runs or []:
                if self._hdr_ranges_overlap(item, er, tolerance=1.0):
                    item["edge_evidence"] = True
                    item["edge_detail"] = (
                        "Rec.709 色域邊界堆積由全片約 %.2f%% 升至該段約 %.2f%%"
                        % (
                            float(er.get("baseline_edge709_percent", 0.0)),
                            float(er.get("edge709_percent", 0.0)),
                        )
                    )
                    break

            ref = self._hdr_hlg_reference_evidence_for_run(
                samples,
                item,
                duration,
            )
            item["hlg_reference"] = ref
            output.append(item)

        return output

    @staticmethod
    def _hdr_ranges_overlap(a, b, tolerance=1.0):
        return not (
            float(a.get('end', 0.0)) < float(b.get('start', 0.0)) - tolerance
            or float(b.get('end', 0.0)) < float(a.get('start', 0.0)) - tolerance
        )

    def _hdr_merge_content_evidence(self, luma_runs, gamut_runs, fps_for_tc):
        """Merge layer-1 luminance evidence with layer-2 gamut evidence."""
        merged = []
        used_gamut = set()

        for lr in luma_runs or []:
            hits = []
            for gi, gr in enumerate(gamut_runs or []):
                if self._hdr_ranges_overlap(lr, gr):
                    hits.append((gi, gr))
                    used_gamut.add(gi)

            if hits:
                start = min([lr['start']] + [g['start'] for _, g in hits])
                end = max([lr['end']] + [g['end'] for _, g in hits])
                merged.append({
                    'start': start,
                    'end': end,
                    'tc_start': self._timecode_frames(start, fps_for_tc),
                    'tc_end': self._timecode_frames(end, fps_for_tc),
                    'evidence': 'both',
                    'detail': '亮度／飽和度分布突變 + BT.2020/Rec.709 色域分布顯著下降',
                })
            else:
                item = dict(lr)
                item['evidence'] = 'luma'
                item['detail'] = 'HDR 亮度分布與全片基準明顯不一致'
                merged.append(item)

        for gi, gr in enumerate(gamut_runs or []):
            if gi in used_gamut:
                continue
            item = dict(gr)
            item['detail'] = (
                'BT.2020 中超出 Rec.709 邊界的色域佔用明顯下降 '
                '(基準 %.2f%% → 區段約 %.2f%%)'
                % (
                    float(gr.get('baseline_outside709_percent', 0.0)),
                    float(gr.get('avg_outside709_percent', 0.0)),
                )
            )
            merged.append(item)

        merged.sort(key=lambda x: float(x.get('start', 0.0)))
        return merged

    @staticmethod
    def _hdr_forward_hlg(v):
        """ARIB STD-B67 HLG OETF."""
        import math
        v = max(0.0, float(v))
        a = 0.17883277
        b = 1.0 - 4.0 * a
        c = 0.5 - a * math.log(4.0 * a)
        if v <= (1.0 / 12.0):
            return (3.0 * v) ** 0.5
        return a * math.log(12.0 * v - b) + c

    @staticmethod
    def _hdr_rec709_to_bt2020_linear(r, g, b):
        """Linear Rec.709 RGB -> linear BT.2020 RGB."""
        return (
            0.6274040 * r + 0.3292820 * g + 0.0433136 * b,
            0.0690970 * r + 0.9195400 * g + 0.0113612 * b,
            0.0163916 * r + 0.0880132 * g + 0.8955950 * b,
        )

    @staticmethod
    def _hdr_bt2020_to_rec709_matrix(r, g, b):
        """Linear BT.2020 RGB -> linear Rec.709 RGB."""
        return (
            1.6604910 * r - 0.5876411 * g - 0.0728499 * b,
            -0.1245505 * r + 1.1328999 * g - 0.0083494 * b,
            -0.0181508 * r - 0.1005789 * g + 1.1187297 * b,
        )

    def _hdr_sdr709_to_hlg_code(
        self,
        r,
        g,
        b,
        gamma=2.4,
        reference_hlg_code=0.75,
    ):
        """QC hypothesis: Rec.709 SDR -> BT.2020 HLG.

        Multiple standard-style SDR decoding / reference-white assumptions are
        tested later.  This function intentionally remains deterministic and
        technical rather than using a creative camera LUT.
        """
        gamma = float(gamma or 2.4)
        gamma = max(1.8, min(2.6, gamma))

        rl = max(0.0, min(1.0, r)) ** gamma
        gl = max(0.0, min(1.0, g)) ** gamma
        bl = max(0.0, min(1.0, b)) ** gamma

        r2, g2, b2 = self._hdr_rec709_to_bt2020_linear(rl, gl, bl)

        # Map SDR reference white to a selected HLG signal level.
        # Typical QC candidates use approximately 0.70 / 0.75 / 0.79.
        ref_code = max(0.60, min(0.85, float(reference_hlg_code)))
        reference_scale = self._hdr_inverse_hlg(ref_code)

        r2 = max(0.0, r2) * reference_scale
        g2 = max(0.0, g2) * reference_scale
        b2 = max(0.0, b2) * reference_scale

        return (
            max(0.0, min(1.0, self._hdr_forward_hlg(r2))),
            max(0.0, min(1.0, self._hdr_forward_hlg(g2))),
            max(0.0, min(1.0, self._hdr_forward_hlg(b2))),
        )

    def _hdr_sdr_hlg_candidate_models(self):
        """Return constrained SDR->HLG technical hypotheses.

        The aim is not to guess a camera LUT.  We only vary common SDR gamma
        assumptions and HLG reference-white mapping so the reverse test is not
        unfairly dependent on one exact transform.
        """
        return [
            {
                "name": "Rec.709 Gamma 2.4 / HLG 75%",
                "gamma": 2.4,
                "reference_hlg_code": 0.75,
            },
            {
                "name": "Rec.709 Gamma 2.2 / HLG 75%",
                "gamma": 2.2,
                "reference_hlg_code": 0.75,
            },
            {
                "name": "BT.1886-like / HLG 75%",
                "gamma": 2.4,
                "reference_hlg_code": 0.73,
            },
            {
                "name": "Rec.709 Gamma 2.4 / HLG 79%",
                "gamma": 2.4,
                "reference_hlg_code": 0.79,
            },
            {
                "name": "Rec.709 Gamma 2.2 / HLG 70%",
                "gamma": 2.2,
                "reference_hlg_code": 0.70,
            },
        ]


    def _hdr_inverse_extra_hdr_code(self, r, g, b):
        """Inverse of the QC SDR->HLG hypothesis.

        If an already-HLG picture was mistakenly treated as SDR and passed
        through an SDR->HLG transform again, this inverse tends to move it back
        toward its original HLG code-value distribution.
        """
        reference_scale = 0.26496256042100724

        rl = self._hdr_inverse_hlg(max(0.0, min(1.0, r))) / reference_scale
        gl = self._hdr_inverse_hlg(max(0.0, min(1.0, g))) / reference_scale
        bl = self._hdr_inverse_hlg(max(0.0, min(1.0, b))) / reference_scale

        r7, g7, b7 = self._hdr_bt2020_to_rec709_matrix(rl, gl, bl)

        inv_gamma = 1.0 / 2.4
        return (
            max(0.0, min(1.0, max(0.0, r7) ** inv_gamma)),
            max(0.0, min(1.0, max(0.0, g7) ** inv_gamma)),
            max(0.0, min(1.0, max(0.0, b7) ** inv_gamma)),
        )

    def _hdr_raw_frames_for_range(self, path, start, end, sample_fps=1.0, width=96, height=54):
        """Decode a TC range once. RGB/gamut/reverse models reuse these bytes from RAM."""
        exe = get_ffmpeg_path()
        if not exe:
            return []
        start = max(0.0, float(start or 0.0)); end = max(start, float(end or start))
        duration = max(0.05, end - start)
        cache = getattr(self, "_hdr_raw_frame_cache", None)
        if cache is None:
            cache = {}; self._hdr_raw_frame_cache = cache
        key = (os.path.abspath(path), round(start,3), round(end,3), float(sample_fps), int(width), int(height))
        if key in cache:
            return cache[key]
        startupinfo=None; creationflags=0
        if os.name == "nt":
            startupinfo=subprocess.STARTUPINFO(); startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)
        env=os.environ.copy(); exe_dir=os.path.dirname(os.path.abspath(exe)); env["PATH"]=exe_dir+os.pathsep+env.get("PATH","")
        vf="fps=fps=%s,scale=%d:%d:flags=fast_bilinear,format=rgb24" % (self._ts(sample_fps),int(width),int(height))
        cmd=[exe,"-hide_banner","-loglevel","error","-ss",self._ts(start),"-i",path,"-t",self._ts(duration),"-vf",vf,"-an","-sn","-dn","-vsync","0","-f","rawvideo","-pix_fmt","rgb24","pipe:1"]
        if self.stop_requested:
            return []
        process=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,startupinfo=startupinfo,creationflags=creationflags,env=env)
        if not self._register_current_process(process):
            return []
        fs=int(width)*int(height)*3; frames=[]
        def _read_exact_range(stream, size):
            buf=bytearray()
            while len(buf)<size:
                if self.stop_requested:
                    return bytes(buf)
                part=stream.read(size-len(buf))
                if not part:
                    break
                buf.extend(part)
            return bytes(buf)
        try:
            while not self.stop_requested:
                raw=_read_exact_range(process.stdout,fs)
                if not raw or len(raw)<fs: break
                frames.append(raw)
        finally:
            try:
                if process.stdout: process.stdout.close()
            except Exception: pass
            if process.poll() is None:
                self._terminate_external_process(process)
            self._clear_current_process(process)
        # bounded cache: reverse validation ranges are small; avoid unlimited RAM growth.
        cache[key]=frames
        if len(cache)>24:
            try: cache.pop(next(iter(cache)))
            except Exception: pass
        return frames

    def _hdr_rgb_features_for_range(self, path, start, end, transform="original", sample_fps=1.0, width=96, height=54, transform_params=None):
        frames=self._hdr_raw_frames_for_range(path,start,end,sample_fps,width,height)
        out=[]
        for raw in frames:
            lumas=[]; sat_sum=0.0; n=0
            for i in range(0,len(raw),3):
                r=raw[i]/255.0; g=raw[i+1]/255.0; b=raw[i+2]/255.0
                if transform=="sdr_to_hlg":
                    q=transform_params or {}; r,g,b=self._hdr_sdr709_to_hlg_code(r,g,b,gamma=q.get("gamma",2.4),reference_hlg_code=q.get("reference_hlg_code",0.75))
                elif transform=="inverse_extra_hdr": r,g,b=self._hdr_inverse_extra_hdr_code(r,g,b)
                y=0.2627*r+0.6780*g+0.0593*b; lumas.append(y); sat_sum += max(r,g,b)-min(r,g,b); n+=1
            if lumas:
                lumas.sort(); pi=min(len(lumas)-1,max(0,int(round((len(lumas)-1)*0.95))))
                out.append({"yavg":sum(lumas)/float(len(lumas)),"yhigh":lumas[pi],"satavg":sat_sum/float(max(1,n))})
        return out

    def _hdr_gamut_features_for_range(self, path, start, end, metadata, transform="original", sample_fps=1.0, width=96, height=54, transform_params=None):
        frames=self._hdr_raw_frames_for_range(path,start,end,sample_fps,width,height)
        rows=[]; is_hlg=bool(metadata.get("is_hlg")); is_pq=bool(metadata.get("is_pq"))
        # 8-bit decode code-value inverse transfer LUT: same maths, far fewer pow/log calls.
        lut=[]
        for c in range(256):
            v=c/255.0
            if is_hlg: lut.append(self._hdr_inverse_hlg(v))
            elif is_pq: lut.append(self._hdr_inverse_pq(v))
            else: lut.append(v**2.2)
        for raw in frames:
            outside=edge=considered=0
            for i in range(0,len(raw),3):
                ri,gi,bi=raw[i],raw[i+1],raw[i+2]
                rp=ri/255.0; gp=gi/255.0; bp=bi/255.0
                if transform=="sdr_to_hlg":
                    q=transform_params or {}; rp,gp,bp=self._hdr_sdr709_to_hlg_code(rp,gp,bp,gamma=q.get("gamma",2.4),reference_hlg_code=q.get("reference_hlg_code",0.75));
                    r=self._hdr_inverse_hlg(rp) if is_hlg else (self._hdr_inverse_pq(rp) if is_pq else rp**2.2)
                    g=self._hdr_inverse_hlg(gp) if is_hlg else (self._hdr_inverse_pq(gp) if is_pq else gp**2.2)
                    b=self._hdr_inverse_hlg(bp) if is_hlg else (self._hdr_inverse_pq(bp) if is_pq else bp**2.2)
                elif transform=="inverse_extra_hdr":
                    rp,gp,bp=self._hdr_inverse_extra_hdr_code(rp,gp,bp)
                    r=self._hdr_inverse_hlg(rp) if is_hlg else (self._hdr_inverse_pq(rp) if is_pq else rp**2.2)
                    g=self._hdr_inverse_hlg(gp) if is_hlg else (self._hdr_inverse_pq(gp) if is_pq else gp**2.2)
                    b=self._hdr_inverse_hlg(bp) if is_hlg else (self._hdr_inverse_pq(bp) if is_pq else bp**2.2)
                else: r,g,b=lut[ri],lut[gi],lut[bi]
                peak=max(r,g,b)
                if peak<0.0008: continue
                rr,gg,bb=self._hdr_bt2020_to_rec709_linear(r,g,b); considered+=1; tol=max(peak*0.012,1e-7)
                if rr < -tol or gg < -tol or bb < -tol: outside+=1
                ps=max(0.0,rr)+max(0.0,gg)+max(0.0,bb)
                if ps>1e-9 and min(max(0.0,rr)/ps,max(0.0,gg)/ps,max(0.0,bb)/ps)<=0.012: edge+=1
            if considered: rows.append({"gamut_outside":outside/float(considered),"gamut_edge":edge/float(considered)})
        return rows

    def _hdr_combined_features_for_range(
        self, path, start, end, metadata=None, transform="original",
        sample_fps=1.0, width=96, height=54, transform_params=None
    ):
        """Calculate tone/saturation and gamut metrics in one pixel pass.

        Reverse A/B validation previously walked every decoded RGB frame twice:
        once for Y/SAT and again for gamut/edge.  This helper preserves the same
        equations and sample density while combining those loops.  Results are
        cached per range/model so sandwich and reverse-validation stages can reuse
        identical measurements without decoding or rescanning pixels.
        """
        cache = getattr(self, "_hdr_combined_feature_cache", None)
        if cache is None:
            cache = {}
            self._hdr_combined_feature_cache = cache
        params_key = tuple(sorted((transform_params or {}).items()))
        key = (
            os.path.abspath(path), round(float(start or 0.0), 3),
            round(float(end or 0.0), 3), str(transform), float(sample_fps),
            int(width), int(height), bool((metadata or {}).get("is_hlg")),
            bool((metadata or {}).get("is_pq")), bool((metadata or {}).get("is_2020")),
            params_key,
        )
        if key in cache:
            return [dict(r) for r in cache[key]]

        frames = self._hdr_raw_frames_for_range(
            path, start, end, sample_fps, width, height
        )
        is_hlg = bool((metadata or {}).get("is_hlg"))
        is_pq = bool((metadata or {}).get("is_pq"))
        need_gamut = metadata is not None

        linear_lut = None
        if need_gamut and transform == "original":
            lut_cache = getattr(self, "_hdr_inverse_lut_cache", None)
            if lut_cache is None:
                lut_cache = {}
                self._hdr_inverse_lut_cache = lut_cache
            lut_key = "hlg" if is_hlg else ("pq" if is_pq else "gamma22")
            linear_lut = lut_cache.get(lut_key)
            if linear_lut is None:
                if is_hlg:
                    linear_lut = [self._hdr_inverse_hlg(v / 255.0) for v in range(256)]
                elif is_pq:
                    linear_lut = [self._hdr_inverse_pq(v / 255.0) for v in range(256)]
                else:
                    linear_lut = [(v / 255.0) ** 2.2 for v in range(256)]
                lut_cache[lut_key] = linear_lut

        out = []
        for raw in frames:
            if self.stop_requested:
                break
            lumas = []
            sat_sum = 0.0
            pixel_count = 0
            outside = 0
            edge = 0
            considered = 0

            for i in range(0, len(raw), 3):
                ri, gi, bi = raw[i], raw[i + 1], raw[i + 2]
                rp, gp, bp = ri / 255.0, gi / 255.0, bi / 255.0

                if transform == "sdr_to_hlg":
                    q = transform_params or {}
                    rp, gp, bp = self._hdr_sdr709_to_hlg_code(
                        rp, gp, bp,
                        gamma=q.get("gamma", 2.4),
                        reference_hlg_code=q.get("reference_hlg_code", 0.75),
                    )
                elif transform == "inverse_extra_hdr":
                    rp, gp, bp = self._hdr_inverse_extra_hdr_code(rp, gp, bp)

                y = 0.2627 * rp + 0.6780 * gp + 0.0593 * bp
                lumas.append(y)
                sat_sum += max(rp, gp, bp) - min(rp, gp, bp)
                pixel_count += 1

                if need_gamut:
                    if transform == "original":
                        r, g, b = linear_lut[ri], linear_lut[gi], linear_lut[bi]
                    else:
                        if is_hlg:
                            r = self._hdr_inverse_hlg(rp)
                            g = self._hdr_inverse_hlg(gp)
                            b = self._hdr_inverse_hlg(bp)
                        elif is_pq:
                            r = self._hdr_inverse_pq(rp)
                            g = self._hdr_inverse_pq(gp)
                            b = self._hdr_inverse_pq(bp)
                        else:
                            r, g, b = rp ** 2.2, gp ** 2.2, bp ** 2.2

                    peak = max(r, g, b)
                    if peak < 0.0008:
                        continue
                    rr, gg, bb = self._hdr_bt2020_to_rec709_linear(r, g, b)
                    considered += 1
                    tol = max(peak * 0.012, 1e-7)
                    if rr < -tol or gg < -tol or bb < -tol:
                        outside += 1
                    positive_sum = max(0.0, rr) + max(0.0, gg) + max(0.0, bb)
                    if positive_sum > 1e-9:
                        if min(
                            max(0.0, rr) / positive_sum,
                            max(0.0, gg) / positive_sum,
                            max(0.0, bb) / positive_sum,
                        ) <= 0.012:
                            edge += 1

            if lumas:
                lumas.sort()
                pi = min(
                    len(lumas) - 1,
                    max(0, int(round((len(lumas) - 1) * 0.95))),
                )
                row = {
                    "yavg": sum(lumas) / float(len(lumas)),
                    "yhigh": lumas[pi],
                    "satavg": sat_sum / float(max(1, pixel_count)),
                }
                if need_gamut and considered:
                    row["gamut_outside"] = outside / float(considered)
                    row["gamut_edge"] = edge / float(considered)
                out.append(row)

        cache[key] = [dict(r) for r in out]
        if len(cache) > 96:
            try:
                cache.pop(next(iter(cache)))
            except Exception:
                pass
        return out

    def _hdr_combined_features_for_models(
        self, path, start, end, metadata, models,
        sample_fps=1.0, width=96, height=54
    ):
        """Evaluate all SDR->HLG hypotheses during one raw-frame/pixel traversal.

        The five technical hypotheses still use their original equations and sample
        density.  Raw frames are decoded once and each pixel is visited once; model
        accumulators are updated together, eliminating five independent full-frame
        scans in the Reverse A/B stage.
        """
        models = [dict(m) for m in (models or [])]
        if not models:
            return {}
        frames = self._hdr_raw_frames_for_range(path, start, end, sample_fps, width, height)
        if not frames:
            return {}

        # Only two SDR gamma values are normally used. Precompute their 8-bit decode
        # LUTs and each model's HLG reference scale once per batch.
        gamma_luts = {}
        model_info = []
        for m in models:
            gamma = max(1.8, min(2.6, float(m.get('gamma', 2.4) or 2.4)))
            if gamma not in gamma_luts:
                gamma_luts[gamma] = [(v / 255.0) ** gamma for v in range(256)]
            ref_code = max(0.60, min(0.85, float(m.get('reference_hlg_code', 0.75))))
            model_info.append((m, gamma_luts[gamma], self._hdr_inverse_hlg(ref_code)))

        results = {m.get('name',''): [] for m in models}
        for raw in frames:
            if self.stop_requested:
                break
            acc = []
            for _m, _glut, _scale in model_info:
                acc.append({
                    'lumas': [], 'sat_sum': 0.0, 'pixel_count': 0,
                    'outside': 0, 'edge': 0, 'considered': 0,
                })

            for i in range(0, len(raw), 3):
                ri, gi, bi = raw[i], raw[i+1], raw[i+2]
                for mi, (_m, glut, scale) in enumerate(model_info):
                    rl, gl, bl = glut[ri], glut[gi], glut[bi]
                    r2 = max(0.0, 0.6274040 * rl + 0.3292820 * gl + 0.0433136 * bl) * scale
                    g2 = max(0.0, 0.0690970 * rl + 0.9195400 * gl + 0.0113612 * bl) * scale
                    b2 = max(0.0, 0.0163916 * rl + 0.0880132 * gl + 0.8955950 * bl) * scale
                    rp = max(0.0, min(1.0, self._hdr_forward_hlg(r2)))
                    gp = max(0.0, min(1.0, self._hdr_forward_hlg(g2)))
                    bp = max(0.0, min(1.0, self._hdr_forward_hlg(b2)))

                    a = acc[mi]
                    y = 0.2627 * rp + 0.6780 * gp + 0.0593 * bp
                    a['lumas'].append(y)
                    a['sat_sum'] += max(rp, gp, bp) - min(rp, gp, bp)
                    a['pixel_count'] += 1

                    # Exactly the same post-transform gamut calculation used by
                    # _hdr_combined_features_for_range for HLG material.
                    r = self._hdr_inverse_hlg(rp)
                    g = self._hdr_inverse_hlg(gp)
                    b = self._hdr_inverse_hlg(bp)
                    peak = max(r, g, b)
                    if peak < 0.0008:
                        continue
                    rr, gg, bb = self._hdr_bt2020_to_rec709_linear(r, g, b)
                    a['considered'] += 1
                    tol = max(peak * 0.012, 1e-7)
                    if rr < -tol or gg < -tol or bb < -tol:
                        a['outside'] += 1
                    ps = max(0.0, rr) + max(0.0, gg) + max(0.0, bb)
                    if ps > 1e-9:
                        if min(max(0.0, rr)/ps, max(0.0, gg)/ps, max(0.0, bb)/ps) <= 0.012:
                            a['edge'] += 1

            for mi, (m, _glut, _scale) in enumerate(model_info):
                a = acc[mi]
                if not a['lumas']:
                    continue
                lumas = a['lumas']
                lumas.sort()
                pi = min(len(lumas)-1, max(0, int(round((len(lumas)-1) * 0.95))))
                row = {
                    'yavg': sum(lumas) / float(len(lumas)),
                    'yhigh': lumas[pi],
                    'satavg': a['sat_sum'] / float(max(1, a['pixel_count'])),
                }
                if a['considered']:
                    row['gamut_outside'] = a['outside'] / float(a['considered'])
                    row['gamut_edge'] = a['edge'] / float(a['considered'])
                results.setdefault(m.get('name',''), []).append(row)
        return results

    def _hdr_feature_center(self, rows):
        if not rows:
            return None
        result = {
            "yavg": self._hdr_median([r.get("yavg") for r in rows]),
            "yhigh": self._hdr_median([r.get("yhigh") for r in rows]),
            "satavg": self._hdr_median([r.get("satavg") for r in rows]),
        }

        gamut_out = [
            r.get("gamut_outside")
            for r in rows
            if r.get("gamut_outside") is not None
        ]
        gamut_edge = [
            r.get("gamut_edge")
            for r in rows
            if r.get("gamut_edge") is not None
        ]

        if gamut_out:
            result["gamut_outside"] = self._hdr_median(gamut_out)
        if gamut_edge:
            result["gamut_edge"] = self._hdr_median(gamut_edge)

        return result

    @staticmethod
    def _hdr_feature_distance(a, b):
        if not a or not b:
            return 999.0

        def rel(x, y, floor):
            return abs(float(x) - float(y)) / max(abs(float(y)), floor)

        return (
            0.35 * rel(a.get("yavg", 0.0), b.get("yavg", 0.0), 0.05)
            + 0.35 * rel(a.get("yhigh", 0.0), b.get("yhigh", 0.0), 0.08)
            + 0.30 * rel(a.get("satavg", 0.0), b.get("satavg", 0.0), 0.03)
        )

    def _hdr_reverse_validate_run(
        self,
        path,
        run,
        duration,
        hypothesis,
        metadata=None,
    ):
        """Layer 6: multi-model 5-metric reverse A/B validation.

        For SDR->HLG we test several constrained technical conversion models
        instead of requiring one exact transform.  Each candidate is scored
        against local neighbouring HLG using up to five metrics:
          YAVG, YHIGH, SATAVG, gamut occupancy, gamut edge pile-up.

        For inverse-extra-HDR we keep one deterministic inverse hypothesis.
        """
        start = max(0.0, float(run.get("start", 0.0)))
        end = min(
            float(duration or run.get("end", 0.0)),
            float(run.get("end", 0.0)),
        )
        if end <= start:
            return {"valid": False, "reason": "區段時間無效"}

        # Deep reverse validation is one of the most expensive HDR stages.
        # Different candidate generators can legitimately converge on the same
        # TC range, so memoize the complete result for this file/range/hypothesis.
        reverse_cache = getattr(self, "_hdr_reverse_validation_cache", None)
        if reverse_cache is None:
            reverse_cache = {}
            self._hdr_reverse_validation_cache = reverse_cache
        reverse_key = (
            os.path.abspath(path), round(start, 3), round(end, 3),
            str(hypothesis), bool((metadata or {}).get("is_hlg")),
            bool((metadata or {}).get("is_pq")), bool((metadata or {}).get("is_2020")),
        )
        if reverse_key in reverse_cache:
            return copy.deepcopy(reverse_cache[reverse_key])

        ref_span = 3.0
        ranges = []
        if start > 0.25:
            ranges.append((max(0.0, start - ref_span), start))
        if duration and end < float(duration) - 0.25:
            ranges.append((end, min(float(duration), end + ref_span)))

        # Local reference and candidate features are calculated in one pixel pass
        # per decoded frame (tone/saturation + gamut/edge together).
        ref_rows = []
        for rs, re_ in ranges:
            ref_rows += self._hdr_combined_features_for_range(
                path, rs, re_, metadata=metadata, transform="original",
                sample_fps=1.0,
            )

        original_rows = self._hdr_combined_features_for_range(
            path, start, end, metadata=metadata, transform="original",
            sample_fps=1.0,
        )

        ref = self._hdr_feature_center(ref_rows)
        original = self._hdr_feature_center(original_rows)

        if not ref or not original:
            return {
                "valid": False,
                "reason": "可供反向驗證的相鄰畫面不足",
            }

        metrics = [
            ("yavg", "亮度／中間調", 0.05),
            ("yhigh", "高光", 0.08),
            ("satavg", "飽和度", 0.03),
            ("gamut_outside", "色域佔用", 0.02),
            ("gamut_edge", "色域邊界", 0.02),
        ]

        def score_candidate(changed):
            metric_results = {}
            improved_count = 0
            strong_count = 0
            worsened_count = 0
            available_count = 0
            before_errors = []
            after_errors = []

            for key, label, floor in metrics:
                if key not in ref or key not in original or key not in changed:
                    continue

                rv = float(ref.get(key, 0.0))
                ov = float(original.get(key, 0.0))
                cv = float(changed.get(key, 0.0))
                denom = max(abs(rv), floor)

                before_err = abs(ov - rv) / denom
                after_err = abs(cv - rv) / denom
                imp = 0.0
                if before_err > 1e-9:
                    imp = (before_err - after_err) / before_err

                improved = bool(
                    after_err < before_err
                    and imp >= 0.06
                )
                strong_improved = bool(
                    after_err < before_err
                    and imp >= 0.18
                )
                worsened = bool(
                    after_err > before_err
                    and (
                        (after_err - before_err)
                        / max(before_err, 0.03)
                    ) >= 0.20
                )

                available_count += 1
                improved_count += int(improved)
                strong_count += int(strong_improved)
                worsened_count += int(worsened)

                before_errors.append(before_err)
                after_errors.append(after_err)

                metric_results[key] = {
                    "label": label,
                    "before_error": before_err,
                    "after_error": after_err,
                    "improvement": imp,
                    "improved": improved,
                    "strong_improved": strong_improved,
                    "worsened": worsened,
                }

            if available_count < 3:
                return None

            before_score = sum(before_errors) / float(len(before_errors))
            after_score = sum(after_errors) / float(len(after_errors))
            overall = 0.0
            if before_score > 1e-9:
                overall = (before_score - after_score) / before_score

            majority = int(math.ceil(available_count * 0.60))
            strong = bool(
                before_score >= 0.06
                and after_score < before_score
                and improved_count >= majority
                and strong_count >= 2
                and worsened_count <= 1
                and overall >= 0.15
            )

            moderate = bool(
                not strong
                and before_score >= 0.05
                and after_score <= before_score * 0.985
                and improved_count >= max(
                    2,
                    int(math.ceil(available_count * 0.50)),
                )
                and worsened_count <= 1
                and overall >= 0.06
            )

            # Ranking prefers overall improvement, then number of improved
            # independent metrics, while penalizing worsening.
            rank = (
                overall
                + improved_count * 0.06
                + strong_count * 0.03
                - worsened_count * 0.10
            )

            return {
                "before": before_score,
                "after": after_score,
                "improvement": overall,
                "strong": strong,
                "moderate": moderate,
                "feature_improved_count": improved_count,
                "feature_strong_improved_count": strong_count,
                "feature_worsened_count": worsened_count,
                "available_metric_count": available_count,
                "feature_results": metric_results,
                "rank": rank,
            }

        candidates = []

        if hypothesis == "sdr_to_hlg":
            model_list = self._hdr_sdr_hlg_candidate_models()
        else:
            model_list = [{
                "name": "Inverse extra HDR",
                "inverse": True,
            }]

        batch_rows = None
        if hypothesis == "sdr_to_hlg":
            batch_rows = self._hdr_combined_features_for_models(
                path, start, end, metadata, model_list, sample_fps=1.0
            )

        for model in model_list:
            if self.stop_requested:
                break

            if hypothesis == "sdr_to_hlg":
                changed_rows = (batch_rows or {}).get(model.get("name", ""), [])
            else:
                changed_rows = self._hdr_combined_features_for_range(
                    path, start, end, metadata=metadata, transform=hypothesis,
                    sample_fps=1.0, transform_params=None,
                )

            changed = self._hdr_feature_center(changed_rows)
            if not changed:
                continue

            scored = score_candidate(changed)
            if not scored:
                continue

            scored["model_name"] = model.get("name", "")
            scored["model"] = dict(model)
            candidates.append(scored)

        if not candidates:
            return {
                "valid": False,
                "reason": "反向驗證沒有可用的轉換模型",
            }

        candidates.sort(
            key=lambda x: (
                int(bool(x.get("strong"))),
                int(bool(x.get("moderate"))),
                float(x.get("rank", -999.0)),
            ),
            reverse=True,
        )
        best = candidates[0]

        reverse_result = {
            "valid": True,
            "before": best.get("before", 0.0),
            "after": best.get("after", 0.0),
            "improvement": best.get("improvement", 0.0),
            "strong": bool(best.get("strong")),
            "moderate": bool(best.get("moderate")),
            "feature_improved_count": int(
                best.get("feature_improved_count", 0)
            ),
            "feature_strong_improved_count": int(
                best.get("feature_strong_improved_count", 0)
            ),
            "feature_worsened_count": int(
                best.get("feature_worsened_count", 0)
            ),
            "available_metric_count": int(
                best.get("available_metric_count", 0)
            ),
            "feature_results": best.get("feature_results", {}),
            "validation_mode": (
                "multi_model_sdr_hlg"
                if hypothesis == "sdr_to_hlg"
                else "inverse_extra_hdr"
            ),
            "best_model_name": best.get("model_name", ""),
            "candidate_count": len(candidates),
            "candidate_summaries": [
                {
                    "name": c.get("model_name", ""),
                    "strong": bool(c.get("strong")),
                    "moderate": bool(c.get("moderate")),
                    "improvement": float(c.get("improvement", 0.0)),
                    "improved": int(c.get("feature_improved_count", 0)),
                    "available": int(c.get("available_metric_count", 0)),
                }
                for c in candidates
            ],
        }
        reverse_cache[reverse_key] = copy.deepcopy(reverse_result)
        if len(reverse_cache) > 128:
            try:
                reverse_cache.pop(next(iter(reverse_cache)))
            except Exception:
                pass
        return reverse_result


    def _hdr_find_overprocessed_hlg_runs(
        self,
        samples,
        gamut_samples,
        duration,
        fps_for_tc,
    ):
        """Find sustained 'too HDR' candidates before reverse validation.

        Bright scenes alone are not reported.  This stage only creates
        candidates; a user-visible HLG-overprocessed warning requires the
        inverse colour-management hypothesis to improve the local match.
        """
        usable = [
            s for s in samples
            if "YAVG" in s and ("YHIGH" in s or "YMAX" in s)
        ]
        if len(usable) < 6:
            return []

        med_ya = self._hdr_median([s.get("YAVG") for s in usable])
        med_yh = self._hdr_median(
            [s.get("YHIGH", s.get("YMAX")) for s in usable]
        )
        med_sat = self._hdr_median(
            [s.get("SATAVG") for s in usable if "SATAVG" in s]
        )

        gamut_by_second = {}
        for s in gamut_samples or []:
            gamut_by_second[int(round(float(s.get("time", 0.0))))] = float(
                s.get("outside709_ratio", 0.0)
            )
        med_gamut = self._hdr_median(
            [s.get("outside709_ratio") for s in (gamut_samples or [])]
        ) if gamut_samples else 0.0

        flags = []
        for s in usable:
            t = float(s.get("time", 0.0))
            ya = float(s.get("YAVG", 0.0))
            yh = float(s.get("YHIGH", s.get("YMAX", 0.0)))
            sat = float(s.get("SATAVG", med_sat or 0.0))

            high_yavg = bool(med_ya > 0.0 and ya > med_ya * 1.18)
            high_yhigh = bool(med_yh > 0.0 and yh > med_yh * 1.07)
            high_sat = bool(med_sat > 0.0 and sat > med_sat * 1.24)

            gamut = gamut_by_second.get(int(round(t)))
            high_gamut = bool(
                gamut is not None
                and med_gamut > 0.0
                and gamut >= min(0.995, max(med_gamut * 1.10, med_gamut + 0.045))
            )

            score = (
                int(high_yavg)
                + int(high_yhigh)
                + int(high_sat)
                + int(high_gamut)
            )
            flags.append((t, score >= 2, score))

        sample_step = 0.5
        if len(usable) >= 2:
            diffs = [
                usable[i]["time"] - usable[i - 1]["time"]
                for i in range(1, min(len(usable), 20))
                if usable[i]["time"] > usable[i - 1]["time"]
            ]
            if diffs:
                sample_step = self._hdr_median(diffs)

        max_gap = sample_step * 1.75
        runs = []
        start = last = None
        scores = []

        def flush():
            nonlocal start, last, scores
            if start is None or last is None:
                start = last = None
                scores = []
                return
            end = min(
                float(duration or (last + sample_step)),
                last + sample_step,
            )
            if end - start >= 1.8 and len(scores) >= 3:
                runs.append(
                    {
                        "start": start,
                        "end": end,
                        "score": sum(scores) / float(len(scores)),
                        "tc_start": self._timecode_frames(start, fps_for_tc),
                        "tc_end": self._timecode_frames(end, fps_for_tc),
                        "evidence": "over_candidate",
                    }
                )
            start = last = None
            scores = []

        for t, flagged, score in flags:
            if flagged:
                if start is None:
                    start = last = t
                    scores = [score]
                elif t - last <= max_gap:
                    last = t
                    scores.append(score)
                else:
                    flush()
                    start = last = t
                    scores = [score]
            else:
                flush()
        flush()

        return runs

    @staticmethod
    def _hdr_median(values):
        values = sorted(float(v) for v in values if v is not None)
        if not values:
            return 0.0
        n = len(values)
        if n % 2:
            return values[n // 2]
        return (values[n // 2 - 1] + values[n // 2]) / 2.0

    def _hdr_find_suspicious_runs(self, samples, duration, fps_for_tc):
        """Find sustained content-distribution changes inside HDR-tagged video.

        A shot is not flagged merely because it is dark.  It must show a
        sustained combined drop in highlight distribution and average luma
        relative to the programme's own baseline.  Saturation is used only as
        secondary evidence.  This makes the detector useful for locating
        *possible* unconverted SDR/709 inserts while avoiding a false claim
        that the algorithm can prove a source gamut from pixels alone.
        """
        usable = [
            s for s in samples
            if "YAVG" in s and ("YHIGH" in s or "YMAX" in s)
        ]
        if len(usable) < 6:
            return [], {"reason": "有效內容樣本不足"}

        yh_values = [s.get("YHIGH", s.get("YMAX")) for s in usable]
        ya_values = [s.get("YAVG") for s in usable]
        sat_values = [s.get("SATAVG") for s in usable if "SATAVG" in s]

        med_yh = self._hdr_median(yh_values)
        med_ya = self._hdr_median(ya_values)
        med_sat = self._hdr_median(sat_values) if sat_values else 0.0

        # If the programme itself has almost no variation, relative detection
        # is intrinsically weak.  We still return metadata + statistics but do
        # not manufacture suspicious ranges.
        if med_yh <= 0.0 or med_ya <= 0.0:
            return [], {
                "median_yhigh": med_yh,
                "median_yavg": med_ya,
                "median_satavg": med_sat,
                "reason": "無法建立內容基準",
            }

        flags = []
        for s in usable:
            yh = float(s.get("YHIGH", s.get("YMAX", 0.0)))
            ya = float(s.get("YAVG", 0.0))
            sat = float(s.get("SATAVG", med_sat or 0.0))

            # 相對全片 HDR 基準檢查三項內容特徵。
            # 只因畫面較暗不會直接報警；至少 2/3 同時下降才列為第一層異常。
            low_yavg = ya < med_ya * 0.84
            low_yhigh = yh < med_yh * 0.92
            low_sat = bool(med_sat > 0.0 and sat < med_sat * 0.75)

            score = int(low_yavg) + int(low_yhigh) + int(low_sat)

            flags.append((float(s.get("time", 0.0)), score >= 2, score))

        # Merge only sustained flags. At 2 fps require >= 4 samples (~2 sec).
        runs = []
        start = None
        last = None
        scores = []

        sample_step = 0.5
        if len(usable) >= 2:
            diffs = [
                max(0.001, usable[i]["time"] - usable[i - 1]["time"])
                for i in range(1, min(len(usable), 20))
                if usable[i]["time"] > usable[i - 1]["time"]
            ]
            if diffs:
                sample_step = self._hdr_median(diffs)

        max_gap = sample_step * 1.75

        def flush():
            nonlocal start, last, scores
            if start is None or last is None:
                start = last = None
                scores = []
                return
            end = min(float(duration or (last + sample_step)), last + sample_step)
            span = max(0.0, end - start)
            count_est = int(round(span / max(sample_step, 0.001)))
            if span >= 1.8 and count_est >= 3:
                runs.append({
                    "start": start,
                    "end": end,
                    "score": (sum(scores) / float(len(scores))) if scores else 0.0,
                    "tc_start": self._timecode_frames(start, fps_for_tc),
                    "tc_end": self._timecode_frames(end, fps_for_tc),
                })
            start = last = None
            scores = []

        for t, flagged, score in flags:
            if flagged:
                if start is None:
                    start = t
                    last = t
                    scores = [score]
                elif t - last <= max_gap:
                    last = t
                    scores.append(score)
                else:
                    flush()
                    start = t
                    last = t
                    scores = [score]
            else:
                flush()
        flush()

        return runs, {
            "median_yhigh": med_yh,
            "median_yavg": med_ya,
            "median_satavg": med_sat,
            "sample_count": len(usable),
            "sample_step": sample_step,
        }

    @staticmethod
    def _hdr_expected_spec_from_metadata(metadata):
        metadata = metadata or {}
        if metadata.get("is_hlg") and metadata.get("is_2020"):
            return "BT.2020 / HLG"
        if metadata.get("is_pq") and metadata.get("is_2020"):
            return "BT.2020 / PQ"
        if metadata.get("is_2020"):
            return "BT.2020"
        if metadata.get("is_709"):
            return "BT.709 / SDR"
        return "自動判斷"

    def _hdr_selected_target_spec(self, metadata=None):
        # Internal source-content probes may temporarily force a native target
        # without touching Tk variables from a worker thread.  User-facing target
        # selection remains unchanged outside the guarded probe.
        override = getattr(self, "_hdr_target_override", None)
        if override:
            if override == "自動判斷":
                return self._hdr_expected_spec_from_metadata(metadata or {})
            return override
        try:
            selected = clean_text(self.hdr_target_spec.get())
        except Exception:
            selected = "自動判斷"
        if not selected or selected == "自動判斷":
            return self._hdr_expected_spec_from_metadata(metadata or {})
        return selected

    @staticmethod
    def _hdr_metadata_matches_target(metadata, target):
        metadata = metadata or {}
        if target == "BT.709 / SDR":
            return bool(metadata.get("is_709") and not metadata.get("is_hlg") and not metadata.get("is_pq"))
        if target == "BT.2020 / HLG":
            return bool(metadata.get("is_2020") and metadata.get("is_hlg"))
        if target == "BT.2020 / PQ":
            return bool(metadata.get("is_2020") and metadata.get("is_pq"))
        if target == "BT.2020":
            return bool(metadata.get("is_2020"))
        return True

    @staticmethod
    def _hdr_picture_spec_matches_target(actual_spec, target_spec):
        """Return whether a decoded-picture classification is compatible with a target.

        ``BT.2020`` means the picture evidence confirmed BT.2020/WCG but did not
        independently resolve the transfer function.  It is therefore compatible
        with a BT.2020, BT.2020/HLG or BT.2020/PQ target and must not be treated as
        proof that an HLG/PQ declaration is wrong.  More specific decoded-picture
        classifications remain strict.
        """
        actual_spec = clean_text(actual_spec)
        target_spec = clean_text(target_spec)
        if not actual_spec or not target_spec:
            return True
        if actual_spec == target_spec:
            return True
        if actual_spec == "BT.2020" and target_spec in (
            "BT.2020", "BT.2020 / HLG", "BT.2020 / PQ"
        ):
            return True
        # A generic BT.2020 delivery target constrains gamut, not transfer.
        # Therefore a picture independently classified as BT.2020/HLG or
        # BT.2020/PQ is still compatible with a generic BT.2020 target.
        if target_spec == "BT.2020" and actual_spec in (
            "BT.2020 / HLG", "BT.2020 / PQ"
        ):
            return True
        return False

    def _hdr_refine_picture_native_spec_from_state(self, picture, state):
        """Strengthen an inconclusive picture classification with picture-only HDR evidence.

        The programme state contains decoded-picture WCG, headroom and HLG tone
        evidence.  These fields are independent of the file's colour tags even
        though the surrounding hypothesis engine also keeps metadata priors for
        other purposes.  Only the picture-only component scores below are used.

        This is intentionally conservative: it may promote an inconclusive/BT.2020
        picture to HLG when WCG + HLG tone/headroom all agree, but it never promotes
        a picture to PQ from Metadata.
        """
        row = dict(picture or {})
        st = state or {}
        if not st.get("valid"):
            return row

        spec = clean_text(row.get("spec", ""))
        if spec not in ("", "自動畫面判斷不足", "BT.2020"):
            return row

        try:
            wcg = float(st.get("wcg_strength", 0.0) or 0.0)
            hlg = float(st.get("hlg_positive_support", 0.0) or 0.0)
            headroom = float(st.get("hdr_headroom_strength", 0.0) or 0.0)
        except Exception:
            return row

        # Three independent picture cues must agree before a HLG claim is made.
        # No MediaInfo/ffprobe HLG/PQ tag participates in this promotion.
        if wcg >= 0.62 and hlg >= 0.64 and headroom >= 0.42:
            row["spec"] = "BT.2020 / HLG"
            row["confidence"] = "極高" if (wcg >= 0.78 and hlg >= 0.78 and headroom >= 0.62) else "高"
            row["reason"] = (
                "實際畫面同時呈現持續 BT.2020/WCG 色域、HDR headroom 與 HLG 型"
                "參考白/高光結構；此判定只使用 decoded-picture 證據，不依賴 Metadata。"
            )
            row["is_709"] = False
            row["is_2020"] = True
            row["is_hlg"] = True
            row["picture_wcg_strength"] = wcg
            row["picture_hlg_support"] = hlg
            row["picture_hdr_headroom"] = headroom
            return row

        # If transfer remains unresolved but the picture itself has strong WCG
        # evidence, keep the classification at generic BT.2020.  This is not a
        # contradiction to HLG/PQ; it means only that transfer could not be proven.
        if spec in ("", "自動畫面判斷不足") and wcg >= 0.72:
            row["spec"] = "BT.2020"
            row["confidence"] = "高"
            row["reason"] = (
                "實際畫面具有明確 BT.2020/WCG 色域證據，但 transfer function 的"
                "獨立畫面證據不足，因此不強行判定 HLG 或 PQ。"
            )
            row["is_709"] = False
            row["is_2020"] = True
            row["is_hlg"] = False
            row["picture_wcg_strength"] = wcg
        return row

    @staticmethod
    def _hdr_content_profile(gamut_samples, metadata=None):
        """Target-independent programme-level WCG evidence from decoded pictures.

        Metadata is accepted only for backward call compatibility and is deliberately
        ignored.  The same decoded pixels must produce the same content profile no
        matter whether the file is tagged 709, BT.2020, HLG or PQ.

        Low outside-709 occupancy is only weak/negative WCG evidence; it never by
        itself proves that the programme is Rec.709/SDR.
        """
        usable=[x for x in (gamut_samples or []) if x.get("considered_pixels",0)>0]
        ratios=[float(x.get("outside709_ratio",0.0)) for x in usable]
        if not ratios:
            return {"kind":"畫面色域證據不足","confidence":"一般","median_outside709":0.0,"p75_outside709":0.0,"wcg_temporal_coverage":0.0,"strong_wcg_coverage":0.0,"sample_count":0}
        ordered=sorted(ratios)
        med=ordered[len(ordered)//2]
        p75=ordered[min(len(ordered)-1,int(round((len(ordered)-1)*0.75)))]
        coverage=sum(1 for x in ratios if x>=0.02)/float(len(ratios))
        strong_coverage=sum(1 for x in ratios if x>=0.04)/float(len(ratios))

        # One uniform threshold set for every file.  These are intentionally
        # conservative because ordinary BT.2020/HLG material may legitimately
        # keep most colours inside Rec.709.
        strong_wcg = bool(
            (med >= 0.040 and p75 >= 0.075 and coverage >= 0.55)
            or (p75 >= 0.110 and strong_coverage >= 0.35)
        )
        moderate_wcg = bool(
            (med >= 0.015 and p75 >= 0.035 and coverage >= 0.25)
            or (p75 >= 0.060 and strong_coverage >= 0.15)
        )

        if strong_wcg:
            kind = "具有明確且持續的 BT.2020 / WCG 色域內容特徵"
            conf = "極高" if (coverage >= 0.78 or med >= 0.065) else "高"
        elif moderate_wcg:
            kind = "BT.2020 / WCG 內容證據有限，需結合亮度／transfer／matrix 畫面證據判斷"
            conf = "一般"
        else:
            kind = "BT.2020/WCG 持續證據偏低（單靠色域佔用不能判定 Rec.709 / SDR）"
            conf = "高" if (len(usable)>=20 and coverage<0.20 and p75<0.025) else "一般"

        return {
            "kind":kind, "confidence":conf,
            "median_outside709":med, "p75_outside709":p75,
            "sample_count":len(usable),
            "wcg_temporal_coverage":coverage,
            "strong_wcg_coverage":strong_coverage,
            "strong_wcg":strong_wcg,
            "moderate_wcg":moderate_wcg,
        }


    @staticmethod
    def _hdr_percentile(values, q):
        vals = sorted(float(v) for v in (values or []) if v is not None)
        if not vals:
            return 0.0
        q = max(0.0, min(1.0, float(q)))
        pos = (len(vals) - 1) * q
        lo = int(math.floor(pos)); hi = int(math.ceil(pos))
        if lo == hi:
            return vals[lo]
        frac = pos - lo
        return vals[lo] * (1.0 - frac) + vals[hi] * frac

    def _hdr_program_fingerprint(self, samples, gamut_samples):
        """Target-independent whole-programme colour-state fingerprint.

        This layer deliberately does not decide the colour space from one magic
        waveform number.  It summarizes tone, saturation, clipping/headroom and
        Rec.709-gamut occupancy so later hypotheses can compete on the same data.
        """
        usable = [s for s in (samples or []) if s.get('YAVG') is not None and (s.get('YHIGH') is not None or s.get('YMAX') is not None)]
        scale = max(1.0, float(self._hdr_signal_nominal_max(usable))) if usable else 255.0
        yav = [max(0.0, min(1.25, float(s.get('YAVG', 0.0)) / scale)) for s in usable]
        yhi = [max(0.0, min(1.25, float(s.get('YHIGH', s.get('YMAX', 0.0))) / scale)) for s in usable]
        ymax = [max(0.0, min(1.25, float(s.get('YMAX', s.get('YHIGH', 0.0))) / scale)) for s in usable]
        sat = [max(0.0, float(s.get('SATAVG', 0.0)) / scale) for s in usable if s.get('SATAVG') is not None]
        # Whole-programme code-domain shape cues.  These are intentionally
        # target-independent and are used only as supporting evidence in Layer 7.
        # A HLG master that has already been down-mapped to SDR and then merely
        # re-tagged/re-encoded as HLG can retain apparent WCG occupancy, so gamut
        # occupancy alone is not sufficient.  Sustained upper-tone expansion plus
        # unusually expanded chroma is a useful independent transform-history cue.
        joint_expansion = []
        chroma_luma_ratio = []
        for row in usable:
            try:
                yy = max(0.0, min(1.25, float(row.get('YHIGH', row.get('YMAX', 0.0))) / scale))
                ya = max(0.0, min(1.25, float(row.get('YAVG', 0.0)) / scale))
                sa = max(0.0, float(row.get('SATAVG', 0.0)) / scale)
            except Exception:
                continue
            chroma_luma_ratio.append(sa / max(0.05, ya))
            # Require both tone and chroma expansion in the same sampled frame.
            joint_expansion.append(1.0 if (yy >= 0.78 and sa >= 0.28) else 0.0)
        gs = [g for g in (gamut_samples or []) if int(g.get('considered_pixels', 0) or 0) > 0]
        gout = [max(0.0, float(g.get('outside709_ratio', 0.0))) for g in gs]
        gedge = [max(0.0, float(g.get('edge709_ratio', 0.0))) for g in gs]
        def cov(vals, pred):
            return (sum(1 for v in vals if pred(v)) / float(len(vals))) if vals else 0.0
        return {
            'sample_count': len(usable),
            'gamut_sample_count': len(gs),
            'yavg_p25': self._hdr_percentile(yav, 0.25),
            'yavg_p50': self._hdr_percentile(yav, 0.50),
            'yavg_p75': self._hdr_percentile(yav, 0.75),
            'yhigh_p50': self._hdr_percentile(yhi, 0.50),
            'yhigh_p75': self._hdr_percentile(yhi, 0.75),
            'yhigh_p95': self._hdr_percentile(yhi, 0.95),
            'yhigh_p99': self._hdr_percentile(yhi, 0.99),
            'ymax_p95': self._hdr_percentile(ymax, 0.95),
            'ymax_p99': self._hdr_percentile(ymax, 0.99),
            'sat_p50': self._hdr_percentile(sat, 0.50),
            'sat_p90': self._hdr_percentile(sat, 0.90),
            'upper_shoulder_coverage': cov(yhi, lambda v: v >= 0.78),
            'high_chroma_coverage': cov(sat, lambda v: v >= 0.28),
            'tone_chroma_expansion_coverage': (sum(joint_expansion) / float(len(joint_expansion))) if joint_expansion else 0.0,
            'chroma_luma_ratio_p50': self._hdr_percentile(chroma_luma_ratio, 0.50),
            'near_75_high_coverage': cov(yhi, lambda v: 0.69 <= v <= 0.82),
            'near_sdr_white_coverage': cov(yhi, lambda v: v >= 0.90),
            'near_clip_coverage': cov(yhi, lambda v: v >= 0.965),
            'gamut_out_p50': self._hdr_percentile(gout, 0.50),
            'gamut_out_p75': self._hdr_percentile(gout, 0.75),
            'gamut_out_p95': self._hdr_percentile(gout, 0.95),
            'gamut_wcg_coverage': cov(gout, lambda v: v >= 0.02),
            'gamut_strong_wcg_coverage': cov(gout, lambda v: v >= 0.04),
            'gamut_edge_p75': self._hdr_percentile(gedge, 0.75),
        }

    @staticmethod
    def _hdr_clamp01(v):
        return max(0.0, min(1.0, float(v)))

    def _hdr_picture_native_spec(self, fingerprint, matrix_probe=None):
        """Classify the *picture* colour state without trusting metadata tags.

        This helper deliberately ignores MediaInfo / ffprobe colour primaries and
        transfer declarations.  It uses only decoded-picture evidence already
        produced by the HDR module:

        * raw Y'CbCr behaviour under BT.709 vs BT.2020-NCL matrices;
        * code-domain highlight / reference-white distribution;
        * saturation / picture-information guards.

        The result is therefore an actual-content judgement.  Container / VUI
        signalling remains useful only as a separate compliance cross-check.
        """
        fp = fingerprint or {}
        mp = matrix_probe or {}

        sample_count = int(fp.get("sample_count", 0) or 0)
        if sample_count < 1 or not mp.get("valid"):
            return {
                "spec": "自動畫面判斷不足",
                "confidence": "一般",
                "reason": "實際畫面樣本或 raw YCbCr matrix 證據不足",
                "is_709": False,
                "is_2020": False,
                "is_hlg": False,
            }

        e709 = max(0.0, float(mp.get("excess709", 0.0) or 0.0))
        e2020 = max(0.0, float(mp.get("excess2020", 0.0) or 0.0))
        ratio = float(mp.get("matrix_advantage_ratio", 1.0) or 1.0)
        y95 = float(mp.get("y_p95", fp.get("yhigh_p95", 0.0)) or 0.0)
        y99 = float(mp.get("y_p99", fp.get("yhigh_p99", 0.0)) or 0.0)
        chroma = float(mp.get("mean_abs_chroma", 0.0) or 0.0)

        # Matrix judgement uses only the decoded Y'CbCr values.  A ratio < 1 means
        # the BT.709 matrix produces less illegal/excess RGB energy than BT.2020;
        # > 1 means BT.2020 fits better.  Require useful exposure/chroma so dark or
        # near-monochrome pictures are not over-classified.
        picture_informative = bool(y95 >= 0.45 and chroma >= 0.035)
        eps = 1e-7
        fit709 = (e709 + eps) / (e2020 + eps)
        fit2020 = (e2020 + eps) / (e709 + eps)

        strong_709 = bool(
            picture_informative
            and ratio <= 0.82
            and fit709 <= 0.82
        )
        strong_2020 = bool(
            picture_informative
            and ratio >= 1.22
            and fit2020 <= 0.82
        )

        # When both excess values are tiny, the matrix alone is weak.  Do not use
        # the file's declared colour space to break the tie.  Keep the picture
        # judgement conservative instead.
        matrix_energy = max(e709, e2020)
        if matrix_energy < 0.000035:
            strong_709 = False
            strong_2020 = False

        # Transfer/tone evidence, again from picture code values only.  HLG is not
        # inferred from a tag.  It needs a BT.2020-like matrix fit plus a plausible
        # HLG reference/highlight structure with usable picture information.
        ref75_cov = float(fp.get("near_75_high_coverage", 0.0) or 0.0)
        near_white_cov = float(fp.get("near_sdr_white_coverage", 0.0) or 0.0)
        clip_cov = float(fp.get("near_clip_coverage", 0.0) or 0.0)
        ymax95 = float(fp.get("ymax_p95", y95) or y95)
        ymax99 = float(fp.get("ymax_p99", y99) or y99)

        hlg_reference = self._hdr_clamp01(ref75_cov / 0.28)
        hlg_headroom = self._hdr_clamp01((ymax99 - 0.92) / 0.07)
        hlg_not_sdr_clip = self._hdr_clamp01(1.0 - clip_cov / 0.28)
        hlg_not_white_pileup = self._hdr_clamp01(1.0 - near_white_cov / 0.72)
        hlg_score = self._hdr_clamp01(
            0.38 * hlg_reference
            + 0.34 * hlg_headroom
            + 0.16 * hlg_not_sdr_clip
            + 0.12 * hlg_not_white_pileup
        )

        if strong_709:
            confidence = "極高" if ratio <= 0.68 and fit709 <= 0.68 else "高"
            return {
                "spec": "BT.709 / SDR",
                "confidence": confidence,
                "reason": (
                    "實際 raw YCbCr 畫面以 BT.709 matrix 解釋明顯較自然"
                    "（709/2020 excess 比值 %.3f）；不採用檔案色彩標示作判定。"
                    % ratio
                ),
                "is_709": True,
                "is_2020": False,
                "is_hlg": False,
                "matrix_ratio": ratio,
                "hlg_picture_score": hlg_score,
            }

        if strong_2020:
            is_hlg_picture = bool(hlg_score >= 0.58 and ymax95 >= 0.70)
            if is_hlg_picture:
                confidence = "高" if hlg_score < 0.74 else "極高"
                return {
                    "spec": "BT.2020 / HLG",
                    "confidence": confidence,
                    "reason": (
                        "實際 raw YCbCr 畫面較符合 BT.2020 matrix，且畫面亮度/"
                        "參考白/高光結構符合 HLG 型態；判定不依賴 Metadata。"
                    ),
                    "is_709": False,
                    "is_2020": True,
                    "is_hlg": True,
                    "matrix_ratio": ratio,
                    "hlg_picture_score": hlg_score,
                }
            return {
                "spec": "BT.2020",
                "confidence": "高" if ratio >= 1.45 else "一般",
                "reason": (
                    "實際 raw YCbCr 畫面較符合 BT.2020 matrix，但 HLG transfer 的"
                    "獨立畫面證據未達門檻；不因檔案標示 HLG 而直接判 HLG。"
                ),
                "is_709": False,
                "is_2020": True,
                "is_hlg": False,
                "matrix_ratio": ratio,
                "hlg_picture_score": hlg_score,
            }

        return {
            "spec": "自動畫面判斷不足",
            "confidence": "一般",
            "reason": (
                "BT.709 與 BT.2020 matrix 對此畫面的差異不足，不能只靠標示強行判定；"
                "請以人工波形/原始製作資訊複核。"
            ),
            "is_709": False,
            "is_2020": False,
            "is_hlg": False,
            "matrix_ratio": ratio,
            "hlg_picture_score": hlg_score,
        }

    def _hdr_multi_hypothesis_color_state(self, metadata, fingerprint, content_profile=None, matrix_probe=None):
        """Layer 7 — whole-programme multi-hypothesis colour-state fusion.

        Release rule:
        * WCG evidence proves gamut usage only; it must not by itself prove a
          correct HLG transfer/tone state.
        * A declared HLG picture is considered healthy only when independent
          HLG-positive tone/headroom evidence is also present, or when the
          programme is too dark/low-chroma to make a safe absolute judgement.
        * Whole-programme mismatches are detected from the samples already
          collected by the normal HDR scan.  No extra progress stage is added.
        """
        md = metadata or {}
        fp = fingerprint or {}
        cp = content_profile or {}
        mp = matrix_probe or {}
        if int(fp.get('sample_count', 0) or 0) < 6:
            return {'valid': False, 'reason': '整片內容樣本不足'}

        out50 = float(fp.get('gamut_out_p50', 0.0) or 0.0)
        out75 = float(fp.get('gamut_out_p75', 0.0) or 0.0)
        wcg_cov = float(fp.get('gamut_wcg_coverage', 0.0) or 0.0)
        strong_cov = float(fp.get('gamut_strong_wcg_coverage', 0.0) or 0.0)
        y95 = float(fp.get('yhigh_p95', 0.0) or 0.0)
        y99 = float(fp.get('yhigh_p99', 0.0) or 0.0)
        ymax95 = float(fp.get('ymax_p95', y99) or y99)
        ymax99 = float(fp.get('ymax_p99', ymax95) or ymax95)
        white_cov = float(fp.get('near_sdr_white_coverage', 0.0) or 0.0)
        clip_cov = float(fp.get('near_clip_coverage', 0.0) or 0.0)
        ref75_cov = float(fp.get('near_75_high_coverage', 0.0) or 0.0)
        sat50 = float(fp.get('sat_p50', 0.0) or 0.0)
        yavg50 = float(fp.get('yavg_p50', 0.0) or 0.0)
        upper_shoulder_cov = float(fp.get('upper_shoulder_coverage', 0.0) or 0.0)
        high_chroma_cov = float(fp.get('high_chroma_coverage', 0.0) or 0.0)
        expansion_cov = float(fp.get('tone_chroma_expansion_coverage', 0.0) or 0.0)
        chroma_luma_ratio = float(fp.get('chroma_luma_ratio_p50', 0.0) or 0.0)

        # ----- Independent evidence family A: gamut / WCG -----
        # content_profile is intentionally used only as a consistency guard for
        # the SAME gamut family; it is not counted as another independent vote.
        cp_p75 = float(cp.get('p75_outside709', out75) or 0.0)
        cp_cov = float(cp.get('wcg_temporal_coverage', wcg_cov) or 0.0)
        profile_wcg_confirmed = bool(cp_p75 >= 0.025 or cp_cov >= 0.30)
        wcg_strength = self._hdr_clamp01(
            0.45 * (out75 / 0.055) +
            0.35 * (wcg_cov / 0.55) +
            0.20 * (strong_cov / 0.35)
        )
        if not profile_wcg_confirmed:
            wcg_strength *= 0.72
        narrow709 = self._hdr_clamp01(1.0 - wcg_strength)

        # ----- Independent evidence family B: SDR-like upper-tone shape -----
        sdr_white_strength = self._hdr_clamp01(
            0.45 * max(0.0, (y95 - 0.86) / 0.12) +
            0.35 * (white_cov / 0.45) +
            0.20 * (clip_cov / 0.20)
        )

        ratio_strength = self._hdr_clamp01((chroma_luma_ratio - 0.50) / 0.35)
        transform_expansion_strength = self._hdr_clamp01(
            0.40 * (upper_shoulder_cov / 0.70) +
            0.35 * (high_chroma_cov / 0.70) +
            0.25 * (expansion_cov / 0.65)
        )
        transform_expansion_strength = self._hdr_clamp01(
            0.82 * transform_expansion_strength + 0.18 * ratio_strength
        )

        # ----- Independent evidence family C: real HDR/HLG headroom -----
        # This must stay separate from WCG.  A re-tagged/down-mapped picture can
        # retain apparent BT.2020/WCG occupancy while no longer behaving like a
        # healthy HLG tone state.
        sdr_ceiling_strength = self._hdr_clamp01((0.945 - ymax95) / 0.075)
        hdr_headroom_strength = self._hdr_clamp01((ymax95 - 0.945) / 0.045)
        if ymax99 >= 0.985:
            hdr_headroom_strength = max(hdr_headroom_strength, 0.90)

        ref75_strength = self._hdr_clamp01(ref75_cov / 0.35)
        hlg_tone_support = self._hdr_clamp01(
            0.58 * ref75_strength +
            0.42 * hdr_headroom_strength
        )
        hlg_positive_support = self._hdr_clamp01(
            0.52 * hlg_tone_support +
            0.28 * hdr_headroom_strength +
            0.20 * wcg_strength
        )

        # Very dark / very low-chroma programmes do not contain enough absolute
        # picture evidence for a safe whole-programme transfer judgement.
        # This protects the existing low-light / low-saturation HLG regression.
        exposure_ok = bool(yavg50 >= 0.10 or y95 >= 0.55)
        chroma_ok = bool(sat50 >= 0.015 or wcg_cov >= 0.05)
        picture_informative = bool(
            exposure_ok and chroma_ok and
            (y95 >= 0.62 or ymax95 >= 0.80)
        )

        # ----- Independent evidence family D: raw Y'CbCr matrix behaviour -----
        # The raw probe is already run by the existing metadata-only cross-check
        # in PASS-like HLG cases.  "valid" only means a probe succeeded; it must
        # NOT be treated as mismatch by itself.
        matrix_valid = bool(mp.get('valid'))
        matrix_ratio = float(mp.get('matrix_advantage_ratio', 99.0) or 99.0)
        matrix_e20 = float(mp.get('excess2020', 9.0) or 9.0)
        matrix_y95 = float(mp.get('y_p95', 0.0) or 0.0)
        matrix_chroma = float(mp.get('mean_abs_chroma', 0.0) or 0.0)
        matrix_picture_ok = bool(matrix_y95 >= 0.60 and matrix_chroma >= 0.055)
        matrix_sdr_support = 0.0
        if matrix_valid and matrix_picture_ok:
            ratio_part = self._hdr_clamp01((2.55 - matrix_ratio) / 1.25)
            excess_part = self._hdr_clamp01((0.00060 - matrix_e20) / 0.00050)
            matrix_sdr_support = self._hdr_clamp01(
                0.58 * ratio_part + 0.42 * excess_part
            )
        matrix_mismatch = bool(matrix_sdr_support >= 0.58)

        # Alternative SDR/709-state support deliberately excludes the WCG score.
        # A file may still contain some wide-gamut colours after a bad/partial
        # conversion, so WCG must not veto an otherwise strong tone-state warning.
        sdr_alternative_support = self._hdr_clamp01(
            0.42 * sdr_ceiling_strength +
            0.30 * transform_expansion_strength +
            0.16 * sdr_white_strength +
            0.12 * matrix_sdr_support
        )

        scores = {}
        scores['normal_709_sdr'] = self._hdr_clamp01(
            0.65 * narrow709 +
            0.20 * sdr_white_strength +
            0.15 * (1.0 if not md.get('is_2020') else 0.0)
        )
        scores['normal_bt2020_wcg'] = self._hdr_clamp01(
            0.80 * wcg_strength +
            0.20 * (1.0 if md.get('is_2020') else 0.0)
        )

        # HLG is no longer "metadata + WCG = normal".  Metadata contributes only
        # a small prior; real tone/headroom evidence carries most of the score.
        _normal_hlg_base = self._hdr_clamp01(
            0.30 * wcg_strength +
            0.38 * hlg_tone_support +
            0.20 * hdr_headroom_strength +
            0.12 * (1.0 if md.get('is_hlg') else 0.0)
        )
        scores['normal_hlg'] = self._hdr_clamp01(
            _normal_hlg_base *
            (1.0 - 0.34 * transform_expansion_strength) *
            (1.0 - 0.18 * matrix_sdr_support)
        )
        scores['normal_pq'] = self._hdr_clamp01(
            0.55 * wcg_strength +
            0.20 * (1.0 - min(1.0, clip_cov / 0.40)) +
            0.25 * (1.0 if md.get('is_pq') else 0.0)
        )

        hdr_tag = bool(md.get('is_hlg') or md.get('is_pq'))
        bt2020_tag = bool(md.get('is_2020'))
        downmap_bias = 1.0 if hdr_tag else (0.72 if bt2020_tag else 0.0)

        if md.get('is_hlg'):
            # Keep the original strict "already converted to 709" model for
            # high-specificity cases.  It remains the route that can claim the
            # more specific HLG->709 diagnosis.
            scores['already_to_709'] = self._hdr_clamp01(downmap_bias * (
                0.05 * narrow709 +
                0.03 * sdr_white_strength +
                0.57 * transform_expansion_strength +
                0.10 * expansion_cov +
                0.25 * sdr_ceiling_strength
            ))
        else:
            scores['already_to_709'] = self._hdr_clamp01(downmap_bias * (
                0.50 * narrow709 +
                0.35 * sdr_white_strength +
                0.15 * (1.0 if exposure_ok else 0.0)
            ))

        scores['metadata_only_sdr'] = self._hdr_clamp01(
            (1.0 if bt2020_tag else 0.0) * (
                0.50 * narrow709 +
                0.25 * matrix_sdr_support +
                0.15 * (1.0 if exposure_ok else 0.0) +
                0.10 * (1.0 if chroma_ok else 0.0)
            )
        )

        declared_fit = (
            scores['normal_hlg'] if md.get('is_hlg')
            else (
                scores['normal_pq'] if md.get('is_pq')
                else (
                    scores['normal_bt2020_wcg']
                    if bt2020_tag else scores['normal_709_sdr']
                )
            )
        )

        # Internal transform-consistency score only.
        # Release policy: this score is NOT allowed to create a whole-program
        # WARNING by itself.  Headroom / SDR ceiling / raw-matrix behaviour vary
        # too much across legitimate HLG programmes to serve as a generic gate.
        # It remains available only as supporting evidence for future validated
        # detectors and for specific high-specificity routes.
        ambiguous_transform = self._hdr_clamp01(
            (1.0 - declared_fit) * 0.70 +
            min(wcg_strength, narrow709) * 0.30
        )
        if md.get('is_hlg'):
            hlg_integrity_gap = self._hdr_clamp01(
                0.48 * (1.0 - hlg_positive_support) +
                0.36 * sdr_alternative_support +
                0.16 * matrix_sdr_support
            )
            if not picture_informative:
                hlg_integrity_gap *= 0.45
            scores['wrong_transform'] = max(
                ambiguous_transform,
                self._hdr_clamp01(hlg_integrity_gap)
            )
        else:
            scores['wrong_transform'] = ambiguous_transform

        ordered = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
        best_name, best_score = ordered[0]
        second_score = ordered[1][1] if len(ordered) > 1 else 0.0
        margin = best_score - second_score

        warning_type = None
        warning_score = 0.0
        warning_margin = 0.0

        if bt2020_tag:
            # Route 1: specific, high-confidence HLG/PQ -> 709/down-map diagnosis.
            if (
                scores['already_to_709'] >= 0.76
                and scores['already_to_709'] - declared_fit >= 0.14
                and (
                    (
                        md.get('is_hlg')
                        and transform_expansion_strength >= 0.82
                        and expansion_cov >= 0.70
                        and upper_shoulder_cov >= 0.70
                        and high_chroma_cov >= 0.70
                        and chroma_luma_ratio >= 0.62
                        and sdr_ceiling_strength >= 0.45
                        and hdr_headroom_strength < 0.35
                    )
                    or (
                        narrow709 >= 0.62
                        and sdr_white_strength >= 0.46
                    )
                )
            ):
                warning_type = 'already_to_709'
                warning_score = scores['already_to_709']
                warning_margin = scores['already_to_709'] - declared_fit

            # Route 2: metadata-only / unconverted SDR diagnosis.
            elif (
                scores['metadata_only_sdr'] >= 0.78
                and scores['metadata_only_sdr'] - declared_fit >= 0.18
                and narrow709 >= 0.68
                and (
                    matrix_mismatch
                    or (wcg_cov < 0.16 and out75 < 0.022)
                )
            ):
                warning_type = 'metadata_only_sdr'
                warning_score = scores['metadata_only_sdr']
                warning_margin = scores['metadata_only_sdr'] - declared_fit


        independent_evidence_count = 0
        if warning_type == 'already_to_709':
            independent_evidence_count += int(transform_expansion_strength >= 0.82)
            independent_evidence_count += int(
                sdr_ceiling_strength >= 0.45
                and hdr_headroom_strength < 0.35
            )
            independent_evidence_count += int(narrow709 >= 0.62)
            independent_evidence_count += int(sdr_white_strength >= 0.46)
        elif warning_type == 'metadata_only_sdr':
            independent_evidence_count += int(narrow709 >= 0.68)
            independent_evidence_count += int(matrix_mismatch)
            independent_evidence_count += int(wcg_cov < 0.16 and out75 < 0.022)

        if (
            warning_score >= 0.90
            and warning_margin >= 0.28
            and independent_evidence_count >= 3
        ):
            confidence = '極高'
        elif (
            warning_score >= 0.80
            and warning_margin >= 0.16
            and independent_evidence_count >= 2
        ):
            confidence = '高'
        else:
            confidence = '一般'

        return {
            'valid': True,
            'scores': scores,
            'best_hypothesis': best_name,
            'best_score': best_score,
            'second_score': second_score,
            'margin': margin,
            'declared_fit': declared_fit,
            'warning_type': warning_type,
            'warning_score': warning_score,
            'warning_margin': warning_margin,
            'confidence': confidence,
            'wcg_strength': wcg_strength,
            'narrow709_strength': narrow709,
            'sdr_white_strength': sdr_white_strength,
            'hlg_reference_support': hlg_tone_support,
            'hlg_positive_support': hlg_positive_support,
            'sdr_alternative_support': sdr_alternative_support,
            'transform_expansion_strength': transform_expansion_strength,
            'sdr_ceiling_strength': sdr_ceiling_strength,
            'hdr_headroom_strength': hdr_headroom_strength,
            'matrix_sdr_support': matrix_sdr_support,
            'independent_evidence_count': independent_evidence_count,
            'ymax_p95': ymax95,
            'ymax_p99': ymax99,
            'tone_chroma_expansion_coverage': expansion_cov,
            'upper_shoulder_coverage': upper_shoulder_cov,
            'high_chroma_coverage': high_chroma_cov,
            'chroma_luma_ratio_p50': chroma_luma_ratio,
            'matrix_mismatch_support': matrix_mismatch,
        }

    def _hdr_color_state_warning_run(self, state, metadata, fingerprint, duration, fps, target_spec):
        state = state or {}
        kind = state.get('warning_type')
        if not state.get('valid') or not kind or float(duration or 0.0) < 0.50:
            return None
        md = metadata or {}
        if kind == 'already_to_709':
            if md.get('is_hlg'):
                category = 'transform_hlg_to_709'
                title_detail = '畫面疑似已完成 HLG → Rec.709 / SDR 轉換，但檔案仍保留 BT.2020 / HLG 標示'
            elif md.get('is_pq'):
                category = 'transform_pq_to_709'
                title_detail = '畫面疑似已完成 PQ/HDR → Rec.709 / SDR 轉換，但檔案仍保留 BT.2020 / PQ 標示'
            else:
                category = 'transform_2020_to_709'
                title_detail = '畫面疑似已轉為 Rec.709 型內容，但檔案仍保留 BT.2020 標示'
        elif kind == 'metadata_only_sdr':
            category = 'transform_sdr_mistag_hdr'
            title_detail = '畫面疑似仍是 Rec.709 / SDR，但檔案被標示為 BT.2020 / HDR；可能只改了 Metadata 或未完成應有色彩轉換'
        else:
            category = 'transform_wrong'
            title_detail = '畫面疑似經過不適當或錯誤的 LUT / 色彩空間轉換，實際訊號與檔案標示無法合理吻合'

        fp = fingerprint or {}
        detail = (
            '%s；多方向比對：Rec.709 型色域收窄=%.0f%%、SDR white/高位訊號特徵=%.0f%%、'
            'Tone+Chroma 轉換形態=%.0f%%、SDR 峰值壓縮特徵=%.0f%%、宣告色彩狀態吻合度=%.0f%%。'
            '此結果只表示「疑似」，不代表能從成品反推出具體 LUT 名稱。'
            % (
                title_detail,
                float(state.get('narrow709_strength', 0.0)) * 100.0,
                float(state.get('sdr_white_strength', 0.0)) * 100.0,
                float(state.get('transform_expansion_strength', 0.0)) * 100.0,
                float(state.get('sdr_ceiling_strength', 0.0)) * 100.0,
                float(state.get('declared_fit', 0.0)) * 100.0,
            )
        )
        return {
            'start': 0.0, 'end': float(duration),
            'tc_start': self._timecode_frames(0.0, fps),
            'tc_end': self._timecode_frames(float(duration), fps),
            'category': category,
            'confidence': state.get('confidence', '一般'),
            'evidence': 'color_state_fusion',
            'detail': detail,
            'target_spec': target_spec,
            'color_state': state,
            'fingerprint': fp,
        }

    @staticmethod
    def _hdr_confidence_rank(value):
        return {"一般": 1, "高": 2, "極高": 3}.get(str(value or ""), 0)

    def _hdr_raw_matrix_consistency_probe(self, path, duration=None, sample_fps=0.5, width=64, height=36):
        """Small, target-independent code-domain check for possible metadata-only BT.2020/HLG tagging.

        The normal gamut detector intentionally interprets the file according to its declared
        metadata.  If an SDR/Rec.709 master is *only* re-tagged as BT.2020/HLG, that interpretation
        itself can manufacture apparent out-of-709 RGB values.  This auxiliary probe therefore
        stays in Y'CbCr code space and compares how naturally the same decoded samples fit the
        BT.709 and BT.2020-NCL matrices before any transfer/gamut conversion.

        It is only supporting evidence.  A narrow-gamut or low-light genuine HLG shot is not
        declared wrong from this probe alone; callers must combine it with exposure/content cues.
        """
        exe = get_ffmpeg_path()
        if not exe:
            return {"valid": False}
        try:
            fps_value = max(0.25, min(1.0, float(sample_fps or 0.5)))
            w = max(16, int(width)); h = max(16, int(height))
            vf = "fps=fps=%s,scale=%d:%d:flags=fast_bilinear,format=yuv444p16le" % (
                self._ts(fps_value), w, h
            )
            cmd = [
                exe, "-hide_banner", "-loglevel", "error", "-i", path,
                "-vf", vf, "-an", "-sn", "-dn", "-vsync", "0",
                "-f", "rawvideo", "-pix_fmt", "yuv444p16le", "pipe:1",
            ]
            startupinfo = None
            creationflags = 0
            if os.name == "nt":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            if self.stop_requested:
                return {"valid": False}
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                startupinfo=startupinfo, creationflags=creationflags,
            )
            if not self._register_current_process(proc):
                return {"valid": False}
            # communicate() may block on Windows pipes; the UI Stop handler now
            # terminates the registered process immediately and escalates to kill.
            raw, _err = proc.communicate()
            if self.stop_requested:
                return {"valid": False}
            if proc.returncode not in (0, None) or not raw:
                return {"valid": False}

            from array import array
            vals = array('H')
            vals.frombytes(raw)
            if sys.byteorder != 'little':
                vals.byteswap()
            plane = w * h
            frame_words = plane * 3
            frame_count = len(vals) // frame_words
            if frame_count <= 0:
                return {"valid": False}

            # 16-bit limited-range normalization (same ratios as 10-bit 64..940 / 64..960).
            y_black = 16.0 / 255.0
            y_span = 219.0 / 255.0
            c_mid = 128.0 / 255.0
            c_span = 224.0 / 255.0
            inv16 = 1.0 / 65535.0

            clip709 = excess709 = 0.0
            clip2020 = excess2020 = 0.0
            chroma_sum = 0.0
            y_values = []
            total_pixels = 0

            def excess_triplet(y, cb, cr, matrix2020):
                if matrix2020:
                    rr = y + 1.4746 * cr
                    gg = y - 0.164553 * cb - 0.571353 * cr
                    bb = y + 1.8814 * cb
                else:
                    rr = y + 1.5748 * cr
                    gg = y - 0.187324 * cb - 0.468124 * cr
                    bb = y + 1.8556 * cb
                ex = 0.0
                clipped = False
                for value in (rr, gg, bb):
                    if value < 0.0:
                        ex += -value; clipped = True
                    elif value > 1.0:
                        ex += value - 1.0; clipped = True
                return clipped, ex / 3.0

            for fi in range(frame_count):
                off = fi * frame_words
                yo = off; cbo = off + plane; cro = off + plane * 2
                for pi in range(plane):
                    y = ((vals[yo + pi] * inv16) - y_black) / y_span
                    cb = ((vals[cbo + pi] * inv16) - c_mid) / c_span
                    cr = ((vals[cro + pi] * inv16) - c_mid) / c_span
                    y_values.append(max(0.0, min(1.25, y)))
                    chroma_sum += abs(cb) + abs(cr)
                    c7, e7 = excess_triplet(y, cb, cr, False)
                    c2, e2 = excess_triplet(y, cb, cr, True)
                    clip709 += 1.0 if c7 else 0.0; excess709 += e7
                    clip2020 += 1.0 if c2 else 0.0; excess2020 += e2
                    total_pixels += 1

            if total_pixels <= 0:
                return {"valid": False}
            y_values.sort()
            p95 = y_values[min(len(y_values)-1, int(round((len(y_values)-1)*0.95)))] if y_values else 0.0
            p99 = y_values[min(len(y_values)-1, int(round((len(y_values)-1)*0.99)))] if y_values else 0.0
            e709 = excess709 / float(total_pixels)
            e2020 = excess2020 / float(total_pixels)
            return {
                "valid": True,
                "sample_count": frame_count,
                "clip709": clip709 / float(total_pixels),
                "clip2020": clip2020 / float(total_pixels),
                "excess709": e709,
                "excess2020": e2020,
                "matrix_advantage_ratio": (e709 + 1e-7) / (e2020 + 1e-7),
                "mean_abs_chroma": chroma_sum / float(total_pixels),
                "y_p95": p95,
                "y_p99": p99,
            }
        except Exception:
            return {"valid": False}
        finally:
            try:
                proc_obj = locals().get("proc")
                if proc_obj is not None:
                    if self.stop_requested and proc_obj.poll() is None:
                        self._terminate_external_process(proc_obj)
                    self._clear_current_process(proc_obj)
            except Exception:
                pass

    def _hdr_metadata_only_mismatch_run(self, path, metadata, target_spec, duration, fps, existing_runs=None):
        """Return a whole-programme review warning when HLG/BT.2020 tags lack independent picture support.

        This gate is deliberately conservative and is never used as a FAIL condition by itself.
        It exists for the real-world failure mode where an SDR/Rec.709 master is merely re-tagged
        BT.2020/HLG.  Low-light / low-saturation genuine HLG is protected by the exposure gate.
        """
        # Source-content cross-check: this must be independent of the user's target.
        # A file that is only re-tagged BT.2020/HLG remains the same picture whether
        # the operator later compares it against HLG or BT.709/SDR delivery.
        if not (metadata or {}).get("is_hlg") or not (metadata or {}).get("is_2020"):
            return None

        # Do not let short/internal temporal candidates suppress the whole-programme
        # HLG/metadata integrity cross-check.  Earlier builds returned immediately
        # whenever *any* candidate existed, even when every candidate was later
        # removed by the user-selected minimum-duration gate.  That produced a
        # false PASS and also prevented Layer 7 from receiving the raw matrix
        # evidence it needs.
        #
        # Preserve performance for files that already have a real user-visible
        # content warning: only skip this auxiliary whole-programme probe when at
        # least one existing run survives the SAME visible-duration filter used by
        # GUI/TXT/Excel.
        _visible_existing = self._hdr_filter_short_content_runs(existing_runs or [])
        if _visible_existing:
            return None

        probe = self._hdr_raw_matrix_consistency_probe(path, duration=duration)

        # Keep the already-paid-for probe available to Layer 7.  This does NOT
        # add another decode pass: the metadata-only gate already performs this
        # probe when no temporal issue run exists.  Layer 7 may reuse the result
        # to judge HLG integrity even when the stricter metadata-only warning
        # threshold itself is not reached.
        try:
            _st = os.stat(path)
            _probe_key = (os.path.abspath(path), int(_st.st_size), int(_st.st_mtime))
        except Exception:
            _probe_key = (os.path.abspath(path), None, None)
        if not hasattr(self, "_hdr_matrix_probe_cache"):
            self._hdr_matrix_probe_cache = {}
        self._hdr_matrix_probe_cache[_probe_key] = dict(probe or {})

        if not probe.get("valid"):
            return None

        y95 = float(probe.get("y_p95", 0.0))
        y99 = float(probe.get("y_p99", 0.0))
        chroma = float(probe.get("mean_abs_chroma", 0.0))
        e20 = float(probe.get("excess2020", 0.0))
        ratio = float(probe.get("matrix_advantage_ratio", 99.0))

        # Do not flag low-key / low-saturation scenes: there may simply be too little picture
        # information to prove wide-gamut/HDR usage.  For ordinary exposed material, require
        # several independent cues before asking for review.
        enough_picture_information = bool(y95 >= 0.66 and chroma >= 0.075)
        little_matrix_discrimination = bool(e20 <= 0.00035 and ratio <= 2.15)
        sdr_like_headroom = bool(y99 <= 0.91)
        if not (enough_picture_information and little_matrix_discrimination and sdr_like_headroom):
            return None

        total = self._hdr_effective_timeline_duration(duration)
        if total < 0.50:
            return None
        confidence = "高" if (y95 >= 0.72 and chroma >= 0.10 and e20 <= 0.00020 and ratio <= 1.90) else "一般"
        return {
            "start": 0.0,
            "end": total,
            "tc_start": self._timecode_frames(0.0, fps),
            "tc_end": self._timecode_frames(total, fps),
            "category": "metadata_only_suspect",
            "confidence": confidence,
            "evidence": "metadata_picture_crosscheck",
            "detail": "BT.2020/HLG 標示存在，但原始 YCbCr 畫面缺乏可獨立驗證的 BT.2020/HLG 編碼差異，疑似僅改 Metadata 或需人工複核",
            "matrix_probe": probe,
            "target_spec": target_spec,
        }

    def _hdr_effective_timeline_duration(self, duration, samples=None, gamut_samples=None, runs=None):
        """Return a reliable picture-timeline duration for HDR/gamut analysis.

        Some files (especially remuxed/test MP4/MXF material) expose no usable
        format/stream duration to ffprobe even though FFmpeg decodes the whole
        picture stream correctly.  A zero duration used to erase already
        validated SDR ranges while building the BT.709 complement:

            min(0, sdr_run_end) -> 0

        The result was a false whole-programme HDR range even when the same
        analysis had correctly found an SDR island.  Keep the probed duration
        when it is credible; otherwise derive the timeline end from decoded
        sample timestamps.
        """
        try:
            probed = max(0.0, float(duration or 0.0))
        except Exception:
            probed = 0.0

        def sampled_end(rows, fallback_step):
            times = []
            for row in (rows or []):
                try:
                    t = float(row.get("time", 0.0))
                    if math.isfinite(t) and t >= 0.0:
                        times.append(t)
                except Exception:
                    pass
            if not times:
                return 0.0
            times = sorted(set(times))
            diffs = [
                times[i] - times[i - 1]
                for i in range(1, min(len(times), 80))
                if times[i] > times[i - 1]
            ]
            step = self._hdr_median(diffs) if diffs else float(fallback_step)
            step = max(0.01, min(2.0, float(step or fallback_step)))
            return max(times) + step

        sample_end = max(
            sampled_end(samples, 0.5),
            sampled_end(gamut_samples, 1.0),
        )
        run_end = 0.0
        for run in (runs or []):
            try:
                run_end = max(run_end, float(run.get("end", 0.0)))
            except Exception:
                pass

        observed = max(sample_end, run_end)
        if probed >= 0.50:
            # Small sampling-rounding differences must not change an otherwise
            # valid container duration.  Only replace it when decoded picture
            # evidence extends materially beyond it.
            if observed > probed + 0.25:
                return observed
            return probed
        return observed

    def _hdr_reverse_support_profile(self, reverse):
        """Classify reverse-A/B support into independent evidence families.

        A best-fit transform is not proof by itself.  We require improvement
        in both tone and gamut families and prefer agreement across multiple
        constrained SDR->HLG models.  This prevents one model from overfitting
        a perfectly valid low-saturation / low-key HLG shot.
        """
        rv = reverse or {}
        feats = rv.get("feature_results") or {}
        tone_keys = ("yavg", "yhigh")
        gamut_keys = ("gamut_outside", "gamut_edge")
        tone_improved = any(bool((feats.get(k) or {}).get("improved")) for k in tone_keys)
        tone_strong = any(bool((feats.get(k) or {}).get("strong_improved")) for k in tone_keys)
        gamut_improved = any(bool((feats.get(k) or {}).get("improved")) for k in gamut_keys)
        gamut_strong = any(bool((feats.get(k) or {}).get("strong_improved")) for k in gamut_keys)

        summaries = rv.get("candidate_summaries") or []
        model_support = sum(1 for x in summaries if x.get("strong") or x.get("moderate"))
        strong_models = sum(1 for x in summaries if x.get("strong"))
        independent = bool(tone_improved and gamut_improved)
        strong_independent = bool(independent and (tone_strong or gamut_strong))
        model_consensus = bool(model_support >= 2)
        strong_consensus = bool(strong_models >= 2 or model_support >= 3)
        return {
            "tone_improved": tone_improved,
            "gamut_improved": gamut_improved,
            "independent": independent,
            "strong_independent": strong_independent,
            "model_support": model_support,
            "strong_models": strong_models,
            "model_consensus": model_consensus,
            "strong_consensus": strong_consensus,
        }

    def _hdr_transition_plateau_support(self, probe, samples, gamut_samples):
        """Reject short spike/transition shapes before deep reverse validation.

        The user-visible minimum-duration gate remains authoritative.  This extra
        guard only scrutinizes near-threshold ranges (<1.5 s by default).  Longer
        states are left untouched, while a short range must contain at least two
        mutually consistent 2-fps tone samples instead of a single flash/transition
        excursion.  It does not use filename, target specification or fixed TC.
        """
        try:
            a = float((probe or {}).get('start', 0.0))
            b = float((probe or {}).get('end', 0.0))
        except Exception:
            return False
        span = b - a
        min_visible = self._hdr_min_visible_issue_seconds()
        if span + 1e-6 < min_visible:
            return False
        # Ordinary sustained states are already protected by the duration gate and
        # multi-family validator; avoid changing established detector behaviour.
        if span >= max(1.50, min_visible + 0.50):
            return True

        tone = []
        for row in (samples or []):
            try:
                t = float(row.get('time', 0.0))
            except Exception:
                continue
            if a + 0.05 <= t <= b - 0.05 and 'YAVG' in row:
                tone.append(row)
        if len(tone) < 2:
            return False

        def _stable(vals, relative_limit, absolute_floor):
            vals = [float(v) for v in vals]
            if len(vals) < 2:
                return True
            lo, hi = min(vals), max(vals)
            mid = sorted(vals)[len(vals)//2]
            return (hi - lo) <= max(float(absolute_floor), abs(mid) * float(relative_limit))

        y_stable = _stable([x.get('YAVG', 0.0) for x in tone], 0.28, 12.0)
        sat_rows = [x for x in tone if 'SATAVG' in x]
        sat_stable = True if len(sat_rows) < 2 else _stable(
            [x.get('SATAVG', 0.0) for x in sat_rows], 0.40, 8.0
        )

        # If two 1-fps gamut samples happen to lie inside a near-threshold state,
        # require them not to contradict each other.  One gamut sample is neutral.
        gamut = []
        for row in (gamut_samples or []):
            try:
                t = float(row.get('time', 0.0))
            except Exception:
                continue
            if a + 0.05 <= t <= b - 0.05 and row.get('considered_pixels', 0) > 0:
                gamut.append(float(row.get('outside709_ratio', 0.0)))
        gamut_stable = True
        if len(gamut) >= 2:
            gamut_stable = (max(gamut) - min(gamut)) <= max(0.08, (sum(gamut)/len(gamut)) * 0.85)

        return bool(y_stable and sat_stable and gamut_stable)

    def _hdr_validate_timeline_sdr_candidate(self, path, probe, duration, metadata):
        """Validate one target-independent timeline candidate as SDR/Rec.709-like.

        Candidate discovery may be sensitive; classification is intentionally stricter.
        A two-sided island can be accepted from independent picture evidence. A range
        touching the programme boundary must have strong reverse-A/B support, because
        one-sided cluster separation alone is not sufficient to infer SDR content.
        """
        item = dict(probe or {})

        is_cluster = bool(item.get("timeline_cluster"))
        bounded = bool(item.get("bounded_by_other_state")) if is_cluster else bool(
            float(item.get("outer_tone", 999.0)) <= 1.85
            and float(item.get("outer_gamut", 999.0)) <= 1.85
        )
        sdr_direction = bool(item.get("sdr_like_direction", True))
        clear_state = bool(float(item.get("temporal_score", 0.0)) >= 0.45)

        # A strongly bounded A-B-A content island can already be accepted from
        # two independent picture families.  Test this cheap path BEFORE the
        # expensive multi-model reverse A/B decode.  This does not loosen the
        # original rule: direct_ok was already an independent acceptance path.
        direct_ok = bool(
            bounded and sdr_direction and clear_state
            and float(item.get("temporal_score", 0.0)) >= 0.90
            and (
                (float(item.get("middle_tone", 0.0)) >= 0.48
                 and float(item.get("middle_gamut", 0.0)) >= 0.24)
                or (bool(item.get("gamut_narrower"))
                    and (bool(item.get("edge_narrower")) or bool(item.get("saturation_support")))
                    and float(item.get("middle_gamut", 0.0)) >= 0.34)
            )
        )
        if direct_ok:
            item["category"] = "sdr709"
            item["confidence"] = "高"
            item["detail"] = (
                "前後內容狀態一致而中間區段形成穩定的 Rec.709 / SDR 型內容島，亮度與色域兩組獨立畫面證據同時成立"
            )
            return item

        rv = self._hdr_reverse_validate_run(
            path, item, duration=duration, hypothesis="sdr_to_hlg", metadata=metadata
        )
        rs = self._hdr_reverse_support_profile(rv)

        # Strong transform evidence can validate an SDR range even at programme
        # boundaries, but ordinary cluster separation cannot.
        reverse_ok = bool(
            rv.get("valid") and sdr_direction and rs.get("independent")
            and (rv.get("strong") or rv.get("moderate") or float(rv.get("improvement", 0.0)) >= 0.04)
            and (rs.get("model_consensus") or (rv.get("strong") and float(rv.get("improvement", 0.0)) >= 0.07))
            and clear_state
            and (
                bounded
                or (rv.get("strong") and rs.get("strong_consensus")
                    and float(item.get("direction_score", 0.0)) >= 0.85
                    and bool(item.get("gamut_narrower")))
            )
        )

        if not reverse_ok:
            return None
        if rv.get("valid"):
            item["reverse"] = rv
        item["category"] = "sdr709"
        item["confidence"] = "極高" if (
            rv.get("strong") and rs.get("strong_consensus")
            and float(item.get("temporal_score", 0.0)) >= 1.80
        ) else "高"
        item["detail"] = (
            "時間線內容狀態與 Rec.709 型色域方向一致，且 SDR→HLG 反向驗證在亮度與色域兩組獨立指標上獲一致支持"
        )
        return item


    def _hdr_collect_validated_sdr_states(self, path, samples, gamut_samples, duration, fps, metadata, existing=None):
        """Build one target-independent list of validated SDR/Rec.709 content states.

        All delivery targets reuse this exact list. Candidate generators may be
        sensitive, but no range becomes a content state until it passes the
        shared SDR validator. This prevents HLG-target and SDR-target branches
        from deriving different content timelines from the same pictures.
        """
        validated = []
        for r in (existing or []):
            if r.get("category") == "sdr709":
                validated.append(dict(r))

        candidates = []
        try:
            candidates += self._hdr_timeline_state_candidates(
                samples, gamut_samples, duration=duration, fps_for_tc=fps
            )
        except Exception:
            pass
        try:
            candidates += self._hdr_timeline_cluster_candidates(
                samples, gamut_samples, duration=duration, fps_for_tc=fps
            )
        except Exception:
            pass
        try:
            candidates += self._hdr_discover_temporal_islands(
                samples, gamut_samples, duration=duration, fps_for_tc=fps
            )
        except Exception:
            pass

        candidates.sort(key=lambda x: float(x.get("temporal_score", 0.0)), reverse=True)
        min_visible = self._hdr_min_visible_issue_seconds()
        seen = []
        for probe in candidates[:60]:
            if self.stop_requested:
                break
            try:
                a = float(probe.get("start", 0.0)); b = float(probe.get("end", 0.0))
            except Exception:
                continue
            if b <= a:
                continue
            # Transition/flash guard: first apply the user-visible duration gate,
            # then require a stable plateau for near-threshold states before spending
            # expensive reverse-A/B work.  Sustained states are unchanged.
            if (b - a) + 1e-6 < min_visible:
                continue
            if not self._hdr_transition_plateau_support(probe, samples, gamut_samples):
                continue
            duplicate = False
            for qa, qb in seen:
                inter = max(0.0, min(b, qb) - max(a, qa))
                shorter = max(0.001, min(b-a, qb-qa))
                if inter / shorter >= 0.80:
                    duplicate = True
                    break
            if duplicate:
                continue
            seen.append((a,b))
            if any(self._hdr_ranges_overlap(probe, x, tolerance=0.45) for x in validated):
                continue
            try:
                item = self._hdr_validate_timeline_sdr_candidate(
                    path, probe, duration=duration, metadata=metadata
                )
            except Exception:
                item = None
            if item is not None:
                validated.append(item)

        # Canonical merge of same-state ranges before any target inversion.
        if not validated:
            return [], candidates
        merged = self._hdr_merge_final_runs(
            validated, float(duration or 0.0), fps, gap=0.35
        )
        merged = [x for x in merged if x.get("category") == "sdr709"]
        merged = self._hdr_filter_short_content_runs(merged, min_visible)
        return merged, candidates

    def _hdr_discover_temporal_islands(self, samples, gamut_samples, duration, fps_for_tc):
        """Discover content-state islands on the whole timeline.

        This is a generic candidate-discovery stage.  It deliberately does not
        know filenames, clip lengths, target test patterns, or fixed timecodes.
        It groups the existing 2 fps tone samples and 1 fps gamut samples into
        one-second bins, finds sustained state boundaries from robust local
        feature jumps, and proposes interior states whose two outer neighbours
        resemble each other while the centre differs.  User-visible SDR/709
        classification still requires the normal reverse A/B validator to pass
        in independent tone and gamut families.
        """
        try:
            total = float(duration or 0.0)
        except Exception:
            total = 0.0

        all_times = []
        for row in (samples or []):
            try:
                all_times.append(float(row.get("time", 0.0)))
            except Exception:
                pass
        for row in (gamut_samples or []):
            try:
                all_times.append(float(row.get("time", 0.0)))
            except Exception:
                pass
        if all_times:
            total = max(total, max(all_times) + 1.0)
        if total < 3.0:
            return []

        bins = {}
        def bucket(i):
            return bins.setdefault(i, {"yavg": [], "yhigh": [], "sat": [], "gamut": [], "edge": []})

        for row in (samples or []):
            try:
                i = max(0, int(float(row.get("time", 0.0))))
            except Exception:
                continue
            b = bucket(i)
            if "YAVG" in row:
                b["yavg"].append(float(row["YAVG"]))
            if "YHIGH" in row or "YMAX" in row:
                b["yhigh"].append(float(row.get("YHIGH", row.get("YMAX", 0.0))))
            if "SATAVG" in row:
                b["sat"].append(float(row["SATAVG"]))

        for row in (gamut_samples or []):
            try:
                i = max(0, int(float(row.get("time", 0.0))))
            except Exception:
                continue
            b = bucket(i)
            if "outside709_ratio" in row:
                b["gamut"].append(float(row.get("outside709_ratio", 0.0)))
            if "edge709_ratio" in row:
                b["edge"].append(float(row.get("edge709_ratio", 0.0)))

        def mean(values):
            return (sum(values) / float(len(values))) if values else None

        rows = []
        for sec in sorted(bins):
            b = bins[sec]
            r = {"sec": sec, "start": float(sec), "end": min(total, float(sec + 1))}
            for key in ("yavg", "yhigh", "sat", "gamut", "edge"):
                r[key] = mean(b[key])
            if (r["yavg"] is not None or r["yhigh"] is not None) and r["gamut"] is not None:
                rows.append(r)
        if len(rows) < 3:
            return []

        def median(values):
            vals = [float(v) for v in values if v is not None]
            return self._hdr_median(vals) if vals else 0.0

        # Floors stop very small programme values from creating enormous ratios.
        scales = {
            "yavg": max(abs(median([r["yavg"] for r in rows])) * 0.08, 5.0),
            "yhigh": max(abs(median([r["yhigh"] for r in rows])) * 0.08, 7.0),
            "sat": max(abs(median([r["sat"] for r in rows])) * 0.12, 4.0),
            "gamut": max(abs(median([r["gamut"] for r in rows])) * 0.25, 0.015),
            "edge": max(abs(median([r["edge"] for r in rows])) * 0.18, 0.018),
        }

        def metric_delta(a, b, key):
            x, y = a.get(key), b.get(key)
            if x is None or y is None:
                return 0.0
            return abs(float(x) - float(y)) / max(scales[key], 1e-9)

        def family_delta(a, b, keys):
            vals = [metric_delta(a, b, k) for k in keys if a.get(k) is not None and b.get(k) is not None]
            return (sum(vals) / float(len(vals))) if vals else 0.0

        # Candidate discovery is intentionally sensitive.  Natural scene cuts may
        # enter this list, but they remain invisible unless reverse A/B later
        # confirms an SDR/709 interpretation in two independent evidence families.
        cuts = [0]
        boundary_scores = [0.0] * len(rows)
        hard_gap = set()
        for i in range(1, len(rows)):
            if rows[i]["sec"] > rows[i - 1]["sec"] + 1:
                hard_gap.add(i)
                boundary_scores[i] = 999.0
                continue
            tone = family_delta(rows[i - 1], rows[i], ("yavg", "yhigh", "sat"))
            gamut = family_delta(rows[i - 1], rows[i], ("gamut", "edge"))
            max_single = max(
                metric_delta(rows[i - 1], rows[i], "yavg"),
                metric_delta(rows[i - 1], rows[i], "yhigh"),
                metric_delta(rows[i - 1], rows[i], "sat"),
                metric_delta(rows[i - 1], rows[i], "gamut"),
                metric_delta(rows[i - 1], rows[i], "edge"),
            )
            boundary_scores[i] = max(tone, gamut, max_single)

        # Keep local peaks rather than every elevated adjacent difference.
        # This prevents one real transition from being fragmented by a gradual
        # one- or two-second settling period inside the new state.
        for i in range(1, len(rows)):
            if i in hard_gap:
                cuts.append(i)
                continue
            score = boundary_scores[i]
            if score < 1.05:
                continue
            lo = max(1, i - 1)
            hi = min(len(rows) - 1, i + 1)
            local = boundary_scores[lo:hi + 1]
            if score + 1e-9 < max(local):
                continue
            cuts.append(i)
        cuts.append(len(rows))
        cuts = sorted(set(cuts))

        segments = []
        for a, b in zip(cuts[:-1], cuts[1:]):
            part = rows[a:b]
            if not part:
                continue
            c = {"start": part[0]["start"], "end": part[-1]["end"]}
            for key in ("yavg", "yhigh", "sat", "gamut", "edge"):
                c[key] = mean([r[key] for r in part if r[key] is not None])
            segments.append(c)
        if len(segments) < 3:
            return []

        out = []
        for i in range(1, len(segments) - 1):
            left, mid, right = segments[i - 1], segments[i], segments[i + 1]
            span = max(0.0, float(mid["end"]) - float(mid["start"]))
            if span < 1.0:
                continue
            outer_tone = family_delta(left, right, ("yavg", "yhigh", "sat"))
            outer_gamut = family_delta(left, right, ("gamut", "edge"))
            mid_tone = min(
                family_delta(mid, left, ("yavg", "yhigh", "sat")),
                family_delta(mid, right, ("yavg", "yhigh", "sat")),
            )
            mid_gamut = min(
                family_delta(mid, left, ("gamut", "edge")),
                family_delta(mid, right, ("gamut", "edge")),
            )

            # The outside states only need to be materially closer to one another
            # than the middle is to either side.  This is more robust across normal
            # programme shot variation than a fixed absolute A-B-A threshold.
            outer_total = outer_tone + outer_gamut
            middle_total = mid_tone + mid_gamut
            outer_similar = bool(
                outer_tone <= 1.25 and outer_gamut <= 1.25
                and middle_total >= max(0.90, outer_total * 1.45)
            )
            middle_diff = bool(
                (mid_tone >= 0.45 and mid_gamut >= 0.30)
                or (mid_tone >= 0.85)
                or (mid_gamut >= 0.85)
            )
            if not (outer_similar and middle_diff):
                continue

            score = middle_total - 0.45 * outer_total
            out.append({
                "start": float(mid["start"]),
                "end": float(mid["end"]),
                "tc_start": self._timecode_frames(float(mid["start"]), fps_for_tc),
                "tc_end": self._timecode_frames(float(mid["end"]), fps_for_tc),
                "evidence": "temporal_state",
                "temporal_island": True,
                "temporal_score": score,
                "outer_tone": outer_tone,
                "outer_gamut": outer_gamut,
                "middle_tone": mid_tone,
                "middle_gamut": mid_gamut,
            })

        out.sort(key=lambda x: float(x.get("temporal_score", 0.0)), reverse=True)
        return out

    def _hdr_timeline_cluster_candidates(self, samples, gamut_samples, duration, fps_for_tc):
        """Discover sustained alternate content states using robust two-state clustering.

        This is target-independent candidate discovery. It does not assume a fixed
        clip length, filename, timecode, or A-B-A pattern. One-second bins are built
        from the existing 2 fps tone samples and 1 fps gamut samples. A simple
        dependency-free two-cluster model finds a sustained secondary state that may
        represent SDR-like content inside an HDR/WCG programme (or vice versa).

        The returned ranges are *candidates only*: user-visible SDR/HDR classification
        still requires the existing reverse A/B validator and independent evidence.
        """
        try:
            total = max(0.0, float(duration or 0.0))
        except Exception:
            total = 0.0

        bins = {}
        def bucket(sec):
            return bins.setdefault(sec, {"yavg": [], "yhigh": [], "sat": [], "gamut": [], "edge": []})

        times = []
        for row in (samples or []):
            try:
                tt = max(0.0, float(row.get("time", 0.0))); times.append(tt); sec = int(tt)
            except Exception:
                continue
            b = bucket(sec)
            if "YAVG" in row: b["yavg"].append(float(row.get("YAVG", 0.0)))
            if "YHIGH" in row or "YMAX" in row: b["yhigh"].append(float(row.get("YHIGH", row.get("YMAX", 0.0))))
            if "SATAVG" in row: b["sat"].append(float(row.get("SATAVG", 0.0)))
        for row in (gamut_samples or []):
            try:
                tt = max(0.0, float(row.get("time", 0.0))); times.append(tt); sec = int(tt)
            except Exception:
                continue
            b = bucket(sec)
            if "outside709_ratio" in row: b["gamut"].append(float(row.get("outside709_ratio", 0.0)))
            if "edge709_ratio" in row: b["edge"].append(float(row.get("edge709_ratio", 0.0)))

        if times:
            total = max(total, max(times) + 1.0)
        if total < 3.0:
            return []

        def avg(vals):
            return (sum(vals) / float(len(vals))) if vals else None
        rows = []
        for sec in sorted(bins):
            b = bins[sec]
            r = {"sec": sec, "start": float(sec), "end": min(total, float(sec + 1))}
            for k in ("yavg", "yhigh", "sat", "gamut", "edge"):
                r[k] = avg(b[k])
            if (r["yavg"] is not None or r["yhigh"] is not None) and r["gamut"] is not None:
                rows.append(r)
        if len(rows) < 4:
            return []

        # Never bridge decode/sample gaps.
        groups, cur = [], []
        for r in rows:
            if cur and r["sec"] > cur[-1]["sec"] + 1:
                if len(cur) >= 4: groups.append(cur)
                cur = []
            cur.append(r)
        if cur and len(cur) >= 4: groups.append(cur)

        def med(vals):
            vv = [float(v) for v in vals if v is not None]
            return self._hdr_median(vv) if vv else 0.0

        out = []
        keys = ("yavg", "yhigh", "sat", "gamut", "edge")
        for group in groups:
            # Robust normalization by median absolute deviation; floors prevent
            # low-valued gamut channels from dominating.
            centers = {k: med([r.get(k) for r in group]) for k in keys}
            spreads = {}
            floors = {"yavg": 4.0, "yhigh": 6.0, "sat": 3.0, "gamut": 0.012, "edge": 0.015}
            for k in keys:
                dev = [abs(float(r[k]) - centers[k]) for r in group if r.get(k) is not None]
                spreads[k] = max(med(dev) * 1.4826, floors[k])

            vecs = []
            for r in group:
                v = []
                valid = True
                for k in keys:
                    if r.get(k) is None:
                        valid = False; break
                    v.append((float(r[k]) - centers[k]) / max(spreads[k], 1e-9))
                if valid: vecs.append((r, v))
            if len(vecs) < 4:
                continue

            # Deterministic farthest-pair initialization.
            def dist2(a, b):
                return sum((x-y)*(x-y) for x,y in zip(a,b))
            seed_a = vecs[0][1]
            seed_b = max((v for _,v in vecs), key=lambda v: dist2(v, seed_a))
            seed_a = max((v for _,v in vecs), key=lambda v: dist2(v, seed_b))
            c0, c1 = list(seed_a), list(seed_b)
            labels = [0] * len(vecs)
            for _ in range(12):
                changed = False
                for i, (_, v) in enumerate(vecs):
                    lab = 0 if dist2(v, c0) <= dist2(v, c1) else 1
                    if lab != labels[i]: labels[i] = lab; changed = True
                parts = [[vecs[i][1] for i in range(len(vecs)) if labels[i] == lab] for lab in (0,1)]
                if not parts[0] or not parts[1]:
                    break
                nc = []
                for pts in parts:
                    nc.append([sum(p[d] for p in pts)/float(len(pts)) for d in range(len(keys))])
                c0, c1 = nc
                if not changed: break
            if not any(labels) or all(labels):
                continue

            # Require meaningful cluster separation and minimum state support.
            sep = dist2(c0, c1) ** 0.5
            counts = [labels.count(0), labels.count(1)]
            if sep < 1.35 or min(counts) < 1:
                continue

            # Convert cluster centers back to raw feature medians so later logic
            # can determine direction (narrower-gamut / lower-saturation etc.).
            raw = []
            for lab in (0,1):
                rs = [vecs[i][0] for i in range(len(vecs)) if labels[i] == lab]
                raw.append({k: med([r.get(k) for r in rs]) for k in keys})

            # SDR-like tendency: lower WCG occupancy is strongest, with edge and
            # saturation as supporting cues. Tone is intentionally non-directional.
            def sdr_score(lab):
                other = 1-lab
                a, b = raw[lab], raw[other]
                gdrop = (float(b["gamut"]) - float(a["gamut"])) / max(abs(float(b["gamut"])), 0.015)
                edrop = (float(b["edge"]) - float(a["edge"])) / max(abs(float(b["edge"])), 0.018)
                sdrop = (float(b["sat"]) - float(a["sat"])) / max(abs(float(b["sat"])), 4.0)
                return 1.8*gdrop + 0.8*edrop + 0.45*sdrop
            candidate_label = 0 if sdr_score(0) >= sdr_score(1) else 1
            direction_score = sdr_score(candidate_label)

            # Emit contiguous runs from the candidate cluster. A single one-second
            # run is allowed into validation, but confidence later stays governed by
            # the expensive multi-evidence validator.
            start_i = None
            for idx in range(len(vecs)+1):
                active = idx < len(vecs) and labels[idx] == candidate_label
                if active and start_i is None:
                    start_i = idx
                if (not active) and start_i is not None:
                    end_i = idx
                    part = [vecs[q][0] for q in range(start_i, end_i)]
                    a = float(part[0]["start"]); b = float(part[-1]["end"])
                    if b-a >= 0.75:
                        # Local neighbouring-state support, where available.
                        left = vecs[start_i-1][0] if start_i > 0 else None
                        right = vecs[end_i][0] if end_i < len(vecs) else None
                        # A cluster touching the programme boundary has only one
                        # neighbouring state.  It is still useful as a candidate,
                        # but it must NEVER be treated as an A-B-A island.  Older
                        # builds encoded a missing neighbour as a numeric distance
                        # of 1.0, which accidentally made edge clusters look
                        # "well bounded" and caused long normal HLG sections to be
                        # labelled SDR/709.
                        has_left = left is not None
                        has_right = right is not None
                        bounded = bool(has_left and has_right)
                        out.append({
                            "start": a, "end": b,
                            "tc_start": self._timecode_frames(a, fps_for_tc),
                            "tc_end": self._timecode_frames(b, fps_for_tc),
                            "evidence": "timeline_cluster",
                            "timeline_cluster": True,
                            "cluster_separation": sep,
                            "direction_score": direction_score,
                            "sdr_like_direction": bool(direction_score >= 0.45),
                            "gamut_narrower": bool(raw[candidate_label]["gamut"] < raw[1-candidate_label]["gamut"] * 0.88),
                            "edge_narrower": bool(raw[candidate_label]["edge"] < raw[1-candidate_label]["edge"] * 0.90),
                            "saturation_support": bool(raw[candidate_label]["sat"] < raw[1-candidate_label]["sat"] * 0.90),
                            "temporal_score": sep + max(0.0, direction_score),
                            "middle_tone": 0.0,
                            "middle_gamut": max(0.0, direction_score),
                            "has_left_state": has_left,
                            "has_right_state": has_right,
                            "bounded_by_other_state": bounded,
                            # Missing neighbours use a sentinel that cannot pass
                            # the normal two-sided temporal-island gates.
                            "outer_tone": 0.0 if bounded else 999.0,
                            "outer_gamut": 0.0 if bounded else 999.0,
                        })
                    start_i = None

        # Strongest first; nested/near-identical ranges are deduplicated by caller.
        out.sort(key=lambda x: float(x.get("temporal_score",0.0)), reverse=True)
        return out

    def _hdr_hlg_sandwich_profile(self, path, run, duration, metadata=None):
        """Detect a true HLG -> SDR-like -> HLG A-B-A temporal sandwich.

        This is deliberately stricter than a simple local-reference comparison:
        the material on BOTH sides must resemble each other, while the middle
        candidate must differ in both tone and gamut families.  It therefore
        helps recover short genuine SDR inserts without re-introducing false
        positives on ordinary shot-to-shot HLG changes.
        """
        try:
            start=max(0.0,float(run.get("start",0.0)))
            end=min(float(duration or run.get("end",0.0)),float(run.get("end",0.0)))
        except Exception:
            return {"valid":False}
        if end<=start or start<1.0 or not duration or end>float(duration)-1.0:
            return {"valid":False}

        ref_span=min(3.0,max(1.5,(end-start)*0.75))
        left=(max(0.0,start-ref_span),start)
        right=(end,min(float(duration),end+ref_span))

        def center(a,b):
            rows = self._hdr_combined_features_for_range(
                path, a, b, metadata=metadata, transform="original", sample_fps=1.0
            )
            return self._hdr_feature_center(rows)

        lc=center(*left); cc=center(start,end); rc=center(*right)
        if not lc or not cc or not rc:
            return {"valid":False}

        def rel(a,b,floor):
            return abs(float(a)-float(b))/max(abs(float(b)),floor)
        tone_keys=(("yavg",0.05),("yhigh",0.08))
        gamut_keys=(("gamut_outside",0.02),("gamut_edge",0.02))
        def fam_dist(a,b,keys):
            vals=[]
            for k,f in keys:
                if k in a and k in b:
                    vals.append(rel(a.get(k,0.0),b.get(k,0.0),f))
            return sum(vals)/len(vals) if vals else 999.0

        outer_tone=fam_dist(lc,rc,tone_keys)
        outer_gamut=fam_dist(lc,rc,gamut_keys)
        mid_tone=min(fam_dist(cc,lc,tone_keys),fam_dist(cc,rc,tone_keys))
        mid_gamut=min(fam_dist(cc,lc,gamut_keys),fam_dist(cc,rc,gamut_keys))

        # Two-sided references must be mutually consistent; the centre must
        # depart in BOTH independent families.  Thresholds are intentionally
        # conservative and are not used outside HLG target analysis.
        outer_similar=bool(outer_tone<=0.24 and outer_gamut<=0.34)
        middle_diff=bool(mid_tone>=0.18 and mid_gamut>=0.20)
        strong=bool(outer_similar and middle_diff and mid_tone>=0.24 and mid_gamut>=0.28)
        very_strong=bool(outer_similar and mid_tone>=0.32 and mid_gamut>=0.38)
        return {
            "valid":True,
            "outer_similar":outer_similar,
            "middle_diff":middle_diff,
            "strong":strong,
            "very_strong":very_strong,
            "outer_tone":outer_tone,
            "outer_gamut":outer_gamut,
            "middle_tone":mid_tone,
            "middle_gamut":mid_gamut,
        }

    def _hdr_timeline_state_candidates(self, samples, gamut_samples, duration, fps_for_tc):
        """Build target-independent candidate content states from the whole timeline.

        This stage is deliberately content-driven and never looks at filenames,
        fixed clip lengths, or expected test-pattern timecodes.  It aggregates the
        existing 2 fps signalstats + 1 fps gamut samples into one-second feature
        bins, scans for locally stable A-B-A state islands over multiple possible
        durations, and returns only the strongest non-duplicate candidate ranges.

        Importantly, this is *candidate discovery only*.  A candidate never becomes
        a user-visible SDR/Rec.709 warning until the normal reverse A/B validator
        also finds independent tone + gamut support.  This keeps sensitivity high
        without turning ordinary shot changes into QC failures.
        """
        try:
            total = max(0.0, float(duration or 0.0))
        except Exception:
            total = 0.0

        # Aggregate to one-second bins.  Tone remains sourced from the original
        # 2 fps sampling and gamut from the original 1 fps sampling; no sampling
        # density is reduced here.
        bins = {}
        def bucket(sec):
            return bins.setdefault(sec, {"yavg": [], "yhigh": [], "sat": [], "gamut": [], "edge": []})

        times = []
        for row in (samples or []):
            try:
                t = max(0.0, float(row.get("time", 0.0))); times.append(t)
                sec = int(t)
            except Exception:
                continue
            b = bucket(sec)
            if "YAVG" in row: b["yavg"].append(float(row.get("YAVG", 0.0)))
            if "YHIGH" in row or "YMAX" in row: b["yhigh"].append(float(row.get("YHIGH", row.get("YMAX", 0.0))))
            if "SATAVG" in row: b["sat"].append(float(row.get("SATAVG", 0.0)))

        for row in (gamut_samples or []):
            try:
                t = max(0.0, float(row.get("time", 0.0))); times.append(t)
                sec = int(t)
            except Exception:
                continue
            b = bucket(sec)
            if "outside709_ratio" in row: b["gamut"].append(float(row.get("outside709_ratio", 0.0)))
            if "edge709_ratio" in row: b["edge"].append(float(row.get("edge709_ratio", 0.0)))

        if times:
            total = max(total, max(times) + 1.0)
        if total < 3.0:
            return []

        def mean(vals):
            return (sum(vals) / float(len(vals))) if vals else None
        rows = []
        for sec in sorted(bins):
            b = bins[sec]
            row = {"sec": sec, "start": float(sec), "end": min(total, float(sec + 1))}
            for key in ("yavg", "yhigh", "sat", "gamut", "edge"):
                row[key] = mean(b[key])
            # Require at least tone and gamut families so later confidence claims
            # truly come from independent evidence families.
            if (row["yavg"] is not None or row["yhigh"] is not None) and row["gamut"] is not None:
                rows.append(row)
        if len(rows) < 3:
            return []

        # Split at missing one-second bins.  We never bridge a decode/sample gap.
        groups = []
        cur = []
        for row in rows:
            if cur and row["sec"] > cur[-1]["sec"] + 1:
                groups.append(cur); cur = []
            cur.append(row)
        if cur: groups.append(cur)

        def med(vals):
            vv = [float(v) for v in vals if v is not None]
            return self._hdr_median(vv) if vv else 0.0

        # Programme-robust feature scales.  Floors prevent low-valued gamut
        # metrics from exploding into arbitrary ratios.
        scales = {
            "yavg": max(abs(med([r["yavg"] for r in rows])) * 0.08, 5.0),
            "yhigh": max(abs(med([r["yhigh"] for r in rows])) * 0.08, 7.0),
            "sat": max(abs(med([r["sat"] for r in rows])) * 0.12, 4.0),
            "gamut": max(abs(med([r["gamut"] for r in rows])) * 0.25, 0.015),
            "edge": max(abs(med([r["edge"] for r in rows])) * 0.18, 0.018),
        }

        def center(part):
            if not part: return None
            return {k: med([r.get(k) for r in part]) for k in scales}

        def family_delta(a, b, keys):
            if not a or not b: return 999.0
            vals = []
            for k in keys:
                if a.get(k) is None or b.get(k) is None: continue
                vals.append(abs(float(a[k]) - float(b[k])) / max(scales[k], 1e-9))
            return (sum(vals) / float(len(vals))) if vals else 999.0

        candidates = []
        for group in groups:
            n = len(group)
            if n < 3: continue

            # Scan a practical range of possible insert durations.  This is not a
            # clip-length special case: every location in every programme is
            # treated identically.  Long-duration mismatches remain covered by
            # the existing programme-level/base-run detectors.
            max_span = min(n - 2, 90)
            for i in range(1, n - 1):
                max_j = min(n - 1, i + max_span)
                for j in range(i + 1, max_j + 1):
                    span = j - i
                    # Both sides are local references.  Reference width follows
                    # the candidate duration but is bounded for stability/cost.
                    ref = max(1, min(5, span))
                    if i - ref < 0 or j + ref > n:
                        continue
                    left = center(group[i-ref:i])
                    mid = center(group[i:j])
                    right = center(group[j:j+ref])
                    if not left or not mid or not right:
                        continue
                    outer_tone = family_delta(left, right, ("yavg", "yhigh", "sat"))
                    outer_gamut = family_delta(left, right, ("gamut", "edge"))
                    mid_tone = min(
                        family_delta(mid, left, ("yavg", "yhigh", "sat")),
                        family_delta(mid, right, ("yavg", "yhigh", "sat")),
                    )
                    mid_gamut = min(
                        family_delta(mid, left, ("gamut", "edge")),
                        family_delta(mid, right, ("gamut", "edge")),
                    )
                    outer_total = outer_tone + outer_gamut
                    middle_total = mid_tone + mid_gamut

                    # Candidate discovery must be more sensitive than final QC
                    # classification.  A real transfer/gamut mismatch may first
                    # reveal itself strongly in only one family; requiring BOTH
                    # families here can kill the candidate before reverse A/B ever
                    # sees it.  We therefore allow a sustained centre departure in
                    # either family, while still requiring the two outside reference
                    # states to be substantially more similar to each other than to
                    # the middle.  Final user-visible classification remains strict.
                    outer_similar = bool(
                        outer_tone <= 1.85 and outer_gamut <= 1.85
                        and middle_total >= max(0.55, outer_total * 1.12)
                    )
                    middle_diff = bool(
                        (mid_tone >= 0.22 and mid_gamut >= 0.12)
                        or mid_tone >= 0.42
                        or mid_gamut >= 0.32
                    )
                    if not (outer_similar and middle_diff):
                        continue

                    start = float(group[i]["start"])
                    end = float(group[j-1]["end"])
                    if end - start < 0.75:
                        continue
                    score = middle_total - 0.50 * outer_total
                    # Directional state evidence.  Candidate discovery itself is
                    # target-independent, but keeping the local centres lets the
                    # later classifier decide whether the middle looks like a
                    # *lower-range / narrower-gamut* SDR-like island or simply a
                    # different HLG shot.  This is generic and contains no fixed
                    # clip length / filename / timecode assumptions.
                    outer_yavg = med([left.get("yavg"), right.get("yavg")])
                    outer_yhigh = med([left.get("yhigh"), right.get("yhigh")])
                    outer_sat = med([left.get("sat"), right.get("sat")])
                    outer_gamut_v = med([left.get("gamut"), right.get("gamut")])
                    outer_edge_v = med([left.get("edge"), right.get("edge")])
                    mid_yavg = float(mid.get("yavg") or 0.0)
                    mid_yhigh = float(mid.get("yhigh") or 0.0)
                    mid_sat = float(mid.get("sat") or 0.0)
                    mid_gamut_v = float(mid.get("gamut") or 0.0)
                    mid_edge_v = float(mid.get("edge") or 0.0)

                    # SDR/HLG transfer mismatches do not always appear darker in
                    # decoded code values; depending on the decode/display path an
                    # SDR insert can be either lower or higher than neighbouring HLG.
                    # What matters here is a sustained two-sided *tone separation*,
                    # not a hard-coded darker-than-HLG assumption.
                    tone_lower = bool(
                        outer_yhigh > 0.0 and mid_yhigh <= outer_yhigh * 0.86
                        and (outer_yavg <= 0.0 or mid_yavg <= outer_yavg * 0.90)
                    )
                    tone_separated = bool(
                        outer_yhigh > 0.0
                        and abs(mid_yhigh - outer_yhigh) >= max(10.0, outer_yhigh * 0.14)
                        and (
                            outer_yavg <= 0.0
                            or abs(mid_yavg - outer_yavg) >= max(7.0, outer_yavg * 0.10)
                        )
                    )
                    gamut_narrower = bool(
                        outer_gamut_v >= 0.012
                        and mid_gamut_v <= max(0.004, outer_gamut_v * 0.68)
                    )
                    edge_narrower = bool(
                        outer_edge_v >= 0.010
                        and mid_edge_v <= max(0.004, outer_edge_v * 0.78)
                    )
                    saturation_support = bool(
                        outer_sat > 0.0 and mid_sat <= outer_sat * 0.88
                    )
                    # Directional SDR-like support.  Do not require every
                    # possible symptom simultaneously: depending on grading and
                    # decode path, Rec.709 material inside an HLG programme can
                    # show a strong tone-shape break with only moderate gamut
                    # contraction, or vice versa.  The later reverse validator and
                    # confidence gate still require independent support before a
                    # warning becomes visible.
                    sdr_like_direction = bool(
                        (tone_separated and gamut_narrower)
                        or (gamut_narrower and (edge_narrower or saturation_support))
                        or (tone_separated and mid_gamut >= 0.48 and (edge_narrower or saturation_support))
                    )

                    candidates.append({
                        "start": start,
                        "end": end,
                        "tc_start": self._timecode_frames(start, fps_for_tc),
                        "tc_end": self._timecode_frames(end, fps_for_tc),
                        "evidence": "timeline_state",
                        "timeline_candidate": True,
                        "temporal_score": score,
                        "outer_tone": outer_tone,
                        "outer_gamut": outer_gamut,
                        "middle_tone": mid_tone,
                        "middle_gamut": mid_gamut,
                        "outer_yavg": outer_yavg,
                        "outer_yhigh": outer_yhigh,
                        "outer_sat": outer_sat,
                        "outer_gamut_value": outer_gamut_v,
                        "outer_edge_value": outer_edge_v,
                        "middle_yavg": mid_yavg,
                        "middle_yhigh": mid_yhigh,
                        "middle_sat": mid_sat,
                        "middle_gamut_value": mid_gamut_v,
                        "middle_edge_value": mid_edge_v,
                        "tone_lower": tone_lower,
                        "tone_separated": tone_separated,
                        "gamut_narrower": gamut_narrower,
                        "edge_narrower": edge_narrower,
                        "saturation_support": saturation_support,
                        "sdr_like_direction": sdr_like_direction,
                    })

        # Prefer stronger/longer candidates and suppress nested duplicates.  We
        # deliberately keep only a bounded number before expensive FFmpeg A/B
        # re-validation so long programmes remain practical.
        candidates.sort(key=lambda x: (float(x.get("temporal_score", 0.0)), float(x.get("end",0.0))-float(x.get("start",0.0))), reverse=True)
        selected = []
        for cand in candidates:
            a, b = float(cand["start"]), float(cand["end"])
            duplicate_index = None
            for idx, keep in enumerate(selected):
                ka, kb = float(keep["start"]), float(keep["end"])
                inter = max(0.0, min(b, kb) - max(a, ka))
                shorter = max(0.001, min(b-a, kb-ka))
                if inter / shorter >= 0.72:
                    duplicate_index = idx; break
            if duplicate_index is not None:
                keep = selected[duplicate_index]
                cand_span = b - a
                keep_span = float(keep["end"]) - float(keep["start"])
                cand_score = float(cand.get("temporal_score",0.0))
                keep_score = float(keep.get("temporal_score",0.0))
                # When two candidates explain essentially the same state island,
                # prefer the wider interval if it retains most of the evidence.
                # This improves user-facing TC boundaries without weakening the
                # later reverse-A/B gate.
                if cand_span > keep_span and cand_score >= keep_score * 0.85:
                    selected[duplicate_index] = cand
                continue
            selected.append(cand)
            if len(selected) >= 32:
                break
        selected.sort(key=lambda x: float(x.get("start", 0.0)))
        return selected

    def _hdr_min_visible_issue_seconds(self):
        """Return the user-selected minimum visible picture-issue duration."""
        try:
            value = float(self.hdr_min_issue_seconds.get())
        except Exception:
            value = 1.0
        return max(0.10, min(30.0, value))

    def _hdr_filter_short_content_runs(self, runs, min_seconds=None):
        """Suppress sub-threshold picture-content ranges from visible results.

        This is a transition/flash guard, not a metadata guard.  File-level
        metadata/content mismatch records stay visible even for very short files;
        ordinary SDR/HDR/WCG picture ranges must persist for the selected minimum
        duration before they can enter GUI/TXT/Excel or influence content WARNING.
        """
        if min_seconds is None:
            min_seconds = self._hdr_min_visible_issue_seconds()
        try:
            threshold = max(0.10, float(min_seconds))
        except Exception:
            threshold = 1.0
        kept = []
        for run in (runs or []):
            row = dict(run)
            if row.get("category") == "metadata_only_suspect":
                kept.append(row)
                continue
            try:
                span = max(0.0, float(row.get("end", 0.0)) - float(row.get("start", 0.0)))
            except Exception:
                span = 0.0
            if span + 1e-6 >= threshold:
                kept.append(row)
        return kept

    def _hdr_merge_final_runs(self, runs, duration, fps, gap=0.35):
        """Merge overlapping/adjacent final issues and suppress generic duplicates.

        Different detector layers may describe the same TC.  User-facing GUI,
        TXT and Excel must receive one canonical issue record per real range.
        """
        rows=[]
        total=max(0.0, float(duration or 0.0))
        for r in sorted((runs or []), key=lambda x:(float(x.get("start",0.0)), -self._hdr_confidence_rank(x.get("confidence")))):
            x=dict(r)
            a=max(0.0, float(x.get("start",0.0)))
            b=float(x.get("end",0.0))
            if total>0:
                b=min(total,b)
            if b<=a:
                continue
            x["start"],x["end"]=a,b
            # A specific classification always wins over an overlapping generic one.
            if x.get("category") == "unknown":
                if any(y.get("category") != "unknown" and min(b,y["end"])-max(a,y["start"]) > 0 for y in rows):
                    continue
            else:
                rows=[y for y in rows if not (y.get("category")=="unknown" and min(b,y["end"])-max(a,y["start"]) > 0)]

            if rows:
                y=rows[-1]
                same=bool(y.get("category")==x.get("category") and y.get("target_spec")==x.get("target_spec"))
                if same and a <= float(y.get("end",0.0))+gap:
                    y["end"]=max(float(y.get("end",0.0)), b)
                    if self._hdr_confidence_rank(x.get("confidence")) > self._hdr_confidence_rank(y.get("confidence")):
                        y["confidence"]=x.get("confidence")
                        if x.get("detail"):
                            y["detail"]=x.get("detail")
                    y["edge_evidence"]=bool(y.get("edge_evidence") or x.get("edge_evidence"))
                    # keep the stronger reverse record if available
                    if self._hdr_confidence_rank(x.get("confidence")) >= self._hdr_confidence_rank(y.get("confidence")) and x.get("reverse"):
                        y["reverse"]=x.get("reverse")
                    continue
            rows.append(x)

        for x in rows:
            x["tc_start"]=self._timecode_frames(float(x.get("start",0.0)), fps)
            x["tc_end"]=self._timecode_frames(float(x.get("end",0.0)), fps)
        return rows

    def _hdr_apply_delivery_consistency(self, result):
        md = result.get("metadata") or {}
        requested_target = clean_text(result.get("requested_target_spec", "")) or "自動判斷"
        auto_mode = requested_target == "自動判斷"

        # target is the effective analysis target.  In Auto mode it is derived from
        # the source Metadata / Bitstream declaration; decoded-picture classification
        # is validation evidence only and never changes this target.
        target = result.get("target_spec") or self._hdr_selected_target_spec(md)
        result["target_spec"] = target
        result["requested_target_spec"] = requested_target

        actual_spec = clean_text(result.get("actual_picture_spec", ""))
        actual_known = actual_spec in (
            "BT.709 / SDR", "BT.2020", "BT.2020 / HLG", "BT.2020 / PQ"
        )
        actual_confidence = clean_text(result.get("actual_picture_confidence", ""))
        strong_actual = actual_known and actual_confidence in ("高", "極高")
        compare_target = target
        metadata_matches_target = self._hdr_metadata_matches_target(md, compare_target)
        # Auto mode treats the source Metadata / Bitstream declaration as the
        # expected source specification, so signalling consistency is part of
        # PASS/FAIL.  Manual mode is different: the operator explicitly selects
        # the delivery target, therefore decoded-picture compliance decides the
        # result and pre-existing source tags are informational only.
        metadata_ok = metadata_matches_target if auto_mode else True

        profile = result.get("content_profile") or {}
        runs = list(result.get("runs") or [])

        # If the programme-wide picture classifier has already identified the whole
        # decoded picture as Rec.709/SDR with high confidence, a full-duration
        # hdr_wcg/wcg_only run is contradictory wording.  It is normally caused by
        # declared HDR/BT.2020 signalling being reused by an older target-oriented
        # detector.  Keep the QC failure, but represent it as signalling-vs-picture
        # mismatch instead of claiming that the picture itself is HDR.  Localised
        # HDR islands are deliberately left untouched.
        if strong_actual and actual_spec == "BT.709 / SDR" and runs:
            try:
                total_duration = max(0.001, float(result.get("duration") or 0.0))
            except Exception:
                total_duration = 0.001
            declared_spec = self._hdr_expected_spec_from_metadata(md)
            reconciled_runs = []
            for _run in runs:
                _r = dict(_run)
                _cat = _r.get("category")
                try:
                    _span = max(0.0, float(_r.get("end", 0.0)) - float(_r.get("start", 0.0)))
                except Exception:
                    _span = 0.0
                _coverage = _span / total_duration if total_duration > 0.0 else 0.0
                if _cat in ("hdr_wcg", "wcg_only") and _coverage >= 0.80:
                    _r["category"] = "picture_metadata_mismatch"
                    _r["actual_picture_spec"] = actual_spec
                    _r["actual_picture_confidence"] = actual_confidence
                    _r["declared_spec"] = declared_spec
                    _r["detail"] = "檔案 HDR/BT.2020 標示與高可信 Rec.709/SDR 實際畫面判定互相不一致"
                reconciled_runs.append(_r)
            runs = reconciled_runs
            result["runs"] = runs

        # In manual target mode, source signalling is not the delivery verdict.
        # If the programme-wide decoded-picture classifier strongly agrees with
        # the operator-selected target, remove programme-level findings whose only
        # meaning is "source tags differ from picture".  Keep genuine local picture
        # anomalies intact.  This makes e.g. a HLG-tagged file with verified 709
        # pictures PASS when the operator deliberately selects BT.709 / SDR.
        if (not auto_mode) and strong_actual and self._hdr_picture_spec_matches_target(actual_spec, target) and runs:
            try:
                _manual_total = max(0.001, float(result.get("duration") or 0.0))
            except Exception:
                _manual_total = 0.001
            _metadata_only_categories = {
                "picture_metadata_mismatch",
                "metadata_only_suspect",
                "transform_sdr_mistag_hdr",
                "transform_hlg_to_709",
                "transform_pq_to_709",
                "transform_2020_to_709",
            }
            _manual_filtered = []
            for _run in runs:
                _cat = _run.get("category")
                try:
                    _span = max(0.0, float(_run.get("end", 0.0)) - float(_run.get("start", 0.0)))
                except Exception:
                    _span = 0.0
                _coverage = _span / _manual_total if _manual_total > 0.0 else 0.0
                if _cat in _metadata_only_categories and _coverage >= 0.80:
                    continue
                _manual_filtered.append(_run)
            runs = _manual_filtered
            result["runs"] = runs

        reasons = []
        # Auto requires a usable source declaration because the user's Auto rule is
        # explicitly "follow the original file signalling, then verify pictures".
        # If that declaration is missing/ambiguous, there is no legitimate Auto
        # baseline; do not silently turn this into PASS.
        auto_target_unknown = bool(auto_mode and target == "自動判斷")
        if auto_target_unknown:
            reasons.append("原影片 Metadata / Bitstream 色彩標示不足，Auto 無法建立 709/2020/HLG/PQ 檢測基準")

        if not metadata_ok:
            reasons.append("檔案 Metadata / Bitstream 標示不符合檢測目標規格")

        content_kind = profile.get("kind", "證據不足")
        metadata_only_runs = [x for x in runs if x.get("category") == "metadata_only_suspect"]
        if metadata_only_runs:
            result["content_judgement"] = "疑似 Rec.709 / SDR 型實際內容；BT.2020 / HLG 標示缺乏獨立畫面證據"
            result["metadata_content_mismatch"] = True
            reasons.append("BT.2020 / HLG Metadata 與實際畫面技術特徵疑似不一致，可能僅有標示而未完成實際色彩轉換")
        else:
            _actual_spec = clean_text(result.get("actual_picture_spec", ""))
            _actual_conf = clean_text(result.get("actual_picture_confidence", ""))
            if _actual_spec and _actual_spec != "自動畫面判斷不足":
                result["content_judgement"] = "實際畫面判定：%s（可信度：%s）" % (
                    _actual_spec, _actual_conf or "一般"
                )
            else:
                result["content_judgement"] = content_kind

        # BT.2020/WCG 內容一致性：低 gamut 只作多證據之一，不單獨判假 2020。
        low_wcg = ("證據偏低" in content_kind or "Rec.709 / SDR 型" in content_kind)
        limited_wcg = "證據有限" in content_kind

        rec709_like_runs = [x for x in runs if x.get("category") == "rec709_like"]
        rec709_like_coverage = 0.0
        try:
            total_duration = max(0.001, float(result.get("duration") or 0.0))
            spans = []
            for x in sorted(rec709_like_runs, key=lambda y: float(y.get("start", 0.0))):
                a = max(0.0, float(x.get("start", 0.0)))
                b = min(total_duration, float(x.get("end", 0.0)))
                if b <= a:
                    continue
                if spans and a <= spans[-1][1] + 0.35:
                    spans[-1][1] = max(spans[-1][1], b)
                else:
                    spans.append([a, b])
            rec709_like_coverage = sum(max(0.0, b-a) for a,b in spans) / total_duration
        except Exception:
            rec709_like_coverage = 0.0

        # The decoded-picture classification must agree with the effective target.
        # Auto: effective target comes from the original file declaration.
        # Manual: effective target is the operator-selected delivery specification.
        actual_target_mismatch = False
        if strong_actual and target in (
            "BT.709 / SDR", "BT.2020", "BT.2020 / HLG", "BT.2020 / PQ"
        ) and not self._hdr_picture_spec_matches_target(actual_spec, target):
            actual_target_mismatch = True
            if auto_mode:
                reasons.append(
                    "實際畫面判定為 %s（可信度：%s），與原影片標示規格 %s 不一致"
                    % (actual_spec, actual_confidence, target)
                )
            else:
                reasons.append(
                    "實際畫面判定為 %s（可信度：%s），不符合所選目標規格 %s"
                    % (actual_spec, actual_confidence, target)
                )
            # Ensure the mismatch is visible as a user-facing problem even when
            # older local anomaly detectors produced no run.
            if not any(x.get("category") == "picture_target_mismatch" for x in runs):
                try:
                    _duration_for_run = max(0.0, float(result.get("duration") or 0.0))
                except Exception:
                    _duration_for_run = 0.0
                _fps_for_run = float(result.get("fps") or 25.0) or 25.0
                _new_run = {
                    "start": 0.0,
                    "end": _duration_for_run,
                    "category": "picture_target_mismatch",
                    "confidence": actual_confidence,
                    "actual_picture_spec": actual_spec,
                    "actual_picture_confidence": actual_confidence,
                    "selected_target_spec": target,
                    "declared_spec": target if auto_mode else self._hdr_expected_spec_from_metadata(md),
                    "auto_mode": bool(auto_mode),
                    "target_spec": target,
                    "tc_start": self._timecode_frames(0.0, _fps_for_run),
                    "tc_end": self._timecode_frames(_duration_for_run, _fps_for_run),
                }
                runs.append(_new_run)
                result["runs"] = runs

        # The following target-specific checks use the effective target.
        # In Auto mode this target comes from the original file declaration; wording
        # must therefore describe declaration-vs-picture consistency, not manual delivery.
        if target == "BT.2020" and not (md.get("is_hlg") or md.get("is_pq")):
            repeated_rec709 = bool(
                len(rec709_like_runs) >= 3
                and (rec709_like_coverage >= 0.12 or len(rec709_like_runs) >= 8)
            )
            if low_wcg or repeated_rec709:
                result["content_judgement"] = (
                    "畫面多個時段持續呈現 Rec.709 / SDR 型色域分布"
                    if repeated_rec709 else "疑似 Rec.709 / SDR 色域內容"
                )
                result["metadata_content_mismatch"] = True
                reasons.append("BT.2020 標示與實際畫面內容疑似不一致")
                if repeated_rec709:
                    reasons.append("多個時段反覆出現 Rec.709 / SDR 型色域特徵，與 BT.2020/WCG 標示不一致" if auto_mode else "多個時段反覆出現 Rec.709 / SDR 型色域特徵，與 BT.2020/WCG 目標不一致")
            elif limited_wcg:
                result["content_judgement"] = "BT.2020 / WCG 內容證據有限"
                reasons.append("BT.2020 Metadata 存在，但實際畫面的 WCG 證據未達明確一致門檻")
        elif target in ("BT.2020 / HLG", "BT.2020 / PQ") and low_wcg:
            if any(x.get("category") == "sdr709" for x in runs):
                reasons.append("BT.2020/WCG 內容證據偏低，並同時檢測到 SDR/Rec.709 型持續區段")

        if target == "BT.709 / SDR" and not auto_mode:
            # Manual BT.709 means the operator is asking whether the decoded
            # picture meets BT.709 / SDR.  Do not convert HLG/2020 source tags
            # into picture-content failures when the picture classifier already
            # confirms BT.709 / SDR.  Metadata remains visible in the header.
            if not strong_actual and not metadata_only_runs:
                if md.get("is_hlg") or md.get("is_pq"):
                    reasons.append("實際畫面判定證據不足；來源 HDR 標示僅供人工複核，不直接代表畫面為 HDR")
                elif md.get("is_2020") and not low_wcg:
                    reasons.append("實際畫面判定證據不足；來源 BT.2020 標示僅供人工複核")

        if runs:
            if auto_mode:
                reasons.append("檢測到持續的 SDR / HDR / 色域內容一致性異常區段")
            elif target == "BT.709 / SDR":
                if any(x.get("category") == "hdr_wcg" for x in runs):
                    reasons.append("檢測到持續的 HDR / BT.2020/WCG 內容，不符合 BT.709 / SDR 目標")
                if any(x.get("category") == "wcg_only" for x in runs):
                    reasons.append("檢測到持續的 BT.2020 / WCG 色域內容，不符合 BT.709 / SDR 目標")
                # In manual BT.709 mode source signalling is informational only.
                # A metadata/content mismatch is not itself a delivery failure when
                # decoded pictures satisfy the selected BT.709 / SDR target.
            elif target == "BT.2020":
                reasons.append("檢測到持續的色域內容一致性異常區段")
            elif target == "BT.2020 / HLG":
                reasons.append("檢測到持續的 SDR/HDR/HLG 內容一致性異常區段")
            elif target == "BT.2020 / PQ":
                reasons.append("檢測到持續的 SDR/HDR/PQ 內容一致性異常區段")
            else:
                reasons.append("檢測到持續的 SDR/HDR/色域內容異常區段")

        dedup=[]
        for _reason in reasons:
            if _reason and _reason not in dedup:
                dedup.append(_reason)
        reasons=dedup
        result["consistency_reasons"] = reasons

        if not metadata_ok or actual_target_mismatch:
            result["status"] = "FAIL"
        elif auto_target_unknown or reasons:
            result["status"] = "WARNING"
        elif result.get("status") not in ("ERROR",):
            result["status"] = "PASS"

        if result.get("status") == "PASS":
            if auto_mode:
                result["message"] = "檔案標示與實際畫面內容未發現達到門檻的不一致。"
            else:
                result["message"] = "所選目標規格與實際畫面內容未發現達到門檻的不一致。"
        elif result.get("status") in ("WARNING", "FAIL"):
            result["message"] = "；".join(reasons) if reasons else result.get("message", "")
        return result

    def _analyze_hdr_gamut_file(self, path):
        # v1.2.0 colour-state fusion pass: keep the deep-performance L2-L6 engine,
        # add Layer 7 whole-programme multi-hypothesis colour/transform consistency.
        # INFO + field-order modules are intentionally untouched.
        self._hdr_range_feature_cache = {}
        self._hdr_raw_frame_cache = {}
        self._hdr_combined_feature_cache = {}
        self._hdr_reverse_validation_cache = {}
        self._hdr_inverse_lut_cache = {}
        self._hdr_probe_cache = {}
        self._hdr_probe_stream_cache = {}
        self._hdr_stage_progress(1, "讀取影片資訊")
        data = self.read_media(path)
        self._hdr_stage_progress(3, "讀取色彩標示")

        # One consolidated ffprobe supplies colour signalling and timing fields.
        # This replaces the former separate primaries/transfer/matrix queries and
        # usually avoids the extra duration probes as well.
        self._hdr_stage_progress(5, "讀取 HDR / Bitstream 標示")
        bitstream = self._hdr_probe_bitstream_metadata(path)
        ff_primaries = bitstream.get("color_primaries", "")
        ff_transfer = bitstream.get("color_transfer", "")
        ff_matrix = bitstream.get("color_space", "")
        self._hdr_stage_progress(7, "檢查 HDR / Bitstream 標示")
        metadata_crosscheck = self._hdr_metadata_crosscheck(
            data,
            bitstream,
        )

        # Layer 1 — Metadata
        metadata = self._hdr_metadata_kind(
            data,
            ff_primaries=ff_primaries,
            ff_transfer=ff_transfer,
            ff_matrix=ff_matrix,
        )

        # Use the same actual decoded-picture cadence as the field module.
        # This prevents 50-header / 25-picture MXF files from producing wrong TC
        # or duration arithmetic in HDR/gamut analysis.
        try:
            _picture_probe = self._field_probe_info(path)
            fps = float(_picture_probe.get("fps") or 0.0)
        except Exception:
            fps = 0.0
        if fps <= 0.0:
            fps = (
                normalize_fps(data.get("fps", ""))
                or normalize_fps(bitstream.get("r_frame_rate", ""))
                or normalize_fps(bitstream.get("avg_frame_rate", ""))
                or 25.0
            )
        duration = self._hdr_duration_from_probe(bitstream, fps_hint=fps)
        if duration <= 0.0:
            duration = self._probe_duration_seconds(path, fps_hint=fps)

        try:
            _requested_target_spec = clean_text(self.hdr_target_spec.get())
        except Exception:
            _requested_target_spec = "自動判斷"
        if not _requested_target_spec:
            _requested_target_spec = "自動判斷"

        result = {
            "file": path,
            "metadata": metadata,
            "fps": fps,
            "duration": duration,
            "samples": 0,
            "runs": [],
            "stats": {},
            "status": "INFO",
            "message": "",
            "reverse_validation": False,
            "analysis_layers": 1,
            "metadata_crosscheck": metadata_crosscheck,
            # requested_target_spec is the operator-facing delivery selection.
            # target_spec remains the internal/effective analysis baseline so the
            # existing detector branches do not change behaviour in Auto mode.
            "requested_target_spec": _requested_target_spec,
            "target_spec": self._hdr_selected_target_spec(metadata),
        }

        # BT.2020 本身是有效的色域標示，不因 Transfer 不是 HLG/PQ 而 WARNING。
        # 只要檢測到 BT.2020（包括 BT.2020 / HLG、BT.2020 / PQ，或
        # Transfer 只標示 BT.2020），都繼續做實際畫面的亮度／色域一致性分析。
        # 只有完全沒有 BT.2020 標示的素材，才停在 Metadata INFO。

        # Layers 2 + 3 + 4 — ONE full-programme FFmpeg decode.
        # Sampling remains exactly 2 fps for signalstats and 1 fps / 128x72 for
        # gamut+edge.  A conservative fallback preserves compatibility with an
        # older FFmpeg build if the split-filter path is unavailable.
        self._hdr_stage_progress(10, "同步分析亮度／飽和度及 BT.2020 / Rec.709 色域")
        samples = []
        gamut_samples = []
        try:
            samples, gamut_samples = self._hdr_joint_signal_gamut_samples(
                path, metadata=metadata, signal_fps=2.0, gamut_fps=1.0,
                width=128, height=72, duration=duration,
                progress_callback=lambda p: self._hdr_stage_progress(10.0 + 62.0 * p, "同步分析亮度／飽和度及色域")
            )
        except Exception as _joint_exc:
            try:
                self.log("HDR整合解碼不可用，回退相容分析：%s" % _joint_exc)
            except Exception:
                pass

        if (not self.stop_requested) and (not samples or not gamut_samples):
            # Compatibility fallback only; normal supported FFmpeg uses one decode.
            samples = self._hdr_signalstats_samples(
                path, sample_fps=2.0, duration=duration,
                progress_callback=lambda p: self._hdr_stage_progress(10.0 + 30.0 * p, "分析亮度／飽和度")
            )
            gamut_samples = self._hdr_gamut_boundary_samples(
                path, metadata=metadata, sample_fps=1.0, width=128, height=72,
                duration=duration,
                progress_callback=lambda p: self._hdr_stage_progress(40.0 + 32.0 * p, "分析 BT.2020 / Rec.709 色域")
            )

        self._hdr_stage_progress(72, "亮度／飽和度及色域分析完成")
        result["samples"] = len(samples)
        luma_runs, stats = self._hdr_find_suspicious_runs(
            samples, duration=duration, fps_for_tc=fps,
        )

        # Normalize the picture-timeline duration now that both decoded sample
        # streams are available.  This value is used by ALL later segmentation,
        # reverse A/B validation, target inversion, TC generation and reports.
        # Do not let an unavailable ffprobe duration (0.0) collapse valid ranges.
        _probed_duration = float(duration or 0.0)
        duration = self._hdr_effective_timeline_duration(
            duration, samples=samples, gamut_samples=gamut_samples
        )
        result["duration"] = duration

        # Luma candidates are cheap to rebuild and may have been created before
        # the decoded timeline supplied a usable duration.  Rebuild only when
        # the effective end changed materially.
        if abs(duration - _probed_duration) > 0.25:
            luma_runs, stats = self._hdr_find_suspicious_runs(
                samples, duration=duration, fps_for_tc=fps
            )
            result["stats"] = stats

        gamut_runs, gamut_stats = self._hdr_find_gamut_drop_runs(
            gamut_samples,
            duration=duration,
            fps_for_tc=fps,
        )
        edge_runs, edge_stats = self._hdr_find_gamut_edge_runs(
            gamut_samples,
            duration=duration,
            fps_for_tc=fps,
        )

        self._hdr_stage_progress(74, "比對前後畫面")
        base_runs = self._hdr_merge_content_evidence(
            luma_runs,
            gamut_runs,
            fps_for_tc=fps,
        )

        # Layer 5 — HLG reference-level consistency.
        # Layer 4 and 5 strengthen candidates; neither is allowed to create a
        # user-visible warning by itself.
        base_runs = self._hdr_attach_extra_evidence(
            base_runs,
            edge_runs,
            samples,
            duration=duration,
            fps_for_tc=fps,
        )

        for item in base_runs:
            item["hlg_nits_profile"] = (
                self._hdr_hlg_nits_profile_for_run(
                    samples,
                    item,
                    duration=duration,
                )
                if metadata.get("is_hlg")
                else {"valid": False}
            )

        result["stats"] = stats
        result["gamut_samples"] = len(gamut_samples)
        result["gamut_stats"] = gamut_stats
        result["edge_stats"] = edge_stats
        result["analysis_layers"] = 5

        classified = []

        # Layer 6 — standardized colour-management A/B reverse validation.
        # For HLG only:
        #   A) candidate is Rec.709/BT.1886-style SDR -> map to BT.2020 HLG
        #   B) candidate is HLG already processed as SDR->HDR -> undo one map
        # Only suspicious TC ranges are re-read, never the whole programme.
        target_spec = result.get("target_spec") or self._hdr_selected_target_spec(metadata)
        hlg_content_analysis = bool(metadata.get("is_hlg") and target_spec in ("BT.2020 / HLG", "BT.709 / SDR"))
        if hlg_content_analysis:
            self._hdr_stage_progress(78, "驗證可疑區段")
            base_total = max(1, len(base_runs))
            for base_index, run in enumerate(base_runs, 1):
                if self.stop_requested:
                    break
                self._hdr_stage_progress(78.0 + 10.0 * ((base_index - 1) / float(base_total)), "驗證可疑區段 %d/%d" % (base_index, base_total))
                if not self._hdr_transition_plateau_support(run, samples, gamut_samples):
                    continue

                rv = self._hdr_reverse_validate_run(
                    path,
                    run,
                    duration=duration,
                    hypothesis="sdr_to_hlg",
                    metadata=metadata,
                )

                item = dict(run)

                pre_ref = item.get("hlg_reference") or {}
                pre_nits = item.get("hlg_nits_profile") or {}

                # Reverse A/B is supporting evidence only; never promote a failed
                # transform test to strong merely because correlated scene statistics agree.

                item["reverse"] = rv

                if rv.get("valid"):
                    try:
                        self.log(
                            "HDR反向驗證：TC %s - %s | 最佳技術模型=%s | "
                            "改善 %.1f%% | %d/%d 項改善 | strong=%s moderate=%s"
                            % (
                                item.get("tc_start", ""),
                                item.get("tc_end", ""),
                                rv.get("best_model_name", "—"),
                                float(rv.get("improvement", 0.0)) * 100.0,
                                int(rv.get("feature_improved_count", 0)),
                                int(rv.get("available_metric_count", 0)),
                                bool(rv.get("strong")),
                                bool(rv.get("moderate")),
                            )
                        )
                    except Exception:
                        pass

                ref = item.get("hlg_reference") or {}
                ref_low = bool(
                    ref.get("valid")
                    and ref.get("direction") == "low"
                )
                nits_ref = item.get("hlg_nits_profile") or {}
                nits_low = bool(
                    nits_ref.get("valid")
                    and nits_ref.get("direction") == "low"
                )
                edge = bool(item.get("edge_evidence"))
                both = item.get("evidence") == "both"

                reverse_support = self._hdr_reverse_support_profile(rv)
                independent_scene_cues = int(both) + int(edge) + int(ref_low or nits_low)
                sandwich = self._hdr_hlg_sandwich_profile(
                    path, item, duration=duration, metadata=metadata
                )
                item["sandwich"] = sandwich

                # A true HLG->SDR-like->HLG insert is special: the two outside
                # references must match each other while the middle departs in
                # both tone and gamut.  This independent temporal structure can
                # recover a short genuine SDR insert without loosening the
                # ordinary shot-change thresholds.
                sandwich_support = bool(
                    sandwich.get("strong")
                    and reverse_support.get("independent")
                    and float(rv.get("improvement",0.0)) >= 0.04
                )
                sandwich_extreme = bool(
                    sandwich.get("very_strong")
                    and reverse_support.get("independent")
                    and (rv.get("strong") or rv.get("moderate"))
                    and reverse_support.get("model_consensus")
                )

                # A correct HLG programme can contain low-key or low-saturation shots.
                # Therefore SDR/709 classification requires BOTH independent picture
                # families (tone + gamut) plus a real reverse-A/B result.  The reverse
                # result alone is never allowed to create an SDR warning.
                extreme_ok = bool(
                    rv.get("strong")
                    and reverse_support.get("independent")
                    and reverse_support.get("strong_consensus")
                    and both
                    and (ref_low or nits_low or edge)
                )
                high_ok = bool(
                    (rv.get("strong") or rv.get("moderate"))
                    and reverse_support.get("independent")
                    and both
                    and (ref_low or nits_low or edge)
                    and independent_scene_cues >= 2
                )

                if extreme_ok or sandwich_extreme:
                    item["category"] = "sdr709"
                    item["confidence"] = "極高"
                    item["detail"] = (
                        "前後 HLG 參考互相一致，中間區段在亮度及 Rec.709 型色域兩組獨立特徵上明顯偏離，"
                        "且 SDR→HLG 反向驗證獲多模型一致支持"
                        if sandwich_extreme else
                        "亮度結構與 Rec.709 型色域收窄同時成立，且多模型 SDR→HLG 反向驗證在獨立的亮度及色域指標上均改善"
                    )
                    classified.append(item)
                elif high_ok or sandwich_support:
                    item["category"] = "sdr709"
                    item["confidence"] = "高" if sandwich_support else "高"
                    item["detail"] = (
                        "檢出 HLG→SDR-like→HLG 的 A-B-A 時間結構：前後參考相近而中段同時呈現亮度與 Rec.709 型色域偏離，反向驗證亦提供支持"
                        if sandwich_support else
                        "亮度與色域兩組獨立證據均符合 SDR / Rec.709，反向驗證亦提供一致支持"
                    )
                    classified.append(item)
                else:
                    # Keep only genuinely multi-family unexplained anomalies.  Relative
                    # shot-to-shot brightness or gamut variation alone stays internal so
                    # a normal HLG shot is not reported as an error.
                    unexplained_ok = bool(both and edge and (ref_low or nits_low))
                    if unexplained_ok:
                        item["category"] = "unknown"
                        item["confidence"] = "一般"
                        item["detail"] = "多組獨立內容指標持續偏離 HLG 基準，建議人工複核"
                        classified.append(item)

            # Build the programme SDR/Rec.709 state timeline ONCE with the
            # shared target-independent validator.  Every target later reuses
            # this exact state list instead of rediscovering content separately.
            _validated_sdr_states, _all_state_candidates = self._hdr_collect_validated_sdr_states(
                path, samples, gamut_samples, duration, fps, metadata, existing=classified
            )
            result["validated_sdr_states"] = [dict(x) for x in _validated_sdr_states]
            result["timeline_candidate_count"] = len(_all_state_candidates or [])

            # Persist the objectively validated source-content SDR timeline so a
            # later delivery-target switch (for example HLG -> BT.709/SDR) reuses
            # exactly the same picture classification instead of rediscovering it
            # under another target.  Cache identity includes file metadata so stale
            # results are never reused after the source is replaced.
            try:
                _st = os.stat(path)
                _source_key = (os.path.abspath(path), int(_st.st_size), int(_st.st_mtime))
            except Exception:
                _source_key = (os.path.abspath(path), None, None)
            # Only a native-HLG analysis is authoritative enough to populate
            # the cross-target source-state cache.  A BT.709 delivery run must
            # not cache its own (possibly empty) pre-inversion state and thereby
            # suppress the guarded native-source probe below.
            if target_spec == "BT.2020 / HLG" or getattr(self, "_hdr_internal_source_probe", False):
                if not hasattr(self, "_hdr_source_state_cache"):
                    self._hdr_source_state_cache = {}
                self._hdr_source_state_cache[_source_key] = {
                    "sdr_states": [dict(x) for x in _validated_sdr_states],
                    "candidate_count": len(_all_state_candidates or []),
                    "native_target": "BT.2020 / HLG",
                }
            for _state in _validated_sdr_states:
                if not any(self._hdr_ranges_overlap(_state, x, tolerance=0.45)
                           and x.get("category") == "sdr709" for x in classified):
                    classified.append(dict(_state))

            # HLG duplicate-HDR candidates.
            self._hdr_stage_progress(88, "檢查 HLG 重複 HDR 處理")
            over_candidates = self._hdr_find_overprocessed_hlg_runs(
                samples,
                gamut_samples,
                duration=duration,
                fps_for_tc=fps,
            )

            # Attach Layers 4/5 to over-HDR candidates too.
            over_candidates = self._hdr_attach_extra_evidence(
                over_candidates,
                edge_runs,
                samples,
                duration=duration,
                fps_for_tc=fps,
            )

            over_total = max(1, len(over_candidates))
            for over_index, run in enumerate(over_candidates, 1):
                if self.stop_requested:
                    break
                self._hdr_stage_progress(89.0 + 7.0 * ((over_index - 1) / float(over_total)), "檢查 HLG 重複 HDR %d/%d" % (over_index, over_total))

                if any(
                    self._hdr_ranges_overlap(run, existing, tolerance=0.75)
                    for existing in classified
                ):
                    continue

                rv = self._hdr_reverse_validate_run(
                    path,
                    run,
                    duration=duration,
                    hypothesis="inverse_extra_hdr",
                    metadata=metadata,
                )

                ref = run.get("hlg_reference") or {}
                ref_high = bool(
                    ref.get("valid")
                    and ref.get("direction") == "high"
                )
                nits_ref = self._hdr_hlg_nits_profile_for_run(
                    samples,
                    run,
                    duration=duration,
                )
                run["hlg_nits_profile"] = nits_ref
                nits_high = bool(
                    nits_ref.get("valid")
                    and nits_ref.get("direction") == "high"
                )
                edge = bool(run.get("edge_evidence"))

                # Duplicate-HDR false positives are costly. Require strong
                # reverse A/B plus at least one independent supporting cue.
                if rv.get("strong") and (ref_high or nits_high or edge):
                    item = dict(run)
                    item["reverse"] = rv
                    item["category"] = "double_hdr"
                    item["confidence"] = "極高"
                    item["detail"] = (
                        "此段高光／色域結構異常，撤回一次 SDR→HDR 型"
                        "映射後與前後正常 HLG 明顯更接近"
                    )
                    classified.append(item)

            result["reverse_validation"] = True
            result["analysis_layers"] = 6

        else:
            # 非 HLG：只有 BT.2020/PQ/BT.2020 generic 才使用相對色域／亮度
            # 異常建立可見區段。BT.709/SDR 的一般鏡頭亮度變化不能被誤當 HDR 異常。
            if metadata.get("is_2020"):
                for run in base_runs:
                    item = dict(run)
                    evidence_count = int(item.get("evidence") == "both") + int(bool(item.get("edge_evidence")))
                    # Generic BT.2020：若異常包含 gamut drop，優先解讀為 Rec.709/SDR-like
                    # 色域內容，而不是籠統的「色域內容異常」。亮度-only 仍保留 fallback。
                    if target_spec == "BT.2020" and item.get("evidence") in ("gamut", "both"):
                        item["category"] = "rec709_like"
                        item["confidence"] = "高" if evidence_count >= 2 else "一般"
                        item["detail"] = "BT.2020 標示下，此區段的廣色域佔用明顯收窄，呈現 Rec.709 / SDR 型色域分布"
                    else:
                        item["category"] = "unknown"
                        item["confidence"] = "高" if evidence_count >= 2 else "一般"
                        item["detail"] = "色域內容分布與全片基準明顯不一致"
                    classified.append(item)

        # Target-aware reinterpretation.  The detector first identifies the source-content
        # structure, then this stage reports only the portions that violate the user's target.
        target_spec = result.get("target_spec") or self._hdr_selected_target_spec(metadata)

        # Build the source/content assessment BEFORE applying the user's delivery target.
        # Target selection must never rewrite what the picture itself was classified as.
        source_content_profile = self._hdr_content_profile(gamut_samples, metadata)
        result["content_profile"] = source_content_profile
        _source_metadata_only_run = self._hdr_metadata_only_mismatch_run(
            path, metadata, target_spec, duration, fps, existing_runs=classified
        )
        result["source_metadata_only_suspect"] = bool(_source_metadata_only_run is not None)

        # Layer 7 — programme-level multi-hypothesis colour-state fusion.
        # It complements temporal Layers 2–6 and is specifically able to catch a
        # whole programme that is consistently transformed/mistagged, where there
        # is no normal neighbouring shot to act as a reference.
        _colour_fingerprint = self._hdr_program_fingerprint(samples, gamut_samples)

        # Actual-content colour judgement must not depend on MediaInfo/ffprobe tags.
        # Reuse an existing raw Y'CbCr probe when available; otherwise execute the
        # small matrix probe for every source, regardless of declared 709/2020/HLG.
        _matrix_support = (_source_metadata_only_run or {}).get("matrix_probe") if _source_metadata_only_run else None
        if _matrix_support is None:
            try:
                _st = os.stat(path)
                _probe_key = (os.path.abspath(path), int(_st.st_size), int(_st.st_mtime))
            except Exception:
                _probe_key = (os.path.abspath(path), None, None)
            _matrix_support = (getattr(self, "_hdr_matrix_probe_cache", {}) or {}).get(_probe_key)
            if not (_matrix_support or {}).get("valid"):
                _matrix_support = self._hdr_raw_matrix_consistency_probe(
                    path, duration=duration, sample_fps=0.5, width=64, height=36
                )
                if not hasattr(self, "_hdr_matrix_probe_cache"):
                    self._hdr_matrix_probe_cache = {}
                self._hdr_matrix_probe_cache[_probe_key] = dict(_matrix_support or {})

        _picture_native = self._hdr_picture_native_spec(
            _colour_fingerprint, matrix_probe=_matrix_support
        )
        result["actual_picture_spec"] = _picture_native.get("spec", "自動畫面判斷不足")
        result["actual_picture_confidence"] = _picture_native.get("confidence", "一般")
        result["actual_picture_reason"] = _picture_native.get("reason", "")
        result["actual_picture_evidence"] = dict(_picture_native)

        # Auto mode keeps target_spec derived from the source Metadata / Bitstream.
        # actual_picture_spec is evidence only and must never overwrite that target.

        _colour_state = self._hdr_multi_hypothesis_color_state(
            metadata, _colour_fingerprint, content_profile=source_content_profile, matrix_probe=_matrix_support
        )

        # The raw-matrix classifier is deliberately conservative.  When it cannot
        # resolve the matrix/transfer by itself, allow independent decoded-picture
        # WCG + HLG tone/headroom evidence to refine the picture class.  Metadata
        # tags are not used for this refinement.
        _picture_native = self._hdr_refine_picture_native_spec_from_state(
            _picture_native, _colour_state
        )
        result["actual_picture_spec"] = _picture_native.get("spec", "自動畫面判斷不足")
        result["actual_picture_confidence"] = _picture_native.get("confidence", "一般")
        result["actual_picture_reason"] = _picture_native.get("reason", "")
        result["actual_picture_evidence"] = dict(_picture_native)

        result["color_state_fingerprint"] = _colour_fingerprint
        result["color_state_hypotheses"] = _colour_state
        result["analysis_layers"] = 7
        _colour_state_run = self._hdr_color_state_warning_run(
            _colour_state, metadata, _colour_fingerprint, duration, fps, target_spec
        )

        # Source-content class follows decoded picture evidence only.  Metadata may
        # disagree and will be reported separately, but must never define the class.
        _native_spec = result.get("actual_picture_spec")
        if _native_spec == "BT.709 / SDR":
            result["source_content_class"] = "SDR709"
        elif _native_spec == "BT.2020 / HLG":
            result["source_content_class"] = "HLG_WCG"
        elif _native_spec == "BT.2020 / PQ":
            result["source_content_class"] = "PQ_WCG"
        elif _native_spec == "BT.2020":
            result["source_content_class"] = "BT2020_WCG"
        else:
            result["source_content_class"] = "PICTURE_UNCERTAIN"

        if target_spec == "BT.709 / SDR":
            # Never derive a second content timeline for the SDR target. Reuse the
            # same validated SDR/Rec.709 states used by HLG analysis. If they were
            # not built above (e.g. non-HLG tagged source), build them once here
            # with the same target-independent validator.
            sdr_runs = [dict(r) for r in (result.get("validated_sdr_states") or [])]
            _state_candidates = []

            # First reuse a native/source-content timeline from an earlier analysis
            # of the same file.  This is the canonical timeline and must take
            # precedence over target-specific Metadata fallbacks.
            try:
                _st = os.stat(path)
                _source_key = (os.path.abspath(path), int(_st.st_size), int(_st.st_mtime))
            except Exception:
                _source_key = (os.path.abspath(path), None, None)
            _cached_source = (getattr(self, "_hdr_source_state_cache", {}) or {}).get(_source_key)
            _cached_states = [dict(r) for r in ((_cached_source or {}).get("sdr_states") or [])]

            # IMPORTANT: current-run validated picture states have first priority.
            # An older/empty cache must never erase a SDR range that this very
            # analysis has already validated (the bug that caused 03-07 SDR to
            # disappear and the BT.709 target to fall back to whole-programme HDR).
            if not sdr_runs and _cached_states:
                sdr_runs = _cached_states
                result["validated_sdr_states"] = [dict(x) for x in sdr_runs]
            if _cached_source is not None:
                result["timeline_candidate_count"] = max(
                    int(result.get("timeline_candidate_count") or 0),
                    int(_cached_source.get("candidate_count") or 0),
                )

            # If this run has already produced an objective SDR timeline, persist
            # it immediately.  This keeps target switching deterministic without
            # re-running classification and, crucially, without relying on metadata.
            if sdr_runs:
                if not hasattr(self, "_hdr_source_state_cache"):
                    self._hdr_source_state_cache = {}
                self._hdr_source_state_cache[_source_key] = {
                    "sdr_states": [dict(x) for x in sdr_runs],
                    "candidate_count": int(result.get("timeline_candidate_count") or 0),
                    "native_target": "picture_timeline",
                }
                _cached_source = self._hdr_source_state_cache[_source_key]
                _cached_states = [dict(x) for x in sdr_runs]

            # If BT.709/SDR is the first target analysed for an HLG source and no
            # canonical source timeline exists yet, perform one guarded native-HLG
            # source probe.  This executes the exact same picture-classification
            # path used by Auto/HLG, then reuses only its SDR/Rec.709 states here.
            # It is generic: no filename, duration, fixed TC or sample-specific rule.
            if (not sdr_runs) and (not _cached_states) and metadata.get("is_hlg") and not getattr(self, "_hdr_internal_source_probe", False):
                _old_override = getattr(self, "_hdr_target_override", None)
                self._hdr_internal_source_probe = True
                self._hdr_target_override = "BT.2020 / HLG"
                try:
                    _probe_result = self._analyze_hdr_gamut_file(path)
                    # Prefer the probe's canonical target-independent state list.
                    # Falling back to visible runs is only for backward compatibility.
                    _probe_states = [dict(r) for r in ((_probe_result or {}).get("validated_sdr_states") or [])]
                    if not _probe_states:
                        _probe_states = [dict(r) for r in ((_probe_result or {}).get("runs") or []) if r.get("category") == "sdr709"]
                    _probe_candidates = int((_probe_result or {}).get("timeline_candidate_count") or 0)
                    if not hasattr(self, "_hdr_source_state_cache"):
                        self._hdr_source_state_cache = {}
                    self._hdr_source_state_cache[_source_key] = {
                        "sdr_states": [dict(x) for x in _probe_states],
                        "candidate_count": _probe_candidates,
                        "native_target": "BT.2020 / HLG",
                    }
                    sdr_runs = [dict(x) for x in _probe_states]
                    result["validated_sdr_states"] = [dict(x) for x in sdr_runs]
                    result["timeline_candidate_count"] = max(
                        int(result.get("timeline_candidate_count") or 0), _probe_candidates
                    )
                except Exception as _probe_exc:
                    try:
                        self.log("HDR來源內容時間線探測失敗：%s" % _probe_exc)
                    except Exception:
                        pass
                finally:
                    self._hdr_target_override = _old_override
                    self._hdr_internal_source_probe = False

            # For non-HLG sources, or as a final same-path fallback, use the shared
            # target-independent validator once.
            if not sdr_runs and not _cached_states:
                sdr_runs, _state_candidates = self._hdr_collect_validated_sdr_states(
                    path, samples, gamut_samples, duration, fps, metadata, existing=classified
                )
                result["validated_sdr_states"] = [dict(x) for x in sdr_runs]
                result["timeline_candidate_count"] = max(
                    int(result.get("timeline_candidate_count") or 0), len(_state_candidates or [])
                )

            if _source_metadata_only_run is not None:
                # The picture-side cross-check says the programme is SDR/Rec.709-like.
                # In MANUAL BT.709 mode that is supporting evidence for the selected
                # target, not a delivery failure.  Source HDR/BT.2020 tags stay visible
                # in the header but do not manufacture a WARNING/FAIL.
                result["validated_sdr_states"] = [{
                    "start": 0.0, "end": self._hdr_effective_timeline_duration(duration, samples=samples, gamut_samples=gamut_samples),
                    "category": "sdr709", "confidence": _source_metadata_only_run.get("confidence", "一般"),
                    "evidence": "metadata_picture_crosscheck"
                }]
                result["sdr_target_used_timeline_complement"] = True
                classified = []

            elif metadata.get("is_hlg") or metadata.get("is_pq") or metadata.get("is_2020"):
                # SDR-like ranges are NORMAL for an SDR target. Report the complement as
                # HDR/WCG content, preserving explicit TC ranges in GUI/TXT/Excel.
                if sdr_runs:
                    # From this point the BT.709 result is a pure complement of the
                    # canonical SDR timeline.  Do not allow any metadata/full-range
                    # fallback to replace it later in this branch.
                    result["sdr_target_used_timeline_complement"] = True

                    # IMPORTANT: calculate the canonical timeline end BEFORE
                    # clamping SDR states.  Older builds clamped with raw
                    # `duration`; when ffprobe returned 0, every valid SDR state
                    # became [a, 0] and was discarded, so the inverse mask became
                    # the whole programme.
                    total = self._hdr_effective_timeline_duration(
                        duration, samples=samples, gamut_samples=gamut_samples, runs=sdr_runs
                    )
                    merged = []
                    for r in sorted(sdr_runs, key=lambda x: float(x.get("start", 0.0))):
                        a = max(0.0, float(r.get("start", 0.0)))
                        b = float(r.get("end", 0.0))
                        if total > 0.0:
                            b = min(total, b)
                        if b <= a:
                            continue
                        if merged and a <= merged[-1][1] + 0.35:
                            merged[-1][1] = max(merged[-1][1], b)
                        else:
                            merged.append([a, b])
                    inv = []
                    cursor = 0.0
                    for a, b in merged:
                        if a - cursor >= 0.50:
                            inv.append((cursor, a))
                        cursor = max(cursor, b)
                    if total - cursor >= 0.50:
                        inv.append((cursor, total))
                    classified = [{
                        "start": a, "end": b,
                        "tc_start": self._timecode_frames(a, fps),
                        "tc_end": self._timecode_frames(b, fps),
                        "category": ("hdr_wcg" if (metadata.get("is_hlg") or metadata.get("is_pq")) else "wcg_only"),
                        "confidence": "極高" if metadata.get("is_hlg") or metadata.get("is_pq") else "高",
                        "evidence": "target_inverse",
                        "detail": (
                            "此區段呈現 HDR / BT.2020/WCG 內容特徵，不符合 BT.709 / SDR 目標"
                            if (metadata.get("is_hlg") or metadata.get("is_pq"))
                            else "此區段呈現 BT.2020 / WCG 色域內容特徵，不符合 BT.709 / SDR 目標"
                        ),
                        "target_spec": target_spec,
                    } for a, b in inv]
                else:
                    # No validated SDR-state complement exists.  Crucially, do NOT
                    # convert the file's HDR/BT.2020 tag into a whole-programme HDR
                    # picture finding.  Manual delivery verdicts must come from decoded
                    # picture evidence.  Programme-wide picture mismatch, when strong,
                    # is added later by _hdr_apply_delivery_consistency().
                    classified = [
                        dict(r) for r in (classified or [])
                        if r.get("category") not in (
                            "metadata_only_suspect", "picture_metadata_mismatch"
                        )
                    ]
        else:
            for _r in classified:
                _r["target_spec"] = target_spec
                # HLG-specific evidence must not leak into generic BT.2020 / PQ target reports.
                if target_spec != "BT.2020 / HLG":
                    _r.pop("hlg_reference", None)
                    _r.pop("hlg_nits_profile", None)
                    if target_spec != "BT.2020 / HLG":
                        _r.pop("reverse", None)

        # Layer 7 may add one whole-programme transform-state warning.  Never
        # delete or downgrade an existing temporal finding.  Avoid duplicate
        # programme-level metadata warnings by preferring the more explanatory
        # transform-state category when both point to the same Rec.709-like state.
        if _colour_state_run is not None:
            _same_family = {"metadata_only_suspect", "transform_sdr_mistag_hdr", "transform_hlg_to_709", "transform_pq_to_709", "transform_2020_to_709"}
            if _colour_state_run.get("category") in _same_family:
                classified = [r for r in classified if r.get("category") not in _same_family]
            classified.append(_colour_state_run)

        self._hdr_stage_progress(97, "整理檢測結果")
        _final_duration = self._hdr_effective_timeline_duration(
            duration, samples=samples, gamut_samples=gamut_samples, runs=classified
        )
        classified = self._hdr_merge_final_runs(classified, _final_duration, fps, gap=0.60)
        # Final user-visible duration gate.  The detector may keep shorter
        # transition/flash candidates internally, but they must not enter
        # GUI/TXT/Excel or content WARNING unless they persist long enough.
        classified = self._hdr_filter_short_content_runs(classified)
        result["runs"] = classified

        sdr_count = sum(
            1 for r in classified if r.get("category") == "sdr709"
        )
        double_count = sum(
            1 for r in classified if r.get("category") == "double_hdr"
        )
        unknown_count = sum(1 for r in classified if r.get("category") == "unknown")
        rec709_like_count = sum(1 for r in classified if r.get("category") == "rec709_like")
        hdr_wcg_count = sum(1 for r in classified if r.get("category") == "hdr_wcg")
        wcg_only_count = sum(1 for r in classified if r.get("category") == "wcg_only")
        hlg709_count = sum(1 for r in classified if r.get("category") == "transform_hlg_to_709")
        pq709_count = sum(1 for r in classified if r.get("category") == "transform_pq_to_709")
        bt2020_709_count = sum(1 for r in classified if r.get("category") == "transform_2020_to_709")
        sdr_mistag_count = sum(1 for r in classified if r.get("category") == "transform_sdr_mistag_hdr")
        wrong_transform_count = sum(1 for r in classified if r.get("category") == "transform_wrong")

        if classified:
            result["status"] = "WARNING"
            parts = []
            if sdr_count:
                parts.append("疑似 SDR / Rec.709 混入 %d 段" % sdr_count)
            if double_count:
                parts.append("疑似 HLG 重複 HDR 處理 %d 段" % double_count)
            if hdr_wcg_count:
                parts.append("疑似 HDR / BT.2020/WCG 內容混入 %d 段" % hdr_wcg_count)
            if wcg_only_count:
                parts.append("疑似 BT.2020 / WCG 色域內容混入 %d 段" % wcg_only_count)
            if rec709_like_count:
                parts.append("疑似 Rec.709 / SDR 色域內容 %d 段" % rec709_like_count)
            if hlg709_count:
                parts.append("疑似 HLG 畫面已轉為 Rec.709，但色彩標示未同步 %d 段" % hlg709_count)
            if pq709_count:
                parts.append("疑似 PQ/HDR 畫面已轉為 Rec.709，但色彩標示未同步 %d 段" % pq709_count)
            if bt2020_709_count:
                parts.append("疑似 BT.2020 畫面已轉為 Rec.709，但色彩標示未同步 %d 段" % bt2020_709_count)
            if sdr_mistag_count:
                parts.append("疑似 Rec.709 / SDR 畫面被錯標為 BT.2020 / HDR %d 段" % sdr_mistag_count)
            if wrong_transform_count:
                parts.append("疑似錯誤／不適當 LUT 或色彩轉換 %d 段" % wrong_transform_count)
            if unknown_count:
                parts.append(("SDR 內容一致性異常 %d 段" if result.get("target_spec") == "BT.709 / SDR" else "其他 HDR / 色域內容一致性異常 %d 段") % unknown_count)
            result["message"] = "；".join(parts)
        else:
            result["status"] = "PASS"
            if metadata.get("is_hlg"):
                result["message"] = (
                    "未發現疑似 SDR / Rec.709 混入、"
                    "HLG 重複 HDR 處理或其他明顯 HDR 內容異常。"
                )
            else:
                result["message"] = "未發現達到門檻的 BT.2020 / 色域內容一致性異常。"

        # content_profile was built before target mapping so the actual-content judgement
        # cannot change merely because the operator changed the delivery target.

        # Final cross-check for the specific professional-QC failure mode where an SDR/Rec.709
        # picture is merely re-tagged as BT.2020/HLG.  This is target/content based, never filename
        # or sample based, and it is conservative: it creates a review WARNING only when several
        # independent code-domain cues agree.
        _metadata_only_run = _source_metadata_only_run
        _fusion_mismatch_present = any(
            r.get("category") in ("transform_hlg_to_709", "transform_pq_to_709", "transform_2020_to_709", "transform_sdr_mistag_hdr")
            for r in (result.get("runs") or [])
        )
        if _metadata_only_run is not None:
            # Preserve the original metadata/content mismatch flag even when Layer 7
            # supplies a clearer user-facing transform explanation.
            result["metadata_content_mismatch"] = True
            if not _fusion_mismatch_present:
                # For HLG/PQ delivery comparison, expose the source/content mismatch as a
                # programme-level review range. For BT.709/SDR it is already the canonical
                # result above and must not be duplicated.
                if result.get("target_spec") != "BT.709 / SDR":
                    _metadata_only_run = dict(_metadata_only_run)
                    _metadata_only_run["target_spec"] = result.get("target_spec")
                    result["runs"] = self._hdr_merge_final_runs(
                        list(result.get("runs") or []) + [_metadata_only_run], _final_duration, fps, gap=0.60
                    )
                result["content_judgement"] = "疑似 Rec.709 / SDR 型實際內容；BT.2020 / HLG 標示缺乏獨立畫面證據"

        result = self._hdr_apply_delivery_consistency(result)
        self._hdr_stage_progress(100, "分析完成")
        return result


    def _hdr_category_title(self, category, target_spec=None):
        # Canonical category titles.  Unknown findings are intentionally kept
        # generic here; _hdr_run_title() below refines their user-facing wording
        # from the evidence already present on that exact run without changing
        # the detector's internal classification or repair/QC gates.
        if category == "sdr709":
            return "疑似 SDR / Rec.709 混入"
        if category == "hdr_wcg":
            if target_spec == "BT.709 / SDR":
                return "疑似 HLG / HDR 內容仍未正確轉換為 Rec.709 / SDR"
            return "疑似 HDR / BT.2020/WCG 內容混入"
        if category == "wcg_only":
            return "疑似 BT.2020 / WCG 色域內容混入"
        if category == "rec709_like":
            return "疑似 Rec.709 / SDR 色域內容"
        if category == "double_hdr":
            return "疑似 HLG 被重複 HDR 處理"
        if category == "metadata_only_suspect":
            if target_spec == "BT.709 / SDR":
                return "疑似影片仍是 Rec.709 / SDR，但 HDR / BT.2020 標示不一致"
            return "疑似影片仍是 Rec.709 / SDR，但被標示為 BT.2020 / HLG"
        if category == "picture_metadata_mismatch":
            return "HDR / BT.2020 標示與實際 Rec.709 / SDR 畫面不一致"
        if category == "picture_target_mismatch":
            return "實際畫面內容不符合所選目標規格"
        if category == "transform_hlg_to_709":
            return "疑似畫面已轉成 Rec.709，但仍保留 BT.2020 / HLG 標示"
        if category == "transform_pq_to_709":
            return "疑似畫面已轉成 Rec.709，但仍保留 BT.2020 / PQ 標示"
        if category == "transform_2020_to_709":
            return "疑似畫面已轉成 Rec.709，但仍保留 BT.2020 標示"
        if category == "transform_sdr_mistag_hdr":
            return "疑似 Rec.709 / SDR 畫面被錯標為 BT.2020 / HDR"
        if category == "transform_wrong":
            return "疑似使用錯誤或不適當的 LUT / 色彩轉換"
        if target_spec == "BT.709 / SDR":
            return "SDR 內容一致性異常"
        if target_spec == "BT.2020":
            return "BT.2020 色域內容一致性異常"
        return "HDR / 色域內容一致性異常"

    def _hdr_run_title(self, run, target_spec=None):
        """Return a precise user-facing title for one final HDR/gamut run.

        Internal categories remain unchanged.  In particular, an ``unknown``
        run must NOT be promoted to ``sdr709`` merely to obtain a nicer label.
        Instead we describe the evidence that actually passed: gamut narrowing,
        tone/saturation structure, gamut-edge evidence, or HLG-reference drift.
        This preserves the conservative QC gate while avoiding the old behaviour
        where every unresolved finding was displayed as the same 'HDR 內容異常'.
        """
        run = run or {}
        category = run.get("category", "unknown")
        if category == "picture_target_mismatch":
            actual = clean_text(run.get("actual_picture_spec", "")) or "實際畫面"
            if run.get("auto_mode"):
                declared = clean_text(run.get("declared_spec", "")) or clean_text(target_spec) or "原影片標示規格"
                return "疑似 %s 實際內容，與 %s 標示不一致" % (actual, declared)
            selected = clean_text(run.get("selected_target_spec", "")) or clean_text(target_spec) or "所選目標規格"
            return "疑似 %s 實際內容，與 %s 目標不一致" % (actual, selected)
        if category != "unknown":
            return self._hdr_category_title(category, target_spec)

        evidence = str(run.get("evidence") or "").strip().lower()
        edge = bool(run.get("edge_evidence"))
        ref = run.get("hlg_reference") or {}
        nits_ref = run.get("hlg_nits_profile") or {}
        ref_dir = ref.get("direction") if ref.get("valid") else None
        nits_dir = nits_ref.get("direction") if nits_ref.get("valid") else None

        if target_spec == "BT.2020 / HLG":
            # Gamut evidence is directional in this detector: the Layer-2 gamut
            # candidate is created only when BT.2020 occupancy outside Rec.709
            # drops materially relative to the programme baseline.  When HLG
            # reverse-validation is unavailable/insufficient, report the observed
            # Rec.709-like narrowing but do not call it a confirmed SDR insert.
            if evidence == "gamut":
                return "疑似 Rec.709 / SDR 型色域收窄"
            if evidence == "both":
                if ref_dir == "low" or nits_dir == "low":
                    return "疑似 SDR / Rec.709 型內容（需複核）"
                if ref_dir == "high" or nits_dir == "high":
                    return "疑似 HLG / HDR 過度處理或色彩轉換異常"
                if edge:
                    return "疑似 HDR / 色域內容不一致"
                return "疑似亮度／飽和度及色域內容不一致"
            if evidence == "luma":
                if ref_dir in ("low", "high") or nits_dir in ("low", "high"):
                    return "疑似 HLG 亮度結構異常"
                return "疑似 HDR 亮度／飽和度結構異常"
            if edge:
                return "疑似色域邊界分布異常"
            if ref_dir in ("low", "high") or nits_dir in ("low", "high"):
                return "疑似 HLG 參考亮度結構異常"
            return "HDR / 色域內容一致性異常"

        if target_spec == "BT.2020":
            if evidence in ("gamut", "both"):
                return "疑似 Rec.709 / SDR 型色域收窄"
            if evidence == "luma":
                return "疑似亮度／飽和度內容異常"
            if edge:
                return "疑似 BT.2020 色域邊界分布異常"
            return "BT.2020 色域內容一致性異常"

        if target_spec == "BT.709 / SDR":
            if evidence == "both":
                return "疑似 SDR 亮度／色域內容不一致"
            if evidence == "gamut" or edge:
                return "疑似 SDR 色域內容不一致"
            if evidence == "luma":
                return "疑似 SDR 亮度／飽和度結構異常"
            return "SDR 內容一致性異常"

        return self._hdr_category_title(category, target_spec)

    @staticmethod
    def _hdr_analysis_mode_text(metadata):
        metadata = metadata or {}
        if not metadata.get("is_2020"):
            return "未檢測到 BT.2020；已按 SDR / 色域內容一致性模式進行完整畫面分析。"
        if metadata.get("is_hlg"):
            return "檢測到 BT.2020 / HLG，已進行完整畫面分析。"
        if metadata.get("is_pq"):
            return "檢測到 BT.2020 / PQ，已進行完整畫面分析。"
        return "檢測到 BT.2020，已進行完整畫面分析。"

    def _hdr_run_evidence_lines(self, run):
        """Return the same human-readable evidence wording used by the HDR panel."""
        run = run or {}
        category = run.get("category", "unknown")
        evidence = run.get("evidence", "")
        rv = run.get("reverse") or {}
        target_spec = run.get("target_spec")
        lines = []

        if category == "hdr_wcg":
            lines.append("畫面呈現 HDR / BT.2020/WCG 內容特徵")
            lines.append("不符合 BT.709 / SDR 目標規格")

        elif category == "rec709_like":
            lines.append("廣色域佔用相對全片基準明顯收窄")
            lines.append("此區段呈現 Rec.709 / SDR 型色域分布")
            if run.get("edge_evidence"):
                lines.append("Rec.709 色域邊界分布亦提供支持")

        elif category == "sdr709":
            # SDR/Rec.709 states can come from classic luma/gamut evidence OR from
            # the newer target-independent timeline-state validator.  The latter
            # uses evidence names such as timeline_state / timeline_cluster, so
            # checking only both/gamut/luma can leave the UI with a blank
            # "判斷依據" section even though the range has already passed the
            # shared multi-evidence validator.  Build wording from the actual
            # state features as well, then use detail as a final safe fallback.
            sandwich = run.get("sandwich") or {}
            if sandwich.get("strong"):
                lines.append("前後 HLG 參考畫面互相一致，中間區段形成明顯 A-B-A 時間結構")
            elif run.get("bounded_by_other_state") or run.get("temporal_island"):
                lines.append("前後內容狀態較一致，而此區段形成持續的 SDR / Rec.709 型內容狀態")

            if evidence == "both":
                lines += ["亮度／飽和度與前後 HLG 明顯不同", "Rec.709 色域特徵明顯"]
            elif evidence == "gamut":
                lines.append("Rec.709 色域特徵明顯")
            elif evidence == "luma":
                lines.append("亮度／飽和度與前後 HLG 明顯不同")
            elif evidence in ("timeline_state", "timeline_cluster", "temporal_state"):
                if run.get("tone_separated"):
                    lines.append("亮度／轉換結構與相鄰參考畫面有持續差異")
                if run.get("gamut_narrower"):
                    lines.append("BT.2020/WCG 色域佔用相對鄰近內容明顯收窄")
                if run.get("saturation_support"):
                    lines.append("飽和度分布亦呈現較窄的 SDR / Rec.709 型特徵")
                if run.get("sdr_like_direction") and not (run.get("gamut_narrower") or run.get("tone_separated")):
                    lines.append("時間線多項內容特徵共同指向 SDR / Rec.709 型狀態")

            if run.get("edge_evidence"):
                lines.append("Rec.709 色域邊界出現異常堆積")
            ref = run.get("hlg_reference") or {}
            if ref.get("valid") and ref.get("direction") == "low":
                lines.append("HLG 參考亮度結構相對前後畫面明顯偏低")
            nits_ref = run.get("hlg_nits_profile") or {}
            if nits_ref.get("valid") and nits_ref.get("direction") == "low":
                lines.append("HLG 參考顯示亮度分布相對前後畫面明顯偏低")
            if rv.get("strong") or rv.get("moderate"):
                improvement = max(0.0, float(rv.get("improvement", 0.0)) * 100.0)
                feature_count = int(rv.get("feature_improved_count", 0))
                total_metrics = int(rv.get("available_metric_count", 3))
                support = self._hdr_reverse_support_profile(rv)
                lines.append(
                    "SDR → HLG 技術反向驗證提供支持（%d/%d 項特徵改善；亮度/色域獨立支持=%s；整體改善約 %.1f%%）"
                    % (feature_count, total_metrics, "是" if support.get("independent") else "否", improvement)
                )

            if not lines and run.get("detail"):
                lines.append(str(run.get("detail")))
            if not lines:
                lines.append("此區段已通過 SDR / Rec.709 時間線內容狀態的多證據一致性驗證")

        elif category == "wcg_only":
            lines.append("畫面呈現 BT.2020 / WCG 色域內容特徵")
            lines.append("不符合 BT.709 / SDR 目標規格")

        elif category == "picture_metadata_mismatch":
            actual_spec = clean_text(run.get("actual_picture_spec", "")) or "BT.709 / SDR"
            actual_conf = clean_text(run.get("actual_picture_confidence", "")) or "高"
            declared = clean_text(run.get("declared_spec", "")) or "HDR / BT.2020"
            lines.append("實際畫面：%s（可信度：%s）" % (actual_spec, actual_conf))
            lines.append("檔案標示：%s" % declared)
            lines.append("結論：實際畫面與檔案標示不一致")

        elif category == "picture_target_mismatch":
            actual_spec = clean_text(run.get("actual_picture_spec", "")) or "未知"
            actual_conf = clean_text(run.get("actual_picture_confidence", "")) or "高"
            selected_target = clean_text(run.get("selected_target_spec", "")) or clean_text(target_spec) or "所選目標"
            lines.append("實際畫面：%s（可信度：%s）" % (actual_spec, actual_conf))
            if run.get("auto_mode"):
                declared = clean_text(run.get("declared_spec", "")) or selected_target
                lines.append("檔案標示：%s" % declared)
                lines.append("結論：實際畫面與檔案標示不一致")
            else:
                lines.append("目標規格：%s" % selected_target)
                lines.append("結論：實際畫面不符合所選目標規格")

        elif category == "metadata_only_suspect":
            probe = run.get("matrix_probe") or {}
            lines.append("檔案宣告 BT.2020 / HLG，但原始 YCbCr 畫面的 BT.2020 與 BT.709 矩陣可辨識差異偏弱")
            lines.append("畫面曝光及色彩資訊足以分析，並非單純低光／低飽和導致證據不足")
            if probe.get("valid"):
                lines.append("BT.2020 矩陣沒有呈現足夠獨立優勢，符合『僅改 Metadata／未完成實際色彩轉換』的可疑型態")

        elif category in ("transform_hlg_to_709", "transform_pq_to_709", "transform_2020_to_709", "transform_sdr_mistag_hdr", "transform_wrong"):
            state = run.get("color_state") or {}
            fp = run.get("fingerprint") or {}
            if category == "transform_hlg_to_709":
                lines.append("畫面多項特徵更接近已轉換後的 Rec.709 / SDR，而檔案仍宣告 BT.2020 / HLG")
            elif category == "transform_pq_to_709":
                lines.append("畫面多項特徵更接近已轉換後的 Rec.709 / SDR，而檔案仍宣告 BT.2020 / PQ")
            elif category == "transform_2020_to_709":
                lines.append("畫面多項特徵更接近 Rec.709 型內容，而檔案仍宣告 BT.2020")
            elif category == "transform_sdr_mistag_hdr":
                lines.append("實際畫面較符合 Rec.709 / SDR；BT.2020 / HDR 標示缺乏足夠獨立畫面證據")
            else:
                lines.append("宣告色彩狀態與實際 tone / saturation / gamut 結構均無法合理吻合")
            lines.append("Rec.709 型色域收窄支持約 %.0f%%；SDR white / 高位訊號支持約 %.0f%%" % (
                float(state.get("narrow709_strength", 0.0)) * 100.0,
                float(state.get("sdr_white_strength", 0.0)) * 100.0,
            ))
            if category == "transform_hlg_to_709":
                lines.append("Tone+Chroma 轉換形態支持約 %.0f%%；SDR 峰值壓縮支持約 %.0f%%；HDR 高光餘量反證約 %.0f%%" % (
                    float(state.get("transform_expansion_strength", 0.0)) * 100.0,
                    float(state.get("sdr_ceiling_strength", 0.0)) * 100.0,
                    float(state.get("hdr_headroom_strength", 0.0)) * 100.0,
                ))
            lines.append("宣告色彩狀態吻合度約 %.0f%%；需至少兩類獨立證據同方向才作『疑似』判斷" % (float(state.get("declared_fit", 0.0)) * 100.0))

        elif category == "double_hdr":
            lines.append("高光／飽和度或色域分布異常偏高")
            if run.get("edge_evidence"):
                lines.append("色域邊界分布與前後正常 HLG 不一致")
            ref = run.get("hlg_reference") or {}
            if ref.get("valid") and ref.get("direction") == "high":
                lines.append("HLG 參考亮度結構相對前後畫面異常偏高")
            nits_ref = run.get("hlg_nits_profile") or {}
            if nits_ref.get("valid") and nits_ref.get("direction") == "high":
                lines.append("HLG 參考顯示亮度分布相對前後畫面異常偏高")
            if rv.get("strong"):
                improvement = max(0.0, float(rv.get("improvement", 0.0)) * 100.0)
                feature_count = int(rv.get("feature_improved_count", 0))
                total_metrics = int(rv.get("available_metric_count", 3))
                lines.append(
                    "撤回一次 HDR 映射後驗證通過（%d/%d 項畫面特徵更接近前後 HLG；整體匹配改善約 %.1f%%）"
                    % (feature_count, total_metrics, improvement)
                )
            lines.append("疑似原本已是 HLG，卻又被重複 HDR 處理")

        else:
            if evidence == "both":
                lines.append("亮度／飽和度與色域同時出現異常")
            elif evidence == "gamut":
                lines.append("色域分布出現明顯異常")
            elif evidence == "luma":
                lines.append("亮度／飽和度分布出現明顯異常")
            else:
                if target_spec == "BT.2020":
                    lines.append("色域內容分布與全片基準不一致")
                elif target_spec == "BT.709 / SDR":
                    lines.append("SDR 內容分布與目標規格不一致")
                else:
                    lines.append("HDR 內容分布與前後畫面不一致")
            if run.get("edge_evidence"):
                lines.append("色域邊界分布亦有異常")
            ref = run.get("hlg_reference") or {}
            if target_spec == "BT.2020 / HLG" and ref.get("valid") and ref.get("direction") in ("low", "high"):
                lines.append("HLG 參考亮度結構與前後畫面不一致")
            

        return lines


    def _hdr_write_result(self, result):
        box = self._hdr_result_text
        if box is None:
            return

        path = result["file"]
        md = result["metadata"]
        status = result["status"]
        runs = result.get("runs") or []

        # CTkTextbox 內層是 tkinter.Text；使用 tag 只改結果字色，
        # 不影響既有 UI 主題或其他功能。
        inner = getattr(box, "_textbox", None)
        try:
            if inner is not None:
                # 問題標題／一般警示維持橙色；最終 PASS/WARNING/FAIL 另用
                # 高對比狀態標籤，避免「檢測結果」與「問題」看起來同一層級。
                inner.tag_configure(
                    "hdr_warning",
                    foreground="#F2B84B",
                    font=("Consolas", 16, "bold"),
                )
                inner.tag_configure(
                    "hdr_pass",
                    foreground="#63C174",
                    font=("Consolas", 16, "bold"),
                )
                inner.tag_configure(
                    "hdr_status_pass",
                    foreground="#7CFF9B",
                    background="#143D24",
                    font=("Consolas", 17, "bold"),
                )
                inner.tag_configure(
                    "hdr_status_warning",
                    foreground="#FFE08A",
                    background="#554000",
                    font=("Consolas", 17, "bold"),
                )
                inner.tag_configure(
                    "hdr_status_fail",
                    foreground="#FFFFFF",
                    background="#9E1B32",
                    font=("Consolas", 17, "bold"),
                )
                inner.tag_configure(
                    "hdr_info",
                    foreground="#6EB6E8",
                    font=("Consolas", 16, "bold"),
                )
                inner.tag_configure(
                    "hdr_fail",
                    foreground="#FF5C5C",
                    font=("Consolas", 16, "bold"),
                )
                inner.tag_configure(
                    "hdr_error",
                    foreground="#E36A6A",
                    font=("Consolas", 16, "bold"),
                )
                inner.tag_configure(
                    "hdr_title",
                    foreground="#8CC8FF",
                    font=("Consolas", 15, "bold"),
                )
                inner.tag_configure(
                    "hdr_high",
                    foreground="#F2B84B",
                    font=("Consolas", 15, "bold"),
                )
                inner.tag_configure(
                    "hdr_conf_normal",
                    foreground="#B9C1CA",
                    font=("Consolas", 15, "bold"),
                )
                inner.tag_configure(
                    "hdr_conf_high",
                    foreground="#F2B84B",
                    font=("Consolas", 15, "bold"),
                )
                inner.tag_configure(
                    "hdr_conf_extreme",
                    foreground="#FFC45C",
                    font=("Consolas", 16, "bold"),
                )
        except Exception:
            inner = None

        def insert_line(value="", tag=None):
            try:
                box.configure(state="normal")
                if inner is not None and tag:
                    inner.insert("end", str(value) + "\n", tag)
                else:
                    box.insert("end", str(value) + "\n")
                box.see("end")
                box.configure(state="disabled")
            except Exception:
                pass

        insert_line("")
        insert_line("檔案：%s" % os.path.basename(path), "hdr_title")
        insert_line("HDR 標示：%s" % md["kind"])
        insert_line(
            "色彩資訊：%s / %s / Matrix %s"
            % (
                md["primaries"],
                md["transfer"],
                md["matrix"],
            )
        )
        display_target = result.get("requested_target_spec") or result.get("target_spec") or "自動判斷"
        if display_target == "自動判斷":
            insert_line("目標規格：自動判斷（依標示：%s）" % (result.get("target_spec") or "未能判定"))
        else:
            insert_line("目標規格：%s" % display_target)
        insert_line("實際內容判斷：%s" % (result.get("content_judgement") or "分析中／證據不足"))
        insert_line("規格一致性：%s" % status, "hdr_status_pass" if status == "PASS" else ("hdr_status_fail" if status == "FAIL" else ("hdr_status_warning" if status == "WARNING" else None)))
        if result.get("consistency_reasons"):
            for reason in result.get("consistency_reasons"):
                insert_line("  • %s" % reason)

        target_spec = result.get("target_spec") or "自動判斷"
        if display_target == "自動判斷":
            insert_line("分析模式：自動依原影片標示 %s 作檢測基準，再以實際畫面驗證內容一致性。" % target_spec)
        elif target_spec == "BT.709 / SDR":
            insert_line("分析模式：以 BT.709 / SDR 為目標，反向檢查 HDR / BT.2020/WCG 內容混入。")
        elif target_spec == "BT.2020":
            insert_line("分析模式：以 BT.2020 色域為目標，檢查 Metadata 與實際色域內容一致性；不使用 HLG/PQ 專屬判斷。")
        elif target_spec == "BT.2020 / HLG":
            insert_line("分析模式：以 BT.2020 / HLG 為目標，檢查色域、HLG 亮度結構及 SDR/Rec.709 混入。")
        elif target_spec == "BT.2020 / PQ":
            insert_line("分析模式：以 BT.2020 / PQ 為目標，檢查色域、PQ 規格及內容一致性。")
        else:
            insert_line("分析模式：自動判斷實際畫面內容；Metadata / Bitstream 僅作一致性對照。")

        cross = result.get("metadata_crosscheck") or {}
        # Metadata cross-check is supporting evidence, not a standalone visible
        # warning when the final delivery/content decision is PASS.  Some tools
        # expose equivalent colour signalling with different textual forms;
        # surfacing that as a yellow warning beside PASS confused users and was
        # a regression introduced by the VUI fallback work.  Keep the evidence
        # internally, and show it only when the final result already requires
        # user attention (WARNING/FAIL).
        if cross.get("has_conflict") and status in ("WARNING", "FAIL"):
            insert_line(
                "⚠ 檔案的 HDR 色彩標示互相矛盾，播放時可能出現偏色／過淡／過濃；Metadata 與視訊 Bitstream 顯示不同的色域或 HLG/PQ 狀態，請檢查來源／轉碼設定。",
                "hdr_warning",
            )

        insert_line("")

        if status in ("WARNING", "FAIL"):
            insert_line("檢測結果：%s" % status, "hdr_status_fail" if status == "FAIL" else "hdr_status_warning")
            insert_line("發現規格或 SDR / HDR / 色域內容一致性問題。")
            insert_line("")

            for i, run in enumerate(runs, 1):
                category = run.get("category", "unknown")
                evidence = run.get("evidence", "")
                rv = run.get("reverse") or {}

                title = self._hdr_run_title(run, result.get("target_spec"))

                confidence = run.get("confidence", "一般")

                insert_line("問題 %d：%s" % (i, title), "hdr_warning")
                insert_line(
                    "疑似區段：TC %s - %s"
                    % (
                        run.get("tc_start", ""),
                        run.get("tc_end", ""),
                    )
                )
                insert_line("")
                confidence_tag = {
                    "一般": "hdr_conf_normal",
                    "高": "hdr_conf_high",
                    "極高": "hdr_conf_extreme",
                }.get(confidence)

                insert_line(
                    "判斷可信度：%s" % confidence,
                    confidence_tag,
                )

                evidence_lines = self._hdr_run_evidence_lines(run)
                if not evidence_lines:
                    detail = str(run.get("detail") or "").strip()
                    evidence_lines = [detail] if detail else ["此問題已通過內容一致性檢測，但未取得可顯示的細分證據"]

                if category in ("picture_metadata_mismatch", "picture_target_mismatch"):
                    # 一致性問題要直接呈現「畫面 / 標示或目標 / 結論」，
                    # 不把 Metadata 放在「判斷依據」下，避免誤解為畫面分類證據。
                    for evidence_line in evidence_lines:
                        insert_line(evidence_line)
                else:
                    insert_line("判斷依據：")
                    for evidence_line in evidence_lines:
                        insert_line("  ✓ %s" % evidence_line)

                insert_line("")

            insert_line(
                "建議：請針對以上 TC 使用 Waveform / Vectorscope / HDR Monitor 複核。"
            )

        elif status == "PASS":
            insert_line("檢測結果：PASS", "hdr_status_pass")
            insert_line("未發現明顯 HDR 內容異常。")
            if md.get("is_hlg"):
                insert_line("✓ 未發現疑似 SDR / Rec.709 混入")
                insert_line("✓ 未發現疑似 HLG 被重複 HDR 處理")
                insert_line("✓ 未發現明顯亮度／色域異常")
            else:
                insert_line(result.get("message", ""))

        elif status == "ERROR":
            insert_line("檢測結果：ERROR", "hdr_error")
            insert_line(result.get("message", "分析失敗。"))
            insert_line("請檢查 FFmpeg / FFprobe 或影片格式後再試。")
        else:
            insert_line("檢測結果：INFO", "hdr_info")
            insert_line(result.get("message", ""))

        insert_line("-" * 86)


    def _hdr_progress_schedule_tick(self):
        """Animate the visible HDR progress toward the latest real target.

        The analysis code is still authoritative: this routine never advances
        beyond the most recently reported real progress.  Limiting each UI
        tick to at most 1 percentage point prevents visible 18% -> 38% style
        jumps when an FFmpeg stage reports progress in larger chunks.
        """
        if self._hdr_progress_timer is not None:
            return
        try:
            self._hdr_progress_timer = self.after(20, self._hdr_progress_tick)
        except Exception:
            self._hdr_progress_timer = None

    def _hdr_progress_tick(self):
        self._hdr_progress_timer = None
        try:
            target = max(0.0, min(1.0, float(self._hdr_progress_target)))
            shown = max(0.0, min(1.0, float(self._hdr_progress_display)))

            if target > shown:
                # Never skip more than one displayed percentage point per tick.
                shown = min(target, shown + 0.005)
            elif target < shown:
                # Progress is monotonic during one analysis run.  Ignore a stale
                # out-of-order callback instead of moving the bar backwards.
                target = shown
                self._hdr_progress_target = shown

            self._hdr_progress_display = shown

            if self._hdr_progress is not None:
                try:
                    self._hdr_progress.set(shown)
                except Exception:
                    pass

            if self._hdr_progress_label is not None:
                try:
                    if shown + 1e-9 >= target and self._hdr_progress_final_label:
                        text = self._hdr_progress_final_label
                    else:
                        text = "%s  %d%%" % (
                            self._hdr_progress_stage_text or "分析進度",
                            int(round(shown * 100.0)),
                        )
                    self._hdr_progress_label.configure(text=text)
                except Exception:
                    pass

            if shown + 1e-9 < target:
                self._hdr_progress_schedule_tick()
            elif shown >= 0.999999 and getattr(self, "_hdr_analysis_complete_pending", False):
                # Only reveal results after the visible progress has actually reached 100%.
                self._hdr_analysis_complete_pending = False
                pending = list(getattr(self, "_hdr_pending_results", []) or [])
                self._hdr_pending_results = []
                for result in pending:
                    self._hdr_write_result(result)
                if self._hdr_progress_label is not None:
                    try:
                        self._hdr_progress_label.configure(text="分析完成  100%")
                    except Exception:
                        pass
                self.status_var.set("HDR / 色域分析完成")
                if self._hdr_start_button is not None:
                    try:
                        self._hdr_start_button.configure(state="normal")
                    except Exception:
                        pass
                if self._hdr_stop_button is not None:
                    try:
                        self._hdr_stop_button.configure(text=self._icon_text("stop", "停止分析", "■"), state="disabled")
                    except Exception:
                        pass
        except Exception:
            pass

    def _hdr_set_progress_target(self, overall, label=None, final_label=None):
        """Set the real progress target without making the visible bar jump."""
        try:
            overall = max(0.0, min(1.0, float(overall)))
            # Ignore stale callbacks from an earlier stage/file.
            if overall > self._hdr_progress_target:
                self._hdr_progress_target = overall
            if label:
                self._hdr_progress_stage_text = str(label)
            if final_label is not None:
                self._hdr_progress_final_label = final_label
            self._hdr_progress_schedule_tick()
        except Exception:
            pass

    def _hdr_stage_progress(self, local_percent, stage_text=""):
        """Update the true HDR progress target; UI catches up smoothly."""
        try:
            index, total, filename = getattr(
                self,
                "_hdr_progress_context",
                (1, 1, ""),
            )
            total = max(1, int(total))
            index = max(1, int(index))
            local = max(0.0, min(100.0, float(local_percent))) / 100.0
            overall = ((index - 1) + local) / float(total)

            label = "正在分析"
            if stage_text:
                label += "：" + stage_text
            elif filename:
                label += "：" + filename

            self.after(0, lambda o=overall, l=label: self._hdr_set_progress_target(o, l))
        except Exception:
            pass

    def _hdr_update_progress(self, done, total, filename=""):
        total = max(1, int(total))
        pct = max(0.0, min(1.0, float(done) / float(total)))
        label = ("正在分析：" + filename) if filename else "分析進度"
        self._hdr_set_progress_target(pct, label)

    def start_hdr_gamut_analysis(self):
        if self.running:
            return
        if not self.selected_files:
            messagebox.showwarning("SDR / HDR / 色域檢測", "請先選擇影片。")
            return
        if not get_ffmpeg_path():
            messagebox.showerror("SDR / HDR / 色域檢測", "找不到 ffmpeg.exe。")
            return

        try:
            min_issue_seconds = float(self.hdr_min_issue_seconds.get())
            if not (0.10 <= min_issue_seconds <= 30.0):
                raise ValueError
        except Exception:
            messagebox.showerror(
                "SDR / HDR / 色域檢測",
                "最少內容異常長度必須介於 0.10–30.00 秒。"
            )
            return

        self.running = True
        self.stop_requested = False
        self._hdr_results = []
        self._hdr_pending_results = []
        self._hdr_analysis_complete_pending = False
        # Start every HDR run from a real 0% visible state.
        if self._hdr_progress_timer is not None:
            try:
                self.after_cancel(self._hdr_progress_timer)
            except Exception:
                pass
        self._hdr_progress_timer = None
        self._hdr_progress_target = 0.0
        self._hdr_progress_display = 0.0
        self._hdr_progress_stage_text = "正在分析"
        self._hdr_progress_final_label = None
        if self._hdr_progress is not None:
            try:
                self._hdr_progress.set(0.0)
            except Exception:
                pass
        if self._hdr_progress_label is not None:
            try:
                self._hdr_progress_label.configure(text="分析進度  0%")
            except Exception:
                pass

        if self._hdr_start_button is not None:
            self._hdr_start_button.configure(state="disabled")
        if self._hdr_stop_button is not None:
            self._hdr_stop_button.configure(state="normal")

        if self._hdr_result_text is not None:
            try:
                self._hdr_result_text.configure(state="normal")
                self._hdr_result_text.delete("1.0", "end")
                self._hdr_result_text.insert(
                    "end",
                    "SDR / HDR / 色域檢測開始。\n"
                    "正在分析 SDR / HDR 標示、亮度、色域、內容一致性及可疑區段。\n"
                    + "=" * 86 + "\n"
                )
                self._hdr_result_text.configure(state="disabled")
            except Exception:
                pass

        threading.Thread(
            target=self._run_hdr_gamut_analysis,
            daemon=True,
        ).start()

    def stop_hdr_gamut_analysis(self):
        if not self.running:
            return
        self.stop_requested = True
        self.status_var.set("正在停止 HDR / 色域分析…")

        self._request_stop_current_process()

        if self._hdr_stop_button is not None:
            try:
                self._hdr_stop_button.configure(text=self._icon_text("stop", "正在停止…", "■"), state="disabled")
            except Exception:
                pass

    def _run_hdr_gamut_analysis(self):
        files = list(self.selected_files)
        total = len(files)

        try:
            for index, path in enumerate(files, 1):
                if self.stop_requested:
                    break

                name = os.path.basename(path)
                self._hdr_progress_context = (index, total, name)
                self._hdr_stage_progress(0, "準備分析 " + name)

                try:
                    result = self._analyze_hdr_gamut_file(path)
                except Exception as exc:
                    result = {
                        "file": path,
                        "metadata": {
                            "kind": "分析失敗",
                            "primaries": "—",
                            "transfer": "—",
                            "matrix": "—",
                        },
                        "status": "ERROR",
                        "message": "分析失敗：%s" % exc,
                        "runs": [],
                        "samples": 0,
                    }

                self._hdr_results.append(result)
                self._hdr_pending_results.append(result)
                self.after(
                    0,
                    lambda i=index, n=name: self._hdr_update_progress(i, total, n)
                )
        finally:
            stopped = bool(self.stop_requested)
            self.running = False
            self.stop_requested = False

            def finish():
                if stopped:
                    if self._hdr_start_button is not None:
                        try:
                            self._hdr_start_button.configure(state="normal")
                        except Exception:
                            pass
                    if self._hdr_stop_button is not None:
                        try:
                            self._hdr_stop_button.configure(text=self._icon_text("stop", "停止分析", "■"), state="disabled")
                        except Exception:
                            pass
                    self._hdr_pending_results = []
                    self._hdr_progress_final_label = "分析已停止"
                    self._hdr_progress_schedule_tick()
                    self.status_var.set("HDR / 色域分析已停止")
                else:
                    # Analysis is complete, but do not show the result before the visible
                    # progress reaches 100%.  The tick routine flushes pending results.
                    self._hdr_analysis_complete_pending = True
                    self._hdr_set_progress_target(1.0, "分析進度", "分析完成  100%")
                    self.status_var.set("HDR / 色域分析完成，正在同步進度顯示…")

            self.after(0, finish)

    def open_hdr_gamut_check(self):
        """Open independent HDR / gamut content-consistency analysis."""
        if self.running:
            messagebox.showwarning(
                "SDR / HDR / 色域檢測",
                "目前正在進行其他工作，請先完成或停止目前工作。"
            )
            return

        if not self.selected_files:
            messagebox.showwarning(
                "SDR / HDR / 色域檢測",
                "請先選擇影片檔案或資料夾。"
            )
            return

        if self._hdr_win is not None:
            try:
                if self._hdr_win.winfo_exists():
                    self._hdr_win.lift()
                    self._hdr_win.focus_force()
                    return
            except Exception:
                self._hdr_win = None

        win = ctk.CTkToplevel(self)
        self._hdr_win = win
        win.title("SDR / HDR / 色域內容一致性檢測")
        win.geometry("920x780")
        win.minsize(850, 700)
        win.resizable(True, True)

        # 綁定主視窗的 Z-order，確保點下功能鍵後 HDR 視窗顯示在主程式上方。
        # 不使用 grab_set，因此仍可正常切換、縮小、還原及最大化。
        try:
            win.transient(self)
        except Exception:
            pass

        def close_hdr():
            if self.running:
                messagebox.showwarning(
                    "SDR / HDR / 色域檢測",
                    "分析進行中。請先按「停止分析」，再關閉視窗。"
                )
                return
            self._hdr_win = None
            self._hdr_progress = None
            self._hdr_progress_label = None
            self._hdr_result_text = None
            self._hdr_start_button = None
            self._hdr_stop_button = None
            self._hdr_txt_button = None
            self._hdr_excel_button = None
            try:
                win.destroy()
            except Exception:
                pass

        win.protocol("WM_DELETE_WINDOW", close_hdr)

        frame = ctk.CTkFrame(win)
        frame.pack(fill="both", expand=True, padx=18, pady=18)
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_rowconfigure(5, weight=1)

        ctk.CTkLabel(
            frame,
            text=self._icon_text("rainbow", "SDR / HDR / 色域內容一致性檢測", "🌈"),
            image=self._ui_icon("rainbow", (30, 30)),
            compound="left",
            font=ctk.CTkFont(size=24, weight="bold"),
            anchor="w",
        ).grid(row=0, column=0, padx=18, pady=(16, 4), sticky="ew")

        # 精簡頂部說明：避免與黃色說明框重複，把空間留給檢測結果區。
        notice = ctk.CTkFrame(frame)
        notice.grid(row=1, column=0, padx=18, pady=(4, 6), sticky="ew")
        notice.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            notice,
            text=(
                "檢測內容：目標規格 ↔ Metadata / Bitstream ↔ 實際畫面，分析 BT.709 / BT.2020 / HLG / PQ 內容一致性。\n"
                "結果：PASS / WARNING / FAIL、問題 TC、判斷可信度及主要證據。"
            ),
            justify="left",
            anchor="w",
            wraplength=800,
            text_color=("#c58a22", "#e8b04f"),
            font=ctk.CTkFont(size=13),
        ).grid(row=0, column=0, padx=14, pady=(12, 6), sticky="ew")

        confidence_guide = ctk.CTkFrame(
            notice,
            fg_color=("gray92", "gray18"),
            corner_radius=10,
        )
        confidence_guide.grid(
            row=1,
            column=0,
            padx=14,
            pady=(2, 10),
            sticky="ew",
        )
        confidence_guide.grid_columnconfigure(0, weight=1)
        confidence_guide.grid_columnconfigure(1, weight=1)
        confidence_guide.grid_columnconfigure(2, weight=1)

        ctk.CTkLabel(
            confidence_guide,
            text="判斷可信度",
            justify="left",
            anchor="w",
            text_color=("gray22", "gray84"),
            font=ctk.CTkFont(size=12, weight="bold"),
        ).grid(
            row=0,
            column=0,
            columnspan=3,
            padx=12,
            pady=(8, 4),
            sticky="w",
        )

        # 一般
        confidence_normal = ctk.CTkFrame(
            confidence_guide,
            fg_color=("gray96", "gray24"),
            border_width=1,
            border_color=("gray78", "gray34"),
            corner_radius=8,
        )
        confidence_normal.grid(
            row=1,
            column=0,
            padx=(10, 5),
            pady=(0, 10),
            sticky="nsew",
        )
        confidence_normal.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            confidence_normal,
            text="一般",
            text_color=("gray22", "gray88"),
            font=ctk.CTkFont(size=17, weight="bold"),
            width=58,
        ).grid(row=0, column=0, padx=(14, 10), pady=12, sticky="w")

        ctk.CTkLabel(
            confidence_normal,
            text="有可疑\n建議人工複核",
            justify="left",
            anchor="w",
            text_color=("gray35", "gray74"),
            font=ctk.CTkFont(size=12, weight="bold"),
        ).grid(row=0, column=1, padx=(0, 14), pady=12, sticky="w")

        # 高
        confidence_high = ctk.CTkFrame(
            confidence_guide,
            fg_color=("#fff8e8", "#30291c"),
            border_width=1,
            border_color=("#d9a441", "#8c6521"),
            corner_radius=8,
        )
        confidence_high.grid(
            row=1,
            column=1,
            padx=5,
            pady=(0, 10),
            sticky="nsew",
        )
        confidence_high.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            confidence_high,
            text="高",
            text_color=("#a76500", "#f0b24a"),
            font=ctk.CTkFont(size=17, weight="bold"),
            width=58,
        ).grid(row=0, column=0, padx=(14, 10), pady=12, sticky="w")

        ctk.CTkLabel(
            confidence_high,
            text="多項證據一致\n判定可信度較高",
            justify="left",
            anchor="w",
            text_color=("gray28", "gray78"),
            font=ctk.CTkFont(size=12, weight="bold"),
        ).grid(row=0, column=1, padx=(0, 14), pady=12, sticky="w")

        # 極高
        confidence_extreme = ctk.CTkFrame(
            confidence_guide,
            fg_color=("#fff3dd", "#352817"),
            border_width=2,
            border_color=("#e0a02f", "#b77a18"),
            corner_radius=8,
        )
        confidence_extreme.grid(
            row=1,
            column=2,
            padx=(5, 10),
            pady=(0, 10),
            sticky="nsew",
        )
        confidence_extreme.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            confidence_extreme,
            text="極高",
            text_color=("#9b5a00", "#ffc15b"),
            font=ctk.CTkFont(size=17, weight="bold"),
            width=58,
        ).grid(row=0, column=0, padx=(14, 10), pady=12, sticky="w")

        ctk.CTkLabel(
            confidence_extreme,
            text="多項證據一致\n且進一步驗證成立",
            justify="left",
            anchor="w",
            text_color=("gray24", "gray84"),
            font=ctk.CTkFont(size=12, weight="bold"),
        ).grid(row=0, column=1, padx=(0, 14), pady=12, sticky="w")

        target_frame = ctk.CTkFrame(frame, fg_color=("gray94", "gray20"), corner_radius=10)
        target_frame.grid(row=2, column=0, padx=18, pady=(8, 4), sticky="ew")
        target_frame.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(target_frame, text="目標規格：", font=ctk.CTkFont(size=14, weight="bold")).grid(row=0, column=0, padx=(14,8), pady=10, sticky="w")
        self._hdr_target_menu = ctk.CTkOptionMenu(
            target_frame, variable=self.hdr_target_spec,
            values=["自動判斷", "BT.709 / SDR", "BT.2020", "BT.2020 / HLG", "BT.2020 / PQ"],
            width=230,
        )
        self._hdr_target_menu.grid(row=0, column=1, padx=(0,14), pady=10, sticky="w")
        ctk.CTkLabel(target_frame, text="自動＝依原影片 Metadata / Bitstream 標示選擇檢測基準，再以實際畫面驗證；手動＝按交付規格判定 PASS / WARNING / FAIL", text_color=("gray40","gray70"), font=ctk.CTkFont(size=12)).grid(row=1,column=0,columnspan=2,padx=14,pady=(0,6),sticky="w")

        ctk.CTkLabel(
            target_frame,
            text="最少內容異常長度（秒）：",
            font=ctk.CTkFont(size=13, weight="bold"),
        ).grid(row=2, column=0, padx=(14, 8), pady=(4, 4), sticky="w")
        ctk.CTkEntry(
            target_frame,
            textvariable=self.hdr_min_issue_seconds,
            width=110,
            height=34,
        ).grid(row=2, column=1, padx=(0, 14), pady=(4, 4), sticky="w")
        ctk.CTkLabel(
            target_frame,
            text="建議 1.00；短於此時間的畫面內容異常只保留作內部證據，避免轉場／閃白／瞬時運動被誤報。Metadata 規格不受此限制。",
            text_color=("gray40", "gray70"),
            font=ctk.CTkFont(size=12),
            justify="left",
            anchor="w",
            wraplength=790,
        ).grid(row=3, column=0, columnspan=2, padx=14, pady=(0, 10), sticky="ew")

        self._hdr_progress_label = ctk.CTkLabel(
            frame,
            text="尚未開始",
            anchor="w",
            font=ctk.CTkFont(size=14, weight="bold"),
        )
        self._hdr_progress_label.grid(
            row=3, column=0, padx=18, pady=(12, 4), sticky="ew"
        )

        self._hdr_progress = ctk.CTkProgressBar(frame)
        self._hdr_progress.set(0)
        self._hdr_progress.grid(
            row=4, column=0, padx=18, pady=(4, 10), sticky="ew"
        )

        self._hdr_result_text = ctk.CTkTextbox(
            frame,
            font=ctk.CTkFont(family="Consolas", size=14),
            wrap="word",
        )
        self._hdr_result_text.grid(
            row=5, column=0, padx=18, pady=8, sticky="nsew"
        )
        self._hdr_result_text.insert(
            "1.0",
            "等待分析。\n\n"
            "會檢查：\n"
            "• HDR / 色域標示與實際畫面是否一致\n"
            "• 是否混入未正確轉換的 SDR / Rec.709\n"
            "• HLG 是否被重複套用 HDR / LUT\n"
            "• 亮度、色域及色域邊界是否出現異常\n"
            "• 可疑段與前後正常 HLG 是否匹配\n\n"
            "發現問題時會直接顯示 TC、可信度及原因。\n"
        )
        self._hdr_result_text.configure(state="disabled")

        button_bar = ctk.CTkFrame(frame, fg_color="transparent")
        button_bar.grid(
            row=6, column=0, padx=18, pady=(10, 16), sticky="ew"
        )
        for col in range(5):
            button_bar.grid_columnconfigure(col, weight=1)

        self._hdr_start_button = ctk.CTkButton(
            button_bar,
            text=self._icon_text("play", "開始檢測", "▶"),
            image=self._ui_icon("play", (22, 22)),
            compound="left",
            height=44,
            command=self.start_hdr_gamut_analysis,
        )
        self._hdr_start_button.grid(
            row=0, column=0, padx=(0, 4), sticky="ew"
        )

        self._hdr_stop_button = ctk.CTkButton(
            button_bar,
            text=self._icon_text("stop", "停止分析", "■"),
            image=self._ui_icon("stop", (22, 22)),
            compound="left",
            height=44,
            state="disabled",
            command=self.stop_hdr_gamut_analysis,
        )
        self._hdr_stop_button.grid(
            row=0, column=1, padx=4, sticky="ew"
        )

        self._hdr_txt_button = ctk.CTkButton(
            button_bar,
            text=self._icon_text("document", "TXT報告", "📄"),
            image=self._ui_icon("document", (22, 22)),
            compound="left",
            height=44,
            command=self.export_hdr_txt,
        )
        self._hdr_txt_button.grid(
            row=0, column=2, padx=4, sticky="ew"
        )

        self._hdr_excel_button = ctk.CTkButton(
            button_bar,
            text=self._icon_text("chart", "Excel報告", "📊"),
            image=self._ui_icon("chart", (22, 22)),
            compound="left",
            height=44,
            command=self.export_hdr_excel,
        )
        self._hdr_excel_button.grid(
            row=0, column=3, padx=4, sticky="ew"
        )

        ctk.CTkButton(
            button_bar,
            text=self._icon_text("close", "關閉", "✕"),
            image=self._ui_icon("close", (22, 22)),
            compound="left",
            height=44,
            command=close_hdr,
        ).grid(
            row=0, column=4, padx=(4, 0), sticky="ew"
        )

        def raise_hdr_window():
            try:
                win.deiconify()
                win.lift()
                win.attributes("-topmost", True)
                win.after(120, lambda: win.attributes("-topmost", False))
                win.focus_force()
            except Exception:
                pass

        # Windows 建立 Toplevel 後需要等視窗管理器完成 mapping；
        # 立即 lift 有時反而會被主視窗蓋回去，因此 idle 後再提升。
        try:
            win.after_idle(raise_hdr_window)
            win.after(180, raise_hdr_window)
        except Exception:
            raise_hdr_window()


    def _report_ready_or_message(self, results, title):
        if self.running:
            messagebox.showinfo(title, "目前仍在分析中，請等待分析完成後再輸出報告。")
            return False
        if not results:
            messagebox.showinfo(title, "目前沒有可輸出的分析結果。")
            return False
        return True

    def export_field_txt(self):
        items = list(self.repair_analysis_results or [])
        if not self._report_ready_or_message(items, "場序檢測報告"):
            return
        if not self._validate_field_repair_policy(show_message=True):
            return
        path = filedialog.asksaveasfilename(
            title="匯出場序檢測 TXT 報告",
            defaultextension=".txt",
            initialfile="Field_Order_Report.txt",
            filetypes=[("Text File", "*.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        lines = [
            "MediaField QC — 場序檢測報告",
            "版本：v%s" % APP_VERSION,
            "檢測時間：%s" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "=" * 78,
        ]
        for item in items:
            file_path = item.get("file", "")
            lines.append("")
            lines.append("檔案：%s" % os.path.basename(file_path))
            lines.append("完整路徑：%s" % file_path)
            if item.get("error"):
                lines.append("結果：ERROR")
                lines.append("原因：%s" % item.get("error"))
                continue

            a = self._effective_repair_analysis(item.get("analysis") or {})
            counts = a.get("counts") or {}
            target = normalize_repair_target(a.get("target", self.repair_target.get()))
            lines.append("目標場序：%s" % target)
            lines.append("來源場序：%s" % (a.get("source_field_order") or "未標示"))
            lines.append("FPS：%.6f" % float(a.get("fps") or 0.0))
            lines.append("分析時長：%s" % self._timecode(a.get("duration", 0)))
            lines.append(
                "TFF：%d | BFF：%d | Progressive(idet)：%d | 主畫面需複核 Undetermined：%d frames"
                % (
                    counts.get("Top Field First", 0),
                    counts.get("Bottom Field First", 0),
                    counts.get("Progressive", 0),
                    sum(
                        int(seg.get("end_frame", 0)) - int(seg.get("start_frame", 0))
                        for seg in (a.get("segments") or [])
                        if seg.get("detected") == "場序無法確定"
                    ),
                )
            )
            segments = a.get("segments") or []
            lines.append("場序區段：%d 段" % len(segments))
            for n, seg in enumerate(segments, 1):
                lines.append(
                    "區段 %d：%s → %s | TC %s - %s | 一致度 %.1f%% | %s"
                    % (
                        n,
                        self._field_user_detected_label(seg),
                        seg.get("target", ""),
                        self._timecode_frames(seg.get("start", 0), a.get("fps") or 25.0),
                        self._timecode_frames(seg.get("end", 0), a.get("fps") or 25.0),
                        float(seg.get("confidence") or 0.0) * 100.0,
                        "已選擇修復" if seg.get("needs_repair") else "保留／不修復",
                    )
                )
            hidden_u = [
                x for x in (a.get("undetermined_reference_segments") or [])
                if not bool(x.get("main_display"))
            ]
            if hidden_u:
                lines.append("技術參考（不列主畫面）：")
                for n, ref in enumerate(hidden_u, 1):
                    lines.append(
                        "  U-ref %d：TC %s - %s | %s"
                        % (
                            n,
                            self._timecode_frames(ref.get("start", 0), a.get("fps") or 25.0),
                            self._timecode_frames(ref.get("end", 0), a.get("fps") or 25.0),
                            ref.get("note", "短暫場序不確定，僅供技術參考"),
                        )
                    )
            lines.append("-" * 78)
        try:
            with open(path, "w", encoding="utf-8-sig") as handle:
                handle.write("\n".join(lines))
            self.status_var.set("場序 TXT 報告已輸出")
        except Exception as exc:
            messagebox.showerror("輸出失敗", "場序 TXT 報告輸出失敗：\n\n%s" % exc)

    def _field_is_hidden_undetermined_segment(self, analysis, segment):
        """Return True when a short raw Undetermined run is technical-reference only.

        This is presentation policy only.  It never rewrites TFF/BFF/Progressive
        classification and never adds an Undetermined range to the repair list.
        """
        analysis = analysis or {}
        segment = segment or {}
        detected = str(segment.get("detected", "") or "")
        if detected not in ("場序無法確定", "Undetermined"):
            return False
        try:
            a = float(segment.get("start", 0.0) or 0.0)
            b = float(segment.get("end", a) or a)
        except Exception:
            return False
        for ref in analysis.get("undetermined_reference_segments") or []:
            if bool(ref.get("main_display")):
                continue
            try:
                ra = float(ref.get("start", 0.0) or 0.0)
                rb = float(ref.get("end", ra) or ra)
            except Exception:
                continue
            if min(b, rb) - max(a, ra) > 0.0005:
                return True
        return False

    def _field_user_detected_label(self, segment):
        """Return a direct user-facing field-order label.

        Keep the internal Progressive-like state for safety logic, but do not expose
        that implementation term in GUI/TXT/Excel.  Users see the observed field
        pattern as Progressive; repair eligibility is still decided independently by
        the Motion / Field-Temporal confirmation layer.
        """
        segment = segment or {}
        detected = str(segment.get("detected", "") or "")
        if detected == "Progressive-like（未確認）":
            return "Progressive"
        if detected in ("場序無法確定", "Undetermined"):
            if str(segment.get("undetermined_context", "")) == "short_review":
                return "短暫場序不確定（可能轉場／效果）"
            return "場序無法確定"
        return detected

    def _field_results_for_excel(self):
        """Excel presentation of the same detection facts + current repair policy."""
        output = []
        for item in self.repair_analysis_results or []:
            file_path = item.get("file", "")
            if item.get("error"):
                output.append({
                    "file": file_path,
                    "pass": False,
                    "result": "ERROR",
                    "summary_issue": "場序分析失敗",
                    "summary_action": "請檢查來源檔案或 FFmpeg 設定後重新分析",
                    "checks": [{
                        "name": "分析",
                        "actual": item.get("error"),
                        "expected": "成功完成",
                        "pass": False,
                        "result": "ERROR",
                        "user_relevant": True,
                    }],
                })
                continue

            a = self._effective_repair_analysis(item.get("analysis") or {})
            counts = a.get("counts") or {}
            anomalies = a.get("anomalies") or []
            target = normalize_repair_target(a.get("target", self.repair_target.get()))
            segments = a.get("segments") or []

            checks = [
                {"name": "目標場序", "actual": target, "expected": target, "pass": True, "source_field": ""},
                {"name": "來源場序", "actual": a.get("source_field_order", "") or "未標示", "expected": "資訊", "pass": True, "source_field": "", "result": "INFO"},
                {"name": "FPS", "actual": "%.6f" % float(a.get("fps") or 0.0), "expected": "分析值", "pass": True, "source_field": "", "result": "INFO"},
                {"name": "TFF frames", "actual": str(counts.get("Top Field First", 0)), "expected": "統計", "pass": True, "source_field": "TFF", "result": "INFO"},
                {"name": "BFF frames", "actual": str(counts.get("Bottom Field First", 0)), "expected": "統計", "pass": True, "source_field": "BFF", "result": "INFO"},
                {"name": "Progressive frames", "actual": str(counts.get("Progressive", 0)), "expected": "統計", "pass": True, "source_field": "P", "result": "INFO"},
            ]

            source_codes = {
                "Top Field First": "TFF",
                "Bottom Field First": "BFF",
                "Progressive": "P",
                "Progressive-like（未確認）": "P",
                "場序無法確定": "場序無法確定",
                "Undetermined": "場序無法確定",
            }

            info_segments = []
            preserved_off_target = []
            for n, seg in enumerate(segments, 1):
                detected_label = str(seg.get("detected", "") or "")
                detected = normalize_field_order(detected_label)
                detected_display = self._field_user_detected_label(seg)
                actual = "%s | %s - %s | 一致度 %.1f%%" % (
                    detected_display,
                    self._timecode_frames(seg.get("start", 0), a.get("fps") or 25.0),
                    self._timecode_frames(seg.get("end", 0), a.get("fps") or 25.0),
                    float(seg.get("confidence") or 0.0) * 100.0,
                )

                info_only = detected_label in (
                    "場序無法確定", "Undetermined", "Progressive-like（未確認）"
                )
                is_target = detected == target
                selected_for_repair = bool(seg.get("needs_repair"))

                if info_only:
                    result_code = "INFO"
                    ok = True
                    if detected_label in ("場序無法確定", "Undetermined") and self._field_is_hidden_undetermined_segment(a, seg):
                        user_relevant = False
                        issue_title = "短暫場序不確定（疑似轉場／效果；技術參考）"
                        relation = "技術參考／不修復"
                    else:
                        user_relevant = True
                        issue_title = "檢測到 %s 區段，建議人工複核" % detected_display
                        relation = "人工複核"
                        info_segments.append(seg)
                elif not is_target and detected in ("Top Field First", "Bottom Field First", "Progressive"):
                    # Excel 是檢測報告，不讓目前的修復 checkbox / 百分比改寫檢測結論。
                    result_code = "INFO"
                    ok = True
                    user_relevant = True
                    issue_title = "檢測到 %s 區段，與目標場序不同" % detected_display
                    relation = "與目標不同"
                    preserved_off_target.append(seg)
                else:
                    result_code = "PASS"
                    ok = True
                    user_relevant = False
                    issue_title = "場序符合目標"
                    relation = "符合目標"

                _tc_in = self._timecode_frames(seg.get("start", 0), a.get("fps") or 25.0)
                _tc_out = self._timecode_frames(seg.get("end", 0), a.get("fps") or 25.0)
                _percent = round(float(seg.get("confidence") or 0.0) * 100.0, 3)
                checks.append({
                    "name": "場序區段 %d" % n,
                    "actual": actual,
                    "expected": seg.get("target", ""),
                    "pass": ok,
                    "result": result_code,
                    "source_field": source_codes.get(detected_label, detected_label),
                    "user_relevant": user_relevant,
                    "issue_title": issue_title,
                    "field_segment": True,
                    "field_detected": detected_display,
                    "field_target": target,
                    "field_tc_in": _tc_in,
                    "field_tc_out": _tc_out,
                    "field_confidence_percent": _percent,
                    "field_relation": relation,
                    "field_selected_for_repair": selected_for_repair,
                })

            # 短暫、前後場序一致的 Undetermined 不污染主摘要，但保留於
            # Excel 技術明細／場序區段工作表，讓使用者仍可追溯轉場/effect 證據。
            for ref_idx, ref in enumerate(a.get("undetermined_reference_segments") or [], 1):
                if bool(ref.get("main_display")):
                    continue
                try:
                    _ra = float(ref.get("start", 0.0) or 0.0)
                    _rb = float(ref.get("end", _ra) or _ra)
                except Exception:
                    _ra = _rb = 0.0
                _already_emitted = False
                for _seg in segments:
                    if str(_seg.get("detected", "") or "") not in ("場序無法確定", "Undetermined"):
                        continue
                    try:
                        _sa = float(_seg.get("start", 0.0) or 0.0)
                        _sb = float(_seg.get("end", _sa) or _sa)
                    except Exception:
                        continue
                    if min(_rb, _sb) - max(_ra, _sa) > 0.0005:
                        _already_emitted = True
                        break
                if _already_emitted:
                    continue
                _tc_in = self._timecode_frames(ref.get("start", 0), a.get("fps") or 25.0)
                _tc_out = self._timecode_frames(ref.get("end", 0), a.get("fps") or 25.0)
                checks.append({
                    "name": "短暫 Undetermined 參考 %d" % ref_idx,
                    "actual": "%s - %s | %s" % (_tc_in, _tc_out, ref.get("note", "短暫場序不確定")),
                    "expected": "技術參考，不列主畫面、不自動修復",
                    "pass": True,
                    "result": "INFO",
                    "source_field": "U-ref",
                    "user_relevant": False,
                    "issue_title": "短暫場序不確定（疑似轉場／效果）",
                    "field_segment": True,
                    "field_detected": "短暫場序不確定（技術參考）",
                    "field_target": target,
                    "field_tc_in": _tc_in,
                    "field_tc_out": _tc_out,
                    "field_confidence_percent": 0.0,
                    "field_relation": "技術參考／不修復",
                    "field_selected_for_repair": False,
                })

            # 檔案級摘要只描述「檢測到甚麼」，不以目前修復設定當成最終結果。
            confirmed_off_target = [seg for seg in segments
                                    if normalize_field_order(seg.get("detected", "")) in ("Top Field First", "Bottom Field First", "Progressive")
                                    and normalize_field_order(seg.get("detected", "")) != target
                                    and str(seg.get("detected", "")) != "Progressive-like（未確認）"]
            review_segments = [
                seg for seg in segments
                if (
                    str(seg.get("detected", "")) == "Progressive-like（未確認）"
                    or (
                        str(seg.get("detected", "")) in ("場序無法確定", "Undetermined")
                        and not self._field_is_hidden_undetermined_segment(a, seg)
                    )
                )
            ]
            if confirmed_off_target:
                max_ratio = max(float(seg.get("confidence") or 0.0) * 100.0 for seg in confirmed_off_target)
                summary_issue = "檢測到 %d 個與目標場序不同的區段；最高一致度 %.1f%%。請到『場序區段』工作表按一致度篩選。" % (len(confirmed_off_target), max_ratio)
                overall_result = "INFO"
            elif review_segments:
                max_ratio = max(float(seg.get("confidence") or 0.0) * 100.0 for seg in review_segments)
                summary_issue = "檢測到 %d 個需人工複核區段；最高一致度 %.1f%%。" % (len(review_segments), max_ratio)
                overall_result = "INFO"
            else:
                summary_issue = "場序一致，未發現與目標場序不同的已確認區段"
                overall_result = "PASS"

            output.append({
                "file": file_path,
                "pass": overall_result == "PASS",
                "result": overall_result,
                "summary_issue": summary_issue,
                "summary_confidence": "—",
                "summary_action": "",
                "checks": checks,
            })
        return output

    def export_field_excel(self):
        items = list(self.repair_analysis_results or [])
        if not self._report_ready_or_message(items, "場序檢測報告"):
            return
        path = filedialog.asksaveasfilename(
            title="匯出場序檢測 Excel 報告",
            defaultextension=".xlsx",
            initialfile="Field_Order_Report.xlsx",
            filetypes=[("Excel Workbook", "*.xlsx"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            _write_xlsx_report(path, self._field_results_for_excel(), APP_VERSION)
            self.status_var.set("場序 Excel 報告已輸出（可按一致度 % 直接篩選）")
        except Exception as exc:
            messagebox.showerror("輸出失敗", "場序 Excel 報告輸出失敗：\n\n%s" % exc)

    def export_hdr_txt(self):
        items = list(self._hdr_results or [])
        if not self._report_ready_or_message(items, "SDR / HDR / 色域內容一致性報告"):
            return
        path = filedialog.asksaveasfilename(
            title="匯出 SDR / HDR / 色域內容一致性 TXT 報告",
            defaultextension=".txt",
            initialfile="SDR_HDR_Gamut_Consistency_Report.txt",
            filetypes=[("Text File", "*.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        lines = [
            "MediaField QC — SDR / HDR / 色域內容一致性檢測報告",
            "版本：v%s" % APP_VERSION,
            "檢測時間：%s" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "=" * 86,
        ]
        for r in items:
            md = r.get("metadata") or {}
            lines.extend([
                "",
                "檔案：%s" % os.path.basename(r.get("file", "")),
                "完整路徑：%s" % r.get("file", ""),
                "目標規格：%s" % (("自動判斷（依標示：%s）" % (r.get("target_spec") or "未能判定")) if (r.get("requested_target_spec") or "自動判斷") == "自動判斷" else (r.get("requested_target_spec") or r.get("target_spec", "自動判斷"))),
                "HDR / SDR 標示：%s" % md.get("kind", ""),
                "實際內容判斷：%s" % r.get("content_judgement", "證據不足"),
                "色彩資訊：%s / %s / Matrix %s" % (md.get("primaries", ""), md.get("transfer", ""), md.get("matrix", "")),
                (("分析模式：自動依原影片標示 %s 作檢測基準，再以實際畫面驗證內容一致性。" % (r.get("target_spec") or "未能判定"))
                 if (r.get("requested_target_spec") or "自動判斷") == "自動判斷"
                 else "分析模式：目標 %s；%s" % (r.get("requested_target_spec") or r.get("target_spec", "自動判斷"), self._hdr_analysis_mode_text(md))),
                "",
                "檢測結果：%s" % r.get("status", ""),
                r.get("message", ""),
            ])
            runs = r.get("runs") or []
            if not runs:
                lines.append("可疑區段：無")
            else:
                lines.append("")
                for n, run in enumerate(runs, 1):
                    lines.append("問題 %d：%s" % (n, self._hdr_run_title(run, r.get("target_spec"))))
                    lines.append("疑似區段：TC %s - %s" % (run.get("tc_start", ""), run.get("tc_end", "")))
                    lines.append("判斷可信度：%s" % run.get("confidence", "一般"))
                    _evidence_lines = self._hdr_run_evidence_lines(run)
                    if run.get("category") in ("picture_metadata_mismatch", "picture_target_mismatch"):
                        for evidence_line in _evidence_lines:
                            lines.append(evidence_line)
                    else:
                        lines.append("判斷依據：")
                        for evidence_line in _evidence_lines:
                            lines.append("  ✓ %s" % evidence_line)
                    lines.append("")
                lines.append("建議：請針對以上 TC 使用 Waveform / Vectorscope / HDR Monitor 複核。")
            lines.append("-" * 86)
        try:
            with open(path, "w", encoding="utf-8-sig") as handle:
                handle.write("\n".join(lines))
            self.status_var.set("SDR / HDR / 色域內容一致性 TXT 報告已輸出")
        except Exception as exc:
            messagebox.showerror("輸出失敗", "HDR / 色域 TXT 報告輸出失敗：\n\n%s" % exc)

    def _hdr_results_for_excel(self):
        """Excel rows are a pure presentation of the same final result object."""
        output = []
        for r in self._hdr_results or []:
            md = r.get("metadata") or {}
            status = r.get("status", "INFO")
            target = r.get("requested_target_spec") or r.get("target_spec", "自動判斷")
            analysis_target = r.get("target_spec", "自動判斷")
            base = {"target_spec": target, "confidence": "—"}
            checks = []

            # Target is user input, not a PASS/FAIL test by itself.
            checks.append(dict(base, name="目標規格", actual=target,
                               expected="用戶指定檢測基準", pass_=True, result="INFO"))

            # Split primaries and transfer so a pure BT.2020 gamut target is not
            # misleadingly shown as a complete HLG/PQ PASS.
            prim = md.get("primaries", "") or "未標示"
            tr = md.get("transfer", "") or "未標示"
            if target == "BT.2020":
                prim_ok = bool(md.get("is_2020"))
                checks.append(dict(base, name="Color Primaries / 色域標示", actual=prim,
                                   expected="BT.2020", pass_=prim_ok,
                                   result="PASS" if prim_ok else "FAIL"))
                checks.append(dict(base, name="Transfer Characteristics", actual=tr,
                                   expected="BT.2020 色域目標不限制 HLG / PQ Transfer",
                                   pass_=True, result="INFO"))
            elif target == "BT.2020 / HLG":
                ok = bool(md.get("is_2020") and md.get("is_hlg"))
                checks.append(dict(base, name="檔案標示", actual=md.get("kind", ""),
                                   expected="BT.2020 / HLG", pass_=ok,
                                   result="PASS" if ok else "FAIL"))
            elif target == "BT.2020 / PQ":
                ok = bool(md.get("is_2020") and md.get("is_pq"))
                checks.append(dict(base, name="檔案標示", actual=md.get("kind", ""),
                                   expected="BT.2020 / PQ", pass_=ok,
                                   result="PASS" if ok else "FAIL"))
            elif target == "BT.709 / SDR":
                ok = bool(md.get("is_709") and not md.get("is_hlg") and not md.get("is_pq"))
                checks.append(dict(base, name="檔案標示", actual=md.get("kind", ""),
                                   expected="BT.709 / SDR", pass_=ok,
                                   result="PASS" if ok else "FAIL"))
            else:
                _actual_spec = clean_text(r.get("actual_picture_spec", ""))
                _auto_known = _actual_spec in ("BT.709 / SDR", "BT.2020", "BT.2020 / HLG", "BT.2020 / PQ")
                _auto_match = self._hdr_metadata_matches_target(md, _actual_spec) if _auto_known else True
                checks.append(dict(base, name="檔案標示", actual=md.get("kind", ""),
                                   expected=("應與實際畫面判斷 %s 一致" % _actual_spec) if _auto_known else "與實際畫面內容一致",
                                   pass_=_auto_match, result=("PASS" if _auto_match else "FAIL") if _auto_known else "INFO"))

            checks.append(dict(base, name="色彩資訊",
                               actual="%s / %s / Matrix %s" % (prim, tr, md.get("matrix", "")),
                               expected=("Primaries / Transfer / Matrix 應與目標及內容一致"),
                               pass_=status == "PASS", result=("PASS" if status == "PASS" else status)))
            checks.append(dict(base, name="實際內容判斷",
                               actual=r.get("content_judgement", "證據不足"),
                               expected=("由實際畫面獨立判斷；Metadata / Bitstream 僅作一致性對照" if target == "自動判斷" else "實際畫面內容分類應獨立於目標選擇，並與 %s 交付要求相容" % target),
                               pass_=status == "PASS", result=("PASS" if status == "PASS" else status)))
            checks.append(dict(base, name="規格一致性", actual=status,
                               expected="PASS", pass_=status == "PASS", result=status))
            checks.append(dict(base, name="結果摘要", actual=r.get("message", ""),
                               expected=("檔案標示與實際畫面內容一致" if target == "自動判斷" else "目標規格、檔案標示與實際畫面內容一致"),
                               pass_=status == "PASS", result=("PASS" if status == "PASS" else status)))

            for c in checks:
                c["pass"] = bool(c.pop("pass_"))
                c.setdefault("result", "PASS" if c["pass"] else (status if status in ("WARNING","FAIL","ERROR") else "INFO"))

            for n, run in enumerate(r.get("runs") or [], 1):
                title = self._hdr_run_title(run, target)
                evidence = "；".join(self._hdr_run_evidence_lines(run))
                checks.append({
                    "name": "問題 %d：%s" % (n, title),
                    "target_spec": target,
                    "actual": "TC %s - %s｜%s" % (run.get("tc_start", ""), run.get("tc_end", ""), evidence),
                    "expected": ("該 TC 應符合 %s 目標，不應出現上述內容偏差" % target),
                    "confidence": run.get("confidence", "一般"),
                    "pass": False,
                    "result": "WARNING" if status != "FAIL" else "FAIL",
                })
            runs = r.get("runs") or []
            if status == "PASS":
                summary_issue = "未發現明顯色彩／HDR 內容一致性問題"
                summary_confidence = "—"
                summary_action = ""
            elif runs:
                # 與場序報告一致：摘要直接列出所有可疑區段，避免只顯示第一個。
                lines = ["共 %d 個需複核問題區段：" % len(runs)]
                conf_levels = []
                for idx, run in enumerate(runs, 1):
                    title = self._hdr_run_title(run, target)
                    tc1 = run.get("tc_start", "")
                    tc2 = run.get("tc_end", "")
                    conf = run.get("confidence", "一般")
                    conf_levels.append(conf)
                    lines.append("%d. TC %s - %s｜%s｜可信度 %s" % (idx, tc1, tc2, title, conf))
                summary_issue = "\n".join(lines)
                # 摘要可信度只顯示最高級別；每個區段自己的可信度已逐項列在問題文字。
                rank = {"一般": 1, "高": 2, "極高": 3}
                summary_confidence = max(conf_levels, key=lambda x: rank.get(str(x), 0)) if conf_levels else "—"
                summary_action = ""
            else:
                summary_issue = r.get("message", "") or "檔案標示與實際內容疑似不一致"
                summary_confidence = "—"
                summary_action = ""
            output.append({
                "file": r.get("file", ""),
                "pass": status == "PASS",
                "result": status,
                "summary_issue": summary_issue,
                "summary_confidence": summary_confidence,
                "summary_action": summary_action,
                "checks": checks,
            })
        return output

    def export_hdr_excel(self):
        items = list(self._hdr_results or [])
        if not self._report_ready_or_message(items, "SDR / HDR / 色域內容一致性報告"):
            return
        path = filedialog.asksaveasfilename(
            title="匯出 SDR / HDR / 色域內容一致性 Excel 報告",
            defaultextension=".xlsx",
            initialfile="SDR_HDR_Gamut_Consistency_Report.xlsx",
            filetypes=[("Excel Workbook", "*.xlsx"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            _write_xlsx_report(path, self._hdr_results_for_excel(), APP_VERSION)
            self.status_var.set("SDR / HDR / 色域內容一致性 Excel 報告已輸出")
        except Exception as exc:
            messagebox.showerror("輸出失敗", "HDR / 色域 Excel 報告輸出失敗：\n\n%s" % exc)


    def open_field_repair(self):
        if self.running:
            messagebox.showwarning("場序檢測", "目前正在檢測，請先完成或停止目前工作。")
            return
        if not self.selected_files:
            messagebox.showwarning("場序檢測", "請先選擇影片檔案或資料夾。")
            return
        ffmpeg_path = get_ffmpeg_path()
        if not ffmpeg_path:
            messagebox.showerror(
                "FFmpeg",
                "找不到 ffmpeg.exe。\n\n請將 ffmpeg.exe 放在 EXE 同目錄或 _internal 資料夾。",
            )
            return

        try:
            startupinfo = None
            if os.name == "nt":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            exe_dir = os.path.dirname(os.path.abspath(ffmpeg_path))
            env = os.environ.copy()
            env["PATH"] = exe_dir + os.pathsep + env.get("PATH", "")
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            test = subprocess.run(
                [ffmpeg_path, "-hide_banner", "-version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                startupinfo=startupinfo,
                creationflags=creationflags,
                env=env,
                universal_newlines=True,
                encoding="utf-8",
                errors="replace",
                timeout=15,
            )
            if test.returncode != 0:
                detail = (test.stderr or test.stdout or "").strip()
                raise RuntimeError("exit code=%s\n%s" % (test.returncode, detail or "沒有額外錯誤訊息"))
        except Exception as exc:
            messagebox.showerror(
                "FFmpeg 無法啟動",
                "已找到 ffmpeg.exe，但 FFmpeg 本身無法正常啟動。\n\n%s" % exc,
            )
            return

        win = ctk.CTkToplevel(self)
        win.title("場序檢測與重構")
        # 一打開即使用舊版限制上限 1000x700；之後可自由拉伸／最大化。
        win.geometry("1000x700")
        win.minsize(820, 560)
        win.resizable(True, True)
        win.transient(self)

        frame = ctk.CTkFrame(win)
        frame.pack(fill="both", expand=True, padx=18, pady=18)
        frame.grid_columnconfigure(0, weight=1)
        # 進度資訊保持自然高度，最後按鈕固定完整顯示。
        frame.grid_rowconfigure(7, weight=0)

        # 三欄固定版面：
        # 左：欄位名稱；中：輸入/選擇框（全部同寬）；右：建議說明。
        # 避免右側文字貼窗邊，也避免 ComboBox 與 Entry 長短不一。
        frame.grid_columnconfigure(0, minsize=235, weight=0)
        frame.grid_columnconfigure(1, weight=1, uniform="field_input")
        frame.grid_columnconfigure(2, minsize=115, weight=0)

        ctk.CTkLabel(
            frame,
            text=self._icon_text("film", "場序檢測與重構", "🎞"),
            image=self._ui_icon("film", (28, 28)),
            compound="left",
            font=ctk.CTkFont(size=24, weight="bold"),
        ).grid(
            row=0, column=0, columnspan=3, padx=18, pady=(18, 4), sticky="w"
        )
        ctk.CTkLabel(
            frame,
            text="第一階段只分析，不會輸出或修改影片；確認分析結果後，再由你決定是否開始修復。",
            text_color=("gray50", "gray70"), font=ctk.CTkFont(size=13)
        ).grid(row=1, column=0, columnspan=3, padx=18, pady=(0, 14), sticky="w")

        ctk.CTkLabel(frame, text="目標場次 / 掃描方式", font=ctk.CTkFont(size=15, weight="bold")).grid(
            row=2, column=0, padx=18, pady=8, sticky="w"
        )
        ScrollableCTkComboBox(
            frame,
            values=["Top Field First", "Bottom Field First", "Progressive"],
            variable=self.repair_target, state="readonly", height=40,
            font=ctk.CTkFont(size=15)
        ).grid(row=2, column=1, padx=(18, 12), pady=8, sticky="ew")
        ctk.CTkLabel(
            frame,
            text="輸出目標",
            text_color=("gray50", "gray70"),
            anchor="w",
        ).grid(row=2, column=2, padx=(4, 18), pady=8, sticky="w")

        ctk.CTkLabel(frame, text="最少異常長度（秒）").grid(row=3, column=0, padx=18, pady=8, sticky="w")
        ctk.CTkEntry(
            frame, textvariable=self.repair_min_seconds, height=40
        ).grid(row=3, column=1, padx=(18, 12), pady=8, sticky="ew")
        ctk.CTkLabel(
            frame, text="建議 1.00",
            text_color=("gray50", "gray70"), anchor="w"
        ).grid(row=3, column=2, padx=(4, 18), pady=8, sticky="w")

        note = ctk.CTkLabel(
            frame,
            text="流程：先分析 TFF / BFF / Progressive → 顯示各區段實際一致度 → "
                 "再於分析結果頁選擇要修復的場序類型及修復一致度。\n"
                 "一致度＝該區段原始 idet 逐幀判定中，與區段場序相同的比例；不是機率值。"
                 "修改修復一致度不需要重新分析影片。",
            justify="left", text_color=("#c98b2e", "#e8b35a"), font=ctk.CTkFont(size=12),
        )
        note.grid(row=4, column=0, columnspan=3, padx=18, pady=(12, 8), sticky="w")

        button_bar = ctk.CTkFrame(frame, fg_color="transparent")
        button_bar.grid(row=5, column=0, columnspan=3, padx=18, pady=(8, 18), sticky="ew")
        button_bar.grid_columnconfigure(0, weight=1)
        button_bar.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(
            button_bar,
            text=self._icon_text("play", "開始分析", "▶"),
            image=self._ui_icon("play", (22, 22)),
            compound="left",
            height=44,
            command=lambda: self._begin_field_analysis(win),
        ).grid(row=0, column=0, padx=4, sticky="ew")
        ctk.CTkButton(
            button_bar,
            text=self._icon_text("close", "取消", "✕"),
            image=self._ui_icon("close", (22, 22)),
            compound="left",
            height=44,
            command=win.destroy,
        ).grid(row=0, column=1, padx=4, sticky="ew")
        # 不使用 grab_set：保持與 HDR 視窗一致，可正常最小化、顯示桌面及切換視窗。

    def _begin_field_analysis(self, settings_win):
        if not self.repair_enabled.get():
            messagebox.showinfo("場序檢測", "目前未啟用自動修復。")
            return
        try:
            min_seconds = float(self.repair_min_seconds.get())
            if min_seconds <= 0:
                raise ValueError
        except Exception:
            messagebox.showerror(
                "分析設定",
                "最少異常長度必須 > 0。"
            )
            return

        # 分析前不再要求使用者先決定修復百分比。分析只保存各區段的實際一致度；
        # 修復百分比由分析完成頁的 TFF / BFF / Progressive 個別設定決定。
        # 每次新分析預設允許修復所有「非目標」場序；目標場序在結果頁會自動停用。
        self.repair_tff.set(True)
        self.repair_bff.set(True)
        self.repair_progressive.set(True)

        settings_win.destroy()
        self.repair_analysis_results = []
        self._show_repair_analysis_window()
        self.running = True
        self.stop_requested = False
        self._update_progressive_repair_choice_text()
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.progress.set(0)
        self._start_analysis_progress_polling()
        threading.Thread(target=self.run_field_analysis, daemon=True).start()

    def _show_repair_analysis_window(self):
        win = ctk.CTkToplevel(self)
        self._repair_analysis_win = win
        win.title("場序分析結果")
        win.geometry("1080x780")
        win.minsize(900, 640)
        win.resizable(True, True)
        win.transient(self)
        win.protocol("WM_DELETE_WINDOW", self._close_repair_analysis_window)

        frame = ctk.CTkFrame(win)
        frame.pack(fill="both", expand=True, padx=16, pady=16)
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_rowconfigure(3, weight=1)

        ctk.CTkLabel(
            frame,
            text=self._icon_text("search", "分析結果（尚未修復）", "🔎"),
            image=self._ui_icon("search", (27, 27)),
            compound="left",
            font=ctk.CTkFont(size=24, weight="bold"),
        ).grid(row=0, column=0, padx=16, pady=(16, 6), sticky="w")

        ctk.CTkLabel(
            frame,
            text=(
                "先查看各區段的實際場序與一致度；下方「修復設定」只決定哪些已分析區段會進入修復，"
                "修改百分比不需要重新分析影片。"
            ),
            text_color=("gray50", "gray70"),
            font=ctk.CTkFont(size=13),
            justify="left",
            wraplength=980,
        ).grid(row=1, column=0, padx=16, pady=(0, 10), sticky="w")

        progress_bar_frame = ctk.CTkFrame(frame, fg_color="transparent")
        progress_bar_frame.grid(row=2, column=0, padx=16, pady=(2, 6), sticky="ew")
        progress_bar_frame.grid_columnconfigure(0, weight=1)
        progress_bar_frame.grid_columnconfigure(1, minsize=78, weight=0)
        self._repair_analysis_progress = ctk.CTkProgressBar(progress_bar_frame, height=14)
        self._repair_analysis_progress.grid(row=0, column=0, padx=(0, 10), sticky="ew")
        self._repair_analysis_progress.set(0)
        self._repair_analysis_progress_label = ctk.CTkLabel(
            progress_bar_frame,
            text="0.0%",
            width=78,
            anchor="e",
            font=ctk.CTkFont(size=13, weight="bold"),
        )
        self._repair_analysis_progress_label.grid(row=0, column=1, sticky="e")
        self._repair_analysis_progress_detail_label = ctk.CTkLabel(
            progress_bar_frame,
            text="",
            anchor="w",
            text_color=("gray50", "gray70"),
            font=ctk.CTkFont(size=12),
        )
        self._repair_analysis_progress_detail_label.grid(
            row=1, column=0, columnspan=2, pady=(2, 0), sticky="w"
        )

        self._repair_analysis_text = ctk.CTkTextbox(frame, font=ctk.CTkFont(size=13))
        self._repair_analysis_text.grid(row=3, column=0, padx=16, pady=8, sticky="nsew")
        self._field_analysis_section = None
        self._configure_field_result_tags()

        # 分析完成後才決定修復政策。三種場序改為橫向三欄並排，
        # 把垂直空間留給上方分析結果；目標場序只以 disabled 灰色表示。
        choice_frame = ctk.CTkFrame(frame)
        choice_frame.grid(row=4, column=0, padx=16, pady=(4, 6), sticky="ew")
        for _col in range(3):
            choice_frame.grid_columnconfigure(_col, weight=1, uniform="repair_policy_cols")

        ctk.CTkLabel(
            choice_frame,
            text="修復設定",
            font=ctk.CTkFont(size=15, weight="bold"),
        ).grid(row=0, column=0, columnspan=3, padx=12, pady=(8, 4), sticky="w")

        # 三個修復類型各自一欄；標題稍放大，便於快速掃視。
        tff_box = ctk.CTkFrame(choice_frame, fg_color="transparent")
        bff_box = ctk.CTkFrame(choice_frame, fg_color="transparent")
        p_box = ctk.CTkFrame(choice_frame, fg_color="transparent")
        tff_box.grid(row=1, column=0, padx=(12, 10), pady=(2, 8), sticky="nsew")
        bff_box.grid(row=1, column=1, padx=10, pady=(2, 8), sticky="nsew")
        p_box.grid(row=1, column=2, padx=(10, 12), pady=(2, 8), sticky="nsew")

        # 三欄內部全部使用完全相同的固定三欄結構：
        # [一致度文字] [數值 Entry] [%]。不要再用置中的子 Frame，
        # 否則不同欄寬/字長會令整組一致度左右漂移。
        for _box in (tff_box, bff_box, p_box):
            _box.grid_columnconfigure(0, weight=1, uniform="repair_conf_label")
            _box.grid_columnconfigure(1, weight=0, minsize=82, uniform="repair_conf_entry")
            _box.grid_columnconfigure(2, weight=0, minsize=22, uniform="repair_conf_pct")

        repair_title_font = ctk.CTkFont(size=14, weight="bold")
        repair_sub_font = ctk.CTkFont(size=12)

        self._repair_tff_checkbox = ctk.CTkCheckBox(
            tff_box,
            text="修復 Top Field First 區段",
            font=repair_title_font,
            variable=self.repair_tff,
            onvalue=True,
            offvalue=False,
            command=self._on_field_repair_policy_changed,
        )
        self._repair_tff_checkbox.grid(row=0, column=0, columnspan=3, pady=(0, 6), sticky="w")
        ctk.CTkLabel(
            tff_box, text="修復一致度選擇", text_color=("gray50", "gray70"),
            font=repair_sub_font, anchor="e"
        ).grid(row=1, column=0, padx=(0, 6), sticky="e")
        self._repair_tff_confidence_entry = ctk.CTkEntry(
            tff_box, textvariable=self.repair_tff_confidence, width=82, justify="center"
        )
        self._repair_tff_confidence_entry.grid(row=1, column=1, padx=(0, 4), sticky="w")
        ctk.CTkLabel(tff_box, text="%", font=repair_sub_font).grid(row=1, column=2, sticky="w")

        self._repair_bff_checkbox = ctk.CTkCheckBox(
            bff_box,
            text="修復 Bottom Field First 區段",
            font=repair_title_font,
            variable=self.repair_bff,
            onvalue=True,
            offvalue=False,
            command=self._on_field_repair_policy_changed,
        )
        self._repair_bff_checkbox.grid(row=0, column=0, columnspan=3, pady=(0, 6), sticky="w")
        ctk.CTkLabel(
            bff_box, text="修復一致度選擇", text_color=("gray50", "gray70"),
            font=repair_sub_font, anchor="e"
        ).grid(row=1, column=0, padx=(0, 6), sticky="e")
        self._repair_bff_confidence_entry = ctk.CTkEntry(
            bff_box, textvariable=self.repair_bff_confidence, width=82, justify="center"
        )
        self._repair_bff_confidence_entry.grid(row=1, column=1, padx=(0, 4), sticky="w")
        ctk.CTkLabel(bff_box, text="%", font=repair_sub_font).grid(row=1, column=2, sticky="w")

        self._repair_progressive_checkbox = ctk.CTkCheckBox(
            p_box,
            text="修復 Progressive 區段",
            font=repair_title_font,
            variable=self.repair_progressive,
            onvalue=True,
            offvalue=False,
            command=self._on_field_repair_policy_changed,
        )
        self._repair_progressive_checkbox.grid(row=0, column=0, columnspan=3, pady=(0, 6), sticky="w")
        ctk.CTkLabel(
            p_box, text="修復一致度選擇", text_color=("gray50", "gray70"),
            font=repair_sub_font, anchor="e"
        ).grid(row=1, column=0, padx=(0, 6), sticky="e")
        self._repair_progressive_confidence_entry = ctk.CTkEntry(
            p_box, textvariable=self.repair_progressive_confidence, width=82, justify="center"
        )
        self._repair_progressive_confidence_entry.grid(row=1, column=1, padx=(0, 4), sticky="w")
        ctk.CTkLabel(p_box, text="%", font=repair_sub_font).grid(row=1, column=2, sticky="w")

        # Progressive 修復方式跟一致度數值欄對齊，不再以整個 p_box 置中。
        self._repair_progressive_method_menu = ctk.CTkOptionMenu(
            p_box,
            variable=self.repair_progressive_method,
            values=[
                "快速時間重取樣（建議）",
                "光流 / 運動補償（高品質・較慢）",
            ],
            width=250,
            command=lambda _choice: self._on_field_repair_policy_changed(),
        )
        self._repair_progressive_method_menu.grid(
            row=2, column=0, columnspan=3, pady=(6, 0), sticky="e"
        )

        for entry in (
            self._repair_tff_confidence_entry,
            self._repair_bff_confidence_entry,
            self._repair_progressive_confidence_entry,
        ):
            try:
                entry.bind("<Return>", lambda _e: self._on_field_repair_policy_changed())
                entry.bind("<FocusOut>", lambda _e: self._on_field_repair_policy_changed())
            except Exception:
                pass

        # 舊版底部「目前修復策略」長段黃字移除，把垂直空間留給結果區。
        self._repair_progressive_choice_label = None
        self._update_progressive_repair_choice_text()

        bar = ctk.CTkFrame(frame, fg_color="transparent")
        bar.grid(row=5, column=0, padx=16, pady=(8, 16), sticky="ew")
        for col in range(5):
            bar.grid_columnconfigure(col, weight=1)
        self._repair_analysis_button = ctk.CTkButton(
            bar,
            text=self._icon_text("wrench", "開始修復", "🛠"),
            image=self._ui_icon("wrench", (22, 22)),
            compound="left",
            height=46,
            state="disabled",
            command=self.start_field_repair_from_analysis,
        )
        self._repair_analysis_button.grid(row=0, column=0, padx=4, sticky="ew")
        self._repair_analysis_stop_button = ctk.CTkButton(
            bar,
            text=self._icon_text("stop", "停止分析", "■"),
            image=self._ui_icon("stop", (22, 22)),
            compound="left",
            height=46,
            state="normal",
            command=self._stop_field_analysis,
        )
        self._repair_analysis_stop_button.grid(row=0, column=1, padx=4, sticky="ew")
        ctk.CTkButton(
            bar,
            text=self._icon_text("document", "TXT報告", "📄"),
            image=self._ui_icon("document", (22, 22)),
            compound="left",
            height=46,
            command=self.export_field_txt,
        ).grid(row=0, column=2, padx=4, sticky="ew")
        ctk.CTkButton(
            bar,
            text=self._icon_text("chart", "Excel報告", "📊"),
            image=self._ui_icon("chart", (22, 22)),
            compound="left",
            height=46,
            command=self.export_field_excel,
        ).grid(row=0, column=3, padx=4, sticky="ew")
        ctk.CTkButton(
            bar,
            text=self._icon_text("close", "取消 / 不修復", "✕"),
            image=self._ui_icon("close", (22, 22)),
            compound="left",
            height=46,
            command=self._close_repair_analysis_window,
        ).grid(row=0, column=4, padx=4, sticky="ew")
        self._repair_analysis_text.insert("end", "正在分析，請稍候……\n")
        # 不使用 grab_set：避免 Windows「顯示桌面」/最小化後 Tk grab 卡住。
        # 不使用 grab_set：避免 Windows「顯示桌面」/最小化後 Tk grab 卡住。

    def _stop_field_analysis(self):
        """Stop the current field-order analysis without starting repair."""
        if not self.running or self.stop_requested:
            return
        self.stop_requested = True
        self.status_var.set("正在停止場序分析…")
        self.write_log("WARNING：收到停止指令，正在中止場序分析。")
        button = getattr(self, "_repair_analysis_stop_button", None)
        if button is not None:
            try:
                button.configure(text=self._icon_text("stop", "正在停止…", "■"), state="disabled")
            except Exception:
                pass
        self._request_stop_current_process()

    def _field_repair_policy_threshold(self, detected):
        """Return the current post-analysis repair threshold for one detected field type."""
        detected = normalize_field_order(detected)
        var = {
            "Top Field First": self.repair_tff_confidence,
            "Bottom Field First": self.repair_bff_confidence,
            "Progressive": self.repair_progressive_confidence,
        }.get(detected)
        fallback = 90.0
        if var is None:
            return fallback / 100.0
        try:
            value = max(0.0, min(100.0, float(var.get())))
        except Exception:
            value = fallback
        return value / 100.0

    def _field_repair_type_enabled(self, detected, target=None):
        """Whether this detected type is selected for repair after analysis."""
        detected = normalize_field_order(detected)
        target = normalize_repair_target(target or self.repair_target.get())
        if detected == target:
            return False
        var = {
            "Top Field First": self.repair_tff,
            "Bottom Field First": self.repair_bff,
            "Progressive": self.repair_progressive,
        }.get(detected)
        if var is None:
            return False
        try:
            return bool(var.get())
        except Exception:
            return False

    def _validate_field_repair_policy(self, show_message=False):
        """Validate all post-analysis repair percentages without altering analysis data."""
        fields = [
            ("Top Field First", self.repair_tff_confidence),
            ("Bottom Field First", self.repair_bff_confidence),
            ("Progressive", self.repair_progressive_confidence),
        ]
        bad = []
        for label, var in fields:
            try:
                value = float(var.get())
                if not (0.0 <= value <= 100.0):
                    raise ValueError
            except Exception:
                bad.append(label)
        if bad and show_message:
            messagebox.showerror(
                "修復設定",
                "修復一致度必須介於 0–100%。\n\n請檢查：%s"
                % "、".join(bad),
                parent=self._repair_analysis_win if self._repair_analysis_win is not None else self,
            )
        return not bad

    def _progressive_repair_method_key(self):
        """Return a stable internal key for the Progressive temporal conversion mode."""
        try:
            value = str(self.repair_progressive_method.get() or "")
        except Exception:
            value = ""
        if "光流" in value or "運動補償" in value or "MCI" in value.upper():
            return "optical"
        return "fast"

    def _progressive_repair_method_label(self):
        if self._progressive_repair_method_key() == "optical":
            return "光流 / 運動補償（高品質・較慢）"
        return "快速時間重取樣（建議）"

    def _field_repair_policy_text(self, target=None):
        target = normalize_repair_target(target or self.repair_target.get())
        rows = []
        for detected, var, label in (
            ("Top Field First", self.repair_tff, "TFF"),
            ("Bottom Field First", self.repair_bff, "BFF"),
            ("Progressive", self.repair_progressive, "Progressive"),
        ):
            if detected == target:
                rows.append("%s＝目標場序（不修復）" % label)
                continue
            if self._field_repair_type_enabled(detected, target):
                rows.append(
                    "%s：修復一致度 ≥ %.1f%%"
                    % (label, self._field_repair_policy_threshold(detected) * 100.0)
                )
            else:
                rows.append("%s：保留／不修復" % label)
        if target in ("Top Field First", "Bottom Field First") and self._field_repair_type_enabled("Progressive", target):
            rows.append("P修復方式：%s" % self._progressive_repair_method_label())
        return "；".join(rows)

    def _on_field_repair_policy_changed(self):
        """Refresh post-analysis repair decisions without re-running field detection."""
        valid = self._validate_field_repair_policy(show_message=False)
        self._update_progressive_repair_choice_text()
        # Invalid entry text must never silently change the effective repair list.
        if valid and not self.running and self.repair_analysis_results:
            self._refresh_field_analysis_result_view()

    def _update_progressive_repair_choice_text(self):
        """Enable/disable TFF/BFF/P repair controls for the current target.

        The old long yellow "current repair strategy" paragraph was intentionally
        removed from the result page.  The controls themselves are now the single,
        direct representation of the repair policy.
        """
        target = normalize_repair_target(self.repair_target.get())
        mapping = (
            ("Top Field First", "修復 Top Field First 區段", self._repair_tff_checkbox, self._repair_tff_confidence_entry),
            ("Bottom Field First", "修復 Bottom Field First 區段", self._repair_bff_checkbox, self._repair_bff_confidence_entry),
            ("Progressive", "修復 Progressive 區段", self._repair_progressive_checkbox, self._repair_progressive_confidence_entry),
        )
        for detected, base_text, checkbox, entry in mapping:
            is_target = detected == target
            try:
                if checkbox is not None:
                    if is_target:
                        checkbox.deselect()
                    checkbox.configure(
                        state="disabled" if (is_target or self.running) else "normal",
                        text=base_text,
                    )
                if entry is not None:
                    entry.configure(state="disabled" if (is_target or self.running) else "normal")
            except Exception:
                pass

        # 修復方式只有在目標是 interlaced、且使用者選擇修復 Progressive 時可調。
        try:
            method_enabled = (
                target in ("Top Field First", "Bottom Field First")
                and bool(self.repair_progressive.get())
                and not self.running
            )
            if self._repair_progressive_method_menu is not None:
                self._repair_progressive_method_menu.configure(
                    state="normal" if method_enabled else "disabled"
                )
        except Exception:
            pass

    def _field_analysis_summary_text(self, file_path, analysis):
        """Build a threshold-neutral, direct field-analysis summary.

        Detection results and repair choices are deliberately separated.  The result
        area reports only what was measured (TC / field type / actual consistency);
        the controls below decide what to repair.
        """
        effective = self._effective_repair_analysis(analysis)
        segments = effective.get("segments") or []
        fps_value = float(effective.get("fps") or analysis.get("fps") or 25.0)
        target_value = effective.get("target") or analysis.get("target") or self.repair_target.get()
        target_norm = normalize_field_order(target_value)

        detected_segments = []
        normal_segments = []
        for seg in segments:
            detected_raw = str(seg.get("detected", "") or "")
            detected_norm = normalize_field_order(detected_raw)
            if detected_raw in ("場序無法確定", "Undetermined"):
                # 短暫 transition/effect 型 U 不污染主結果；只留 TXT/Excel 技術明細。
                if self._field_is_hidden_undetermined_segment(effective, seg):
                    continue
                detected_segments.append(seg)
            elif detected_raw == "Progressive-like（未確認）":
                detected_segments.append(seg)
            elif detected_norm != target_norm:
                detected_segments.append(seg)
            else:
                normal_segments.append(seg)

        if detected_segments:
            result_title = "檢測到 %d 個與目標場序不同／需留意的區段" % len(detected_segments)
        else:
            result_title = "場序正常，未發現與目標場序不同的區段"

        lines = [
            "",
            "檔案：%s" % os.path.basename(file_path),
            "目標場序：%s" % target_value,
            "檢測結果：%s" % result_title,
        ]

        if detected_segments:
            lines += ["", "[檢測區段]"]
            for idx, seg in enumerate(detected_segments, 1):
                tc1 = self._timecode_frames(seg.get("start", 0), fps_value)
                tc2 = self._timecode_frames(seg.get("end", 0), fps_value)
                ratio = float(seg.get("confidence") or 0.0) * 100.0
                detected_display = self._field_user_detected_label(seg)
                detected_raw = str(seg.get("detected", "") or "")
                if detected_raw in ("場序無法確定", "Undetermined"):
                    lines.append(
                        "  %d. TC %s - %s | %s | 一致度 %.1f%%"
                        % (idx, tc1, tc2, detected_display, ratio)
                    )
                else:
                    lines.append(
                        "  %d. TC %s - %s | %s → %s | 一致度 %.1f%%"
                        % (idx, tc1, tc2, detected_display, target_value, ratio)
                    )

        if normal_segments:
            lines += ["", "[正常] %d 個區段符合目標場序，已省略顯示。" % len(normal_segments)]

        if detected_segments:
            lines.append("建議：在下方直接選擇要修復的場序類型及修復一致度；修改百分比不需要重新分析。")
        else:
            lines.append("建議：無需處理。")
        lines.append("技術統計與所有區段明細可由 TXT / Excel 報告查看。")
        return "\n".join(lines) + "\n"

    def _refresh_field_analysis_result_view(self):
        box = getattr(self, "_repair_analysis_text", None)
        if box is None:
            return
        try:
            box.delete("1.0", "end")
        except Exception:
            try:
                inner = getattr(box, "_textbox", None)
                if inner is not None:
                    inner.delete("1.0", "end")
            except Exception:
                return
        self._field_analysis_section = None
        for item in self.repair_analysis_results or []:
            if item.get("error"):
                self._analysis_log(
                    "\n檔案：%s\n  分析失敗：%s\n"
                    % (os.path.basename(item.get("file", "")), item.get("error"))
                )
                continue
            analysis = item.get("analysis") or {}
            self._analysis_log(self._field_analysis_summary_text(item.get("file", ""), analysis))
        self._analysis_log(
            "\n" + "=" * 72
            + "\n分析完成。以上百分比是各區段實際一致度；請在下方直接選擇修復類型及修復一致度，不必重新分析。"
        )

    def _effective_repair_analysis(self, analysis):
        """Apply the post-analysis repair policy to immutable detection results.

        The detector keeps every repair-capable TFF/BFF/Progressive segment with its
        measured consistency; there is no hidden percentage floor.  This method alone decides which of those candidates
        enter the actual repair list, so changing the repair percentage never requires
        a second full field-order analysis.
        """
        if not analysis:
            return {}

        effective = copy.deepcopy(analysis)
        target = normalize_repair_target(
            effective.get("target", self.repair_target.get())
        )

        candidates = [
            dict(a)
            for a in (
                effective.get("repair_candidates")
                or effective.get("anomalies")
                or []
            )
        ]
        selected = []
        for anomaly in candidates:
            detected = normalize_field_order(anomaly.get("detected", ""))
            if detected not in ("Top Field First", "Bottom Field First", "Progressive"):
                continue
            if detected == target:
                continue
            if not self._field_repair_type_enabled(detected, target):
                continue

            threshold = self._field_repair_policy_threshold(detected)
            ratio = float(anomaly.get("confidence") or 0.0)
            if ratio + 1e-9 < threshold:
                continue

            # Progressive 二次驗證只保留作技術參考。使用者已在分析完成頁
            # 明確勾選類型並設定 percentage 時，不再由隱藏安全門檻否決。
            anomaly["repair_threshold"] = threshold
            anomaly["repair_selected"] = True
            selected.append(anomaly)

        effective["repair_candidates"] = candidates
        effective["anomalies"] = selected
        effective["repair_policy"] = {
            "target": target,
            "Top Field First": {
                "enabled": self._field_repair_type_enabled("Top Field First", target),
                "threshold": self._field_repair_policy_threshold("Top Field First"),
            },
            "Bottom Field First": {
                "enabled": self._field_repair_type_enabled("Bottom Field First", target),
                "threshold": self._field_repair_policy_threshold("Bottom Field First"),
            },
            "Progressive": {
                "enabled": self._field_repair_type_enabled("Progressive", target),
                "threshold": self._field_repair_policy_threshold("Progressive"),
            },
        }

        active_thresholds = [
            float(a.get("repair_threshold") or 0.0)
            for a in selected
            if float(a.get("repair_threshold") or 0.0) > 0.0
        ]
        if active_thresholds:
            # Verification follows the actual repair list, not unrelated enabled
            # checkboxes that happened to have a lower percentage.
            effective["confidence_threshold"] = min(active_thresholds)

        # Recompute segment status from current repair policy.  Detection facts
        # (detected type / TC / measured consistency) are never rewritten.
        for seg in effective.get("segments") or []:
            detected_label = str(seg.get("detected", "") or "")
            detected = normalize_field_order(detected_label)
            seg["needs_repair"] = False

            if detected_label in ("場序無法確定", "Undetermined"):
                if str(seg.get("undetermined_context", "")) == "short_review":
                    seg["repair_reason"] = "短暫場序不確定，可能為轉場／效果或場序切換邊界；只供人工複核"
                else:
                    seg["repair_reason"] = "持續場序無法可靠確定；只供人工複核"
                continue
            if detected_label == "Progressive-like（未確認）":
                if not seg.get("repair_reason"):
                    seg["repair_reason"] = "Progressive 二次驗證證據不足；只供人工複核"
                continue
            if detected == target:
                seg["repair_reason"] = "符合目標場序"
                continue
            if detected not in ("Top Field First", "Bottom Field First", "Progressive"):
                seg["repair_reason"] = "未知場序；保留原片"
                continue

            ratio = float(seg.get("confidence") or 0.0)
            threshold = self._field_repair_policy_threshold(detected)
            if not self._field_repair_type_enabled(detected, target):
                seg["repair_reason"] = "此類場序目前設定為保留／不修復"
                continue
            if ratio + 1e-9 < threshold:
                seg["repair_reason"] = "目前修復設定未選取此區段"
                continue

            seg_a = float(seg.get("start", 0.0))
            seg_b = float(seg.get("end", seg_a))
            for anomaly in selected:
                if normalize_field_order(anomaly.get("detected", "")) != detected:
                    continue
                a = float(anomaly.get("start", 0.0))
                b = float(anomaly.get("end", a))
                if min(seg_b, b) - max(seg_a, a) > 0.0005:
                    seg["needs_repair"] = True
                    seg["repair_reason"] = "符合目前修復設定；已列入實際修復範圍"
                    seg["repair_threshold"] = threshold
                    break
            if not seg.get("needs_repair") and detected == "Progressive":
                seg["repair_reason"] = "Progressive 未通過安全修復條件；保留原片"
            elif not seg.get("needs_repair") and not seg.get("repair_reason"):
                seg["repair_reason"] = "目前未列入修復"

        return effective

    def _configure_field_result_tags(self):
        """Configure semantic colours for the field-analysis result box.

        CTkTextbox wraps a normal tkinter.Text widget.  Using text tags keeps the
        dark theme/background untouched while making PASS / REVIEW / REPAIR states
        visually consistent with the HDR / gamut module.
        """
        box = getattr(self, "_repair_analysis_text", None)
        inner = getattr(box, "_textbox", None) if box is not None else None
        if inner is None:
            return
        try:
            base = tkfont.Font(font=inner.cget("font"))
            family = base.actual("family") or "Microsoft JhengHei"
            size = int(base.actual("size") or 13)
            inner.tag_configure("field_title", foreground="#8CC8FF", font=(family, size, "bold"))
            inner.tag_configure("field_info", foreground="#A9D6FF")
            inner.tag_configure("field_repair_header", foreground="#FF7777", font=(family, size, "bold"))
            inner.tag_configure("field_repair", foreground="#FF9A9A")
            inner.tag_configure("field_review_header", foreground="#FFC45C", font=(family, size, "bold"))
            inner.tag_configure("field_review", foreground="#FFD889")
            inner.tag_configure("field_preserve_header", foreground="#E8C96A", font=(family, size, "bold"))
            inner.tag_configure("field_preserve", foreground="#E8D8A0")
            inner.tag_configure("field_detected_header", foreground="#A9D6FF", font=(family, size, "bold"))
            # 一致度顏色只表達量測強度，不代表是否已選修復。
            inner.tag_configure("field_consistency_high", foreground="#FF8A8A")   # 80–100%
            inner.tag_configure("field_consistency_mid", foreground="#FFD36A")    # 60–79.9%
            inner.tag_configure("field_consistency_low", foreground="#B9C0C8")    # 50–59.9%
            inner.tag_configure("field_normal_header", foreground="#76D98B", font=(family, size, "bold"))
            inner.tag_configure("field_normal", foreground="#A2E5AF")
            inner.tag_configure("field_note", foreground="#A8ADB4")
        except Exception:
            pass

    def _analysis_log(self, text):
        """Append field-analysis text with direct, consistency-based colours."""
        box = self._repair_analysis_text
        if box is None:
            return
        inner = getattr(box, "_textbox", None)
        if inner is None:
            box.insert("end", text + "\n")
            box.see("end")
            return

        try:
            for line in str(text).splitlines():
                stripped = line.strip()
                tag = None

                if stripped.startswith("[檢測區段]"):
                    self._field_analysis_section = "detected"
                    tag = "field_detected_header"
                elif stripped.startswith("[正常]"):
                    self._field_analysis_section = "normal"
                    tag = "field_normal_header"
                elif stripped.startswith("檔案："):
                    self._field_analysis_section = None
                    tag = "field_title"
                elif stripped.startswith("目標場序："):
                    tag = "field_info"
                elif stripped.startswith("檢測結果："):
                    if "場序正常" in stripped:
                        tag = "field_normal_header"
                    elif "檢測到" in stripped:
                        tag = "field_detected_header"
                    else:
                        tag = "field_info"
                elif stripped.startswith("建議：") or stripped.startswith("技術統計"):
                    tag = "field_note"
                elif re.match(r"^\d+\.\s*TC\s", stripped):
                    if "場序無法確定" in stripped or "場序不確定" in stripped:
                        tag = "field_review"
                    else:
                        m = re.search(r"一致度\s*([0-9]+(?:\.[0-9]+)?)%", stripped)
                        if m:
                            pct = float(m.group(1))
                            if pct >= 80.0:
                                tag = "field_consistency_high"
                            elif pct >= 60.0:
                                tag = "field_consistency_mid"
                            else:
                                tag = "field_consistency_low"
                        else:
                            tag = "field_info"
                elif "場序無法確定" in stripped or "場序不確定" in stripped:
                    tag = "field_review"

                inner.insert("end", line + "\n", tag if tag else ())
            inner.see("end")
        except Exception:
            try:
                box.insert("end", text + "\n")
                box.see("end")
            except Exception:
                pass

    def _close_repair_analysis_window(self):
        # 若仍在場序分析，關閉視窗/按取消等同「停止分析」：先送出 stop flag
        # 並終止目前 FFmpeg，避免視窗消失後背景仍持續吃 CPU / 磁碟。
        if self.running and not self.stop_requested:
            self._stop_field_analysis()
        try:
            if self._repair_analysis_win is not None and self._repair_analysis_win.winfo_exists():
                self._repair_analysis_win.grab_release()
                self._repair_analysis_win.destroy()
        except Exception:
            pass
        self._repair_analysis_win = None
        self._repair_analysis_text = None
        self._repair_analysis_progress = None
        self._repair_analysis_progress_label = None
        self._repair_analysis_progress_detail_label = None
        self._repair_analysis_button = None
        self._repair_tff_checkbox = None
        self._repair_bff_checkbox = None
        self._repair_progressive_checkbox = None
        self._repair_tff_confidence_entry = None
        self._repair_bff_confidence_entry = None
        self._repair_progressive_confidence_entry = None
        self._repair_progressive_method_menu = None
        self._repair_progressive_choice_label = None

    def _queue_analysis_progress(self, value, detail):
        """Worker -> UI：只保留最新 target，避免 Tk event queue 被 FFmpeg 進度淹沒。"""
        try:
            value = max(0.0, min(1.0, float(value)))
            # 場序分析進度只可向前。Python attribute assignment 在此足夠，
            # 真正 Tk widget 更新一律只在 main thread 的 poller 內執行。
            if value >= float(getattr(self, "_analysis_progress_target", 0.0) or 0.0):
                self._analysis_progress_target = value
                self._analysis_progress_detail = str(detail or "")
        except Exception:
            pass

    def _poll_analysis_progress_queue(self):
        """單一 UI renderer：平滑追趕真實 target，防止上下兩條 CTk progress bar 閃爍。"""
        if not self._analysis_progress_polling:
            return

        target = max(0.0, min(1.0, float(getattr(self, "_analysis_progress_target", 0.0) or 0.0)))
        shown = max(0.0, min(1.0, float(getattr(self, "_analysis_progress_display", 0.0) or 0.0)))
        delta = target - shown

        if delta > 0.0005:
            # 小距離細滑，大距離加快追趕；每 80ms 最多約 1.6%，
            # 不會因 callback burst 出現 progress bar repaint 閃爍。
            step = min(delta, max(0.0025, min(0.016, delta * 0.22)))
            shown = min(target, shown + step)
            self._analysis_progress_display = shown

            detail = str(getattr(self, "_analysis_progress_detail", "") or "")
            self._set_analysis_progress(shown, detail or ("%.1f%%" % (shown * 100.0)))
            try:
                self.progress.set(shown)
            except Exception:
                pass
            # status 也由同一 renderer 更新，禁止 worker 每個 frame 排 after(0)。
            if detail:
                try:
                    clean = re.sub(r"^\s*\d+(?:\.\d+)?%\s*", "", detail).strip()
                    self.status_var.set("分析：%s" % (clean or detail))
                except Exception:
                    pass
        elif target >= 0.9995:
            # 保證最後精確停在 100%，只繪一次。
            if shown < 1.0:
                self._analysis_progress_display = 1.0
                self._set_analysis_progress(1.0, getattr(self, "_analysis_progress_detail", "") or "分析完成")
                try:
                    self.progress.set(1.0)
                except Exception:
                    pass
            if getattr(self, "_analysis_progress_done", False):
                self._analysis_progress_polling = False
                return

        self.after(80, self._poll_analysis_progress_queue)

    def _start_analysis_progress_polling(self):
        try:
            while True:
                self._analysis_progress_queue.get_nowait()
        except queue.Empty:
            pass
        self._analysis_progress_target = 0.0
        self._analysis_progress_display = 0.0
        self._analysis_progress_detail = "準備分析"
        self._analysis_progress_done = False
        self._analysis_progress_polling = True
        self._set_analysis_progress(0.0, "準備分析")
        try:
            self.progress.set(0.0)
        except Exception:
            pass
        self.after(80, self._poll_analysis_progress_queue)

    def _stop_analysis_progress_polling(self):
        # 正常完成時讓 renderer 自己追到 100% 再停止；取消時立即停止。
        self._analysis_progress_done = True
        if self.stop_requested:
            self._analysis_progress_polling = False

    def run_field_analysis(self):
        files = list(self.selected_files)
        total = len(files)
        target = normalize_repair_target(self.repair_target.get())
        self.write_log("")
        self.write_log(self._log_separator("="))
        self.write_log("[場序] 場序分析階段開始（不輸出、不修改影片）")
        self.write_log("目標場次：%s" % target)
        self.write_log(self._log_separator("="))

        for index, path in enumerate(files):
            if self.stop_requested:
                break
            item = {"file": path, "analysis": None, "error": ""}
            try:
                filename = os.path.basename(path)
                self.after(0, lambda p=path: self.status_var.set("正在分析：%s" % os.path.basename(p)))
                # 先取得影片時長。部分 AVC-Intra MXF 的 format duration 可能為空；
                # fallback 會優先使用實際 decoded frame count / decoded cadence，
                # 避免 field-rate-like nb_frames 令進度與 TC 變成 2 倍。
                field_probe = self._field_probe_info(path)
                progress_fps = float(field_probe.get("fps") or 0.0) or self._probe_video_fps(path, 25.0)
                duration_hint = [float(field_probe.get("duration") or 0.0)]
                if duration_hint[0] <= 0.0:
                    duration_hint[0] = self._probe_duration_seconds(path, progress_fps)
                last_ui_time = [0.0]
                last_ui_value = [-1.0]

                total_frames_hint = [(
                    max(1, int(round(duration_hint[0] * progress_fps)))
                    if duration_hint[0] > 0.0 else 0
                )]
                progress_state = {"frame": 0.0, "speed": "", "last_key": ""}

                def analysis_progress(key, value, elapsed):
                    """真實多階段場序進度；callback 不直接碰 Tk widget。"""
                    current = None
                    speed = progress_state["speed"]
                    try:
                        # Phase allocation:
                        #   0-68%  全片快速連續區塊掃描
                        #  68-90%  可疑區逐幀精掃（有實際 window/frame 進度）
                        #  90-98%  Progressive temporal 二次驗證
                        #  98-99.5% 區段/修復決策整理
                        # 100%     整個檔案真正完成後
                        if key == "field_phase":
                            phase = str(value)
                            phase_map = {
                                "coarse_done": (0.68, "快速場序掃描完成"),
                                "refining": (0.681, "逐幀精掃可疑區段"),
                                "refine_done": (0.90, "可疑區逐幀精掃完成"),
                                "refine_skipped": (0.90, "未發現需逐幀精掃的可疑區"),
                                "candidates_ready": (0.905, "整理 Progressive 候選"),
                            }
                            if phase in phase_map:
                                file_frac, label = phase_map[phase]
                                overall = (float(index) + file_frac) / float(total) if total else file_frac
                                self._queue_analysis_progress(
                                    overall, "%.1f%%  %s" % (file_frac * 100.0, label)
                                )
                            return

                        if key == "field_refine_progress":
                            try:
                                done_s, total_s = str(value).split("/", 1)
                                done_n = max(0.0, float(done_s)); total_n = max(1.0, float(total_s))
                                phase_frac = min(1.0, done_n / total_n)
                            except Exception:
                                phase_frac = 0.0; done_n = 0.0; total_n = 1.0
                            file_frac = 0.68 + 0.22 * phase_frac
                            overall = (float(index) + file_frac) / float(total) if total else file_frac
                            detail = "%.1f%%  可疑區逐幀精掃 %.0f / %.0f 幀" % (
                                file_frac * 100.0, done_n, total_n
                            )
                            self._queue_analysis_progress(overall, detail)
                            return

                        if key == "progressive_validation":
                            try:
                                done_s, total_s = str(value).split("/", 1)
                                done_n = max(0, int(float(done_s))); total_n = max(1, int(float(total_s)))
                                phase_frac = min(1.0, float(done_n) / float(total_n))
                            except Exception:
                                phase_frac = 0.0; done_n = 0; total_n = 1
                            file_frac = 0.90 + 0.08 * phase_frac
                            overall = (float(index) + file_frac) / float(total) if total else file_frac
                            detail = "%.1f%%  Progressive 二次驗證：%d / %d" % (
                                file_frac * 100.0, done_n, total_n
                            )
                            self._queue_analysis_progress(overall, detail)
                            return

                        if key == "field_finalize":
                            file_frac = 0.995
                            overall = (float(index) + file_frac) / float(total) if total else file_frac
                            self._queue_analysis_progress(
                                overall, "99.5%  整理場序區段與修復決策"
                            )
                            return

                        if key == "input_duration":
                            reported_duration = max(0.0, float(value))
                            if reported_duration > 0.0:
                                if duration_hint[0] <= 0.0 or reported_duration > duration_hint[0] * 1.10:
                                    duration_hint[0] = reported_duration
                                    total_frames_hint[0] = max(
                                        1, int(round(duration_hint[0] * progress_fps))
                                    )
                            return

                        if key == "frame" and total_frames_hint[0] > 0:
                            frame_no = max(progress_state["frame"], float(value))
                            progress_state["frame"] = frame_no
                            current = frame_no / max(1.0, progress_fps)
                        elif key in ("out_time_ms", "out_time_us") and duration_hint[0] > 0.0:
                            current = float(value) / 1000000.0
                        elif key == "analysis_sample" and total_frames_hint[0] > 0:
                            sample_frame = max(0.0, float(value) - 1.0)
                            current = max(progress_state["frame"], sample_frame) / max(1.0, progress_fps)
                        elif key == "speed":
                            progress_state["speed"] = str(value)
                            return
                        elif key == "progress" and str(value).lower() == "end":
                            current = duration_hint[0] if duration_hint[0] > 0.0 else None
                        else:
                            return
                    except Exception:
                        return

                    if current is None:
                        return
                    if duration_hint[0] > 0.0:
                        frac_file = max(0.0, min(1.0, current / duration_hint[0]))
                    else:
                        frac_file = min(1.0, max(0.0, current / 3600.0))

                    # 此 callback 只代表第一階段 coarse scan，所以最多到 68%。
                    coarse_file_frac = min(0.68, frac_file * 0.68)
                    overall = (float(index) + coarse_file_frac) / float(total) if total else coarse_file_frac

                    now = time.time()
                    time_gap = now - last_ui_time[0]
                    value_gap = abs(overall - last_ui_value[0])
                    if last_ui_value[0] >= 0.0 and time_gap < 0.12 and value_gap < 0.01:
                        return
                    last_ui_time[0] = now
                    last_ui_value[0] = overall

                    detail = "%.1f%%  快速場序掃描" % (coarse_file_frac * 100.0)
                    if duration_hint[0] > 0.0:
                        detail += "  %s / %s" % (
                            self._timecode(current), self._timecode(duration_hint[0])
                        )
                    if progress_state["speed"] and progress_state["speed"] not in ("N/A", "0x"):
                        detail += "  %s" % progress_state["speed"]
                    self._queue_analysis_progress(overall, detail)


                analysis = self._analyze_field_order(path, progress_callback=analysis_progress)
                if not self.stop_requested:
                    overall_done = float(index + 1) / float(total) if total else 1.0
                    self._queue_analysis_progress(overall_done, "100.0%  場序分析完成")
                item["analysis"] = analysis
                self.repair_analysis_results.append(item)
                # GUI 主結果與後續 refresh 共用同一個 formatter，避免分析完成後
                # 修改修復百分比時出現兩套不同文字。
                concise_text = self._field_analysis_summary_text(path, analysis)
                self.write_log(concise_text.strip())
                self.after(0, lambda t=concise_text: self._analysis_log(t))

                # 技術日誌保留完整資料；repair list 仍由同一 effective decision 產生。
                display_analysis = self._effective_repair_analysis(analysis)
                counts = display_analysis.get("counts", {})
                display_segments = display_analysis.get("segments") or []
                repair_segments = [seg for seg in display_segments if seg.get("needs_repair")]
                fps_value = float(analysis.get("fps") or 25.0)
                target_value = display_analysis.get("target") or analysis.get("target") or self.repair_target.get()

                # 主程式日誌仍保留完整技術資料，方便除錯；不灌入使用者主結果框。
                technical_header = (
                    "[場序技術明細] %s | TFF:%d BFF:%d P:%d | FPS:%.6f | 時長:%s | 區段:%d 已選修復:%d"
                    % (
                        os.path.basename(path),
                        counts.get("Top Field First", 0),
                        counts.get("Bottom Field First", 0),
                        counts.get("Progressive", 0),
                        float(analysis.get("fps") or 0),
                        self._timecode(analysis.get("duration", 0)),
                        len(display_segments),
                        len(repair_segments),
                    )
                )
                self.write_log(technical_header)
                for n, segment in enumerate(display_segments, 1):
                    self.write_log(
                        "  區段 %d：%s → %s | TC %s - %s | 一致度 %.1f%% | %s | %s"
                        % (
                            n,
                            self._field_user_detected_label(segment),
                            segment.get("target", ""),
                            self._timecode_frames(segment.get("start", 0), fps_value),
                            self._timecode_frames(segment.get("end", 0), fps_value),
                            float(segment.get("confidence") or 0.0) * 100.0,
                            "已選擇修復" if segment.get("needs_repair") else "保留／不修復",
                            segment.get("repair_reason", ""),
                        )
                    )
            except Exception as exc:
                item["error"] = str(exc)
                self.repair_analysis_results.append(item)
                error_text = "\n檔案：%s\n  分析失敗：%s\n" % (os.path.basename(path), exc)
                self.write_log(error_text.strip())
                self.after(0, lambda t=error_text: self._analysis_log(t))

            # 單檔完成才推到該檔 100%；中間進度由逐幀 idet 真實 frame 數驅動。
            frac = float(index + 1) / float(total) if total else 1.0
            self._queue_analysis_progress(frac, "%.1f%%" % (frac * 100.0))

        stopped = self.stop_requested
        if not stopped:
            self._queue_analysis_progress(1.0, "100.0%")
        self._analysis_progress_done = True
        # renderer 會平滑追到 100% 後自行停止，不再 250ms 強行截斷造成跳變。
        self.running = False
        self.stop_requested = False
        self.after(0, self._update_progressive_repair_choice_text)
        self.after(0, lambda: self.start_button.configure(state="normal"))
        self.after(0, lambda: self.stop_button.configure(state="disabled"))
        def finish_field_buttons():
            button = getattr(self, "_repair_analysis_stop_button", None)
            if button is not None:
                try:
                    button.configure(text="停止分析", state="disabled")
                except Exception:
                    pass
        self.after(0, finish_field_buttons)
        if stopped:
            self.after(0, lambda: self.status_var.set("場序分析已停止"))
            self.after(0, lambda: self._analysis_log("\n[警告] 場序分析已停止；尚未開始修復。"))
            return

        # 以目前修復設定重新渲染一次結果，確保 GUI、TXT、Excel 與真正 repair list
        # 都由同一個 _effective_repair_analysis() 決策來源產生。
        self.after(0, self._refresh_field_analysis_result_view)
        self.after(0, lambda: self._repair_analysis_button.configure(state="normal"))
        self.after(0, lambda: self.status_var.set("場序分析完成：請確認分析結果後決定是否修復"))

    def _set_analysis_progress(self, value, detail=None):
        value = max(0.0, min(1.0, float(value)))
        if self._repair_analysis_progress is not None:
            try:
                self._repair_analysis_progress.set(value)
            except Exception:
                pass
        if self._repair_analysis_progress_label is not None:
            try:
                # 固定只顯示百分比，避免 label 文字長度改變 grid 欄寬。
                self._repair_analysis_progress_label.configure(text="%.1f%%" % (value * 100.0))
            except Exception:
                pass
        if getattr(self, "_repair_analysis_progress_detail_label", None) is not None:
            try:
                detail_text = str(detail or "")
                # 詳細文字本身通常以百分比開頭，移除重複的百分比再顯示階段資訊。
                if detail_text:
                    import re as _re
                    detail_text = _re.sub(r"^\s*\d+(?:\.\d+)?%\s*", "", detail_text).strip()
                self._repair_analysis_progress_detail_label.configure(text=detail_text)
            except Exception:
                pass

    def _analysis_needs_rebuild(self, analysis):
        """Return True only when the current post-analysis repair policy selects work."""
        if not analysis:
            return False
        effective = self._effective_repair_analysis(analysis)
        return bool(effective.get("anomalies"))

    def start_field_repair_from_analysis(self):
        if not self.repair_analysis_results:
            messagebox.showwarning("場序檢測", "尚未取得分析結果。")
            return
        if any(item.get("error") for item in self.repair_analysis_results):
            messagebox.showwarning("場序檢測", "有影片分析失敗；請先確認分析結果。")
            return
        if not self._validate_field_repair_policy(show_message=True):
            return
        if not any(self._analysis_needs_rebuild(item.get("analysis") or {})
                   for item in self.repair_analysis_results):
            messagebox.showinfo(
                "場序檢測",
                "目前修復設定沒有選取任何可修復區段。\n\n"
                "如分析結果存在 TFF / BFF / Progressive 區段，可調整下方修復類型或修復一致度後再開始修復。"
            )
            return
        # 分析完成後、使用者明確確認要修復時，才第一次詢問輸出位置。
        # 分析階段完全不需要也不應該出現輸出資料夾選擇。
        initial_dir = self.repair_output_dir.get().strip()
        if not initial_dir or not os.path.isdir(initial_dir):
            initial_dir = os.path.dirname(self.selected_files[0]) if self.selected_files else os.getcwd()

        output_dir = filedialog.askdirectory(
            parent=self._repair_analysis_win if self._repair_analysis_win is not None else self,
            title="選擇修復影片輸出資料夾",
            initialdir=initial_dir,
            mustexist=True,
        )
        if not output_dir:
            self.status_var.set("已取消修復：未選擇輸出資料夾")
            if self._repair_analysis_win is not None:
                self._analysis_log("\n[警告] 已取消修復：沒有選擇輸出資料夾，尚未輸出任何影片。")
            return

        # 先檢查所有將要產生的 _fixed 檔案。只要已存在，就必須由使用者
        # 明確選擇「是」才允許覆蓋；「否」會略過該影片。
        overwrite_decisions = {}
        for item in self.repair_analysis_results:
            analysis = self._effective_repair_analysis(item.get("analysis") or {})
            if not self._analysis_needs_rebuild(analysis):
                continue
            src_path = item["file"]
            output_path = self._repair_output_path_for_analysis(
                src_path, output_dir, analysis
            )
            output_abs = os.path.abspath(output_path)
            if os.path.exists(output_path):
                replace = messagebox.askyesno(
                    "檔案已存在 — 是否取代？",
                    "目的地已存在同名修復影片：\n\n%s\n\n"
                    "選「是」才會覆蓋現有檔案。\n選「否」則保留現有檔案並略過這部影片。"
                    % os.path.basename(output_path),
                    parent=self._repair_analysis_win if self._repair_analysis_win is not None else self,
                )
                overwrite_decisions[output_abs] = bool(replace)
            else:
                overwrite_decisions[output_abs] = False

        self._repair_overwrite_decisions = overwrite_decisions

        # 記住本次選擇，供本次所有影片及下次開啟時作為預設位置。
        self.repair_output_dir.set(output_dir)
        self.write_log("場序重構輸出資料夾：%s" % output_dir)

        self._close_repair_analysis_window()
        self.running = True
        self.stop_requested = False
        self.repair_results = []
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.progress.set(0)
        self._show_repair_export_progress_window()
        threading.Thread(target=self.run_field_repair, args=(output_dir,), daemon=True).start()

    def _set_repair_verify_progress_target(self, value):
        """Smoothly chase real verify progress; never invent, reverse or overshoot."""
        try:
            value = max(0.0, min(1.0, float(value)))
        except Exception:
            value = 0.0
        self._repair_verify_progress_target = max(
            float(getattr(self, "_repair_verify_progress_target", 0.0) or 0.0),
            value,
        )
        if getattr(self, "_repair_verify_progress_polling", False):
            return
        self._repair_verify_progress_polling = True

        def tick():
            if not getattr(self, "_repair_verify_progress_polling", False):
                return
            target = float(getattr(self, "_repair_verify_progress_target", 0.0) or 0.0)
            shown = float(getattr(self, "_repair_verify_progress_display", 0.0) or 0.0)
            if target > shown:
                # <=1% per tick gives a calm visual progression while remaining
                # bounded by real completed work.
                shown = min(target, shown + min(0.01, max(0.002, (target - shown) * 0.25)))
                self._repair_verify_progress_display = shown
                try:
                    if self._repair_verify_progress is not None:
                        self._repair_verify_progress.set(shown)
                    if self._repair_verify_percent is not None:
                        self._repair_verify_percent.configure(text="%.1f%%" % (shown * 100.0))
                except Exception:
                    pass
            if shown + 1e-6 < target or target < 1.0:
                try:
                    self.after(40, tick)
                except Exception:
                    self._repair_verify_progress_polling = False
            else:
                self._repair_verify_progress_polling = False
        self.after(0, tick)

    def _show_repair_verify_progress_window(self):
        if self._repair_verify_win is not None:
            return
        win = ctk.CTkToplevel(self)
        self._repair_verify_win = win
        win.title("修復後驗證進度")
        win.geometry("700x360")
        win.minsize(620, 300)
        # 修復/驗證期間此視窗只顯示進度，不應鎖住主視窗。
        # 不使用 transient/grab，避免 Windows「顯示桌面」後 parent/child
        # modal 狀態卡住，造成程式無法正常還原或最大化。
        win.resizable(True, True)
        frame = ctk.CTkFrame(win)
        frame.pack(fill="both", expand=True, padx=18, pady=18)
        frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            frame,
            text=self._icon_text("search", "正在驗證修復結果", "🔎"),
            image=self._ui_icon("search", (26, 26)),
            compound="left",
            font=ctk.CTkFont(size=23, weight="bold"),
        ).grid(row=0, column=0, padx=16, pady=(16, 8), sticky="w")
        self._repair_verify_stage = ctk.CTkLabel(frame, text="先核對成品片長／decoded frame count…", font=ctk.CTkFont(size=15, weight="bold"))
        self._repair_verify_stage.grid(row=1, column=0, padx=16, pady=5, sticky="w")
        self._repair_verify_range = ctk.CTkLabel(frame, text="檢測範圍：--")
        self._repair_verify_range.grid(row=2, column=0, padx=16, pady=4, sticky="w")
        self._repair_verify_progress = ctk.CTkProgressBar(frame, height=18)
        self._repair_verify_progress.grid(row=3, column=0, padx=16, pady=(12, 6), sticky="ew")
        # 全程使用真實、單向的 determinate 進度；不再左右來回滑動。
        self._repair_verify_indeterminate = False
        try:
            self._repair_verify_progress.configure(mode="determinate")
        except Exception:
            pass
        self._repair_verify_progress.set(0.0)
        self._repair_verify_progress_target = 0.0
        self._repair_verify_progress_display = 0.0
        self._repair_verify_progress_polling = False
        self._repair_verify_percent = ctk.CTkLabel(frame, text="0.0%", font=ctk.CTkFont(size=18, weight="bold"))
        self._repair_verify_percent.grid(row=4, column=0, padx=16, pady=4, sticky="w")
        self._repair_verify_detail = ctk.CTkLabel(frame, text="正在核對片長、FFmpeg 輸出幀數與容器 video packet；如有疑點才進行完整 decoded-frame 深度驗證。", justify="left", wraplength=620)
        self._repair_verify_detail.grid(row=5, column=0, padx=16, pady=(10, 8), sticky="w")

        self._repair_verify_stop_button = ctk.CTkButton(
            frame,
            text="停止修復／驗證",
            height=40,
            command=self._stop_field_repair_export,
        )
        self._repair_verify_stop_button.grid(
            row=6, column=0, padx=16, pady=(8, 16), sticky="ew"
        )
        # 非 modal：允許 Windows 正常最小化／還原／最大化。

    def _set_repair_verify_preflight_status(self, filename):
        """顯示無法可靠量化百分比的時間軸/decoded-frame 前置驗證狀態。"""
        def update():
            try:
                if self._repair_verify_stage is not None:
                    self._repair_verify_stage.configure(text="正在驗證：%s｜時間軸完整性" % filename)
                if self._repair_verify_range is not None:
                    self._repair_verify_range.configure(text="檢測範圍：全片（片長 / decoded frame count）")
                self._set_repair_verify_progress_target(0.02)
                if self._repair_verify_detail is not None:
                    self._repair_verify_detail.configure(
                        text="正在核對片長、FFmpeg 輸出幀數與 MXF/容器 video packet；只有資料不一致時才啟動完整 decoded-frame 深度驗證。"
                    )
            except Exception:
                pass
            self.status_var.set("正在驗證修復結果：%s｜時間軸完整性" % filename)
        self.after(0, update)

    def _update_repair_verify_progress(self, fraction, file_index, total_files, segment_index, segment_total, start, end, current, duration, filename):
        fraction = max(0.0, min(1.0, float(fraction)))
        # 0-10% is reserved for real preflight integrity work; selective field
        # verification occupies 10-100%.  This prevents the visible 0% pause.
        display_fraction = 0.10 + 0.90 * fraction
        overall = (float(file_index) + display_fraction) / float(max(1, total_files))
        def update():
            try:
                if self._repair_verify_progress is not None:
                    if getattr(self, "_repair_verify_indeterminate", False):
                        try:
                            self._repair_verify_progress.stop()
                            self._repair_verify_progress.configure(mode="determinate")
                        except Exception:
                            pass
                        self._repair_verify_indeterminate = False
                    self._set_repair_verify_progress_target(display_fraction)
                if self._repair_verify_stage is not None:
                    self._repair_verify_stage.configure(text="正在驗證：%s｜區段 %d / %d" % (filename, segment_index, segment_total))
                if self._repair_verify_range is not None:
                    self._repair_verify_range.configure(text="檢測範圍：%s → %s" % (self._timecode(start), self._timecode(end)))
                if self._repair_verify_detail is not None:
                    self._repair_verify_detail.configure(text="區段內：%s / %s｜只驗證已修正區段及前後安全緩衝" % (self._timecode(current), self._timecode(duration)))
            except Exception:
                pass
            self.progress.set(overall)
            self.status_var.set("正在驗證修復結果：%s｜區段 %d / %d｜%.1f%%" % (filename, segment_index, segment_total, display_fraction * 100.0))
        self.after(0, update)

    def _close_repair_verify_progress_window(self):
        try:
            if self._repair_verify_win is not None and self._repair_verify_win.winfo_exists():
                self._repair_verify_win.grab_release()
                self._repair_verify_win.destroy()
        except Exception:
            pass
        self._repair_verify_win = None
        self._repair_verify_progress = None
        self._repair_verify_percent = None
        self._repair_verify_stage = None
        self._repair_verify_range = None
        self._repair_verify_detail = None
        self._repair_verify_progress_polling = False
        self._repair_verify_progress_target = 0.0
        self._repair_verify_progress_display = 0.0

    def _stop_field_repair_export(self):
        """中止目前場序修復/驗證的 FFmpeg 工作。"""
        if not self.running or self.stop_requested:
            return

        self.stop_requested = True
        self.status_var.set("正在停止場序修復…")
        self.write_log("WARNING：收到停止指令，正在中止目前輸出／驗證。")

        for button_name in (
            "_repair_export_stop_button",
            "_repair_verify_stop_button",
        ):
            button = getattr(self, button_name, None)
            if button is not None:
                try:
                    button.configure(text=self._icon_text("stop", "正在停止…", "■"), state="disabled")
                except Exception:
                    pass

        self._request_stop_current_process()

    def _show_repair_export_progress_window(self):
        # 同一時間只允許一個匯出進度視窗。
        if self._repair_export_win is not None:
            try:
                if self._repair_export_win.winfo_exists():
                    self._repair_export_win.lift()
                    return
            except Exception:
                self._repair_export_win = None

        win = ctk.CTkToplevel(self)
        self._repair_export_win = win
        win.title("修復影片 — 匯出進度")
        win.geometry("620x430")
        win.minsize(560, 400)
        # 匯出進度視窗不做 modal child，讓 Windows 顯示桌面後可以正常還原。
        win.resizable(True, True)
        win.protocol("WM_DELETE_WINDOW", lambda: None)
        frame = ctk.CTkFrame(win)
        frame.pack(fill="both", expand=True, padx=18, pady=18)
        frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            frame,
            text=self._icon_text("clapper", "修復影片 — 匯出進度", "🎬"),
            image=self._ui_icon("clapper", (27, 27)),
            compound="left",
            font=ctk.CTkFont(size=23, weight="bold"),
        ).grid(
            row=0, column=0, padx=16, pady=(16, 10), sticky="w"
        )
        self._repair_export_file = ctk.CTkLabel(frame, text="準備輸出…", font=ctk.CTkFont(size=14))
        self._repair_export_file.grid(row=1, column=0, padx=16, pady=6, sticky="w")
        self._repair_export_progress = ctk.CTkProgressBar(frame, height=18)
        self._repair_export_progress.grid(row=2, column=0, padx=16, pady=10, sticky="ew")
        self._repair_export_progress.set(0)
        self._repair_export_percent = ctk.CTkLabel(frame, text="0.0%", font=ctk.CTkFont(size=18, weight="bold"))
        self._repair_export_percent.grid(row=3, column=0, padx=16, pady=4, sticky="w")
        self._repair_export_time = ctk.CTkLabel(frame, text="已處理：00:00:00.000 / 00:00:00.000")
        self._repair_export_time.grid(row=4, column=0, padx=16, pady=4, sticky="w")
        self._repair_export_speed = ctk.CTkLabel(frame, text="速度：--")
        self._repair_export_speed.grid(row=5, column=0, padx=16, pady=4, sticky="w")
        self._repair_export_eta = ctk.CTkLabel(frame, text="預估剩餘：--")
        self._repair_export_eta.grid(row=6, column=0, padx=16, pady=4, sticky="w")

        self._repair_export_stop_button = ctk.CTkButton(
            frame,
            text="停止輸出",
            height=40,
            command=self._stop_field_repair_export,
        )
        self._repair_export_stop_button.grid(
            row=7, column=0, padx=16, pady=(20, 18), sticky="ew"
        )
        # 非 modal：主程式與此進度視窗都可正常縮小、還原及最大化。

    @staticmethod
    def _format_elapsed(seconds):
        try:
            seconds = max(0.0, float(seconds))
        except Exception:
            seconds = 0.0
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = seconds % 60
        return "%02d:%02d:%06.3f" % (h, m, s)

    def _update_repair_export_progress(self, filename, duration, out_seconds, speed, wall_seconds, file_index, total_files):
        fraction = 0.0 if not duration else max(0.0, min(1.0, out_seconds / duration))
        overall = (float(file_index) + fraction) / float(max(1, total_files))
        def update():
            if self._repair_export_progress is not None:
                try:
                    self._repair_export_progress.set(fraction)
                    self._repair_export_percent.configure(text="%.1f%%" % (fraction * 100.0))
                    self._repair_export_time.configure(text="已處理：%s / %s" % (self._format_elapsed(out_seconds), self._format_elapsed(duration)))
                    self._repair_export_speed.configure(text="速度：%s" % (speed or "--"))
                    if fraction > 0.001 and wall_seconds > 0:
                        eta = max(0.0, wall_seconds * (1.0 - fraction) / fraction)
                        self._repair_export_eta.configure(text="預估剩餘：%s" % self._format_elapsed(eta))
                    else:
                        self._repair_export_eta.configure(text="預估剩餘：--")
                except Exception:
                    pass
            self.progress.set(overall)
            self.status_var.set("正在輸出：%s  %.1f%%" % (filename, fraction * 100.0))
        self.after(0, update)

    def _close_repair_export_progress_window(self):
        try:
            if self._repair_export_win is not None and self._repair_export_win.winfo_exists():
                self._repair_export_win.grab_release()
                self._repair_export_win.destroy()
        except Exception:
            pass
        self._repair_export_win = None
        self._repair_export_progress = None
        self._repair_export_percent = None
        self._repair_export_time = None
        self._repair_export_speed = None
        self._repair_export_eta = None
        self._repair_export_file = None

    def run_field_repair(self, confirmed_output_dir=None):
        items = list(self.repair_analysis_results)
        total = len(items)
        passed = 0
        self.write_log("")
        self.write_log(self._log_separator("="))
        self.write_log("[修復] 修復階段開始：使用已確認的分析結果，不重新分析")
        self.write_log("目標場次：%s" % self.repair_target.get())
        self.write_log("修復策略：%s" % self._field_repair_policy_text(self.repair_target.get()))
        self.write_log(self._log_separator("="))

        for index, item in enumerate(items):
            if self.stop_requested:
                break
            path = item["file"]
            # 原始分析結果不修改；修復時才依結果頁的 TFF/BFF/P checkbox
            # 與各自最低一致度建立本次 repair list。
            analysis = self._effective_repair_analysis(item.get("analysis") or {})
            result = {"file": path, "pass": False, "output": "", "anomalies": [], "error": ""}
            try:
                anomalies = (analysis or {}).get("anomalies") or []
                result["anomalies"] = anomalies
                if not self._analysis_needs_rebuild(analysis or {}):
                    result["pass"] = True
                    result["output"] = "（原片已符合目標場次，未修改）"
                    self.write_log("%s：無需修復" % os.path.basename(path))
                    passed += 1
                    continue

                # 輸出位置必須來自「分析完成後、使用者確認修復」時的選擇。
                # 不再在修復執行期間偷偷 fallback 到原片資料夾。
                out_dir = (confirmed_output_dir or "").strip()
                if not out_dir:
                    raise RuntimeError("未指定修復輸出資料夾。")
                if not os.path.isdir(out_dir):
                    os.makedirs(out_dir)
                output_path = self._repair_output_path_for_analysis(
                    path, out_dir, analysis
                )
                if os.path.abspath(output_path) == os.path.abspath(path):
                    raise RuntimeError("輸出檔案不能覆蓋原始影片。")

                output_abs = os.path.abspath(output_path)
                if os.path.exists(output_path) and not self._repair_overwrite_decisions.get(output_abs, False):
                    result["skipped"] = True
                    result["output"] = "（目的地已有同名影片，未同意取代，已略過）"
                    self.write_log("%s：已略過，不取代既有成品" % os.path.basename(path))
                    continue

                duration = float(analysis.get("duration") or 0.0)
                filename = os.path.basename(path)

                export_ready = threading.Event()
                def prepare_export_window():
                    self._close_repair_verify_progress_window()
                    self._show_repair_export_progress_window()
                    self._prepare_export_file(filename, duration)
                    export_ready.set()
                self.after(0, prepare_export_window)
                export_ready.wait(timeout=3.0)
                if self._is_progressive_to_hd25i(path, analysis):
                    # 告訴修復後驗證：這次是 Progressive -> HD 25i 格式轉換。
                    # 之後驗證必須以「結構場序」為第一層，idet 只作內容輔助。
                    analysis["_progressive_to_hd25i"] = True
                    src_probe = self._field_probe_info(path)
                    src_fps_log = float(src_probe.get("fps") or 0.0)
                    if src_fps_log <= 0.0:
                        src_fps_log = self._probe_video_fps(
                            path, normalize_fps(analysis.get("fps")) or 25.0
                        )
                    if 49.0 <= float(src_fps_log) <= 51.0:
                        temporal_note = "原生約 50p 直接組成 25i，不插幀"
                    else:
                        if self._progressive_repair_method_key() == "optical":
                            temporal_note = (
                                "%.3fp → 光流 / MCI 50p（含切鏡保護）→ 25i"
                                % float(src_fps_log)
                            )
                        else:
                            temporal_note = (
                                "%.3fp → 快速 50p 時間重取樣（含切鏡保護）→ 25i"
                                % float(src_fps_log)
                            )
                    self.write_log(
                        "Progressive → 1920x1080 25i %s：%s；"
                        "輸出 AVC-Intra 100 MXF（不是 HEVC MP4）。"
                        % (
                            normalize_repair_target(
                                analysis.get("target", self.repair_target.get())
                            ),
                            temporal_note,
                        )
                    )
                self.write_log("正在輸出修復成品：%s" % output_path)
                export_start = time.time()

                def progress_cb(key, value, wall_seconds):
                    out_seconds = 0.0
                    speed = ""
                    if key in ("out_time_ms", "out_time_us"):
                        try:
                            raw = float(value)
                            out_seconds = raw / 1000000.0
                        except Exception:
                            return
                        self._update_repair_export_progress(
                            filename, duration, out_seconds, speed, time.time() - export_start, index, total
                        )
                    elif key == "speed":
                        speed = value
                        # Keep the last timestamp; FFmpeg emits speed separately.
                        self._update_repair_export_progress(
                            filename, duration, out_seconds, speed, time.time() - export_start, index, total
                        )

                # Keep speed/time information across progress lines.
                last = {"out": 0.0, "speed": "", "frame": 0}
                def progress_cb(key, value, wall_seconds):
                    if key == "frame":
                        try:
                            last["frame"] = max(last["frame"], int(float(value)))
                        except Exception:
                            pass
                    elif key in ("out_time_ms", "out_time_us"):
                        try:
                            last["out"] = max(0.0, float(value) / 1000000.0)
                        except Exception:
                            pass
                    elif key == "speed":
                        last["speed"] = value
                    elif key == "progress" and value == "end":
                        last["out"] = duration
                    self._update_repair_export_progress(
                        filename, duration, last["out"], last["speed"], time.time() - export_start, index, total
                    )

                overwrite_output = bool(self._repair_overwrite_decisions.get(os.path.abspath(output_path), False))
                self._repair_video(path, analysis, output_path, progress_callback=progress_cb, overwrite=overwrite_output)
                # Save FFmpeg's real written-frame counter for fast post-export
                # integrity validation.  This is export evidence, not metadata.
                try:
                    analysis["_repair_export_frame_count"] = int(last.get("frame") or 0)
                except Exception:
                    analysis["_repair_export_frame_count"] = 0

                if self.stop_requested:
                    raise InterruptedError("使用者已停止輸出。")

                self.after(0, lambda f=filename, d=duration, i=index, t=total: self._update_repair_export_progress(f, d, d, "完成", time.time() - export_start, i, t))

                # 時間軸完整性是硬性保護，不能因使用者關閉「修復後場序驗證」而停用。
                # 關閉時只跳過較昂貴的場序內容重掃，仍必須檢查片長與實際 decoded frame count。
                if not self.repair_verify.get():
                    integrity_ok, integrity_message = self._verify_repair_timeline_integrity(
                        output_path, source_analysis=analysis
                    )
                    self.write_log("  %s" % integrity_message)
                    if not integrity_ok:
                        raise RuntimeError("修復後完整性驗證 FAIL：%s" % integrity_message)

                # 修復後不再完整重掃長影片；只驗證原先修正的區段及前後安全緩衝。
                if self.repair_verify.get():
                    # 匯出完成後先關閉匯出視窗，再切換到驗證視窗。
                    # 同一時間永遠只顯示一個進度視窗，避免重疊。
                    verify_ready = threading.Event()
                    def switch_to_verify():
                        self._close_repair_export_progress_window()
                        self._show_repair_verify_progress_window()
                        verify_ready.set()
                    self.after(0, switch_to_verify)
                    verify_ready.wait(timeout=3.0)
                    verify_start = time.time()
                    self._set_repair_verify_preflight_status(filename)
                    def verify_cb(frac, seg_idx, seg_total, a, b, current, seg_duration):
                        self._update_repair_verify_progress(
                            frac, index, total, seg_idx, seg_total, a, b,
                            current, seg_duration, filename
                        )
                    ok, verify_message = self._verify_repair_selective(
                        output_path, analysis.get("target", self.repair_target.get()),
                        source_analysis=analysis, progress_callback=verify_cb
                    )
                    if self.stop_requested:
                        raise InterruptedError("使用者已停止驗證。")
                    self.write_log("  %s" % verify_message)

                    # 驗證完成就收起視窗；下一個檔案需要時再開匯出視窗。
                    self.after(0, self._close_repair_verify_progress_window)

                    if not ok:
                        raise RuntimeError(verify_message)
                    self.write_log("  驗證耗時：%s" % self._format_elapsed(time.time() - verify_start))

                result["output"] = output_path
                result["pass"] = True
                passed += 1
                self.write_log("  結果：PASS")

                if not self.repair_verify.get():
                    self.after(0, self._close_repair_export_progress_window)
            except Exception as exc:
                if self.stop_requested or isinstance(exc, InterruptedError):
                    result["stopped"] = True
                    result["error"] = "使用者停止"
                    self.write_log("  結果：已停止")

                    # FFmpeg 中止時可能留下半成品；避免使用者誤拿去播放/QC。
                    try:
                        if output_path and os.path.isfile(output_path):
                            os.remove(output_path)
                            self.write_log("  已刪除未完成輸出：%s" % output_path)
                    except Exception as cleanup_exc:
                        self.write_log("  WARNING：未完成輸出無法刪除：%s" % cleanup_exc)
                else:
                    result["error"] = str(exc)
                    self.write_log("  結果：FAIL")
                    self.write_log("  ERROR：%s" % exc)
            finally:
                self.repair_results.append(result)

            if self.stop_requested:
                break

        stopped = bool(self.stop_requested)
        self.running = False

        fail_count = len([
            r for r in self.repair_results
            if not r.get("pass") and not r.get("stopped") and not r.get("skipped")
        ])

        self.write_log("")
        self.write_log(self._log_separator("="))
        if stopped:
            self.write_log(
                "場序重構已停止：PASS %d / FAIL %d / 已處理 %d / 總數 %d"
                % (passed, fail_count, len(self.repair_results), total)
            )
        else:
            self.write_log(
                "場序重構完成：總數 %d / PASS %d / FAIL %d"
                % (total, passed, fail_count)
            )
        self.write_log(self._log_separator("="))

        self.stop_requested = False
        self.after(0, lambda: self.start_button.configure(state="normal"))
        self.after(0, lambda: self.stop_button.configure(state="disabled"))
        self.after(0, lambda: self._close_repair_export_progress_window())
        self.after(0, lambda: self._close_repair_verify_progress_window())
        if stopped:
            self.after(0, lambda: self.status_var.set("場序重構已停止"))
        else:
            self.after(0, lambda: self.status_var.set(
                "場序重構完成：PASS %d / FAIL %d" % (passed, fail_count)
            ))

    def _prepare_export_file(self, filename, duration):
        if self._repair_export_file is not None:
            try:
                self._repair_export_file.configure(text="正在輸出：%s" % filename)
                self._repair_export_progress.set(0)
                self._repair_export_percent.configure(text="0.0%%")
                self._repair_export_time.configure(text="已處理：00:00:00.000 / %s" % self._format_elapsed(duration))
                self._repair_export_speed.configure(text="速度：--")
                self._repair_export_eta.configure(text="預估剩餘：--")
            except Exception:
                pass

    @staticmethod
    def _timecode_frames(seconds, fps):
        try:
            fps_i = max(1, int(round(float(fps))))
            total_frames = max(0, int(round(float(seconds) * float(fps))))
            frames = total_frames % fps_i
            total_seconds = total_frames // fps_i
            sec = total_seconds % 60
            total_minutes = total_seconds // 60
            minute = total_minutes % 60
            hour = total_minutes // 60
            return "%02d:%02d:%02d:%02d" % (hour, minute, sec, frames)
        except Exception:
            return "00:00:00:00"

    @staticmethod
    def _timecode(seconds):
        try:
            total_ms = int(round(float(seconds) * 1000.0))
        except Exception:
            return "00:00:00.000"
        ms = total_ms % 1000
        total_s = total_ms // 1000
        s = total_s % 60
        total_m = total_s // 60
        m = total_m % 60
        h = total_m // 60
        return "%02d:%02d:%02d.%03d" % (h, m, s, ms)

    # ------------------------------------------------------------------
    # Check
    # ------------------------------------------------------------------

    def stop_check(self):
        if not self.running:
            return

        self.stop_requested = True
        self.status_var.set("正在停止檢測…")
        self.write_log("WARNING：收到停止指令，將停止目前檢測。")

        self._request_stop_current_process()


    def start_check(self):

        if self.running:
            return

        if not self.selected_files:

            messagebox.showwarning(
                "提示",
                "請先選擇影片檔案或資料夾。"
            )

            return

        active = [
            name
            for name in OPTIONS
            if self.rule_enabled[name].get()
            and self.combos[name].get() != NO_CHECK
        ]

        if not active:

            messagebox.showwarning(
                "提示",
                "請至少啟用一個檢測項目，並選擇檢測標準。"
            )

            return

        if not get_mediainfo_path():

            messagebox.showerror(
                "MediaInfo",
                "找不到 MediaInfo.exe。\n\n"
                "請確認 MediaInfo.exe 位於 EXE 同目錄，"
                "或 _internal\\MediaInfo.exe。"
            )

            return

        bad_names = self._validate_filenames(
            self.selected_files
        )

        if bad_names:

            self.write_log(
                "WARNING：發現 %d 個檔案名稱含空格；檢測時將判定 FAIL。"
                % len(bad_names)
            )

            for bad_path in bad_names:

                self.write_log(
                    "  WARNING  File Name：%s"
                    % os.path.basename(
                        bad_path
                    )
                )

        self.running = True
        self.stop_requested = False
        self.failed = []
        self.results = []

        self.progress.set(
            0
        )

        self.start_button.configure(
            state="disabled"
        )
        self.stop_button.configure(
            state="normal"
        )

        self.write_log("")
        self.write_log(
            self._log_separator("=")
        )

        self.write_log(
            "%s v%s"
            % (
                APP_NAME,
                APP_VERSION
            )
        )

        self.write_log(
            "開始檢測：%s"
            % datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        )

        self.write_log(
            "檔案數量：%d"
            % len(
                self.selected_files
            )
        )

        self.write_log(
            "PASS = 通過    FAIL = 不符合    WARNING = 注意"
        )

        self.write_log(
            self._log_separator("=")
        )

        threading.Thread(
            target=self.run_check,
            daemon=True
        ).start()


    def run_check(self):
        files = list(self.selected_files)
        total = len(files)
        passed = 0
        processed = 0

        for index, path in enumerate(files):
            if self.stop_requested:
                break

            try:
                result = self.check_file(path)

                if self.stop_requested:
                    self.write_log("WARNING：已停止，目前檔案未計入結果：%s" % os.path.basename(path))
                    break

                self.results.append(result)
                processed += 1

                if result["pass"]:
                    passed += 1
                    self.write_log("  結果：PASS")
                else:
                    self.failed.append(path)
                    self.write_log("  結果：FAIL")

            except Exception as exc:
                if self.stop_requested:
                    self.write_log("WARNING：檢測已停止。")
                    break

                result = {
                    "file": path,
                    "pass": False,
                    "error": str(exc),
                    "checks": [],
                }
                self.results.append(result)
                processed += 1
                self.failed.append(path)
                self.write_log("  ERROR：%s" % exc)

            self.after(
                0,
                lambda p=float(index + 1) / float(total): self.progress.set(p)
            )

        stopped = self.stop_requested
        pass_files = [os.path.basename(result["file"]) for result in self.results if result.get("pass")]
        fail_files = [os.path.basename(result["file"]) for result in self.results if not result.get("pass")]

        self.write_log("")
        self.write_log(self._log_separator("="))
        if stopped:
            self.write_log(
                "已停止：已檢測 %d / %d / PASS %d / FAIL %d"
                % (processed, total, passed, len(self.failed))
            )
        else:
            self.write_log(
                "完成：總數 %d / PASS %d / FAIL %d"
                % (total, passed, len(self.failed))
            )

        # 結果摘要：直接列出 PASS / FAIL 檔案名稱，避免使用者需要向上捲動
        # 才能找出是哪一個影片失敗。
        self.write_log("")
        self.write_log("PASS 檔案：")
        if pass_files:
            for filename in pass_files:
                self.write_log("  ✓ %s" % filename)
        else:
            self.write_log("  （無）")

        self.write_log("FAIL 檔案：")
        if fail_files:
            for filename in fail_files:
                self.write_log("  ✗ %s" % filename)
        else:
            self.write_log("  （無）")

        self.write_log(self._log_separator("="))

        self.running = False
        self.stop_requested = False

        self.after(
            0,
            lambda: self.start_button.configure(state="normal")
        )
        self.after(
            0,
            lambda: self.stop_button.configure(state="disabled")
        )
        self.after(
            0,
            lambda: self.status_var.set(
                ("已停止：PASS %d / FAIL %d" if stopped else "完成：PASS %d / FAIL %d")
                % (passed, len(self.failed))
            )
        )


    def _format_check_line(
        self,
        status,
        name,
        actual,
        expected=None
    ):

        status_text = str(
            status
        ).upper()

        name_text = str(
            name
        )

        actual_text = (
            actual
            if actual
            else "(空)"
        )

        left = (
            "  %-6s %-26s │ %-34s"
            % (
                status_text,
                name_text,
                "實際：" + str(
                    actual_text
                ),
            )
        )

        if expected is not None:

            return (
                left
                + " │ 預期："
                + str(expected)
            )

        return left


    def check_file(
        self,
        path
    ):

        self.write_log("")

        self.write_log(
            "檔案：%s"
            % os.path.basename(path)
        )

        self.write_log(
            "路徑：%s"
            % path
        )

        checks = []
        overall = True

        # --------------------------------------------------------------
        # Filename
        # --------------------------------------------------------------

        filename = os.path.basename(
            path
        )

        filename_ok = not (
            self._filename_has_space(
                path
            )
        )

        checks.append(
            {
                "name": "File Name",
                "expected": "不能含空格",
                "actual": filename,
                "pass": filename_ok,
            }
        )

        if filename_ok:

            self.write_log(
                self._format_check_line(
                    "PASS",
                    "File Name",
                    filename
                )
            )

        else:

            overall = False

            self.write_log(
                self._format_check_line(
                    "FAIL",
                    "File Name",
                    filename,
                    "不能含空格"
                )
            )

        # --------------------------------------------------------------
        # IMPORTANT:
        # MediaInfo is called only ONCE here.
        # --------------------------------------------------------------

        data = self.read_media(
            path
        )

        # --------------------------------------------------------------
        # QC rules
        # --------------------------------------------------------------

        for name in OPTIONS:

            if not self.rule_enabled[name].get():
                continue

            expected = self.combos[name].get()

            if expected == NO_CHECK:
                continue

            ok, actual = self.compare_rule(
                name,
                expected,
                data
            )

            checks.append(
                {
                    "name": name,
                    "expected": expected,
                    "actual": actual,
                    "pass": ok,
                }
            )

            if ok:

                self.write_log(
                    self._format_check_line(
                        "PASS",
                        name,
                        actual
                    )
                )

            else:

                overall = False

                self.write_log(
                    self._format_check_line(
                        "FAIL",
                        name,
                        actual,
                        expected
                    )
                )

        return {
            "file": path,
            "pass": overall,
            "error": "",
            "checks": checks,
        }

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    def current_settings(self, rules_override=None, preset_name_override=None):

        if rules_override is None:
            rules = {
                name: {
                    "enabled": bool(
                        self.rule_enabled[name].get()
                    ),
                    "value": self.combos[name].get(),
                }
                for name in OPTIONS
            }
        else:
            rules = {}
            for name in OPTIONS:
                value = rules_override.get(name, NO_CHECK)
                if value not in OPTIONS[name]:
                    value = NO_CHECK
                rules[name] = {
                    "enabled": value != NO_CHECK,
                    "value": value,
                }

        return {
            "format": "MediaField QC Settings",
            "version": APP_VERSION,
            "saved_at": datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            ),
            "preset_name": (
                preset_name_override
                if preset_name_override is not None
                else self.preset_var.get()
            ),
            "rules": rules,
            # 同一個 JSON 同時保存使用者預設，這樣在另一台電腦
            # 或重新開啟程式後載入時，不會只剩下目前主畫面的參數。
            "user_presets": copy.deepcopy(self.user_presets),
            "field_repair": {
                "enabled": bool(self.repair_enabled.get()),
                "target": self.repair_target.get(),
                "min_seconds": self.repair_min_seconds.get(),
                "confidence": self.repair_confidence.get(),  # legacy hidden default; UI no longer exposes this field
                "output_dir": self.repair_output_dir.get(),
                "keep_original": bool(self.repair_keep_original.get()),
                "verify": bool(self.repair_verify.get()),
            },
            "hdr_gamut": {
                "target_spec": self.hdr_target_spec.get(),
                "min_issue_seconds": self.hdr_min_issue_seconds.get(),
            },
        }


    def save_settings(self, rules_override=None, preset_name_override=None):

        path = filedialog.asksaveasfilename(
            title="保存檢測設定",
            defaultextension=".json",
            initialfile="QC_Settings.json",
            filetypes=[
                ("JSON", "*.json"),
                ("All files", "*.*")
            ],
        )

        if not path:
            return

        try:

            payload = self.current_settings(
                rules_override=rules_override,
                preset_name_override=preset_name_override,
            )

            with open(
                path,
                "w",
                encoding="utf-8"
            ) as handle:

                json.dump(
                    payload,
                    handle,
                    ensure_ascii=False,
                    indent=2
                )

            self.write_log(
                "設定已保存：%s"
                % path
            )

            self.status_var.set(
                "設定已保存"
            )

        except Exception as exc:

            messagebox.showerror(
                "保存設定失敗",
                str(exc)
            )


    def load_settings(self):

        path = filedialog.askopenfilename(
            title="載入檢測設定",
            filetypes=[
                ("JSON", "*.json"),
                ("All files", "*.*")
            ],
        )

        if not path:
            return

        try:

            with open(
                path,
                "r",
                encoding="utf-8"
            ) as handle:

                settings = json.load(
                    handle
                )

            if not isinstance(settings, dict):
                raise ValueError("JSON 設定檔格式錯誤：最外層必須是物件。")

            # 新版 JSON 同時保存 user_presets；舊版 JSON 沒有此欄位時
            # 仍然完全相容，只載入其中的 rules。
            imported_presets = settings.get("user_presets")
            if isinstance(imported_presets, dict):
                cleaned_presets = {}
                for preset_name, preset in imported_presets.items():
                    if not isinstance(preset_name, str) or not preset_name.strip():
                        continue
                    if not isinstance(preset, dict):
                        continue

                    cleaned = {}
                    for name in OPTIONS:
                        value = preset.get(name, NO_CHECK)
                        if value not in OPTIONS[name]:
                            value = NO_CHECK
                        cleaned[name] = value

                    cleaned_presets[preset_name.strip()] = cleaned

                self.user_presets = cleaned_presets
                save_user_presets(self.user_presets)
                self._refresh_preset_combo(self.preset_var.get())

            rules = settings.get(
                "rules",
                {}
            )

            if not isinstance(rules, dict):
                raise ValueError("JSON 設定檔格式錯誤：rules 必須是物件。")

            for name in OPTIONS:

                item = rules.get(
                    name,
                    {}
                )

                if not isinstance(item, dict):
                    item = {}

                value = item.get(
                    "value",
                    NO_CHECK
                )

                if value not in OPTIONS[name]:
                    value = NO_CHECK

                enabled = bool(
                    item.get(
                        "enabled",
                        value != NO_CHECK
                    )
                )

                self.combos[name].set(
                    value
                )

                self.rule_enabled[name].set(
                    enabled
                    and value != NO_CHECK
                )

            field_repair = settings.get("field_repair", {})
            if isinstance(field_repair, dict):
                target = field_repair.get("target", self.repair_target.get())
                if target in ("Top Field First", "Bottom Field First", "Progressive"):
                    self.repair_target.set(target)
                self.repair_enabled.set(bool(field_repair.get("enabled", self.repair_enabled.get())))
                self.repair_min_seconds.set(str(field_repair.get("min_seconds", self.repair_min_seconds.get())))
                self.repair_confidence.set(str(field_repair.get("confidence", self.repair_confidence.get())))
                self.repair_output_dir.set(str(field_repair.get("output_dir", self.repair_output_dir.get()) or ""))
                self.repair_keep_original.set(bool(field_repair.get("keep_original", self.repair_keep_original.get())))
                self.repair_verify.set(bool(field_repair.get("verify", self.repair_verify.get())))

            hdr_gamut = settings.get("hdr_gamut", {})
            if isinstance(hdr_gamut, dict):
                hdr_target = hdr_gamut.get("target_spec", self.hdr_target_spec.get())
                if hdr_target in ("自動判斷", "BT.709 / SDR", "BT.2020", "BT.2020 / HLG", "BT.2020 / PQ"):
                    self.hdr_target_spec.set(hdr_target)
                self.hdr_min_issue_seconds.set(str(hdr_gamut.get("min_issue_seconds", self.hdr_min_issue_seconds.get())))

            saved_preset = settings.get(
                "preset_name",
                "自訂"
            )

            if saved_preset in self._preset_names():

                self.preset_var.set(
                    saved_preset
                )

            else:

                # 如果 JSON 中保存的是目前編輯中的「自訂」，仍然保持自訂；
                # 如果是不存在的名稱，則安全回到自訂。
                self.preset_var.set(
                    "自訂"
                )

            self._refresh_summary()

            # 如果載入動作是在「管理預設」視窗中進行，立即刷新左側列表
            # 及右側參數，避免要關閉視窗再重新開啟才看到新內容。
            refresh_callback = getattr(self, "_preset_manager_refresh", None)
            if callable(refresh_callback):
                try:
                    refresh_callback(self.preset_var.get())
                except Exception:
                    pass

            self.write_log(
                "設定已載入：%s"
                % path
            )

            self.status_var.set(
                "設定已載入"
            )

        except Exception as exc:

            messagebox.showerror(
                "載入設定失敗",
                "設定載入失敗：\n\n%s" % exc
            )

    # ------------------------------------------------------------------
    # Reports
    # ------------------------------------------------------------------

    def export_txt(self):

        if not self.results:

            messagebox.showinfo(
                "報告",
                "目前沒有檢測結果。"
            )

            return

        path = filedialog.asksaveasfilename(
            title="匯出 TXT 報告",
            defaultextension=".txt",
            initialfile="QC_Report.txt",
            filetypes=[
                ("Text", "*.txt"),
                ("All files", "*.*")
            ],
        )

        if not path:
            return

        try:

            with open(
                path,
                "w",
                encoding="utf-8"
            ) as handle:

                handle.write(
                    "%s v%s\n"
                    % (
                        APP_NAME,
                        APP_VERSION
                    )
                )

                handle.write(
                    "檢測時間：%s\n"
                    % datetime.now().strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                )

                handle.write(
                    "=" * 80
                    + "\n\n"
                )

                for result in self.results:

                    handle.write(
                        "檔案：%s\n"
                        % result["file"]
                    )

                    handle.write(
                        "結果：%s\n"
                        % (
                            "PASS"
                            if result["pass"]
                            else
                            "FAIL"
                        )
                    )

                    if result.get("error"):

                        handle.write(
                            "ERROR：%s\n"
                            % result["error"]
                        )

                    for item in result.get(
                        "checks",
                        []
                    ):

                        handle.write(
                            "  [%s] %s | 實際：%s | 預期：%s\n"
                            % (
                                "PASS"
                                if item["pass"]
                                else
                                "FAIL",
                                item["name"],
                                item["actual"]
                                or "(空)",
                                item["expected"],
                            )
                        )

                    handle.write(
                        "\n"
                    )

            self.write_log(
                "TXT 報告已輸出：%s"
                % path
            )

            self.status_var.set(
                "TXT 報告已輸出"
            )

        except Exception as exc:

            messagebox.showerror(
                "輸出失敗",
                str(exc)
            )


    def export_excel(self):

        if not self.results:
            messagebox.showinfo(
                "報告",
                "目前沒有檢測結果。"
            )
            return

        path = filedialog.asksaveasfilename(
            title="匯出 Excel QC 報告",
            defaultextension=".xlsx",
            initialfile="QC_Report.xlsx",
            filetypes=[
                ("Excel Workbook", "*.xlsx"),
                ("All files", "*.*")
            ],
        )

        if not path:
            return

        try:
            _write_xlsx_report(
                path,
                self.results,
                APP_VERSION,
            )

            self.write_log("Excel 報告已輸出：%s" % path)
            self.status_var.set("Excel 報告已輸出（檔案摘要 + 技術明細 + 需複核明細）")

        except Exception as exc:
            messagebox.showerror(
                "輸出失敗",
                "Excel 報告輸出失敗：\n\n%s" % exc
            )



    def manage_presets(self):
        """Open a reliable preset editor.

        The manager always loads the exact selected preset into the right-hand
        controls.  The built-in "自訂" represents the current main-panel
        settings when the manager opens; user presets are loaded from
        presets.json.  "自訂" can also be renamed by creating a user preset
        from its current settings.
        """
        if getattr(self, "_preset_manager_win", None) is not None:
            try:
                if self._preset_manager_win.winfo_exists():
                    self._preset_manager_win.lift()
                    self._preset_manager_win.focus_force()
                    return
            except Exception:
                pass

        win = ctk.CTkToplevel(self)
        self._preset_manager_win = win
        win.title("快速預設管理")
        win.geometry("980x780")
        win.minsize(820, 680)
        win.transient(self)

        def close_manager():
            try:
                if win.winfo_exists():
                    win.grab_release()
                    win.destroy()
            except Exception:
                pass
            self._preset_manager_win = None
            self._preset_manager_refresh = None

        win.protocol("WM_DELETE_WINDOW", close_manager)

        win.grid_columnconfigure(0, weight=0, minsize=270)
        win.grid_columnconfigure(1, weight=1)
        win.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(
            win,
            text=self._icon_text("gear", "快速預設管理", "⚙"),
            image=self._ui_icon("gear", (26, 26)),
            compound="left",
            font=ctk.CTkFont(size=25, weight="bold"),
        ).grid(row=0, column=0, columnspan=2, padx=24, pady=(20, 4), sticky="w")

        list_frame = ctk.CTkFrame(win, width=260)
        list_frame.grid(row=1, column=0, padx=(18, 8), pady=8, sticky="nsew")
        list_frame.grid_propagate(False)
        list_frame.grid_rowconfigure(1, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            list_frame, text="預設列表",
            font=ctk.CTkFont(size=16, weight="bold")
        ).grid(row=0, column=0, padx=12, pady=(12, 8), sticky="w")

        preset_list = tk.Listbox(
            list_frame,
            font=("Segoe UI", 16),
            bg="#2b2b2b", fg="#eeeeee",
            selectbackground="#1f6aa5", selectforeground="#ffffff",
            relief="flat", borderwidth=0, activestyle="none",
        )
        preset_list.grid(row=1, column=0, padx=10, pady=5, sticky="nsew")

        edit_frame = ctk.CTkFrame(win)
        edit_frame.grid(row=1, column=1, padx=(8, 18), pady=8, sticky="nsew")
        edit_frame.grid_columnconfigure(0, weight=1)
        edit_frame.grid_rowconfigure(2, weight=1)

        name_var = tk.StringVar(value="自訂")
        ctk.CTkLabel(
            edit_frame, text="預設名稱",
            font=ctk.CTkFont(size=14, weight="bold")
        ).grid(row=0, column=0, padx=16, pady=(14, 4), sticky="w")

        name_entry = ctk.CTkEntry(
            edit_frame, textvariable=name_var, height=40,
            font=ctk.CTkFont(size=14)
        )
        name_entry.grid(row=1, column=0, padx=16, pady=(0, 10), sticky="ew")

        rows_frame = ctk.CTkScrollableFrame(edit_frame)
        rows_frame.grid(row=2, column=0, padx=10, pady=5, sticky="nsew")
        rows_frame.grid_columnconfigure(1, weight=1)

        row_widgets = {}
        for row, parameter in enumerate(OPTIONS):
            ctk.CTkLabel(
                rows_frame, text=parameter,
                font=ctk.CTkFont(size=13), anchor="w"
            ).grid(row=row, column=0, padx=(8, 10), pady=5, sticky="w")

            combo = ScrollableCTkComboBox(
                rows_frame,
                values=OPTIONS[parameter],
                state="readonly",
                height=36,
                font=ctk.CTkFont(size=13),
            )
            combo.set(NO_CHECK)
            combo.grid(row=row, column=1, padx=(0, 8), pady=5, sticky="ew")
            row_widgets[parameter] = combo

        def current_editor_values():
            return {name: row_widgets[name].get() for name in OPTIONS}

        def load_into_editor(name):
            """Load the selected preset, including every checkbox/value pair."""
            if name == "自訂":
                # "自訂" means the current main-panel state, not a blank preset.
                values = {n: self.combos[n].get() for n in OPTIONS}
            else:
                values = self.user_presets.get(name, {})

            name_var.set(name)
            for parameter in OPTIONS:
                value = values.get(parameter, NO_CHECK)
                if value not in OPTIONS[parameter]:
                    value = NO_CHECK
                row_widgets[parameter].set(value)

        def refresh_list(select_name=None):
            names = self._preset_names()
            preset_list.delete(0, "end")
            for preset_name in names:
                marker = "  [內建]" if preset_name == "自訂" else "  [自訂]"
                preset_list.insert("end", preset_name + marker)

            if not names:
                return

            if select_name not in names:
                select_name = self.preset_var.get() if self.preset_var.get() in names else names[0]
            idx = names.index(select_name)
            preset_list.selection_clear(0, "end")
            preset_list.selection_set(idx)
            preset_list.see(idx)
            load_into_editor(select_name)

        def on_list_select(event=None):
            selection = preset_list.curselection()
            if not selection:
                return
            names = self._preset_names()
            idx = selection[0]
            if 0 <= idx < len(names):
                load_into_editor(names[idx])

        preset_list.bind("<<ListboxSelect>>", on_list_select)

        def save_new():
            name = name_var.get().strip()
            if not name:
                messagebox.showwarning("預設", "請輸入預設名稱。", parent=win)
                return
            if name == "自訂" or name in self.user_presets:
                messagebox.showwarning("預設", "名稱已存在，請使用其他名稱。", parent=win)
                return

            self.user_presets[name] = current_editor_values()
            save_user_presets(self.user_presets)
            self._refresh_preset_combo(name)
            self.preset_var.set(name)
            refresh_list(name)
            self.status_var.set("已建立預設：%s" % name)

        def update_current():
            selection = preset_list.curselection()
            names = self._preset_names()
            current_name = names[selection[0]] if selection and selection[0] < len(names) else name_var.get().strip()

            if current_name == "自訂":
                # Persist the current custom settings as a named user preset only
                # when the user gives it a different name.
                target = name_var.get().strip()
                if target == "自訂" or not target:
                    messagebox.showinfo(
                        "自訂預設",
                        "「自訂」是目前主面板的即時設定。\n\n如果要保存成可重複使用的預設，請輸入新的名稱後按「另存新預設」或「改名」。",
                        parent=win,
                    )
                    return
                if target in self.user_presets:
                    messagebox.showwarning("預設", "名稱已存在，請使用其他名稱。", parent=win)
                    return
                self.user_presets[target] = current_editor_values()
                save_user_presets(self.user_presets)
                self._refresh_preset_combo(target)
                self.preset_var.set(target)
                refresh_list(target)
                self.status_var.set("已建立預設：%s" % target)
                return

            self.user_presets[current_name] = current_editor_values()
            save_user_presets(self.user_presets)
            self._refresh_preset_combo(current_name)
            self.preset_var.set(current_name)
            refresh_list(current_name)
            self.status_var.set("已更新預設：%s" % current_name)

        def rename_current():
            selection = preset_list.curselection()
            names = self._preset_names()
            old_name = names[selection[0]] if selection and selection[0] < len(names) else name_var.get().strip()
            new_name = name_var.get().strip()

            if not new_name:
                messagebox.showwarning("預設", "請輸入新的預設名稱。", parent=win)
                return
            if old_name == new_name:
                return
            if new_name in self.user_presets:
                messagebox.showwarning("預設", "新的名稱已存在。", parent=win)
                return

            if old_name == "自訂":
                # Built-in 自訂 itself remains the default entry.  Renaming it
                # creates a real user preset from the currently displayed values.
                self.user_presets[new_name] = current_editor_values()
            else:
                if old_name not in self.user_presets:
                    return
                self.user_presets[new_name] = self.user_presets.pop(old_name)

            save_user_presets(self.user_presets)
            self._refresh_preset_combo(new_name)
            self.preset_var.set(new_name)
            refresh_list(new_name)
            self.status_var.set("已建立/改名預設：%s" % new_name)

        def delete_current():
            selection = preset_list.curselection()
            names = self._preset_names()
            if not selection or selection[0] >= len(names):
                return
            name = names[selection[0]]
            if name == "自訂":
                messagebox.showinfo("內建預設", "「自訂」是內建預設，不能刪除。", parent=win)
                return
            if messagebox.askyesno("刪除預設", "確定刪除「%s」？" % name, parent=win):
                self.user_presets.pop(name, None)
                save_user_presets(self.user_presets)
                self._refresh_preset_combo("自訂")
                self.preset_var.set("自訂")
                refresh_list("自訂")
                self.status_var.set("已刪除預設：%s" % name)

        # 讓主畫面的「載入設定」在管理視窗開啟期間也能即時刷新管理器。
        self._preset_manager_refresh = refresh_list

        def apply_current():
            selection = preset_list.curselection()
            names = self._preset_names()
            selected_name = names[selection[0]] if selection and selection[0] < len(names) else name_var.get().strip()
            values = current_editor_values()

            self._set_rules_from_preset(values)
            self.preset_var.set(selected_name if selected_name in self._preset_names() else "自訂")
            self._refresh_summary()
            self.status_var.set("已套用預設：%s" % self.preset_var.get())
            self.write_log("已套用預設：%s" % self.preset_var.get())

        button_bar = ctk.CTkFrame(edit_frame, fg_color="transparent")
        button_bar.grid(row=3, column=0, padx=12, pady=(8, 14), sticky="ew")
        for i in range(5):
            button_bar.grid_columnconfigure(i, weight=1)

        buttons = [
            ("套用到主畫面", apply_current),
            ("＋ 另存新預設", save_new),
            ("更新目前預設", update_current),
            ("改名", rename_current),
            ("刪除", delete_current),
        ]
        for i, (text, command) in enumerate(buttons):
            ctk.CTkButton(button_bar, text=text, height=40, command=command).grid(
                row=0, column=i, padx=3, sticky="ew"
            )

        io_bar = ctk.CTkFrame(edit_frame, fg_color="transparent")
        io_bar.grid(row=4, column=0, padx=12, pady=(0, 8), sticky="ew")
        for i in range(3):
            io_bar.grid_columnconfigure(i, weight=1)
        def save_manager_settings():
            # 管理器右側正在編輯的內容就是這次 JSON 匯出的內容。
            # 如果正在編輯的是既有使用者預設，同步更新它，確保
            # 「保存設定 → 載入設定」後右側參數與預設名稱完全一致。
            manager_name = name_var.get().strip() or "自訂"
            manager_values = current_editor_values()

            if manager_name != "自訂" and manager_name in self.user_presets:
                self.user_presets[manager_name] = dict(manager_values)
                save_user_presets(self.user_presets)

            self.save_settings(
                rules_override=manager_values,
                preset_name_override=manager_name,
            )

        ctk.CTkButton(
            io_bar,
            text=self._icon_text("save", "保存設定", "💾"),
            image=self._ui_icon("save", (18, 18)),
            compound="left",
            height=38,
            command=save_manager_settings,
        ).grid(row=0, column=0, padx=3, sticky="ew")
        ctk.CTkButton(
            io_bar,
            text=self._icon_text("folder_open", "載入設定", "📂"),
            image=self._ui_icon("folder_open", (18, 18)),
            compound="left",
            height=38,
            command=self.load_settings,
        ).grid(row=0, column=1, padx=3, sticky="ew")
        ctk.CTkButton(io_bar, text="關閉", height=38, command=close_manager).grid(row=0, column=2, padx=3, sticky="ew")

        refresh_list(self.preset_var.get())
        try:
            win.grab_set()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # About
    # ------------------------------------------------------------------

    def show_about(self):
        win = ctk.CTkToplevel(self)
        win.title("關於 " + APP_NAME)
        win.resizable(False, False)
        win.transient(self)

        # About window: compact near-square size.  Final placement is done
        # after all widgets are created so Windows cannot override geometry
        # while the Toplevel is still being mapped.
        about_w, about_h = 560, 520
        win.withdraw()
        win.geometry("%dx%d" % (about_w, about_h))
        win.minsize(about_w, about_h)
        win.maxsize(about_w, about_h)

        ctk.CTkLabel(
            win, text=APP_NAME,
            font=ctk.CTkFont(size=34, weight="bold")
        ).pack(pady=(28, 6))

        ctk.CTkLabel(
            win, text="Version %s" % APP_VERSION,
            font=ctk.CTkFont(size=22)
        ).pack(pady=(0, 32))

        ctk.CTkLabel(
            win, text="Professional Video Quality Checker",
            font=ctk.CTkFont(size=20)
        ).pack(pady=(0, 22))

        ctk.CTkLabel(
            win,
            text="Developer：%s\nInternal Tool" % DEVELOPER,
            justify="center",
            font=ctk.CTkFont(size=18),
        ).pack(pady=(0, 28))

        ctk.CTkLabel(
            win,
            text="Supported Windows:\nWindows 7 / Windows 10 / Windows 11",
            justify="center",
            font=ctk.CTkFont(size=18),
        ).pack(pady=(0, 28))

        ctk.CTkLabel(
            win,
            text="檢測規格由使用者在主面板選擇。\n"
                 "本軟件只專注於檢測MXF檔案而開發。\n"
                 "軟件只供內部使用,未經作者允許不得轉發。",
            justify="center",
            font=ctk.CTkFont(size=16),
        ).pack(pady=(0, 42))

        ctk.CTkButton(
            win, text="關閉", width=180, height=44, command=win.destroy
        ).pack()

        # Show the completed dialog first, then centre the actual native
        # top-level HWND over the actual native main-window HWND.  We move the
        # window only; its Tk-requested size remains unchanged.  This avoids
        # DPI scaling errors caused by mixing Tk logical pixels with Win32
        # physical pixels.
        win.update_idletasks()
        win.deiconify()
        win.update_idletasks()

        positioned = False
        if os.name == "nt":
            try:
                import ctypes

                class RECT(ctypes.Structure):
                    _fields_ = [
                        ("left", ctypes.c_long),
                        ("top", ctypes.c_long),
                        ("right", ctypes.c_long),
                        ("bottom", ctypes.c_long),
                    ]

                user32 = ctypes.windll.user32
                GA_ROOT = 2

                child_hwnd = user32.GetAncestor(win.winfo_id(), GA_ROOT)
                parent_hwnd = user32.GetAncestor(self.winfo_id(), GA_ROOT)

                if child_hwnd and parent_hwnd:
                    child_rect = RECT()
                    parent_rect = RECT()

                    ok_child = user32.GetWindowRect(
                        child_hwnd,
                        ctypes.byref(child_rect),
                    )
                    ok_parent = user32.GetWindowRect(
                        parent_hwnd,
                        ctypes.byref(parent_rect),
                    )

                    if ok_child and ok_parent:
                        child_w = child_rect.right - child_rect.left
                        child_h = child_rect.bottom - child_rect.top
                        parent_w = parent_rect.right - parent_rect.left
                        parent_h = parent_rect.bottom - parent_rect.top

                        x = parent_rect.left + (parent_w - child_w) // 2
                        y = parent_rect.top + (parent_h - child_h) // 2

                        SWP_NOSIZE = 0x0001
                        SWP_NOZORDER = 0x0004
                        SWP_NOACTIVATE = 0x0010
                        user32.SetWindowPos(
                            child_hwnd,
                            0,
                            int(x),
                            int(y),
                            0,
                            0,
                            SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE,
                        )
                        positioned = True
            except Exception:
                positioned = False

        # Safe fallback: centre over the current main Tk window.
        if not positioned:
            self.update_idletasks()
            win.update_idletasks()
            child_w = int(win.winfo_width())
            child_h = int(win.winfo_height())
            parent_x = int(self.winfo_rootx())
            parent_y = int(self.winfo_rooty())
            parent_w = int(self.winfo_width())
            parent_h = int(self.winfo_height())
            center_x = parent_x + (parent_w - child_w) // 2
            center_y = parent_y + (parent_h - child_h) // 2
            win.geometry("+%d+%d" % (center_x, center_y))

        win.lift()
        win.focus_force()
        win.grab_set()


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------

if __name__ == "__main__":

    app = QCCheckerApp()

    app.mainloop()


# MediaField QC v1.2.1 — field-order repair policy:
# Original source is never overwritten.
# Exported repair files are protected by automatic duration/frame/field-order verification where applicable.
# Output folder is selected only after analysis is complete and repair is confirmed.
