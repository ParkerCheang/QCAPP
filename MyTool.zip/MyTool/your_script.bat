﻿@echo off
setlocal EnableExtensions EnableDelayedExpansion
title MXF QC Checker Pro - Build

REM ============================================================
REM MXF QC Checker Pro
REM Build script for Windows 7 / Windows 10 / Windows 11
REM
REM Files expected beside this BAT:
REM   main.py
REM   MediaInfo.exe
REM
REM Optional:
REM   icon.ico
REM
REM Output:
REM   dist\MXF_QC_Checker_Pro\
REM ============================================================

cd /d "%~dp0"

echo.
echo ============================================================
echo          MXF QC Checker Pro - BUILD
echo ============================================================
echo.
echo Working directory:
echo %CD%
echo.

REM Check Python
where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found.
    pause
    exit /b 1
)

python --version
if errorlevel 1 (
    echo [ERROR] Python cannot be executed.
    pause
    exit /b 1
)

REM Check main.py
if not exist "main.py" (
    echo [ERROR] main.py was not found beside this BAT.
    pause
    exit /b 1
)
echo [OK] main.py found.

REM Check MediaInfo.exe
if not exist "MediaInfo.exe" (
    echo [ERROR] MediaInfo.exe was not found beside this BAT.
    pause
    exit /b 1
)
echo [OK] MediaInfo.exe found.

REM Optional icon
if exist "icon.ico" (
    set "ICON_ARG=--icon=icon.ico"
    echo [OK] icon.ico found.
) else (
    set "ICON_ARG="
    echo [INFO] icon.ico not found - building without custom icon.
)

echo.
echo ============================================================
echo Checking required Python packages...
echo ============================================================
echo.

python -c "import customtkinter" >nul 2>nul
if errorlevel 1 (
    echo [INFO] Installing customtkinter...
    python -m pip install customtkinter
    if errorlevel 1 (
        echo [ERROR] Failed to install customtkinter.
        pause
        exit /b 1
    )
)

python -c "import PyInstaller" >nul 2>nul
if errorlevel 1 (
    echo [INFO] Installing PyInstaller...
    python -m pip install pyinstaller
    if errorlevel 1 (
        echo [ERROR] Failed to install PyInstaller.
        pause
        exit /b 1
    )
)

echo [OK] Required packages are available.
echo.

REM Clean previous build
echo ============================================================
echo Cleaning previous build...
echo ============================================================
echo.

if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist "MXF_QC_Checker_Pro.spec" del /q "MXF_QC_Checker_Pro.spec"

echo [OK] Old build files removed.
echo.

REM Build ONEDIR package
echo ============================================================
echo Running PyInstaller...
echo ============================================================
echo.

python -m PyInstaller ^
    --noconfirm ^
    --clean ^
    --onedir ^
    --windowed ^
    --name "MXF_QC_Checker_Pro" ^
    %ICON_ARG% ^
    --collect-all customtkinter ^
    main.py

if errorlevel 1 (
    echo.
    echo ============================================================
    echo [ERROR] PyInstaller build failed.
    echo ============================================================
    pause
    exit /b 1
)

echo.
echo [OK] PyInstaller build completed.
echo.

REM Put MediaInfo in _internal
echo ============================================================
echo Copying MediaInfo.exe...
echo ============================================================
echo.

if not exist "dist\MXF_QC_Checker_Pro\_internal" (
    mkdir "dist\MXF_QC_Checker_Pro\_internal"
)

copy /y "MediaInfo.exe" "dist\MXF_QC_Checker_Pro\_internal\MediaInfo.exe" >nul

if errorlevel 1 (
    echo [ERROR] Failed to copy MediaInfo.exe.
    pause
    exit /b 1
)

echo [OK] MediaInfo.exe copied.
echo.

REM Optional files
if exist "presets.json" (
    copy /y "presets.json" "dist\MXF_QC_Checker_Pro\" >nul
    echo [OK] presets.json copied.
)

if exist "qc_rules.json" (
    copy /y "qc_rules.json" "dist\MXF_QC_Checker_Pro\" >nul
    echo [OK] qc_rules.json copied.
)

if exist "README.txt" (
    copy /y "README.txt" "dist\MXF_QC_Checker_Pro\" >nul
    echo [OK] README.txt copied.
)

REM Create launcher
(
echo @echo off
echo cd /d "%%~dp0"
echo start "" "MXF_QC_Checker_Pro.exe"
) > "dist\MXF_QC_Checker_Pro\Start_MXF_QC.bat"

echo [OK] Start_MXF_QC.bat created.
echo.

REM Final verification
if not exist "dist\MXF_QC_Checker_Pro\MXF_QC_Checker_Pro.exe" (
    echo [ERROR] Final EXE was not found.
    pause
    exit /b 1
)

if not exist "dist\MXF_QC_Checker_Pro\_internal\MediaInfo.exe" (
    echo [ERROR] MediaInfo.exe was not found in final package.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo                 BUILD SUCCESS
echo ============================================================
echo.
echo Output:
echo %CD%\dist\MXF_QC_Checker_Pro\
echo.
echo EXE:
echo %CD%\dist\MXF_QC_Checker_Pro\MXF_QC_Checker_Pro.exe
echo.
echo MediaInfo:
echo %CD%\dist\MXF_QC_Checker_Pro\_internal\MediaInfo.exe
echo.
echo ============================================================
echo.
echo IMPORTANT:
echo Keep the entire MXF_QC_Checker_Pro folder together.
echo Do NOT copy only the EXE.
echo.
pause
exit /b 0
