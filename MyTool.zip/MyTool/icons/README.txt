MediaField QC Emoji Icon Pack

用途：
把目前 Python 介面中使用的 Emoji / 符號，改成 PNG 圖示，以提高 Windows 7/10/11 的一致性。

建議做法：
1. 解壓成專案內的 icon/ 或 icons/ 資料夾。
2. Python 介面改為優先載入 PNG 圖示。
3. 若找不到圖示，保留原本文字作 fallback，避免影響現有穩定性。
4. GitHub 打包時，把整個 icons 資料夾一起打包進 EXE。

內容：
- 96x96 PNG
- 透明背景
- 統一深色 UI 適用風格
